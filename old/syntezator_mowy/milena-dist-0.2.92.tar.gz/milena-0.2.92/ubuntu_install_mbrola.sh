#!/bin/bash
echo skrypt jest nieaktualny i nic nie robi
exit 1

umask 0022
ARCH=`uname -m`
url="http://tcts.fpms.ac.be/synthesis/mbrola/bin/pclinux/mbr301h.zip"
name=mbrola-linux-i386
if [ "$ARCH" = "x86_64" ] ; then
url="http://tcts.fpms.ac.be/synthesis/mbrola/bin/amd64linux/mbrola.zip"
name=mbrola
fi

if ! which mbrola >/dev/null 2>/dev/null ; then
	if [ ! -f mbr301h.zip ] ; then 
		wget -O mbr301h.zip $url || exit 1
	fi
	unzip mbr301h.zip $name
	sudo mv $name /usr/bin/mbrola
fi

if [ ! -f pl1.zip ] ; then
	wget -O pl1.zip http://tcts.fpms.ac.be/synthesis/mbrola/dba/pl1/pl1.zip || exit 1
fi


sudo mkdir -p /usr/share/mbrola/pl1
sudo unzip -d /usr/share/mbrola/pl1 -o pl1.zip
