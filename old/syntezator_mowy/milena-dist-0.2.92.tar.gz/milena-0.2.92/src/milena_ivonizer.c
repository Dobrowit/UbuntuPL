static int _milena_ivonizer(int mode,char *inbuf,char *outbuf,int outlen,struct milena *milena,int widechar)
{

	static int _px[]={
	    160,260,728,321,164,317,346,167,168,352,350,356,377,173,381,
	    379,176,261,731,322,180,318,347,711,184,353,351,357,378,733,
	    382,380,340,193,194,258,196,313,262,199,268,201,280,203,282,
	    205,206,270,272,323,327,211,212,336,214,215,344,366,218,368,
	    220,221,354,223,341,225,226,259,228,314,263,231,269,233,281,
	    235,283,237,238,271,273,324,328,243,244,337,246,247,345,367,
	    250,369,252,253,355,729};

	struct word {
		char *str;
		int flags;
		int stres;
		int strespos;
		int schwa;
	} *words=NULL;
	
	int in_word=0;
	int word_count=0;
	int flags=0,stres=0;
	int pass;
	char *str,*scopy;
	int pos,inipos,ops;

#define sh_outbuf ((unsigned short *)outbuf)

	int _trans(int znak)
	{
	    znak &= 255;
	    if (znak <= 160) return znak;
	    return _px[znak-160];
	}
	
	int outbuflen(char *c)
	{
	    if (!widechar) {
		return strlen(c);
	    }
	    else {
		int i=0;
		short *z=(short *)c;
		while (*z++) i++;
		return i;
	    }
	}
	
	if (outbuf) {
		pos=inipos=outbuflen(outbuf);
	}
	else {
		pos=outlen=0;
	}
	
	void add_outbuf_char(int znak)
	{
		if (pos<outlen) {
		    if (!widechar) {
			outbuf[pos]=znak;
		    }
		    else {
			((short *)outbuf)[pos]=_trans(znak);
		    }
		}
		pos++;
	}
	
	void set_outbuf_char(int p,int znak)
	{
		if (p<outlen) {
		    if (!widechar) {
			outbuf[p]=znak;
		    }
		    else {
			((short *)outbuf)[p]=_trans(znak);
		    }
		}
	}
	
	void add_outbuf_str(char *str)
	{
		while (*str) add_outbuf_char(*str++);
	}
	int scmp(char *s)
	{
	    int i;
	    static char *smg="eaiouy\xf3\xb1\xea";
	    char *c;
	    for (i=ops;i<pos;i++,s++) {
		if (!*s) return 0;
		if (*s == '@') {
		    if (widechar) {
			for (c=smg;*c;c++) if (sh_outbuf[i] == _trans(*c)) break;
			if (!*c) return 0;
		    }
		    else {
			if (!strchr(smg,outbuf[i])) return 0;
		    }
		    continue;
		}
		if (widechar) {
		    if (sh_outbuf[i] != _trans(*s)) return 0;
		}
		else {
		    if (outbuf[i] != *s) return 0;
		}
	    }
	    if (*s) return 0;
	    return 1;
	}
	
	scopy=dupstr(inbuf);
	for (pass=0;pass<2;pass++) {
		str=scopy;
		word_count=0;
		in_word=0;
		flags=0;
		stres=0;
		for (;;str++) {
			if (!*str) break;
			if (isspace(*str)) {
				if (in_word) {
					if (words) *str=0;
					in_word=0;
					flags=0;
					stres=0;
				}
				continue;
			}
			if (*str=='[') {
				if (in_word) {
					if (words)*str=0;
					in_word=0;
					flags=0;
					stres=0;
				}
				str++;
				for (;*str && *str != ']';str++) {
					if (*str=='-' || *str=='+') {
						if (str[1] && isdigit(str[1])) {
							str++;
						}
						continue;
					}
					if (isdigit(*str)) {
						stres=(*str)-'0';
					}
					else if (*str == 'k') {
						flags |= 1;
					}
				}
				if (!*str) break;
				continue;
			}
			if (*str=='{') {
				if (in_word) {
					if (words) *str=0;
					in_word=0;
					flags=0;
					stres=0;
				}
				char *c=strchr(str+1,'}');
				if (c) str=c;
				else break;
				continue;
			}
			if (!in_word) {
				if (words) {
					words[word_count].str=str;
					words[word_count].flags=flags;
					words[word_count].stres=stres;
					words[word_count].schwa=-1;
				}
				word_count++;
				in_word=1;
			}
		}
		if (!word_count) return -1;
		if (!words) words=calloc(word_count+1,sizeof(struct word));
	}
	int i,keep,started;
	for (i=0,keep=0,started=0;i<word_count;i++) {
		char *c,*d,lastvo=0;
		for (c=d=words[i].str;*c;) {
			if (*c=='~') {
				if (c[1]==',') {
					c+=2;
					continue;
				}
				if (c[1]=='+' || c[1]=='\'') {
					//if (c[2]) {
						*d++='~';
						*d++='\'';
					//}
					c+=2;
					continue;
				}
				if (c[1]=='!') {
					if (c[2]) {
						*d++='~';
						*d++='!';
						words[i].stres=0;
					}
					c+=2;
					continue;
				}
				c+=2;
				continue;
			}
			if (*c=='@') {
				words[i].schwa=d-words[i].str;
				if (lastvo == 'e') *d++='y';
				else *d++='e';
				c++;
			}
			else if (*c=='&') {
				c++;
			}
			else {
				if (strchr("eaiouy\xf3\xb1\xea",*c)) {
				    if ((*c & 255) == 0xb1) lastvo='e';
				    else lastvo=*c;
				}
				*d++=*c++;
			}
		}
		*d=0;
		if (!words[i].stres && words[i].schwa>0) {
		    words[i].stres=2;
		}
		if (words[i].stres) {
			char *c=words[i].str;
			int nl=strlen(c);
			int j,cs;
			cs=0;
			for (j=nl-1;j>=0;j--) {
				if (strchr("eaiouy\xf3\xb1\xea",c[j])) {
					if (c[j]=='i' && strchr("eaou\xf3\xb1\xea",c[j+1])) continue;
					if (cs == words[i].stres-1 && j == words[i].schwa) {
					    words[i].stres++;
					}
					if (cs == words[i].stres) {
					    words[i].strespos=j+1;
					    break;
					}
					cs++;
				}
				if (!j) {
					words[i].strespos=0;
					break;
				}
			}
		}
		if (pos) {
			if (keep) add_outbuf_str("~'");
			else add_outbuf_char(' ');
		}
		started=1;
		keep=words[i].flags & 1;
		int j;
		c=words[i].str;
		for (j=0;c[j];j++) {
			if (words[i].stres && words[i].stres != 2 && words[i].strespos == j) {
				add_outbuf_str("~!");
			}
			if (c[j] == '_') {
				if (c[j+1]) add_outbuf_str("~'");
			}
			else {
				add_outbuf_char(c[j]);
			}
		}
	}
	if (milena && (mode & 7) == 0 && pos < outlen-1 && outbuf) {
	    struct milena_fin *ms;
	    int is_set=0;
	    for (ms=milena->ivona_fin;ms;ms=ms->next) {
		if (ms->mode != 4) continue;
		ops=pos-strlen(ms->string);
		if (ops < inipos) continue;
		if (!scmp(ms->string)) continue;
		mode = ms->mode | (mode & 0xf8);
		is_set=1;
		break;
	    }
	    if (!is_set) {
		ops=pos;
		while (ops > inipos) {
		    if (widechar) {
			if(sh_outbuf[ops-1] <128 && (!lci[sh_outbuf[ops-1]] || isdigit(sh_outbuf[ops-1]))) {
			    break;
			}
		    }
		    else {
			if (!lci[outbuf[ops-1] & 255] || isdigit(outbuf[ops-1])) {
			    break;
			}
		    }
		    ops--;
		}
		if (ops < pos) {
		    for (ms=milena->ivona_fin;ms;ms=ms->next) {
			if (scmp(ms->string)) {
			    mode=ms->mode | (mode & 0xf8);
			    break;
			}
		    }
		}
	    }
	}
	else if (!milena && (mode & 7) == 0) {
	    // default: wszystkie kropki na końcu zdania na wykrzykniki
	    mode=3 | (mode & 0xf8);
	}
	add_outbuf_char(".,?!:,,,"[mode & 7]);
	add_outbuf_char(0);
	free(words);
	free(scopy);
	if (pos > outlen) {
		if (outbuf) outbuf[inipos]=0;
		return pos;
	}
	// od inipos do pos-4 trzeba by sprawdzić podwójne ~'
	/*
	for (i=j=inipos;i<pos;i++) {
	    
	    if (i<pos-4 && !strncmp(outbuf+i,"~'~'",4)) {
		if (outbuf_sh[i] == '~' && outbuf_sh[i+1]=='\'' && outbuf_sh[i+2] == '~' && outbuf_sh[i+3]=='\'')
		i+=1;
		continue;
	    }
	    outbuf[j++]=outbuf[i];
	}
	pos=j;
	* 
	*/
	
	return 0;
	//return (pos>outlen)?pos:0;
}

int milena_ivonizer(int mode,char *inbuf,char *outbuf,int outlen)
{
    return _milena_ivonizer(mode,inbuf,outbuf,outlen,NULL,0);
}
int milena_ivonizer_n(int mode,char *inbuf,char *outbuf,int outlen,struct milena *milena)
{
    return _milena_ivonizer(mode,inbuf,outbuf,outlen,milena,0);
}
    
int milena_ReadIvonaFin(struct milena *cfg,char *fname)
{
    char buf[512],*s,*c;
    FILE *f;
    struct milena_fin *ms;
    int mode;
    cfg->input_line=0;
    f=fopen(fname,"rb");
    if (!f) {
//	    perror(fname);
	    return 0;
    }
    while(fgets(buf,256,f)) {
	cfg->input_line++;
	s=strstr(buf,"//");
	if (s) *s=0;
	s=buf;
	while (*s && isspace(*s)) s++;
	mode=3;
	if (*s==':') {
	    s++;mode=4;
	}
	if (!*s) continue;
	c=s;
	while (*c && !isspace(*c)) c++;
	if (*c) *c=0;
	ms=qalloc(sizeof(*ms));
	ms->next=cfg->ivona_fin;
	ms->mode=mode;
	cfg->ivona_fin=ms;
	ms->string=strdup(s);
    }
    fclose(f);
    return 1;
}
#undef sh_outbuf
