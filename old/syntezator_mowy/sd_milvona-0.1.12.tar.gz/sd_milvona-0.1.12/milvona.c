/*
 * voice.c - Milvona Speech-dispatcher module
 * Copyright (C) Bohdan R. Rau 2011 <ethanak@polip.com>
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write see:
 *               <http://www.gnu.org/licenses/>.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <libivolektor.h>
#include <milena.h>
#include <milena_mbrola.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <math.h>
#include <unistd.h>
#include <limits.h>
#include "config.h"
#include "simple.h"
#include "sonic.h"
#include <ctype.h>

char *module_name="milvona";


static int have_ivona;
char *get_milena_part(char *msg,char **omsg,int msgtype,int is_ivona,char *icon);

/*
 * milena_m -> dla głosu Milena
 * milena_i -> dla głosów Ivona
 */

struct milena *milena_m,*milena_i;
struct milena_mbrola_cfg *mimbrola;

extern void init_libraries(void);


static struct milena *_milena_init(int is_ivona)
{
    char ixbuf[256],ibuf[256],obuf[256];
    char *cfgpath;
	struct milena *milena=milena_Init(
                milena_FilePath(is_ivona?"ive_pho.dat":"pl_pho.dat",obuf),
                milena_FilePath("pl_dict.dat",ibuf),
                milena_FilePath("pl_stress.dat",ixbuf));
        if (!milena) return NULL;
        if (!milena_ReadPhraser(milena,
                milena_FilePath("pl_phraser.dat",ibuf))) return NULL;
        if (!milena_ReadPhraser(milena,
                milena_FilePath("pl_hours.dat",ibuf))) return NULL;
        if (!milena_ReadPhraser(milena,
                milena_FilePath("pl_inet_phr.dat",ibuf))) return NULL;
        if (!milena_ReadUserDic(milena,
                milena_FilePath("pl_udict.dat",ibuf))) return NULL;
        if (!milena_ReadUserDic(milena,
                milena_FilePath("pl_computer.dat",ibuf))) return NULL;
        if (is_ivona) {
	    milena_ReadUserDic(milena,
                milena_FilePath("ive_udict.dat",ibuf));
	    milena_ReadIvonaFin(milena,
			milena_FilePath("ive_fin.dat",ibuf));
	}
	int phm=MILENA_PHR_IGNORE_INFO;
	if (strdic_get_bool(module_settings,"hard_tilde",0)) {
	    phm |=MILENA_PHR_IGNORE_TILDE;
	}
	milena_SetPhraserMode(milena,phm);
	milena_ReadKeyChar(milena,milena_FilePath("pl_keys.dat",ibuf));
	cfgpath=strdic_get(module_settings,"milena_dict",NULL);
	if (cfgpath && *cfgpath) {
		if (*cfgpath!='/') {
			dbg("Dict path [%s] not absolute\n",cfgpath);
		}
		else {
			if (!milena_ReadUserDicWithFlags(milena,cfgpath,MILENA_UDIC_IGNORE)) {
				dbg("Cannot read dict [%s]\n",cfgpath);
			}
		}
	}
    return milena;
}

void init_libraries(void)
{
	char ibuf[256];
	char *pd;
	milena_m=_milena_init(0);
	if (!milena_m) exit(1);
	milena_i=_milena_init(1);
	if (!milena_i) exit(1);
    mimbrola=milena_InitModMbrola(
                milena_FilePath("pl_mbrola.dat",ibuf));
    if (!mimbrola) exit(0);
	if (!milena_ReadInton(mimbrola,
                milena_FilePath("pl_intona.dat",ibuf))) exit(0);
	pd=strdic_get(module_settings,"mbrola_conf",NULL);
	if (pd) {
		milena_ModMbrolaExtras(mimbrola,
			milena_FilePath(pd,ibuf));
	}

}

static char *iso2_buffer;
static int iso2_buflen;

static void erase_box_drawings(char *c)
{
	char *d=c,*c1;
	int was=0,n;
	for (;;) {
		c1=strstr(c,"&\x1bx");
		if (!c1) {
			if (c > d) strcpy(d,c);
			return;
		}
		was=(c==c1);
		while (c<c1) *d++=*c++;
		n=strtol(c1+3,&c1,16);
		if (*c1 != ';') {
			while (c<c1) *d++=*c++;
			continue;
		}
		c1++;
		if (n<0x2500 || n > 0x25ff) {
			while (c<c1) *d++=*c++;
			continue;
		}
		if (!was) *d++=' ';
		c=c1;
	}
	*d=0;
	return;
}


void start_speaking(char *msg,int type)
{
	char *new_message=NULL;
	dbg("Start speaking type %d, message [%s]\n",type,msg);
	strip_ssml(msg);
	dbg("Message after strip: [%s]\n",msg);
	voice_settings();
	v_msgtype=type;
	if (type == MSGTYPE_SPEAK && v_spelling) {
		v_msgtype=MSGTYPE_SPELL;
	}
	dbg("Effective message type %d\n",v_msgtype);
    if (v_msgtype == MSGTYPE_SPEAK) {
	if (!strdic_get_bool(module_settings,"hard_tilde",0)) {
	    char *c=msg,*d;
	    int ntil=0;
	    for (;*c;) {
		c=strchr(c,'~');
		if (!c) break;
		c++;
		if (strchr("!',:+",*c)) ntil++;
	    }
	    if (ntil) {
		new_message=malloc(strlen(msg)+6*ntil+1);
		for (c=msg,d=new_message;*c;) {
		    if (*c!='~') {
			*d++=*c++;
			continue;
		    }
		    c++;
		    if (strchr("!',:+",*c)) {
			strcpy(d," tylda");
			d+=6;
		    }
		    else *d++='~';
		}
		*d=0;
		msg=new_message;
	    }
	}
		dbg("Converting to ISO2\n");
    	int nlen=milena_utf2iso(msg,NULL,3,NULL);
		if (nlen<=0) {
			if (!iso2_buffer) iso2_buffer=malloc(iso2_buflen=1024);
			strcpy(iso2_buffer,"ehm?");
		}
		else {
			if (nlen > iso2_buflen) iso2_buffer=ralloc(iso2_buffer,iso2_buflen=nlen+1024);
			milena_utf2iso(msg,iso2_buffer,3,NULL);
		}
		if (strdic_get_bool(module_settings,"ignore_box_drawings",1)) {
			erase_box_drawings(iso2_buffer);
		}
		v_message=iso2_buffer;
		dbg("Converted message [%s]\n",v_message);
	}
	else {
		v_message=msg;
	}
	speak_start();
	if (new_message) free(new_message);
}

static char *ivona_buffer;
static int ivona_buflen;
static char *vibuf=NULL,*vobuf=NULL;
static int viblen=0,voblen=0;

char *get_milena_part(char *msg,char **omsg,int msgtype,int is_ivona,char *icon)
{
	char *oms,*mps;
	int phmode,wc,nlen,cpl=0,*icpl=NULL;
	static struct phone_buffer phb;
	struct milena *m = is_ivona?milena_i:milena_m;
	if (is_ivona) {
		if (!ivona_buffer) ivona_buffer=malloc(ivona_buflen=2048);
		*ivona_buffer=0;
	}
	if (!vibuf) vibuf=malloc(viblen=2048);
	if (!vobuf) vobuf=malloc(voblen=2048);

	mps=strdic_get(module_settings,"punctuation_some","()");
	if (icon) icon[0]=0;
	if (v_caplet == PARAM_CAP_ICON) {
		icpl=&cpl;
	}
	dbg("MSGTYPE IS %d\n",msgtype);
	for (;;) {
		oms=msg;
		switch(msgtype) {
			case MSGTYPE_ICON:
				if (icon) {
					strncpy(icon,trim(msg),63);
					icon[63]=0;
				}
				*omsg=msg+strlen(msg);
				return NULL;
			case MSGTYPE_SPEAK:
			nlen=milena_GetPhraseWithPunct(
				m,&oms,vibuf,viblen,&phmode,v_punctuation,mps);
			dbg("Phraser first run on [%d]=%d\n",viblen,nlen);
			if (nlen < 0) {
				dbg("End of message\n");
				*omsg=oms;
				if (is_ivona) {
					if (*ivona_buffer) return ivona_buffer;
				}
				return NULL;
			}
			if (nlen > 0) {
				vibuf=ralloc(vibuf,viblen=nlen+1024);
				oms=msg;
				nlen=milena_GetPhraseWithPunct(
					m,&oms,vibuf,viblen,&phmode,v_punctuation,mps);
				dbg("Phraser second run on [%d]=%d\n",viblen,nlen);
			}
			dbg("Phraser effect [%s][%d]\n",vibuf,strlen(vibuf));
			msg=oms;
			break;

			case MSGTYPE_CHAR:
			case MSGTYPE_SPELL:

			if (msgtype == MSGTYPE_CHAR && !strncmp(msg,"space",3)) {
				wc=' ';
				msg+=5;
			}
			else {
				wc=get_unichar(&msg);
			}
			if (!wc && msgtype == MSGTYPE_SPELL) return NULL;
			nlen=milena_wchar(m,wc,vibuf,viblen,icpl);
			dbg("Wchar first run on [%d]=%d\n",viblen,nlen);
			if (nlen > 0) {
				vibuf=ralloc(vibuf,viblen=nlen+1024);
				nlen=milena_wchar(m,wc,vibuf,viblen,icpl);
				dbg("Wchar second run on [%d]=%d\n",viblen,nlen);
			}
			else if (nlen<0) {
				strcpy(vibuf,"błąd");
			}
			phmode=16;
			if (msgtype == MSGTYPE_CHAR) {
				while(*msg) msg++;
			}
			else if (*msg && (msgtype == MSGTYPE_SPELL) && !is_ivona) {
				phmode=1;
			}
			break;

			case MSGTYPE_KEY:
			oms=strchr(msg,'_');
			if (oms) *oms++=0;
			else oms=msg+strlen(msg);
			nlen=milena_key(m,msg,vibuf,viblen,icpl);
			dbg("Key first run on [%d]=%d\n",viblen,nlen);
			if (nlen>0) {
				vibuf=ralloc(vibuf,viblen=nlen+1024);
				nlen=milena_key(m,msg,vibuf,viblen,icpl);
				dbg("Key second run on [%d]=%d\n",viblen,nlen);
			}
			else if (nlen<0) {
				strcpy(vibuf,"błąd");
			}
			msg=oms;
			phmode=16;
			break;

			default:
			return NULL;
		}
		if (cpl && icon) strcpy(icon,"capital");
		dbg("Prestresser start with [%s]\n",vibuf);
		nlen=milena_Prestresser(m,vibuf,vobuf,voblen);
		dbg("Prestresser first run on %s[%d]=%d\n",vibuf,voblen,nlen);
		if (nlen<0) return NULL;
		if (nlen>0) {
			vobuf=ralloc(vobuf,voblen=nlen+1024);
			nlen=milena_Prestresser(m,vibuf,vobuf,voblen);
			dbg("Prestresser second run on %s[%d]=%d\n",vibuf,voblen,nlen);
		}
		nlen=milena_TranslatePhrase(m,(unsigned char *)vobuf,vibuf,viblen,0);
		dbg("Translator first run on %s[%d]=%d\n",vobuf,viblen,nlen);
		if (nlen<0) return NULL;
		if (nlen>0) {
			vibuf=ralloc(vibuf,viblen=nlen+1024);
			nlen=milena_TranslatePhrase(m,(unsigned char *)vobuf,vibuf,viblen,0);
			dbg("Translator second run on %s[%d]=%d\n",vobuf,viblen,nlen);
		}
		if (!is_ivona) {
			nlen=milena_Poststresser(vibuf,vobuf,voblen);
			dbg("Poststresser first run on %s[%d]=%d\n",vibuf,voblen,nlen);
			if (nlen > 0) {
				vobuf=ralloc(vobuf,voblen=nlen+1024);
				nlen=milena_Poststresser(vibuf,vobuf,voblen);
				dbg("Poststresser second run on %s[%d]=%d\n",vibuf,voblen,nlen);
			}
			*omsg=msg;
			phb.str_len=0;
			milena_ModMbrolaGenPhraseP(mimbrola,vobuf,&phb,phmode & 7);
			return phb.str;
		}
		nlen=milena_ivonizer_n(phmode,vibuf,ivona_buffer,ivona_buflen,m);
		dbg("Ivonizer first run on %s[%d]=%d\n",vibuf,ivona_buflen,nlen);
		if (nlen < 0) return NULL;
		if (nlen > 0) {
			ivona_buffer=ralloc(ivona_buffer,ivona_buflen=1024+nlen);
			nlen=milena_ivonizer_n(phmode,vibuf,ivona_buffer,ivona_buflen,m);
			dbg("Ivonizer second run on %s[%d]=%d\n",vibuf,ivona_buflen,nlen);
		}
		if (*ivona_buffer  &&
				(msgtype != MSGTYPE_SPEAK ||
				 !strchr(",:",ivona_buffer[strlen(ivona_buffer)-1]))) {
			*omsg=msg;
			return ivona_buffer;
		}
	}
}


static struct module_voice *last_module_voice;
static struct IVOL_data *ivona;

short *ivona_get_wave(char *msg,struct module_voice *voice,int *len,int *offset)
{
	char *err;
	short *wave;
	int l,rest,offs;
	if (voice !=last_module_voice || !ivona) {
		if (ivona) IVOL_close(ivona);
		last_module_voice=voice;
		dbg("Opening ivona\n");
		ivona=IVOL_open(voice->name,&err);
		dbg("Ivona open\n");
		if (!ivona) {
			last_module_voice=NULL;
			dbg("Ivona Error: %s\n",err);
			return NULL;
		}
	}
	wave=IVOL_getWave(ivona,msg,&l,&err);
	if (!wave) {
		dbg("Ivona Error: %s\n",err);
		return NULL;
	}
	voice->samplefreq=ivona->freq;
	IVOL_trimWave(ivona,wave,l,&offs,&rest);
	*offset=offs;
	*len=l-(offs);
	return wave;
}


int play_repitched_wave(short *wave,int len,int freq,float g_pitch)
{
	sonicStream sonic;
	int n;
	short buf[256];
	int fail=0;

	if (v_rate > -2  && v_rate < 2 && g_pitch > 0.99 && g_pitch < 1.01) {
		revolume(wave,len,f_volume);
		return audio_play_sfr(wave,len,freq);
	}
	sonic=sonicCreateStream(freq,1);
	sonicSetSpeed(sonic,f_rate);
	sonicSetPitch(sonic,g_pitch);
	sonicSetVolume(sonic,f_volume);
	while (fail == 0 && len >= 0) {
		if (stop_speaking) break;
		if (len > 0) {
			n=1024;
			if (n > len) n=len;
			if (!sonicWriteShortToStream(sonic,wave,n)) {
				fail=1;
				break;
			}
			wave+=n;
			len-=n;
		}
		else {
			sonicFlushStream(sonic);
			len=-1;
		}
		while (!stop_speaking) {
			n=sonicReadShortFromStream(sonic,buf,256);
			if (n<=0) break;
			if (!play_part(buf,n,freq)) {
				fail=1;
				break;
			}
		}
	}

	play_part(NULL,0,0);
	sonicDestroyStream(sonic);
	return 1-fail;
}

int play_speech(char *phones,struct module_voice *voice)
{
	short *wave;int len;int offset;
	if (voice->synth_type) {
		int n_pitch=0;
		float g_pitch=1.0;
		int delta_pitch=ensure(strdic_get_int(module_settings,"ivona_min_pitch",0),0,101);
		if (v_pitch <= -delta_pitch || v_pitch >=delta_pitch) {
			n_pitch=v_pitch;
			g_pitch=f_pitch;
		}

		wave=ivona_get_wave(phones,voice,&len,&offset);
		if (!wave) return 0;
		audio_init();
		play_repitched_wave(wave+offset,len,voice->samplefreq,g_pitch);
		free(wave);
		return 1;
	}
	else {

		play_mbrola_wave(phones,
			&len,
			strdic_get(module_settings,"mbrola_voice","unknown"),
			voice->samplefreq);
		return 1;

		wave=get_mbrola_wave(phones,&len,strdic_get(module_settings,"mbrola_voice","unknown"));
		if (!wave) return 0;
		revolume(wave,len,f_volume);
		offset=0;
	}
	short *w=wave+offset;
	audio_play_sfr(w,len,voice->samplefreq);
	free(wave);
	return 1;
}

void do_speak(void)
{
	char *cs;
	struct module_voice *curvoice;
	char icon[64];
	char *next_part;
	curvoice=v_voice;
	if (strdic_get_bool(module_settings,"disable_ivona",0)) {
		curvoice=voices;
	}
	while (*v_message && !stop_speaking) {
		dbg("Message part: [%s]\n",v_message);
		cs=get_milena_part(v_message,&next_part,v_msgtype,curvoice->synth_type,icon);
		if (stop_speaking) break;
		if (!cs && !icon[0]) break;
		if (icon[0]) {
			dbg("Icon %s\n",icon);
			play_icon(icon);
		}
		if (stop_speaking) break;
		dbg("Message output: [%s]\n",cs);
		if (!cs || play_speech(cs,curvoice)) {
			dbg("Next in voice\n");
			v_message=next_part;
			continue;
		}

		if (!curvoice->synth_type) break;
		dbg("Switch to emergency voice\n");
		curvoice=voices;
		cs=get_milena_part(v_message,&next_part,v_msgtype,curvoice->synth_type,icon);
		if (!cs && !icon[0]) break;
		if (stop_speaking) break;
		dbg("Message output: [%s]\n",cs);
		if (!cs || play_speech(cs,curvoice)) {
			dbg("Next part\n");
			v_message=next_part;
			continue;
		}
		dbg("Something wrong...\n");
		break;
	}
	dbg("Message said\n");
}




static char *typical_pl1[]={
	"/usr/share/mbrola/pl1/pl1",
	"/usr/share/mbrola/voices/pl1",
	NULL};

int module_local_init(void)
{
	char *mvpath;
	struct module_voice *mv,**mmv;
	char **ivos;int i;
	mvpath=strdic_get(module_settings,"mbrola_voice",NULL);
	if (mvpath) {
		if (!file_exists(mvpath)) {
			dbg("File not found: %s\n",mvpath);
			return 0;
		}
	}
	else {
		int i;
		for (i=0;typical_pl1[1];i++) {
			if (file_exists(typical_pl1[i])) {
				strdic_set_value(&module_settings,"mbrola_voice",typical_pl1[i]);
				break;
			}
		}
		if (!typical_pl1[i]) {
			dbg("Can't find mbrola pl1 voice\n");
			return 0;
		}
	}
	if (strdic_get_bool(module_settings,"powersave",0)) {
		powersave_mode=1;
		if (!file_exists("/dev/shm/pl1")) {
			if (file_copy(strdic_get(module_settings,"mbrola_voice",""),"/dev/shm/pl1")) {
				strdic_set_value(&module_settings,"mbrola_voice","/dev/shm/pl1");
			}
		}
		if (!file_exists("/dev/shm/mbrola")) {
			char *fn=NULL;
			char *fst[]={"/usr/bin/mbrola","usr/local/bin/mbrola","/opt/bin/mbrola",NULL};
			int ix;
			for (ix=0;fst[ix];ix++) {
				if (file_exists(fst[ix])) {
					fn=fst[ix];
					break;
				}
			}
			if (fn) {
				if (file_copy(fn,"/dev/shm/mbrola")) {
					strdic_set_value(&module_settings,"mbrola_binary","/dev/shm/mbrola");
					chmod("/dev/shm/mbrola",0755);
				}
			}
		}
	}
	voices=calloc(1,sizeof(*voices));
	voices->next=NULL;
	voices->name="Milena";
	voices->language="pl";
	voices->synth_type=0;
	voices->samplefreq=16000;
	voices->sex=1;
	mmv=&voices->next;
	ivos=IVOL_voices();
	if (ivos) {
		for (i=0;ivos[i];i++) {
			have_ivona=1;
			mv=calloc(1,sizeof(*mv));
			mv->next=NULL;
			mv->name=strdup(ivos[i]);
			mv->language="pl";
			*mmv=mv;
			mmv=&mv->next;
			mv->synth_type=1;
			mv->samplefreq=0;
			mv->sex=(tolower(mv->name[strlen(mv->name)-1]) == 'a');
		}
		free(ivos);
	}
	init_libraries();
	return 1;
}

int main(int argc,char *argv[])
{
	return module_main(argc,argv);
}
