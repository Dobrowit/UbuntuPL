/*
 * audio.c - Simple Speech-dispatcher module
 * Copyright (C) Bohdan R. Rau 2011 <ethanak@polip.com>
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write see:
 *               <http://www.gnu.org/licenses/>.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ao/ao.h>
#include <string.h>
#include <math.h>
#include "config.h"
#include "simple.h"
#ifdef HAVE_SNDFILE
#include <sndfile.h>
#endif

static int ao_playing;
static ao_device *device;
static int driver=-1;
static ao_sample_format format;
static int ao_initialized;

static char *ao_driver_name;
static int ao_driver_set;
static struct ao_option *ao_options;
static char zero[256]={0};

static int init_ao(int rate)
{
	format.bits = 16;
	format.channels = 1;
	format.rate = rate;
	format.byte_format = AO_FMT_LITTLE;

	if (!ao_initialized) ao_initialize();
	if (driver == -1) {
		if (ao_driver_name) {
			driver=ao_driver_id(ao_driver_name);
			if (driver == -1) {
				free(ao_driver_name);
				ao_driver_name=NULL;
				dbg("Cant open AO %s driver, fallingback to default\n");
				ao_free_options(ao_options);
			}
		}
		if (driver == -1) {
			driver = ao_default_driver_id();
		}
		if (driver == -1) {
			return 0;
		}
	}
	if (!device) device = ao_open_live(driver, &format, ao_options);
	if (!device) {
		return 0;
	}
	return 1;
}

static int _audio_play_sfr(short *samples,int nsamples,int rate)
{
	if (!samples) {
		if (ao_playing) {
			ao_close(device);
			device=NULL;
			ao_playing=0;
		}
		return 1;
	}
    if (ao_playing && rate != format.rate) {
		ao_close(device);
		device=NULL;
		ao_playing=0;
    }
	if (!ao_playing) {
		if (!init_ao(rate)) return 0;
		ao_playing=1;
	}
	if (!ao_play(device,(char *)samples,2*nsamples)) {
		ao_close(device);
		device=NULL;
		ao_playing=0;
		return 0;
	}
	return 1;
}


/* pulseaudio part */
#ifdef HAVE_PULSE

#include <pulse/simple.h>
#include <pulse/error.h>

#define PULSE_SEND_BYTES 256
#define DEFAULT_MIN_AUDLEN 100
#define PULSE_SHORTEST_SOUND 4096

static int p_current_rate;
static pa_simple *p_simple;
static char *p_server;
int p_server_set=0;
static int pulse_use_drain=0;
static int pulse_margin=0;

static int _pulse_open(int freq)
{
	pa_buffer_attr buffAttr;
	pa_sample_spec ss;
	int error;

	ss.rate = freq;
	ss.channels = 1;
	ss.format = PA_SAMPLE_S16LE;

	// pulse_margin in bytes!

	pulse_margin=(freq*ensure(
		strdic_get_int(module_settings,"audio_pulse_margin",0),
		0,
		1000))/500;
	pulse_use_drain=strdic_get_bool(module_settings,"audio_pulse_drain",0);


	/* values got from speech-dispatcher driver code */
	buffAttr.maxlength = (uint32_t)-1;
	buffAttr.tlength = DEFAULT_MIN_AUDLEN;
	buffAttr.prebuf = (uint32_t)-1;
	buffAttr.minreq = (uint32_t)-1;
	buffAttr.fragsize = (uint32_t)-1;
	p_simple = pa_simple_new(p_server, "speech-dispatcher", PA_STREAM_PLAYBACK,
				     NULL, "playback", &ss, NULL, &buffAttr, &error);
	if (!p_simple) {
		fprintf(stderr,"pulse failed: %s\n", pa_strerror(error));
		return 1;
	}
	p_current_rate = freq;
	return 0;
}

static int pulse_open (int freq)
{
    p_simple = NULL;
    p_server = NULL;
    p_current_rate = -1;
    return _pulse_open(freq);
}

static void pulse_drain_or_flush(void)
{
	if (!p_simple) return;
	if (stop_speaking) {
		pa_simple_flush(p_simple,NULL);
	}
	else if (pulse_use_drain) {
		pa_simple_drain(p_simple,NULL);
	}
}

static void pulse_close (void)
{
    if(p_simple) {
        pa_simple_free(p_simple);
        p_simple = NULL;
    }
}

static int pulse_play (short *wave,int len,int freq)
{
    int count=0;
    int nlen;
    int error;
	char *uwave;
	int ncx;
	uwave=(char *)wave;
    if(p_current_rate != freq ) {
        pulse_close();
		_pulse_open(freq);
		p_current_rate = freq;
    }
    count = 2*len;
    ncx=PULSE_SHORTEST_SOUND-count;
    while((count > 0) && !stop_speaking) {
		nlen=PULSE_SEND_BYTES;
		if (nlen > count) nlen=count;
		if(pa_simple_write(p_simple, uwave, nlen, &error) < 0) {
			//loosing part of speech is better than waiting some seconds!
			if (pulse_use_drain) pa_simple_drain(p_simple, NULL);
			pulse_close();
			ncx=0;
			break;
		}
		uwave+=nlen;
		count-=nlen;
	}
	if (pulse_margin>ncx) ncx=pulse_margin;
	while(ncx > 0 && !stop_speaking) {
		nlen=PULSE_SEND_BYTES;
		if (nlen > ncx) nlen=ncx;
		if(pa_simple_write(p_simple, zero, nlen, &error) < 0) {
			//loosing part of speech is better than waiting some seconds!
			if (pulse_use_drain) pa_simple_drain(p_simple, NULL);
			pulse_close();
			break;
		}
		ncx-=nlen;

	}
    return 0;
}


void pu_play(short *w,int len,int freq)
{
	if (!p_simple) {
		if (!w) return;
		pulse_open(freq);
	}
	if (!w) {
		pulse_drain_or_flush();
		pulse_close();
		return;
	}
	pulse_play (w,len,freq);
}

void pulse_play_margin()
{
	int v=pulse_margin;
	int n,error;
	if (!v) return;
	while (v>0 && !stop_speaking) {
		n=256;
		if (n>v) n=v;
		if(pa_simple_write(p_simple, zero, n, &error) < 0) {
			if (pulse_use_drain) pa_simple_drain(p_simple, NULL);
			pulse_close();
			return;
		}
		v-=n;
	}
}

int pu_play0(short *w,int len,int freq)
{
	int error;
	if (!p_simple) {
		if (!w) return 1;
		pulse_open(freq);
	}
	if (!w) {
		return 1;
	}
    if(p_current_rate != freq ) {
		if (p_simple) {
			pulse_play_margin();
			pulse_drain_or_flush();
		}
        pulse_close();
		_pulse_open(freq);
		p_current_rate = freq;
    }
	if(pa_simple_write(p_simple, (char *)w, 2*len, &error) < 0) {
		//pa_simple_drain(p_simple, NULL);
		pulse_close();
		return 0;
	}
	return 1;
}

void pu_fine0(void)
{
	if (p_simple) {
		pulse_play_margin();
		pulse_drain_or_flush();
	}
    pulse_close();
}


#endif

static int (*loc_play)(short *,int,int);
static void (*loc_fin)(void);
static int play_pulse;
static int audio_initialized;

int play_part(short *w,int l,int f)
{
	if (!loc_play) return 0;
	send_begin();
	if (!w) return loc_play(NULL,0,f);
	while (l>0) {
		int n=256;
		if (n>l) n=l;
		if (stop_speaking) return 1;
		if (!loc_play(w,n,f)) return 0;
		w+=n;
		l-=n;
	}
	return 1;
}

void audio_init(void)
{
	if (audio_initialized) return;
	char *s=strdic_get(module_audio_set,"audio_output_method","libao");
	char *s1;
	if (strdic_get_bool(module_settings,"audio_force_libao",0)) {
		dbg("Audio: force using libao\n");
		s="libao";
	}
#ifdef HAVE_PULSE
	if (!strcmp(s,"pulse")) {
		if (!p_server_set) {
			p_server_set=1;
			p_server=strdic_get(module_audio_set,"audio_pulse_server","default");
			if (!strcasecmp(p_server,"default")) p_server=NULL;
		}
		loc_play=pu_play0;
		loc_fin=pu_fine0;
		play_pulse=1;
		audio_initialized=1;
		return;
	}
#endif
	if (!strcmp(s,"alsa")) {
		s1=strdic_get(module_audio_set,"audio_alsa_device","default");
		if (strcmp(s1,"default")) {
			ao_append_option(&ao_options,"dev",s1);
		}
	}
	else if (!strcmp(s,"oss")) {
		s1=strdic_get(module_audio_set,"audio_oss_device","default");
		if (strcmp(s1,"default")) {
			ao_append_option(&ao_options,"dev",s1);
		}
	}
	else if (!strcmp(s,"nas")) {
		s1=strdic_get(module_audio_set,"audio_nas_server",NULL);
		if (!s1) {
			dbg("NAS server not set, falling back to ao\n");
			s=NULL;
		}
		else {
			ao_append_option(&ao_options,"server",s1);
		}
	}
	else if (strcmp(s,"ao") && strcmp(s,"libao")) {
		dbg("Unknown audio method %s, falling back to ao\n");
		s=NULL;
	}
	else {
		s=NULL;
	}
	if (s) ao_driver_name=strdup(s);
	ao_driver_set=1;
	loc_play=_audio_play_sfr;
	loc_fin=NULL;
	play_pulse=0;
	audio_initialized=1;
}


int audio_play_sfr(short *samples,int nsamples,int rate)
{
	int n;
	dbg("Audio starts %d/%d Hz\n",nsamples,rate);
	audio_init();
	send_begin();
#ifdef HAVE_PULSE
	if (play_pulse) {
		pu_play(samples,nsamples,rate);
		pu_play(NULL,0,0);
		dbg("Audio PA finished\n");
		return 1;
	}
#endif
	while (nsamples > 0 && !stop_speaking) {
		n=256;
		if (n>nsamples) n=nsamples;
		if (!_audio_play_sfr(samples,n,rate)) return 0;
		nsamples-=n;
		samples+=n;
	}
	_audio_play_sfr(NULL,0,rate);
	dbg("Audio AO finished\n");
	return 1;
}

void revolume(short *wave,int len,float volume)
{
	int n;
	if (volume < 1.0) {
		while (len-- > 0) {
			n=(*wave) * volume;
			*wave++ = n;
		}
	}
}

void apply_contrast(signed short *data,int len,double contrast_level)
{
        while (len-- > 0) {
                double d=(*data) * (M_PI_2/32768.0);
                *data++=sin(d + contrast_level * sin(d * 4)) * 32767;
        }
}

int play_icon(char *icon)
{
#ifdef HAVE_SNDFILE
	dbg("Playing icon: %s\n",icon);
	char fname[PATH_MAX];
	SF_INFO info;
	SNDFILE *f;
	short *wave;
	int nsamp;
	sprintf(fname,"%s/%s",
		strdic_get(module_settings,"sound_icons","/usr/share/sounds/sound-icons"),
		icon);
	f=sf_open(fname,SFM_READ,&info);
	if (!f) {
		perror(fname);
		return 0;
	}
	if (info.channels < 1 || info.channels > 2) {
		fprintf(stderr,"Can't play %d channels\n",info.channels);
		sf_close(f);
		return 0;
	}
	wave=malloc(2*info.frames*info.channels);
	sf_read_short(f,wave,nsamp=info.frames*info.channels);
	sf_close(f);
	if (info.channels == 2) {
		int i;
		nsamp=nsamp/2;
		for (i=0;i<nsamp;i++) {
			wave[i]=(wave[2*i]+wave[2*i+1])/2;
		}
	}
	send_begin();
	audio_play_sfr(wave,nsamp,info.samplerate);
	free(wave);

#else
	dbg("Sound icons does not work without sndfile\n");
#endif
	return 1;
}

void finalize_audio()
{
	dbg("Finalizing audio\n");
	if (loc_fin) loc_fin();
}
