/*
 * simple.h - Simple Speech-dispatcher module
 * Copyright (C) Bohdan R. Rau 2011 <ethanak@polip.com>
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write see:
 *               <http://www.gnu.org/licenses/>.
 */
#ifndef ETH_COMMON_H
#define ETH_COMMON_H 1

extern struct strdic *module_audio_set;
extern struct strdic *module_current_set;
extern struct strdic *module_log_set;
extern struct strdic *module_settings;
extern struct module_voice *voices;
extern int stop_speaking;
extern int begin_sent;
extern int speaking;

void strip_ssml(char *c);
int ensure(int v,int m1,int m2);


#define MSGTYPE_SPEAK 0
#define MSGTYPE_CHAR 1
#define MSGTYPE_KEY 2
#define MSGTYPE_SPELL 3
#define MSGTYPE_ICON 4

#define PARAM_PUNCT_NONE 0
#define PARAM_PUNCT_SOME 1
#define PARAM_PUNCT_ALL 2

#define PARAM_CAP_NONE 0
#define PARAM_CAP_ICON 1
#define PARAM_CAP_SPELL 2

extern void start_speaking(char *msg,int type);
extern void speak_start(void);
extern int get_unichar(char **str);
extern char *trim(char *c);
extern int file_exists(char *path);
extern int file_copy(char *src,char *dst);
extern int audio_play_sfr(short *samples,int nsamples,int rate);
extern void finalize_audio();
extern void revolume(short *wave,int len,float volume);
extern int play_icon(char *icon);
extern void apply_contrast(signed short *data,int len,double contrast_level);
extern void audio_init(void);
extern int play_part(short *w,int l,int f);
extern void *ralloc(void *ptr,int newlen);
extern void dbg(char *format,...);
extern void reply(int rcode, char *rstring);
extern void send_begin(void);
extern void send_stop(void);
extern void voice_settings(void);

struct strdic {
	struct strdic *next;
	char *value;
	int vlen;
	char name[1];
};
extern void strdic_set_value(struct strdic **S,char *name,char *value);
extern char *strdic_get(struct strdic *s,char *name,char *defval);
extern int strdic_get_int(struct strdic *s,char *name,int defval);
extern int strdic_get_bool(struct strdic *s,char *name,int defval);
extern void strdic_dump(struct strdic *s);

extern int powersave_mode;

struct module_voice {
	struct module_voice *next;
	char *name;
	char *language;
	char *dialect;
	int synth_type;
	int samplefreq;
	int sex;
	void *user_data;
};



extern int v_pitch, v_rate, v_volume,
	v_punctuation,v_spelling, v_caplet,
	v_msgtype;
extern char *v_message;
extern float f_pitch,f_volume,f_rate;
extern struct module_voice *v_voice;
extern short *get_mbrola_wave(char *phonemes,int *len,char *voice);
extern void play_mbrola_wave(char *phonemes,int *len,char *voice,int freq);
int module_main(int argc,char *argv[]);

// must be defined in module
extern void start_speaking(char *msg,int type);
extern void do_speak(void);
extern char *module_name;
extern int module_local_init(void);


#endif
