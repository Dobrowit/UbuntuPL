/*
 * main.c - Simple Speech-dispatcher module
 * Copyright (C) Bohdan R. Rau 2011 <ethanak@polip.com>
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write see:
 *               <http://www.gnu.org/licenses/>.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <semaphore.h>
#include <signal.h>
#include <pthread.h>
#include <sys/stat.h>
#include <limits.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdarg.h>
#include "config.h"
#include "simple.h"
#include <errno.h>
#include <sys/wait.h>

static inline void ignore(register int r) {}

extern int module_init(char *fname);
extern void do_speak(void);
int read_config(int conditional);
pthread_t speaker_thread;

struct strdic *module_audio_set;
struct strdic *module_current_set;
struct strdic *module_log_set;
struct strdic *module_settings;
struct module_voice *voices;
char *input_buffer;
int input_buffer_size;
int input_buffer_len;

sem_t speech_sema;

int stop_speaking;
int begin_sent;
int speaking;

static char config_path[PATH_MAX];
static time_t config_stamp=0;

int powersave_mode=0;

// current values

int v_pitch;
int v_rate;
int v_volume;
int v_punctuation;
int v_spelling;
int v_caplet;
int v_msgtype;
char *v_message;
float f_pitch,f_volume,f_rate;
struct module_voice *v_voice;

/* funkcje różne */

void dbg(char *format,...)
{
	va_list va;
	if (strdic_get_int(module_settings,"log_level",0) <= 0) return;
	va_start(va,format);
	vfprintf(stderr,format,va);
	va_end(va);
}

void dbgs(char *title,struct strdic *dic)
{
	if (strdic_get_int(module_settings,"log_level",0) <= 0) return;
	fprintf(stderr,"Content of %s:\n",title);
	strdic_dump(dic);
}




int get_unichar(char **str)
{
	wchar_t wc;
	int n;
	wc=*(*str)++ & 255;
	if ((wc & 0xe0)==0xc0) {
		wc &=0x1f;
		n=1;
	}
	else if ((wc & 0xf0)==0xe0) {
		wc &=0x0f;
		n=2;
	}
	else if ((wc & 0xf8)==0xf0) {
		wc &=0x07;
		n=3;
	}
	else if ((wc & 0xfc)==0xf8) {
		wc &=0x03;
		n=4;
	}
	else if ((wc & 0xfe)==0xfc) {
		wc &=0x01;
		n=5;
	}
	else return wc;
	while (n--) {
		if ((**str & 0xc0) != 0x80) {
			wc='?';
			break;
		}
		wc=(wc << 6) | ((*(*str)++) & 0x3f);
	}
	return wc;
}

char *trim(char *c)
{
	char *d,*e;
	for (;*c;c++) if (!isspace(*c)) break;
	for (d=e=c;*d;d++) if (!isspace(*d)) e=d+1;
	*e=0;
	return c;
}

static void cpress(char *c)
{
	char *d=c;
	int nsp=0;
	while (*c && isspace(*c)) c++;
	for (;*c;c++) {
		if (isspace(*c)) nsp=1;
		else {
			if (nsp) *d++=' ';
			nsp=0;
			*d++=*c;
		}
	}
	*d=0;
}

void strip_ssml(char *c)
{
	char *d;
	for (d=c;*c;) {
		if (*c == '<') {
			c=strchr(c,'>');
			if (!c) break;
			c++;
			continue;
		}
		if (!strncmp(c,"&lt;",4)) {*d++='<';c+=4;}
		else if (!strncmp(c,"&gt;",4)) {*d++='>';c+=4;}
		else if (!strncmp(c,"&amp;",5)) {*d++='&';c+=5;}
		else *d++=*c++;
	}
	*d=0;
}

void strdic_dump(struct strdic *s)
{
	fprintf(stderr,"{");
	for (;s;s=s->next) {
		fprintf(stderr,"\"%s\" : \"%s\"%s\n",s->name,s->value,s->next?",":"");
	}
	fprintf(stderr,"}\n");
}

void strdic_set_value(struct strdic **S,char *name,char *value)
{
	struct strdic *s;
	int vl=strlen(value)+1;
	for (s=*S;s;s=s->next) if (!strcmp(s->name,name)) break;
	if (!s) {
		if (vl < 64) vl=64;
		s=malloc(strlen(name)+sizeof(*s));
		strcpy(s->name,name);
		s->vlen=vl;
		s->value=malloc(vl);
		s->next=*S;
		*S=s;
		strcpy(s->value,value);
		return;
	}
	if (!strcmp(s->value,value)) return;
	if (s->vlen < vl) {
		s->vlen=(vl+127) & 0xFFC0;
		s->value=realloc(s->value,s->vlen);
	}
	strcpy(s->value,value);
}

char *strdic_get(struct strdic *s,char *name,char *defval)
{
	for (;s;s=s->next) if (!strcmp(s->name,name)) return s->value;
	return defval;
}

int strdic_get_int(struct strdic *s,char *name,int defval)
{
	for (;s;s=s->next) if (!strcmp(s->name,name)) return strtol(s->value,NULL,10);
	return defval;
}

int strdic_get_bool(struct strdic *s,char *name,int defval)
{
	for (;s;s=s->next) if (!strcmp(s->name,name)) {
		if (!*s->value || !strcasecmp(s->value,"default")) return defval;
		if (!strcasecmp(s->value,"on") ||
			strchr("yYtT1",*s->value)) return 1;
		return 0;
	}
	return defval;
}

void *ralloc(void *ptr,int newlen)
{
	if (ptr) return realloc(ptr,newlen);
	return malloc(newlen);
}

static void read_speech_input(void)
{
	char *c,*d;
	if (!input_buffer) {
		input_buffer=malloc(input_buffer_size=1024);
	}
	input_buffer_len=0;
	for (;;) {
		int znak=fgetc(stdin);
		if (znak == '\n') {
			if (input_buffer_len >= 2 &&
				input_buffer[input_buffer_len-2] == '\n' &&
				input_buffer[input_buffer_len-1] == '.') {
					input_buffer[input_buffer_len-2] = 0;
					break;
				}
		}
		if (input_buffer_len >= input_buffer_size) {
			input_buffer=realloc(input_buffer,input_buffer_size=input_buffer_size * 2);
		}
		input_buffer[input_buffer_len++]=znak;
	}
	for (c=d=input_buffer;*c;c++) {
		*d++=*c;
		if (*c=='\n' && c[1]=='.') c++;
	}
	*d=0;
}


pthread_mutex_t mutex_out = PTHREAD_MUTEX_INITIALIZER;
void reply(int rcode,char *rstring)
{
	pthread_mutex_lock(&mutex_out);
	fprintf(stdout,"%d %s\n",rcode,rstring);
	fflush(stdout);
	pthread_mutex_unlock(&mutex_out);
	dbg("Replied %d %s\n",rcode,rstring);
}

static void read_set(struct strdic **set,int rcode,char *rstring,int set_mode)
{
	char buffer[1024],*c,*d;
	int synvoice_set=0;
	int voice_set=0;
	while (fgets(buffer,1024,stdin)) {
		c=trim(buffer);
		if (!strcmp(c,".")) break;
		d=strchr(c,'=');
		if (!d) continue;
		*d++=0;
		strdic_set_value(set,c,d);
		if (!set_mode) continue;
		if (!strcmp(c,"voice")) voice_set=1;
		else if (!strcmp(c,"synthesis_voice") && strcmp(d,"NULL")) synvoice_set=1;
	}
	if (set_mode) {
		/* autocorrection voice => synthesis_voice */
		if (voice_set && !synvoice_set) {
			struct module_voice *mv,*lmv;
			int nr=-1,isex=-1;
			c=strdic_get(*set,"voice","male1");
			lmv=voices;
			if (!strncasecmp(c,"male",4)) {
				isex=0;
				nr=strtol(c+4,NULL,10);
			}
			else if (!strncasecmp(c,"female",6)) {
				isex=1;
				nr=strtol(c+6,NULL,10);
			}
			for (mv=voices; mv && nr > 0;mv=mv->next) {
				if (mv->sex == isex) {lmv=mv;nr--;}
			}
			strdic_set_value(set,"synthesis_voice",lmv->name);
		}
	}
	reply(rcode?rcode:200,rstring?rstring:"OK");
}

void *speaker_thread_fun(void *dummy)
{
    sigset_t all_signals;
    if (!sigfillset(&all_signals)) {
		pthread_sigmask(SIG_BLOCK,&all_signals,NULL);
	}
    pthread_setcancelstate(PTHREAD_CANCEL_ENABLE, NULL);
    pthread_setcanceltype(PTHREAD_CANCEL_ASYNCHRONOUS, NULL);
    for (;;) {
		sem_wait(&speech_sema);
		begin_sent=0;
		do_speak();
		finalize_audio();
		send_stop();
	}
}

void speak_start(void)
{
	sem_post(&speech_sema);
}

int file_exists(char *path)
{
	struct stat sb;
	if (stat(path,&sb)) return 0;
	return S_ISREG(sb.st_mode);
}

int file_copy(char *src,char *dst)
{
	char buf[1024];
	int fd1,fd2;
	fd1=open(src,O_RDONLY);
	if (fd1<0) return 0;
	fd2=open(dst,O_WRONLY|O_CREAT,0644);
	if (fd2<0) {
		close(fd1);
		return 0;
	}
	for (;;) {
		int n=read(fd1,buf,1024);
		if (n<=0) break;
		ignore(write(fd2,buf,n));
	}
	close(fd1);
	close(fd2);
	return 1;
}


time_t get_mtime(char *path)
{
	struct stat sb;
	if (stat(path,&sb)) return 0;
	return sb.st_mtime;
}

int read_config(int conditional)
{
	FILE *f;
	char buf[1024],*line,*eqs,*c,*d;
	int spa;
	if (!config_stamp) return 1;
	if (conditional) {
		if (powersave_mode) return 1;
		time_t m=get_mtime(config_path);
		if (m == config_stamp) return 1;
		config_stamp=m;
	}
	f=fopen(config_path,"r");
	if (!f) {
		perror(config_path);
		return 0;
	}
	while(fgets(buf,1024,f)) {
		line=trim(buf);
		if (!*line || *line=='#') continue;
		eqs=strchr(line,'=');
		if (!eqs) continue;
		*eqs++=0;
		for (c=d=line,spa=0;*c;c++) {
			if (isspace(*c) || *c=='_') {
				spa=1;
				continue;
			}
			if (spa) {
				*d++='_';
				spa=0;
			}
			*d++=*c;
		}
		*d=0;
		while (*eqs && isspace(*eqs)) eqs++;
		strdic_set_value(&module_settings,line,eqs);
	}
	fclose(f);
	if (conditional) dbgs("New settings",module_settings);
	return 1;
}

int module_init(char *c)
{
	sprintf(config_path,"%s/.sd_%s_rc",getenv("HOME"),module_name);
	if (!file_exists(config_path)) {
		if (file_exists(c)) {
			file_copy(c,config_path);
			config_stamp=get_mtime(config_path);
		}
	}
	else {
		config_stamp=get_mtime(config_path);
	}
	read_config(0);
	if (!module_local_init()) return 0;
	dbgs("Initial settings",module_settings);
	return 1;
}

int ensure(int v,int m1,int m2)
{
	if (v < m1) return m1;
	if (v > m2) return m2;
	return v;
}

void voice_settings(void)
{
	char *vox,*c;
	struct module_voice *mv;
	v_pitch=ensure(strdic_get_int(module_current_set,"pitch",0),-100,100);
	v_rate=ensure(strdic_get_int(module_current_set,"rate",0),-50,100);
	v_volume=ensure(strdic_get_int(module_current_set,"volume",0),-100,100);
	f_volume=(v_volume+100)/200.0;
	f_rate=(v_rate > 0) ? (100+v_rate)/100.0:(200+v_rate)/200.0;
	f_pitch=(v_pitch > 0) ? (100+v_pitch)/100.0:(200+v_pitch)/200.0;

	vox=strdic_get(module_current_set,"synthesis_voice","");
	for (mv=voices;mv;mv=mv->next) if (!strcasecmp(mv->name,vox)) break;
	if (!mv) mv=voices;
	v_voice=mv;
	c=strdic_get(module_current_set,"punctuation_mode","none");
	v_punctuation=
		(!strcasecmp(c,"some")) ? PARAM_PUNCT_SOME :
		(!strcasecmp(c,"all")) ? PARAM_PUNCT_ALL : PARAM_PUNCT_NONE;
	v_spelling=strdic_get_bool(module_current_set,"spelling_mode",0);
	c=strdic_get(module_current_set,"cap_let_recogn","none");
	v_caplet=
		(!strcasecmp(c,"icon")) ? PARAM_CAP_ICON :
		(!strcasecmp(c,"spell")) ? PARAM_CAP_SPELL : PARAM_CAP_NONE;
}

int module_main(int argc,char *argv[])
{
	static char cmd[256];
	int n;
	int initialized=0;
	if (sem_init(&speech_sema,0,0)) exit(1);
	pthread_create(&speaker_thread,NULL,speaker_thread_fun,NULL);
	for (;;) {
		if (!fgets(cmd,256,stdin)) break;
		cpress(cmd);
		read_config(1);
		dbg("Command: %s\n",cmd);
		if (!strcmp(cmd,"INIT")) {
			if (initialized) {
				reply(399,"MODULE ALREADY INITIALIZED");
				continue;
			}
			// inicjalizacja modułu
			n=module_init(argv[1]);
			if (n) reply(200,"OK MODULE INITIALIZED");
			else {
				reply(400,"MODULE INITIALIZATION ERROR");
				exit(0);
			}
			initialized=1;
			continue;
		}
		if (!strcmp(cmd,"QUIT")) {
			reply(200,"OK GOOD BYE");
			exit(0);
		}
		if (!initialized) {
			dbg("SPD didn't call INIT!\n");
			n=module_init(argv[1]);
			if (!n) exit(0);
		}
		if (!strcmp(cmd,"AUDIO")) {
			reply(207,"OK RECEIVING AUDIO SETTINGS");
			read_set(&module_audio_set,0,NULL,0);
			dbgs("audio",module_audio_set);
			audio_init();
			continue;
		}
		if (!strcmp(cmd,"SET")) {
			reply(207,"OK RECEIVING SETTINGS");
			read_set(&module_current_set,0,NULL,1);
			dbgs("settings",module_current_set);
			continue;
		}
		if (!strcmp(cmd,"LOGLEVEL")) {
			reply(207,"OK RECEIVING LOGLEVEL");
			read_set(&module_log_set,0,NULL,0);
			dbgs("loglevel",module_log_set);
			continue;
		}
		if (!strcmp(cmd,"LIST VOICES")) {
			struct module_voice *v;
			for (v=voices;v;v=v->next) {
				fprintf(stdout,"200-%s %s %s\n",
					v->name,v->language,v->dialect?v->dialect:"none");
			}
			reply(200,"OK VOICE LIST SENT");
			continue;
		}
		if (!strcmp(cmd,"SPEAK") || !strcmp(cmd,"KEY") || !strcmp(cmd,"CHAR")) {
			int mt;
			mt=MSGTYPE_SPEAK;
			if (!strcmp(cmd,"CHAR")) mt=MSGTYPE_CHAR;
			else if (!strcmp(cmd,"KEY")) mt=MSGTYPE_KEY;
			reply(200,"OK WAITING FOR SPEECH_DATA");
			read_speech_input();
			if (speaking) {
				reply(301,"CANNOT SPEAK");
				continue;
			}
			reply(200,"OK START SPEAKING");
			stop_speaking=0;
			speaking=1;
			start_speaking(input_buffer,mt);
			continue;
		}
		if (!strcmp(cmd,"STOP") || !strcmp(cmd,"PAUSE")) {
			stop_speaking=1;
			continue;
		}
		if (!strcmp(cmd,"SOUND_ICON")) {
			reply(200,"OK WAITING FOR SDATA");
			read_speech_input();
			if (speaking) {
				reply(301,"CANNOT SPEAK");
				continue;
			}
			reply(200,"OK START PLAYING");
			stop_speaking=0;
			speaking=1;
			start_speaking(input_buffer,MSGTYPE_ICON);
			continue;
		}
		reply(300,"UNKNOWN COMMAND");
	}
	return 0;
}

void send_begin(void)
{
	if (!begin_sent) {
		reply(701,"BEGIN");
		begin_sent=1;
	}
}

void send_stop(void)
{
	send_begin();
	if (stop_speaking) {
		reply(703,"STOP");
	}
	else {
		reply(702,"END");
	}
	speaking=0;
}


void play_mbrola_wave(char *phonemes,int *len,char *voice,int freq)
{
	int to_mbr[2],from_mbr[2];
	double d_speed=(v_rate > 0)?(1.0 - v_rate/200.0):(1.0-v_rate/100.0);
	double d_pitch=(v_pitch < 0)?(1.0 + v_pitch/200.0):(1.0+v_pitch/100.0);
	int pid;
	char buf[64],buffer[4096];
	int contrast=ensure(strdic_get_int(module_settings,"mbrola_contrast",0),0,100);
	double d_contrast=(contrast > 0)?(0.03+contrast/1000.0):0.0;
	ignore(pipe(to_mbr));
	ignore(pipe(from_mbr));
	pid=fork();
	if (pid<0) {
		close(to_mbr[0]);
		close(to_mbr[1]);
		close(from_mbr[0]);
		close(from_mbr[1]);
		return;
	}
	if (!pid) {
		close(to_mbr[1]);
		close(from_mbr[0]);
		dup2(to_mbr[0],0);
		dup2(from_mbr[1],1);
		execlp(strdic_get(module_settings,"mbrola_binary","mbrola"),"mbrola","-e",voice,"-","-",NULL);
		exit(1);
	}
	close(to_mbr[0]);
	close(from_mbr[1]);
	int flags0=fcntl(from_mbr[0],F_GETFL,0);
	int flags1=fcntl(to_mbr[1],F_GETFL,0);
	fcntl(to_mbr[1],F_SETFL,flags1 | O_NONBLOCK);
	fcntl(from_mbr[0],F_SETFL,flags0 | O_NONBLOCK);
	sprintf(buf,";;T=%.3f\n;;F=%.3f\n",d_speed,d_pitch);
	ignore(write(to_mbr[1],buf,strlen(buf)));
	int ile=strlen(phonemes);
	int stan=0;
	audio_init();
	for (;;) {
		if (stop_speaking) break;
		if (!ile) {
			if (stan) break;
			stan=1;
			close(to_mbr[1]);
		}
		else {
			int n=write(to_mbr[1],phonemes,ile);
			if (n<0 && errno != EWOULDBLOCK) {
				stan=2;
				close(to_mbr[1]);
				break;
			}
			if (n<0) n=0;
			ile-=n;
			phonemes+=n;
		}
		for (;;) {
			if (stop_speaking) break;
			int n=read(from_mbr[0],buffer,4096);
			dbg("Read from mbrola %d\n",n);
			if (n<0 && errno!=EWOULDBLOCK) {
				dbg("Read failed\n");
				stan=2;
				close(to_mbr[1]);
				break;
			}
			if (n<=0) break;
			if (contrast > 0) {
				apply_contrast((signed short *)buffer,n/2,d_contrast);
			}
			revolume((signed short *)buffer,n/2,f_volume);
			if (!play_part((short *)buffer,n/2,freq)) {
				stan=2;
				close(to_mbr[1]);
				break;
			}
		}
		if (stan) break;
	}
	if (!stan) close(to_mbr[1]);
	fcntl(from_mbr[0],F_SETFL,flags0);
	for (;;) {
		if (stop_speaking) break;
		int n=read(from_mbr[0],buffer,4096);
		if (n<=0) break;
		if (contrast > 0) {
			apply_contrast((signed short *)buffer,n/2,d_contrast);
		}
		revolume((signed short *)buffer,n/2,f_volume);
		if (!play_part((short *)buffer,n/2,freq)) break;
	}
	close(from_mbr[0]);
	play_part(NULL,0,freq);
	waitpid(pid,NULL,0);
}

short *get_mbrola_wave(char *phonemes,int *len,char *voice)
{
	int to_mbr[2],from_mbr[2];
	char *waveform=NULL;
	int wavesize=0;
	double d_speed=(v_rate > 0)?(1.0 - v_rate/200.0):(1.0-v_rate/100.0);
	double d_pitch=(v_pitch < 0)?(1.0 + v_pitch/200.0):(1.0+v_pitch/100.0);
	int pid;
	char buf[64],buffer[4096];
	int contrast=ensure(strdic_get_int(module_settings,"mbrola_contrast",0),0,100);
	double d_contrast=(contrast > 0)?(0.03+contrast/1000.0):0.0;
	ignore(pipe(to_mbr));
	ignore(pipe(from_mbr));
	pid=fork();
	if (pid<0) {
		close(to_mbr[0]);
		close(to_mbr[1]);
		close(from_mbr[0]);
		close(from_mbr[1]);
		return NULL;
	}
	if (!pid) {
		close(to_mbr[1]);
		close(from_mbr[0]);
		dup2(to_mbr[0],0);
		dup2(from_mbr[1],1);
		execlp("mbrola","mbrola","-e",voice,"-","-",NULL);
		exit(1);
	}
	close(to_mbr[0]);
	close(from_mbr[1]);
	sprintf(buf,";;T=%.3f\n;;F=%.3f\n",d_speed,d_pitch);
	ignore(write(to_mbr[1],buf,strlen(buf)));
	ignore(write(to_mbr[1],phonemes,strlen(phonemes)));
	close(to_mbr[1]);
	wavesize=0;
	for (;;) {
		int n=read(from_mbr[0],buffer,4096);
		if (n<=0) break;
		waveform=ralloc(waveform,wavesize+n);
		memcpy(waveform+wavesize,buffer,n);
		wavesize+=n;
	}
	close(from_mbr[0]);
	waitpid(pid,NULL,0);
	if (!wavesize) return NULL;
	if (contrast > 0) {
		apply_contrast((signed short *)waveform,wavesize/2,d_contrast);
	}
	*len=wavesize/2;
	return (short *)waveform;
}
