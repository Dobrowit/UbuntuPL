Instalacja:

1) Jesli korzystasz z Ivony w wersji SAPI:

   zainstaluj Ivol SAPI51 ze strony
   http://milena.polip.com/download.shtml#dlinne
   i uruchom serwer

   Jesli korzystasz z polecenia ivonacl - nie rob nic

2) zainstaluj biblioteke libivolektor i program testowy ivolektor
   (make && sudo make install)

3) skopiuj plik _ivolektor.cfg do swojego katalogu domowego jako
   .ivolektor.cfg i wpisz prawidlowe sciezki.

4) Jesli w systemie masz polecenie play (raczej masz, jesli nie to
   musisz zainstalowac soxa potrafiacego czytac format raw, w przypadku
   Ubuntu sox-fmt-all czy jakos tak), wydaj polecenie ivolektor
   (ew. z parametrem -v glos, gdzie glos to nazwa sekcji w pliku
   .ivolektor.cfg). Ivona powinna sie odezwac.


