/*
 * libivolektor.h - libivolektor headers
 * Copyright (C) Bohdan R. Rau 2011 <ethanak@polip.com>
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program.  If not, write to:
 * 	The Free Software Foundation, Inc.,
 * 	51 Franklin Street, Fifth Floor
 * 	Boston, MA  02110-1301, USA.
 */
#ifndef ETH_LIBIVOLEKTOR_H
#define ETH_LIBIVOLEKTOR_H 1

struct IVOL_data {
    int sex;
    int freq;
    double silmpx;
};


#define IVOL_MALE 0
#define IVOL_FEMALE 1


#ifdef __cplusplus
extern "C" {
#endif

struct IVOL_data *IVOL_open(
    char *name,
    char **error);

struct IVOL_data *IVOL_openNetwork(
    char *name,
    char *host,
    int port,
    char **error);
    
void IVOL_close(
    struct IVOL_data *handle);

short *IVOL_getWave(
    struct IVOL_data *handle,
    char *iso2text,
    int *length,
    char **error);

int IVOL_trimWave(
    struct IVOL_data *handle,
    short *wave,
    int length,
    int *offset, // ilość sampli pomijanych na początku
    int *rest);  // ilość sampli pomijanych na końcu


void *IVOL_initWave(
    struct IVOL_data *handle,
    char *iso2text,
    char **error);

short *IVOL_fetchWave(
    struct IVOL_data *handle,
    void *f,
    int *sample_length,
    char **error);

    
char *IVOL_toiso2(
    char *utf8text);
    
short *IVOL_getSentence(struct IVOL_data *handle,
    char *sentence,
    int *sample_offset, // początek po pauzie
    int *sample_count,  // ilość sampli do pauzy
    int *sample_rest,   // ile można wykorzystać do pauzy
    double pause_factor, // mnożnik długości pauz
    char **error);

int IVOL_trimLastPart(struct IVOL_data *handle,
    short *wave,
    int length,
    int *out_length,
    int *rest);

short *IVOL_Repauser(struct IVOL_data *handle,
    short *wave,
    int *len,
    double factor,
    int *offset,
    int *rest);

char ** IVOL_voices(void);

const char * const IVOL_version(void);

#ifdef __cplusplus
}
#endif

#endif
