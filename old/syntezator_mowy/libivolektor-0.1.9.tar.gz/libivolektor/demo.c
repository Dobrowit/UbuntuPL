#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <getopt.h>
#include "libivolektor.h"
#include <locale.h>

struct IVOL_data *ivona;
char *output_name;

void help(char *name)
{
    char **voices=IVOL_voices();
    int i;
    fprintf(stderr,"Ivolektor %s (C) 2011 Bohdan R. Rau <ethanak@polip.com>\n",IVOL_version());
    fprintf(stderr,"Sposob uzycia:\n%s [-H host] [-P port] [-v voice] [-p pauses] [-t tempo (0.5..2.0)] [-o file] [slowo...]\n",name);
    if (voices) {
    	fprintf(stderr,"Dostepne glosy:\n");
	for (i=0;voices[i];i++) fprintf(stderr,"  %s\n",voices[i]);
    }
    exit(0);
}

int main(int argc,char *argv[])
{
    char *err,*str;
    short *wave;
    int offset,length,brklen;
    double factor=1.0;
    int port=0;
    int tempo=0;
    double tempo_fac;
    char *host=NULL;
    char *voice="ewa";
    char buf[256];
    
    for (;;) {
        int copt=getopt(argc,argv,"hv:p:P:H:t:o:");
        if (copt < 0) break;
        switch(copt) {
            case 'H':
            host=strdup(optarg);
            continue;
            case 'P':
            port=strtol(optarg,NULL,10);
            continue;
            case 'p':
            factor=strtod(optarg,NULL);
            continue;
            case 'v':
            voice=strdup(optarg);
            continue;
            case 'o':
            output_name=strdup(optarg);
            continue;
	    case 't':
	    tempo=1;
	    tempo_fac=strtod(optarg,NULL);
	    if (tempo_fac < 0.499 || tempo_fac > 2.001) help(argv[0]);
	    continue;
            default:
            help(argv[0]);
        }
    }
    setlocale(LC_MESSAGES,"");
    if (optind >= argc) str="Test testowy";
    else {
        int i,len=0;
        for (i=optind;i<argc;i++) {
            len+=strlen(argv[i])+1;
        }
        str=malloc(len);
        for (i=optind;i<argc;i++) {
            if (i==optind) strcpy(str,argv[i]);
            else {
                strcat(str," ");
                strcat(str,argv[i]);
            }
        }
    }
    ivona=IVOL_openNetwork(voice,host,port,&err);
    if (!ivona) {
        fprintf(stderr,"%s\n",err);
        exit(1);
    }
    wave=IVOL_getSentence(ivona,str,&offset,&length,&brklen,factor,&err);
    if (!wave) {
        fprintf(stderr,"%s\n",err);
        exit(1);
    }
    sprintf(buf,"%s -q -t raw -s -c 1 -r %d -2 -",output_name?"sox":"play",ivona->freq);
    if (output_name) sprintf(buf+strlen(buf)," '%s'",output_name);
    if (tempo) sprintf(buf+strlen(buf)," tempo -s %.2f",tempo_fac);
    FILE *f=popen(buf,"w");
    if (f) {
        fwrite(wave+offset,length,2,f);
        pclose(f);
    }
    exit(0);
}

