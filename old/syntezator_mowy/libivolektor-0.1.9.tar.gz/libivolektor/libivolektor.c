/*
 * libivolektor.c - Ivona interface
 * Copyright (C) Bohdan R. Rau 2011 <ethanak@polip.com>
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program.  If not, write to:
 * 	The Free Software Foundation, Inc.,
 * 	51 Franklin Street, Fifth Floor
 * 	Boston, MA  02110-1301, USA.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <iconv.h>

#include <fcntl.h>
#include <errno.h>
#include "libivolektor.h"

const char * const IVOL_version(void)
{
    return IVOL_VERSION_B;
}

static char *utf2iso(char *str);
static char *iso2utf(char *str);
static char *trim(char *str);

#include "ivol_config.c"

#define IVOL_MODE_NATIVE 1
#define IVOL_MODE_RBE 2


#define IVOL_FRAME_LENGTH 256

struct IVOL_PrivData {
    struct IVOL_data public;
    struct ivolConf *conf;
    struct ivolSection *sect;
    int mode;

    int timeout;

    /* native */
    struct sockaddr_in native_sinadr;
    int native_port;
    int native_respawn;
    char *native_ivonacl;
    char *native_ivonaso;
    int native_respawn_pid;

    /* rockbox */
    struct sockaddr_in rockbox_sinadr;
    int rockbox_port;
    int rockbox_ethanak;
    char *rockbox_output_dir; // dla ethanak=0
    int rockbox_voice_id;
    int rockbox_autospawn;
    char *rockbox_spawn_dir;
    char *rockbox_spawn_cmd;
    char *rockbox_wine;
};

#include "ivol_network.c"
#include "ivol_native.c"
#include "ivol_rockbox.c"

static struct IVOL_data *ivol_open_network(char *name,char *host,int port,char **error)
{
    struct ivolSection *ise;
    char *pm;
    struct ivolConf *conf=ivol_ReadConfig("ivolektor.cfg");
    if (!conf) {
        if (error) *error=strdup(strerror(errno));
        return NULL;
    }
    if (conf->ErrorStatus) {
        if (error) {
            *error=malloc(strlen(conf->Error)+128);
            sprintf(*error,"%s w linii %d",conf->Error,conf->ErrorLine);
        }
        ivol_FreeConf(conf);
        return NULL;
    }
    for (ise=conf->sections;ise;ise=ise->next) {
        if (!strcasecmp(ise->name,name)) break;
    }
    if (!ise) {
        ivol_FreeConf(conf);
        if (error) {
            *error=malloc(strlen(name)+128);
            sprintf(*error,"Brak sekcji [%s] w konfiguracji",name);
        }
        return NULL;
    }
    pm=ivol_ConfParam(ise,"mode");
    if (!pm) {
        if (error) {
            *error=malloc(strlen(name)+128);
            sprintf(*error,"Brak parametru 'mode' w sekcji [%s]",name);
        }
        ivol_FreeConf(conf);
        return NULL;
    }
    if (!strcasecmp(pm,"native")) {
        return ivolOpenNative(conf,ise,host,port,error);
    }
    if (!strcasecmp(pm,"opensapi.rockbox")) {
        return ivolOpenRockbox(conf,ise,host,port,error);
    }
    if (error) {
        *error=malloc(strlen(name)+strlen(pm)+128);
        sprintf(*error,"Nieznany tryb '%s' w sekcji [%s]",pm,name);
    }
    ivol_FreeConf(conf);
    return NULL;
}
struct IVOL_data *IVOL_open(char *name,char **error)
{
    return ivol_open_network(name,NULL,0,error);
}

struct IVOL_data *IVOL_openNetwork(char *name,char *host,int port,char **error)
{
    return ivol_open_network(name,host,port,error);
}



static char *a_string[]={
"\240","!"," cent "," funt "," waluta "," jen "," kreska ",
" paragraf "," "," k~!opyrajt "," ","\"","","\255"," rejestr ",
"-"," stopie\361 "," plus minus "," kwadrat "," sze\266cian ",
" "," mikro"," ","."," "," jeden "," ","\""," jedna czwarta ",
" jedna druga "," trzy czwarte ","?","A","A","A","A","E","O","E",
"S~'","E","E","E","E","I","I","I","I","D","\321","O","\323","O",
"O","E"," razy ","E","U","U","U","I","Y","T","s~'","a","a","a","a",
"e","o","e","s~'","e","e","e","e","i","i","i","i","d","\361","o",
"\363","o","o","e"," dzielone ","e","u","u","u","i","y","t","y","A",
"a","E","e","\241","\261","\306","\346","C","c","C","c","Cz","cz",
"D\277","e\277","D","d","E","e","E","e","E","e","\312","\352","E",
"e","G","g","G","g","G","g","G","g","H","h","H","H","I","i","I","i","I",
"i","I","i","I","i","E","e","J","j","K","k","k","L","l","L","l","L","l",
"L","l","\243","\263","\321","\361","N","n","\321","\361","n",
"NG","ng","O","o","O","o","O","o","E","e","R","r","R","r","\257",
"\277","\246","\266","S","s","SZ","sz","SZ","sz","T","t","T","t",
"T","t","U","u","U","u","U","u","U","u","U","u","U","u","W","w","Y",
"y","Y","\254","\274","\257","\277","\257","\277","s"};

static struct {
	int znak;
	char *repr;
} prochar[]={
{0x2116," numer "},
{0x2122," tm "},
{0,NULL}};

#define pushout(n) do {if (outstr) outstr[pos]=n;pos++;} while (0)

static int uni_isspace(int znak)
{
	int i;
	static int spacje[]={0x1680,0x180e,0x2028,0x2029,0x205f,0x3000,0};
	if (znak<=0x20) return 1;
	if (znak>=0x7f && znak <=0xa0) return 1;
	if (znak>=0x2000 && znak <=0x200b) return 1;
	for (i=0;spacje[i];i++) if (znak==spacje[i]) return 1;
	return 0;
}

static int get_unichar(char **str)
{
	int znak,n,m;
	if (!*str) return 0;
	znak=(*(*str)++) & 255;
	if (!(znak & 0x80)) return znak;
	if ((znak & 0xe0)==0xc0) n=1;
	else if ((znak & 0xf0)==0xe0) n=2;
	else return 0;
	znak &= 0x1f;
	while (n--) {
		m=*(*str)++ & 255;
		if ((m & 0xc0)!=0x80) {
			return 0;
		}
		znak=(znak<<6) | (m & 0x3f);
	}
	return znak;
}

static int utf2iso_mp(char *instr,char *outstr)
{
	int pos=0;
	int znak,i;
	while (*instr) {
		char *c=instr;
		znak=get_unichar(&c);
		if (!uni_isspace(znak)) break;
		instr=c;
	}
	if (!*instr) {
		return 0;
	}
	while (*instr) {
		znak=get_unichar(&instr);
		if (znak=='\r') {
			if (*instr=='\n') instr++;
			pushout('\n');
			continue;
		}
		if (znak=='\n') {
			pushout('\n');
			continue;
		}
		if (uni_isspace(znak)) {
			pushout(' ');
			continue;
		}
		if (znak==',' && *instr==',') {
			instr++;
			pushout('"');
			continue;
		}
		if (znak <0x80) {
			pushout(znak);
			continue;
		}
		if (znak == 0x2022) {
			pushout('*');
			continue;
		}
		if (znak == 0x2026) {
			pushout('.');
			pushout('.');
			pushout('.');
			continue;
		}
		if (znak==0x218) znak=0x15e;
		else if (znak==0x219) znak=0x15f;
		else if (znak==0x21a) znak=0x162;
		else if (znak==0x21b) znak=0x163;
		if (znak<=0x17f) {
			char *d=a_string[znak-0xa0];
			while (*d) {
				pushout(*d);
				d++;
			}
			continue;
		}
		if (znak >= 0x2018 && znak <=0x201b) {
			pushout('\'');
			continue;
		}
		if ((znak >= 0x201c && znak <=0x201f) || znak==0x2039 || znak==0x203a) {
			pushout('"');
			continue;
		}
		if (znak== 0x2013 || znak == 0x2014 || znak == 0x2212 || znak == 0x2015) {
			pushout('-');
			continue;
		}
		for (i=0;prochar[i].znak;i++) if (prochar[i].znak == znak) break;
		if (prochar[i].znak) {
			char *c=prochar[i].repr;
			for (;*c;c++) {
				pushout(*c);
			}
			continue;
		}
        pushout(' ');
	}
	pushout(0);
	return pos;
}

static char *utf2iso(char *str)
{
    int n=utf2iso_mp(str,NULL);
    char *so;
    if (n<=0) return NULL;
    so=malloc(n+1);
    utf2iso_mp(str,so);
    return so;
}

static char *iso2utf(char *str)
{
    char *utf;
    size_t p1,p2;
    char *src,*dst;
    iconv_t ic;

    ic=iconv_open("UTF-8","iso-8859-2");
    p1=strlen(str);
    p2=6*p1;
    utf=malloc(p2+1);
    src=str;
    dst=utf;
    iconv(ic,&src,&p1,&dst,&p2);
    *dst=0;
    iconv_close(ic);
    return utf;
}

static double ivol_compute_frame(short *w)
{
    int j;double sum,d;
    sum=0.0;
    for (j=0;j<IVOL_FRAME_LENGTH;j++) {
        d=w[j]/32767.0;
        if (d<0) d=-d;
        sum+=d;
    }
    return sum/IVOL_FRAME_LENGTH;
}

static void normalize_wave(short *wave,int slength)
{
    int mxn,i;
    for (i=mxn=0;i<slength;i++) {
        if (wave[i]>mxn) mxn=wave[i];
        else if (-wave[i]>mxn) mxn=-wave[i];
    }
    if (mxn < 32700 && mxn > 100) {
        double mpx=32767.0/mxn;
        for (i=0;i<slength;i++) wave[i] *= mpx;
    }
}

static short *ivol_getWave(struct IVOL_PrivData *handle,char *iso2text,int *length,char **error)
{
    int slength,mxn,i;
    short *wave;
    switch (handle->mode) {
        case IVOL_MODE_NATIVE:
        wave=ivol_NativeGetWave(handle,iso2text,&slength,error);
        break;
        case IVOL_MODE_RBE:
        wave=ivol_RockboxGetWave(handle,iso2text,&slength,error);
        break;

        default:
        if (error) *error=strdup("Błędny MODE");
        return NULL;
    }
    if (!wave) return NULL;
    normalize_wave(wave,slength);
    *length=slength;
    return wave;
}


static int ivol_trimWave(struct IVOL_PrivData *handle,short *wave,int length,int *offset,int *rest)
{
    int i,ofs,rst;double sum;
    /* w handle można trzymać np. wartości odcięć */
    ofs=-1;rst=-1;
    for (i=0;i<length-IVOL_FRAME_LENGTH;i+=IVOL_FRAME_LENGTH) {
        sum=ivol_compute_frame(wave+i)  * handle ->public.silmpx ;
        if (sum >= 0.03) {
            ofs=i;
            break;
        }
    }
    if (ofs < 0) return -1;
    for (i=length-IVOL_FRAME_LENGTH;i>ofs;i-=IVOL_FRAME_LENGTH) {
        sum=ivol_compute_frame(wave+i)  * handle ->public.silmpx ;
        if (sum >= 0.05) {
            rst=i+IVOL_FRAME_LENGTH;
            break;
        }
    }
    if (rst < 0) return -1;
    *offset=ofs;
    *rest=length-rst;
    return 0;
}

static int ivol_trimLastPart(struct IVOL_PrivData *handle,
    short *wave,
    int length,
    int *out_length,
    int *rest)
{
    int i,phase,rlen,slen;double sum;
    for (i=length-IVOL_FRAME_LENGTH,phase=0;i>0;i-=IVOL_FRAME_LENGTH) {
        sum=ivol_compute_frame(wave+i) * handle ->public.silmpx;
        if (!phase) {
            if (sum > 0.1) phase=1;
            continue;
        }
        if (phase == 1) {
            if (sum < 0.01) {
                rlen=i;
                phase=2;
            }
            continue;
        }
        if (sum >=0.05) {
            phase=3;
            slen=i+IVOL_FRAME_LENGTH;
            break;
        }
    }
    if (phase != 3) return -1;
    *out_length=slen;
    *rest=rlen-slen;
    return 0;
}


/* publiczne funkcje */
static short *ivol_repauser(struct IVOL_PrivData *handle,short *wave,int *len,double factor,int *offset,int *rest);

short *IVOL_getSentence(struct IVOL_data *handle,
    char *sentence,
    int *sample_offset,
    int *sample_count,
    int *sample_rest,
    double pause_factor,
    char **error)
{
    short *wave,*wave2;
    int soffset,srest,slength;
    char *sout;

    sout=utf2iso(sentence);
    if (!sout) {
        if (error) *error=strdup("Puste zdanie");
        return NULL;
    }
    wave=ivol_getWave((struct IVOL_PrivData *)handle,sout,&slength,error);
    free(sout);
    if (!wave) return NULL;

    soffset=0;
    srest=0;
    wave2=ivol_repauser((struct IVOL_PrivData *)handle,wave,&slength,pause_factor,&soffset,&srest);
    if (wave2) {
    	free(wave);
	wave=wave2;
    }
    *sample_offset=soffset;
    *sample_count=slength-(soffset+srest);
    *sample_rest=srest;
    return wave;
}

short *IVOL_getWave(struct IVOL_data *handle,char *iso2text,int *length,char **error)
{
    return ivol_getWave((struct IVOL_PrivData *)handle,iso2text,length,error);
}

int IVOL_trimWave(struct IVOL_data *handle,short *wave,int length,int *offset,int *rest)
{
    return ivol_trimWave((struct IVOL_PrivData *)handle,wave,length,offset,rest);
}

char *IVOL_toiso2(char *str)
{
    return utf2iso(str);
}

int IVOL_trimLastPart(struct IVOL_data *handle,
    short *wave,
    int length,
    int *out_length,
    int *rest)
{
    return ivol_trimLastPart((struct IVOL_PrivData *)handle,wave,length,out_length,rest);
}

void IVOL_close(struct IVOL_data *handle)
{
    ivol_FreeConf(((struct IVOL_PrivData *)handle)->conf);
    switch (((struct IVOL_PrivData *)handle)->mode) {
        case IVOL_MODE_NATIVE:
        ivol_NativeClose((struct IVOL_PrivData *)handle);
        break;
        case IVOL_MODE_RBE:
        ivol_RockboxClose((struct IVOL_PrivData *)handle);
        break;
    }
    free(handle);
}

void *IVOL_initWave(struct IVOL_data *handle,char *iso2text,char **error)
{
    switch (((struct IVOL_PrivData *)handle)->mode) {
        case IVOL_MODE_NATIVE:
        return (void *)ivol_NativeInitWave((struct IVOL_PrivData *)handle,iso2text,error);
        break;
        case IVOL_MODE_RBE:
        return (void *)ivol_RockboxInitWave((struct IVOL_PrivData *)handle,iso2text,error);
        break;
        default:
        if (error) *error=strdup("Błędny MODE");
        return NULL;
    }
    return NULL;
}

short *IVOL_fetchWave(struct IVOL_data *handle,void *f,int *sample_length,char **error)
{
    switch (((struct IVOL_PrivData *)handle)->mode) {
        case IVOL_MODE_NATIVE:
        return (void *)ivol_NativeFetchWave((struct IVOL_PrivData *)handle,(int)f,sample_length,error);
        break;
        case IVOL_MODE_RBE:
        return (void *)ivol_RockboxFetchWave((struct IVOL_PrivData *)handle,(FILE *)f,sample_length,error);
        break;
        default:
        if (error) *error=strdup("Błędny MODE");
        return NULL;
    }
    return NULL;
}

void IVOL_freeWaveHandler(struct IVOL_data *handle,void *hd)
{
    switch (((struct IVOL_PrivData *)handle)->mode) {
	case IVOL_MODE_NATIVE:
	ivol_NativeFreeWHD((int)hd);
	break;

	case IVOL_MODE_RBE:
	ivol_RockboxFreeWHD((FILE *)hd);
	break;

	default:
	break;
    }
}
#include "ivol_pauser.c"
