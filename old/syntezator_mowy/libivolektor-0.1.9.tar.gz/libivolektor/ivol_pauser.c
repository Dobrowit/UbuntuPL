/*
 * ivol_pauser.c - pause shortener for libivolektor
 * Copyright (C) Bohdan R. Rau 2011 <ethanak@polip.com>
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program.  If not, write to:
 * 	The Free Software Foundation, Inc.,
 * 	51 Franklin Street, Fifth Floor
 * 	Boston, MA  02110-1301, USA.
 */


static short *ivol_repauser(struct IVOL_PrivData *handle,short *wave,int *len,double factor,int *offset,int *rest)
{
	int nwlen=*len;
	short *new_wave;
	int nwpos;
	int ofs,rst,nsamples;
	short *old_rest;
	int rc=ivol_trimWave(handle,wave,*len,&ofs,&rst);
	
	void wave_cpy(int cnt)
	{
		if (nwpos+cnt >= nwlen) {
			nwlen=nwpos+cnt+8192;
			new_wave=realloc(new_wave,sizeof(short)*nwlen);
		}
		memcpy(new_wave+nwpos,wave,2*cnt);
		nwpos+=cnt;
		wave+=cnt;
	}
	
	void pause_cpy(int pausamples)
	{
		int cnt=pausamples * factor;
		short *w1,*w2;int i,n1,n2;
		//printf("Pause %d/%d samples\n",cnt,pausamples);
		if (nwpos+cnt >= nwlen) {
			nwlen=nwpos+cnt+8192;
			new_wave=realloc(new_wave,sizeof(short)*nwlen);
		}
		if (cnt<1) return;
		if (cnt < pausamples) {
            w1=wave;
			w2=wave+pausamples-cnt;
			wave+=pausamples;
			for (i=0;i<cnt;i++) {
				double mpx;
				mpx=(double)i/(double) cnt;
				new_wave[nwpos++]=(*w1++) * (1.0-mpx) + (*w2++) * mpx;
			}
			return;
		}
		w1=wave;
		wave+=pausamples;
		
		n1=pausamples/2;
		n2=pausamples-n1;
		w2=w1+n1;
		memcpy(new_wave+nwpos,w1,sizeof(short) * n1);
		nwpos+=n1;
		for (i=pausamples;i<cnt;i++) new_wave[nwpos++]=0;
		//printf("Store %d\n",cnt-pausamples);
		memcpy(new_wave+nwpos,w2,sizeof(short) * n2);
		nwpos+=n2;
	}
	
	if (rc < 0) return NULL;
	old_rest=wave+((*len)-rst);
	if (offset)*offset=ofs;
	if (rest)*rest=rst;
	if (factor > 1.0) nwlen=(*len) * factor;
	new_wave=malloc(sizeof(short) * nwlen);
	nwpos=0;
	wave_cpy(ofs);
	nsamples=(*len)-(ofs+rst);
	for (;;) {
		int i,j;
		double sum;
		double lsum=0;
		int pause_start,pause_end;
		pause_start=-1;
		pause_end=-1;
		for (i=0;i<nsamples-IVOL_FRAME_LENGTH;i+=IVOL_FRAME_LENGTH) {
			sum=ivol_compute_frame(wave+i)  * handle ->public.silmpx;
			if (sum >= lsum) {
				lsum=sum;
				continue;
			}
			if (sum < 0.005) {
				pause_start=i;
				break;
			}
		}
		if (pause_start < 0) break;
		for (i=pause_start+IVOL_FRAME_LENGTH;i<nsamples-IVOL_FRAME_LENGTH;i+=IVOL_FRAME_LENGTH) {
			sum=ivol_compute_frame(wave+i)  * handle ->public.silmpx;
			if (sum <=lsum) {
				lsum=sum;
				continue;
			}
			if (sum > 0.005) {
				pause_end=i;
				break;
			}
		}
		if (pause_end < 0) break;
		if (pause_end < pause_start + 4 * IVOL_FRAME_LENGTH) {
			wave_cpy(pause_end);
			nsamples-=pause_end;
			continue;
		}
		wave_cpy(pause_start);
		nsamples-=pause_start;
		if (pause_end - pause_start < 4 * IVOL_FRAME_LENGTH * factor) {
            pause_end = pause_start + 4 * IVOL_FRAME_LENGTH * factor;
        }
		
		
		pause_end-=pause_start;
		pause_cpy(pause_end);
		nsamples-=pause_end;
	}
	wave_cpy(nsamples+rst);
	*len=nwpos;
	return new_wave;
}

short *IVOL_Repauser(struct IVOL_data *handle,short *wave,int *len,double factor,int *offset,int *rest)
{
	return ivol_repauser((struct IVOL_PrivData *)handle,wave,len,factor,offset,rest);
}

