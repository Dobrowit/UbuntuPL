/*
 * ivol_config.c - part of libivolektor library
 * Copyright (C) Bohdan R. Rau 2011 <ethanak@polip.com>
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program.  If not, write to:
 * 	The Free Software Foundation, Inc.,
 * 	51 Franklin Street, Fifth Floor
 * 	Boston, MA  02110-1301, USA.
 */


struct ivolParam {
    struct ivolParam *next;
    char *value;
    char name[1];
};

struct ivolSection {
    struct ivolSection *next;
    char name[32];
    struct ivolParam *params;
};

struct ivolConf {
    struct ivolSection *sections;
    char *Error;
    int ErrorLine;
    int ErrorStatus;
};


static char *trim(char *str)
{
    char *d,*e;
    while (*str && isspace(*str)) str++;
    for (d=e=str;*d;d++) if (!isspace(*d)) e=d+1;
    *e=0;
    return str;
}

static char *xfree(char *c)
{
	if (c) free(c);
}

static char *pathdup(char *c)
{
	int le;char *ot,*ev;
	if (!c) return NULL;
	if (*c != '~' || c[1]!='/') return strdup(c);
	ev=getenv("HOME");
	if (!ev) return strdup(c);
	le=strlen(c)+strlen(ev);
	ot=malloc(le);
	strcpy(ot,ev);
	strcat(ot,c+1);
	return ot;
}

static char *unquote(char *str)
{
    int quot=0;
    char *c,*d;
    if (*str=='"' || *str== '\'') {
        quot=*str++;
    }
    for (c=d=str;*c;) {
        if (*c==quot) {
            c++;
            if (*c) return 0;
            break;
        }
        if (*c != '\\') {
            *d++=*c++;
            continue;
        }
        c++;
        if (*c=='n') *d++='\n';
        else if (*c=='r') *d++='\r';
        else if (*c=='t') *d++='\t';
        else *d++=*c;
        c++;
    }
    *d=0;
    return str;
}

static int ivol_ConfSection(struct ivolConf *ic,char *str)
{
    struct ivolSection *sec;
    if (strlen(str)>31) {
        ic->Error="Nazwa zbyt długa";
        return -1;
    }
    for (sec=ic->sections;sec;sec=sec->next) {
        if (!strcasecmp(sec->name,str)) {
            ic->Error="Powtórzona nazwa";
            return -1;
        }
    }
    sec=malloc(sizeof(*sec));
    memset(sec,0,sizeof(*sec));
    strcpy(sec->name,str);
    sec->next=ic->sections;
    ic->sections=sec;
    return 0;
}
static int ivol_ParseConfLine(struct ivolConf *ic,char *str)
{
    char *c;
    struct ivolParam *ip;
    str=trim(str);
    if (*str == '#' || !*str) return 0;
    if (*str=='[') {
        str++;
        c=strchr(str,']');
        if (!c) {
            ic->Error="Syntax error";
            return -1;
        }
        *c++=0;
        if (*c) {
            ic->Error="Syntax error";
            return -1;
        }
        return ivol_ConfSection(ic,str);
    }
    c=strchr(str,'=');
    if (!c) {
        ic->Error="Syntax error";
        return -1;
    }
    *c++=0;
    str=trim(str);
    c=trim(c);
    if (!*str || !*c) {
        ic->Error="Syntax error";
        return -1;
    }
    c=unquote(c);
    if (!c) {
        ic->Error="Syntax error";
        return -1;
    }
    if (!ic->sections) {
        ic->Error="Brak zdefiniowanej sekcji";
        return -1;
    }
    for (ip=ic->sections->params;ip;ip=ip->next) {
        if (!strcasecmp(ip->name,str)) {
            ic->Error="Powielony parametr";
            return -1;
        }
    }
    ip=malloc(sizeof(*ip)+strlen(str)+strlen(c)+2);
    strcpy(ip->name,str);
    ip->value=ip->name+strlen(ip->name)+1;
    strcpy(ip->value,c);
    ip->next=ic->sections->params;
    ic->sections->params=ip;
    return 0;
}


static FILE *ivol_openConfig(char *fname)
{
	FILE *f;
	char buf[256];
	f=fopen(fname,"r");
	if (f || *fname=='/' || *fname=='.') return f;
	sprintf(buf,"%s/.%s",getenv("HOME"),fname);
	return fopen(buf,"r");

}

static struct ivolConf *ivol_ReadConfig(char *fname)
{
    FILE *f;
    char buf[256];
    struct ivolConf *ic;

    f=ivol_openConfig(fname);
    if (!f) {
        return NULL;
    }
    ic=malloc(sizeof(*ic));
    memset(ic,0,sizeof(*ic));
    ic->ErrorLine=0;
    while(fgets(buf,256,f)) {
        ic->ErrorLine++;
        if (ivol_ParseConfLine(ic,buf)) {
            fclose(f);
            ic->ErrorStatus=1;
            return ic;
        }
    }
    fclose(f);
    ic->ErrorStatus=0;
    return ic;
}

void ivol_FreeConf(struct ivolConf *conf)
{
    struct ivolSection *se;
    struct ivolParam *pa;
    while ((se=conf->sections)) {
        conf->sections=se->next;
        while ((pa=se->params)) {
            se->params=pa->next;
            free(pa);
        }
        free(se);
    }
    free(conf);
}

static char *ivol_ConfParam(struct ivolSection *ise,char *name)
{
    struct ivolParam *ipa;
    for (ipa=ise->params;ipa;ipa=ipa->next) if (!strcasecmp(ipa->name,name)) return ipa->value;
    return NULL;
}

static int ivol_bool(char *pm)
{
    if (!strcasecmp(pm,"no") || !strcasecmp(pm,"false")) return 0;
    if (!strcasecmp(pm,"yes") || !strcasecmp(pm,"true")) return 1;
    return -1;
}

static int str_param(char *pm,char *pat)
{
    if (!*pm) return 0;
    for (;*pm;) {
        if (tolower(*pm++) != tolower(*pat++)) return 0;
    }
    return 1;
}


static char *ivol_File(struct ivolSection *ise,char *name,char **error)
{
    char *pm;
    pm=ivol_ConfParam(ise,name);
    if (!pm) {
        if (error) {
            *error=malloc(strlen(ise->name)+128);
            sprintf(*error,"Brak parametru '%s' w sekcji [%s]",name,ise->name);
        }
        return NULL;
    }
    if (*pm != '/' && strncmp(pm,"~/",2)) {
        if (error) {
            *error=malloc(strlen(ise->name)+128);
            sprintf(*error,"Ścieżka podana w '%s' nie jest absolutna w sekcji [%s]",name,ise->name);
        }
        return NULL;
    }
    return pm;
}

char **IVOL_voices(void)
{
	char **voices;
	int nv,i,pass,ns;
	voices=NULL;
	char buf[256],*str,*c,*ptr;
	FILE *f=ivol_openConfig("ivolektor.cfg");
	if (!f) return NULL;
	ns=sizeof(*voices);
	for (pass=0;pass<2;pass++) {
		nv=0;
		fseek(f,0,SEEK_SET);
		while(fgets(buf,256,f)) {
			str=trim(buf);
			if (*str == '#' || !*str) continue;
			if (*str!='[') continue;
			str++;
			c=strchr(str,']');
			if (!c) continue;
            		*c=0;
			if (!pass) {
				nv++;
				ns+=sizeof(*voices) + (c-str)+1;
				continue;
			}
			*str=toupper(*str);
			for (c=str+1;*c;c++) *c=tolower(*c);
			for (i=0;i<nv;i++) if (!strcmp(str,voices[i])) break;
			if (i<nv) continue;
			strcpy(ptr,str);
			voices[nv++]=ptr;
			ptr+=strlen(ptr)+1;
		}
		if (pass) {
			voices[nv]=NULL;
			break;
		}
		voices=malloc(ns);
		ptr=(char *)(voices+(nv+1));
        }
	fclose(f);
	return voices;
}
