/*
 * ivol_network.c - part of libivolektor library
 * Copyright (C) Bohdan R. Rau 2011 <ethanak@polip.com>
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program.  If not, write to:
 * 	The Free Software Foundation, Inc.,
 * 	51 Franklin Street, Fifth Floor
 * 	Boston, MA  02110-1301, USA.
 */


int ivol_InitAddr(char *host,int port,struct sockaddr_in *sinadr)
{
        if (!inet_aton(host,&sinadr->sin_addr)) {
                struct hostent *h = gethostbyname(host);
                if (!h) return 0;
                memcpy(&(sinadr->sin_addr), h->h_addr, sizeof(struct in_addr));
                endhostent();
        }
        sinadr->sin_family = AF_INET;
        sinadr->sin_port = htons(port);
        return 1;
}


static int connect_nb(int fd,struct sockaddr *sinadr,int msec)
{
	int flags,ret,error;
	fd_set wset;
	struct timeval tv;
	socklen_t len=sizeof(error);
	flags=fcntl(fd,F_GETFL,0);
	if (flags < 0) return -1;
	FD_ZERO(&wset);
	FD_SET(fd,&wset);
	tv.tv_sec=msec/1000;
	tv.tv_usec=(msec % 1000) * 1000;
	if (fcntl(fd,F_SETFL,flags | O_NONBLOCK)<0) return -1;
	ret = connect(fd, sinadr, sizeof(*sinadr));
	if (ret < 0 && errno != EINPROGRESS) return -1;
	if (ret == 0) goto done;
	ret = select(fd + 1, NULL, &wset, NULL, &tv);
	if (ret<0) return -1;
    if (ret == 0) {
        errno = ETIMEDOUT;
        return -1;
    }
    if (!FD_ISSET(fd, &wset)) return -1;
    if(getsockopt(fd, SOL_SOCKET, SO_ERROR, &error, &len) < 0) return -1;
done:
    if (fcntl(fd,F_SETFL,flags)<0) return -1;
    return 0;
}

FILE *ivol_ConnectFile(struct sockaddr_in *sinadr,int msec)
{
    int fd;
    if ((fd = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
        return NULL;
    }
    /*
    if (connect(fd, (struct sockaddr *) sinadr, sizeof(*sinadr)) < 0) {
        close(fd);
        return NULL;
    }
    */
    if (connect_nb(fd, (struct sockaddr *) sinadr,msec) < 0) {
        close(fd);
        return NULL;
    }

    return fdopen(fd,"r+");
}
