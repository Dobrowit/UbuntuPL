/*
 * ivol_rockbox.c - opensapi Ivona driver for libivolektor
 * Copyright (C) Bohdan R. Rau 2011 <ethanak@polip.com>
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program.  If not, write to:
 * 	The Free Software Foundation, Inc.,
 * 	51 Franklin Street, Fifth Floor
 * 	Boston, MA  02110-1301, USA.
 */



static FILE * ivol_spawn_rockbox(struct IVOL_PrivData *ipd)
{
    int ivol_pid;
    char *args[4];
    ivol_pid=fork();
    if (ivol_pid <0) return NULL ;
    if (!ivol_pid) {
        /* child */
        close(0);
        close(1);
        close(2);
        char *cmd=ipd->rockbox_spawn_cmd;
        if (strstr(cmd,"%P")) {
            char *c,*d;
            cmd=malloc(strlen(cmd)+16);
            for (c=ipd->rockbox_spawn_cmd,d=cmd;*c;) {
                if (*c=='%') {
                    c++;
                    if (*c=='P') {
                        sprintf(d,"%d",ipd->rockbox_port);
                        d+=strlen(d);
                        c++;
                        continue;
                    }
                }
                if (*c) *d++=*c++;
            }
            *d=0;
        }
        chdir(ipd->rockbox_spawn_dir);
        args[0]="sh";
        args[1]="-c";
        args[2]=cmd;
        args[3]=NULL;
	if (ipd->rockbox_wine) setenv("WINEPREFIX",ipd->rockbox_wine,1);
        execv("/bin/sh",args);
        exit(0);
    }
    /* parent */
    int i,pn;
    FILE *f=NULL;
    for (i=0;i<15;i++) {
        sleep(1);
        pn=waitpid(ivol_pid,NULL,WNOHANG);
        if (pn == ivol_pid) {
            errno=ECHILD;
            break;
        }
        f=ivol_ConnectFile(&ipd->rockbox_sinadr,ipd->timeout);
        if (f) return f;
    }
    return NULL;
}

static struct IVOL_data *ivolOpenRockbox(struct ivolConf *conf,struct ivolSection *ise,char *param_host,int param_port,char **error)
{
    char *pm;
    int port;
    FILE *f;
    char *voice;
    char *fpath;
    int is_ethanak=0;
    struct IVOL_PrivData *ipd;
    char linebuf[1024];
    char *lpos;
    int vid,fid;
    int aspawn=0;
    int spawned;
    char *spawn_dir=NULL;
    char *spawn_cmd=NULL;

    voice=ivol_ConfParam(ise,"voice");
    if (!voice) {
        if (error) {
            *error=malloc(strlen(ise->name)+128);
            sprintf(*error,"Brak parametru 'voice' w sekcji [%s]",ise->name);
        }
        ivol_FreeConf(conf);
        return NULL;
    }

    pm=ivol_ConfParam(ise,"patch");
    if (pm) {
        is_ethanak=!strcmp(pm,"ethanak");
    }

    pm=ivol_ConfParam(ise,"autospawn");
    if (pm) {
        aspawn=ivol_bool(pm);
        if (aspawn < 0) {
            if (error) {
                *error=malloc(strlen(ise->name)+strlen(pm)+128);
                sprintf(*error,"Błędna wartość '%s' parametru 'autospawn' w sekcji [%s]",
                    pm,ise->name);
            }
            ivol_FreeConf(conf);
            return NULL;
        }
    }
    if (aspawn) {
        spawn_dir=ivol_ConfParam(ise,"spawndir");
        if (!spawn_dir) {
            if (error) {
                *error=malloc(strlen(ise->name)+128);
                sprintf(*error,"Brak parametru 'spawndir' w sekcji [%s]",ise->name);
            }
            ivol_FreeConf(conf);
            return NULL;
        }
        spawn_cmd=ivol_ConfParam(ise,"spawncmd");
        if (!spawn_cmd) {
            if (error) {
                *error=malloc(strlen(ise->name)+128);
                sprintf(*error,"Brak parametru 'spawncmd' w sekcji [%s]",ise->name);
            }
            ivol_FreeConf(conf);
            return NULL;
        }
    }

    if (!is_ethanak) {
        fpath=ivol_ConfParam(ise,"path");
        if (!fpath) {
            if (error) {
                *error=malloc(strlen(ise->name)+128);
                sprintf(*error,"Brak parametru 'path' w sekcji [%s]",ise->name);
            }
            ivol_FreeConf(conf);
            return NULL;
        }
    }
    else {
        fpath=NULL;
    }
//    if (!is_ethanak) {
//        if (error) *error=strdup("Open-Sapi rockbox bez patcha ethanak nie jest obsługiwany");
//        ivol_FreeConf(conf);
//        return NULL;
//    }

    ipd=malloc(sizeof(*ipd));
    memset(ipd,0,sizeof(*ipd));
    ipd->conf=conf;
    ipd->sect=ise;
    ipd->mode=IVOL_MODE_RBE;
    ipd->rockbox_ethanak=is_ethanak;
    ipd->rockbox_output_dir=pathdup(fpath);
    ipd->rockbox_autospawn=aspawn;
    ipd->rockbox_spawn_cmd=pathdup(spawn_cmd);
    ipd->rockbox_spawn_dir=pathdup(spawn_dir);
    ipd->rockbox_wine=pathdup(ivol_ConfParam(ise,"wine"));

    pm=ivol_ConfParam(ise,"silmpx");
    if (pm) ipd->public.silmpx=strtod(pm,NULL);
    else ipd->public.silmpx=1.0;

    pm=ivol_ConfParam(ise,"timeout");
    if (!pm) ipd->timeout=1000;
    else {
		ipd->timeout=strtol(pm,NULL,10);
		if (ipd->timeout < 200) ipd->timeout=200;
		else if (ipd->timeout > 5000) ipd->timeout=5000;
	}

    if (param_port) {
        ipd->rockbox_port=param_port;
    }
    else {
        pm=ivol_ConfParam(ise,"port");
        if (!pm) port=8765;
        else port=strtol(pm,NULL,10);
        ipd->rockbox_port=port;
    }
    if (param_host) pm=param_host;
    pm=ivol_ConfParam(ise,"host");
    if (!pm) pm="127.0.0.1";
    if (strcmp(pm,"127.0.0.1") && strcmp(pm,"localhost")) {
        ipd->rockbox_autospawn=aspawn=0;
    }
    if (!ivol_InitAddr(pm,ipd->rockbox_port,&ipd->rockbox_sinadr)) {
        if(error) {
            *error=malloc(strlen(ise->name)+strlen(pm)+128);
            sprintf(*error,"Błędny adres %s:%d w sekcji [%s]",
                pm,port,ise->name);
        }
        free(ipd);
        ivol_FreeConf(conf);
        return NULL;
    }
    spawned=0;
    f=ivol_ConnectFile(&ipd->rockbox_sinadr,ipd->timeout);
    if (!f && aspawn) {
        f=ivol_spawn_rockbox(ipd);
        if (f) spawned=1;
    }
    if (!f) {
        if (error) *error=strdup(strerror(errno));
        free(ipd);
        ivol_FreeConf(conf);
        return NULL;
    }
    fprintf(f,"getEngine\n");fflush(f);

    fd_set input_fd;
    int fd_inp=fileno(f);
    int rc;
    struct timeval tvi;

    tvi.tv_sec=1;
    tvi.tv_usec=0;
    FD_ZERO(&input_fd);
    FD_SET(fd_inp,&input_fd);
    rc=select(fd_inp+1,&input_fd,NULL,NULL,&tvi);
    if (rc < 0) {
        fclose(f);
        if (error) {
            *error=strdup(strerror(errno));
        }
        free(ipd);
        ivol_FreeConf(conf);
        return NULL;
    }
    if (!FD_ISSET(fd_inp,&input_fd)) {
        fclose(f);
        f=NULL;
        if (aspawn && !spawned) {
            f=ivol_spawn_rockbox(ipd);
            if (f) spawned=1;
        }
        if (!f) {
            if (error) {
                *error=strdup(strerror(errno));
            }
            free(ipd);
            ivol_FreeConf(conf);
            return NULL;
        }
        fprintf(f,"getEngine\n");fflush(f);
    }
    vid=-1;
    while(fgets(linebuf,1024,f)) {
        char *c;
        lpos=linebuf;
        if (strtol(lpos,&lpos,10) != 297) break;
        if (vid != -1) continue;
        if (*lpos++!=':') continue;
        lpos=strchr(lpos,':');
        if (!lpos) continue;
        lpos++;
        fid=strtol(lpos,&lpos,10);
        if (*lpos++!=':') continue;
        c=strchr(lpos,':');
        if (!c) continue;
        *c=0;
        if (strcasecmp(voice,lpos)) continue;
        vid=fid;
    }
    fclose(f);
    if (vid == -1) {
        if (error) {
            *error=malloc(strlen(voice)+strlen(ise->name)+128);
            sprintf(*error,"Brak głosu SAPI '%s' w sekcji [%s]",voice,ise->name);
        }
        free(ipd);
        ivol_FreeConf(conf);
        return NULL;
    }
    ipd->rockbox_voice_id=vid;
    return (struct IVOL_data *)ipd;
}

static int ivol_rockbox_cmd(FILE *f,char *cmd,char *buf)
{
    char *c;int v;
    //printf("Command %s\n",cmd);
    fprintf(f,"%s\n",cmd);
    fflush(f);
    if (!fgets(buf,256,f)) return -1;
    v=strtol(buf,&c,10);
    while (*c && isspace(*c)) c++;
    if (c != buf) strcpy(buf,c);
    //printf("Response %d %s\n",v,buf);
    return v;
}

static FILE *ivol_RockboxInitWave(struct IVOL_PrivData *handle,char *str,char **error)
{
    int rc;
    FILE *f;
    char *ustr,buf[256];
    str=trim(str);
    while (*str && (*str=='<' || isspace(*str))) str++;
    if (!*str) {
        if (error) *error=strdup("Puste zdanie");
        return NULL;
    }
    //if (!handle->rockbox_ethanak) {
    //    if (error) *error=strdup("Open-Sapi rockbox bez patcha ethanak nie jest obsługiwany");
    //    return NULL;
   // }

    f=ivol_ConnectFile(&handle->rockbox_sinadr,handle->timeout);
    if (!f) {
        if (error) *error=strdup(strerror(errno));
        return NULL;
    }
    sprintf(buf,"setEngine %d",handle->rockbox_voice_id);
    rc=ivol_rockbox_cmd(f,buf,buf);
    if (rc<0) {
        if (error) *error=strdup(strerror(errno));
        fclose(f);return NULL;
    }
    char *cmd=(handle->rockbox_ethanak)?"outFile pipe":"outFile osapi.wav";
    rc=ivol_rockbox_cmd(f,cmd,buf);
    if (rc<0) {
        if (error) *error=strdup(strerror(errno));
        fclose(f);return NULL;
    }
    rc=ivol_rockbox_cmd(f,"setVol 100",buf);
    if (rc<0) {
        if (error) *error=strdup(strerror(errno));
        fclose(f);return NULL;
    }
    rc=ivol_rockbox_cmd(f,"setRate 0",buf);
    if (rc<0) {
        if (error) *error=strdup(strerror(errno));
        fclose(f);return NULL;
    }
    ustr=iso2utf(str);
    fprintf(f,"speakMe %s\n",ustr);
    fflush(f);
    free(ustr);
    return f;
}
static short *ivol_RockboxFetchWave(struct IVOL_PrivData *handle,FILE *f,int *sample_length,char **error)
{
    char buf[256],*bptr;
    char *wavestring;
    int stringlen,rc;

    if (!fgets(buf,256,f)) {
        if (error) *error=strdup(strerror(errno));
        fclose(f);return NULL;
    }
    if (!handle->rockbox_ethanak) {
        struct stat sb;
        fclose(f);
        if (strtol(buf,NULL,10) != 201) {
            if (error) *error=strdup(buf);
            return NULL;
        }
        sprintf(buf,"%s/osapi.wav",handle->rockbox_output_dir);
        if (stat(buf,&sb)) {
            if (error) *error=strdup(strerror(errno));
            return NULL;
        }
        stringlen=sb.st_size;
        f=fopen(buf,"r");
        if (!f) {
            if (error) *error=strdup(strerror(errno));
            return NULL;
        }
        goto read_wave;
    }


    rc=strtol(buf,&bptr,10);
    if (rc != 200 || *bptr++!=':') {
        fclose(f);
        if (*error) *error=strdup(trim(buf));
        return NULL;
    }
    bptr=strchr(bptr,':');
    if (!bptr) {
        fclose(f);
        if (*error) *error=strdup(trim(buf));
        return NULL;
    }
    bptr++;
    stringlen=strtol(bptr,NULL,10);
read_wave:
    wavestring=malloc(stringlen);
    rc=fread(wavestring,1,stringlen,f);
    fclose(f);
    int i;
    rc=*(long *)(wavestring+16);
    handle->public.freq=*(long *)(wavestring+24);
    rc+=28;
    stringlen-=rc;
    memcpy(wavestring,wavestring+rc,stringlen);
    *sample_length=stringlen/2;
    return (short *) wavestring;
}

static short *ivol_RockboxGetWave(struct IVOL_PrivData *handle,char *str,int *sample_length,char **error)
{
    FILE *f;
    f=ivol_RockboxInitWave(handle,str,error);
    if (!f) return NULL;
    return ivol_RockboxFetchWave(handle,f,sample_length,error);
}

static void ivol_RockboxFreeWHD(FILE *f)
{
	fclose(f);
}

static void ivol_RockboxClose(struct IVOL_PrivData *handle)
{
	xfree(handle->rockbox_output_dir);
	xfree(handle->rockbox_spawn_dir);
	xfree(handle->rockbox_spawn_cmd);
	xfree(handle->rockbox_wine);

}
