/*
 * ivol_native.c - ivonacl Ivona driver for libivolektor
 * Copyright (C) Bohdan R. Rau 2011 <ethanak@polip.com>
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program.  If not, write to:
 * 	The Free Software Foundation, Inc.,
 * 	51 Franklin Street, Fifth Floor
 * 	Boston, MA  02110-1301, USA.
 */

static struct IVOL_data *ivolOpenNative(struct ivolConf *conf,struct ivolSection *ise,char *param_host,int param_port,char **error)
{
    char *pm,*icl;
    int freq;int port;
    struct IVOL_PrivData *ipd;
    pm=ivol_ConfParam(ise,"frequency");
    if (!pm) {
        if (error) {
            *error=malloc(strlen(ise->name)+128);
            sprintf(*error,"Brak parametru 'frequency' w sekcji [%s]",ise->name);
        }
        ivol_FreeConf(conf);
        return NULL;
    }
    freq=strtol(pm,&pm,10);
    ipd=malloc(sizeof(*ipd));
    memset(ipd,0,sizeof(*ipd));
    ipd->conf=conf;
    ipd->sect=ise;
    ipd->mode=IVOL_MODE_NATIVE;
    ipd->public.freq=freq;
    pm=ivol_ConfParam(ise,"silmpx");
    if (pm) ipd->public.silmpx=strtod(pm,NULL);
    else ipd->public.silmpx=1.0;
    pm=ivol_ConfParam(ise,"timeout");
    if (!pm) ipd->timeout=1000;
    else {
		ipd->timeout=strtol(pm,NULL,10);
		if (ipd->timeout < 200) ipd->timeout=200;
		else if (ipd->timeout > 5000) ipd->timeout=5000;
	}

    if (!param_port) {
        pm=ivol_ConfParam(ise,"port");
        if (!pm) port=9123;
        else port=strtol(pm,NULL,10);
        ipd->native_port=port;
    }
    else {
        ipd->native_port=param_port;
    }
    if (param_host) pm=param_host;
    else pm=ivol_ConfParam(ise,"host");
    if (!pm) pm="127.0.0.1";
    if (!ivol_InitAddr(pm,port,&ipd->native_sinadr)) {
        if(error) {
            *error=malloc(strlen(ise->name)+strlen(pm)+128);
            sprintf(*error,"Błędny adres %s:%d w sekcji [%s]",
                pm,port,ise->name);
        }
        free(ipd);
        ivol_FreeConf(conf);
        return NULL;
    }
    pm=ivol_ConfParam(ise,"sex");
    if (pm) {
        if (str_param(pm,"male")) ipd->public.sex=IVOL_MALE;
        else if (str_param(pm,"female")) ipd->public.sex=IVOL_FEMALE;
        else {
            if (error) {
                *error=malloc(strlen(ise->name)+strlen(pm)+128);
                sprintf(*error,"Błędna wartość '%s' parametru 'sex' w sekcji[%s], dopuszczalne są 'male' lub 'female'",
                    pm,ise->name);
            }
            free(ipd);
            ivol_FreeConf(conf);
            return NULL;
        }
    }
    pm=ivol_ConfParam(ise,"respawn");
    if (pm) {
        int n=ivol_bool(pm);
        if (n<0) {
            if (error) {
                *error=malloc(strlen(ise->name)+strlen(pm)+128);
                sprintf(*error,"Błędna wartość '%s' parametru 'respawn' w sekcji [%s]",
                    pm,ise->name);
            }
            free(ipd);
            ivol_FreeConf(conf);
            return NULL;
        }
        ipd->native_respawn=n;
    }
    if (ipd->native_respawn) {
        pm=ivol_File(ise,"ivonacl",error);
        if (!pm) {
            free(ipd);
            ivol_FreeConf(conf);
            return NULL;
        }
        ipd->native_ivonacl=pathdup(pm);
        pm=ivol_File(ise,"voice",error);
        if (!pm) {
            free(ipd);
            ivol_FreeConf(conf);
            return NULL;
        }
        ipd->native_ivonaso=pathdup(pm);
	ipd->native_ivonacl=pathdup(ipd->native_ivonacl);
    }
    return (struct IVOL_data *)ipd;
}



static int ivol_NativeOpenFD(struct IVOL_PrivData *handle,char **error)
{
    int fd,pid,i;
    if ((fd = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
        if (error) *error=strdup(strerror(errno));
        return -1;
    }
    if (connect_nb(fd, (struct sockaddr *) &handle->native_sinadr,handle->timeout) == 0) {
        return fd;
    }
    close(fd);
    if (!handle->native_respawn) {
        if (error) *error=strdup(strerror(errno));
        return -1;
    }
    if (handle->native_respawn_pid) {
        int n=waitpid(handle->native_respawn_pid,NULL,WNOHANG);
        if (n != handle->native_respawn_pid) {
            kill(handle->native_respawn_pid,SIGKILL);
            waitpid(handle->native_respawn_pid,NULL,0);
        }
        handle->native_respawn_pid=0;
    }
    pid=fork();
    if (pid < 0) {
        if (error) *error=strdup(strerror(errno));
        return -1;
    }
    if (!pid) {
        char *args[16];
        char pname[16];
        sprintf(pname,"%d",handle->native_port);
        args[0]=handle->native_ivonacl;
        args[1]="-d";
        args[2]="--port";
        args[3]=pname;
        args[4]="-l";
        args[5]=handle->native_ivonaso;
        args[6]="--vol";
        args[7]="99";
        args[8]=NULL;
        execv(handle->native_ivonacl,args);
        exit(1);
    }
    handle->native_respawn_pid=pid;
    for (i=0;i<5;i++) {
        sleep(1);
        if ((fd = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
            if (error) *error=strdup(strerror(errno));
            return -1;
        }
		if (connect_nb(fd, (struct sockaddr *) &handle->native_sinadr,handle->timeout) == 0) {
            return fd;
        }
        close(fd);
        if (waitpid(pid,NULL,WNOHANG)==pid) {
            handle->native_respawn_pid=0;
            break;
        }
    }
    if (error) *error=strdup(strerror(errno));
    return -1;
}


static int ivol_NativeInitWave(struct IVOL_PrivData *handle,char *str,char **error)
{
    int len,fd=ivol_NativeOpenFD(handle,error);
    if (fd<0) return fd;
    write(fd,str,len=strlen(str));
    if (!len || str[len-1] != '\n') write(fd,"\n",1);
    return fd;
}

static short *ivol_NativeFetchWave(struct IVOL_PrivData *handle,int fd,int *sample_length,char **error)
{
    int n;
    char *buffer;
    int buffer_length;
    int buffer_size;

    buffer=NULL;
    buffer_size=buffer_length=0;
    for (;;) {
        char wave_buffer[8192];
        n=read(fd,wave_buffer,8192);
        if (n<=0) break;
        if (!buffer) {
            buffer=malloc(buffer_size=65536);
        }
        else if (buffer_length+n > buffer_size) {
            buffer=realloc(buffer,buffer_size=buffer_size+65536);
        }
        memcpy(buffer+buffer_length,wave_buffer,n);
        buffer_length+=n;
    }
    close(fd);
    if (!buffer) {
        if (error) *error=strdup(strerror(errno));
        return NULL;
    }
    *sample_length=buffer_length/2;
    return (short *)buffer;
}

static short *ivol_NativeGetWave(struct IVOL_PrivData *handle,char *str,int *sample_length,char **error)
{
    int fd;
    fd=ivol_NativeInitWave(handle,str,error);
    if (fd<0) return NULL;
    return ivol_NativeFetchWave(handle,fd,sample_length,error);
}

static void ivol_NativeFreeWHD(int hd)
{
	close(hd);
}

static short *ivol_NativeClose(struct IVOL_PrivData *handle)
{
	xfree(handle->native_ivonacl);
	xfree(handle->native_ivonaso);

}
