#!/bin/bash
sudo apt-get install sox libsox-fmt-all antiword odt2txt libenca-dev libao-dev lame faac poppler-utils vorbis-tools || exit 1
sudo apt-get install mbrola mbrola-pl1 </dev/null >/dev/null 2>/dev/null

umask 0022

if ! which mbrola >/dev/null 2>/dev/null ; then
	ARCH=`uname -m`
	url="http://tcts.fpms.ac.be/synthesis/mbrola/bin/pclinux/mbr301h.zip"
	name=mbrola-linux-i386
	if [ "$ARCH" = "x86_64" ] ; then
		#url="http://tcts.fpms.ac.be/synthesis/mbrola/bin/amd64linux/mbrola.zip"
		url=http://tcts.fpms.ac.be/synthesis/mbrola/bin/amd64linux/mbrola_AMD_Linux.zip
		name=mbrola
	fi
	if [ ! -f mbr301h.zip ] ; then 
		wget -O mbr301h.zip $url || exit 1
	fi
	unzip mbr301h.zip $name
	sudo mv $name /usr/bin/mbrola
	sudo chmod 755 /usr/bin/mbrola
fi


dirs="/usr/share/mbrola \
/usr/share/festival \
/usr/local/share/mbrola \
/usr/local/share/festival \
$HOME"
voice=f
for d in $dirs; do
	if [ -d $d ] ; then
		v=`find $d -path "*/pl1" -and -type f`
		if [ "$v" != "" ] ; then
			voice=t
			break
		fi
	fi
done

if [ "$voice" = "f" ] ; then
	if [ ! -f pl1.zip ] ; then
		wget -O pl1.zip http://tcts.fpms.ac.be/synthesis/mbrola/dba/pl1/pl1.zip || exit 1
	fi


	sudo mkdir -p /usr/share/mbrola/pl1
	sudo unzip -d /usr/share/mbrola/pl1 -o pl1.zip
fi

make && sudo make install
