#ifndef MILENA_INPUT_H
#define MILENA_INPUT_H 1

void *alloc_input_buffer(void);
char *fgets_ra(void *ibv,FILE *f);

#endif
