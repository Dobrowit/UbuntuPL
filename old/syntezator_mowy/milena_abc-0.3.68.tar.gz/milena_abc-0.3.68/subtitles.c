/*
 * subtitles.c - Milena Audiobook Creator
 * Copyright (C) Bohdan R. Rau 2010-2012 <ethanak@polip.com>
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write see:
 *               <http://www.gnu.org/licenses/>.
 */

#include "config.h"
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <glib.h>
#include <stdio.h>
#include <gtk/gtk.h>
#include "gmilena.h"
#include <sys/stat.h>
#include <unistd.h>
#include <errno.h>

int jacosub_timeres(char *str,int *otir)
{
	int tir,i,n;
	if (strncmp(str,"#TIMERES",8)) {
		return 0;
	}
	str+=8;
	if (!*str || !strchr("\t ",*str)) {
		return 0;
	}
	while (*str && strchr("\t ",*str)) {
		str++;
	}
	if (!*str || !isdigit(*str)) {
		return 0;
	}
	tir=strtol(str,&str,10);
	if (otir) *otir=tir;
	if (tir >= 100) {
		return tir;
	}
	for (;;) {
		while (*str && !strchr("\r\n",*str)) str++;
		while (*str && strchr("\r\n",*str)) str++;
		if (!*str) return tir;
		for (i=0;i<4;i++) {
			if (!isdigit(*str)) break;
			n=strtol(str,&str,10);
			if (i==3) {
				if (n>tir) {
					if (n<100) return 100;
					tir=n;
				}
				break;
			}
			if (*str!="::."[i]) break;
			str++;
		}
	}
	return tir;
}

static char *get_hmst(char **str,int timeres)
{
	int hms[4],i,n;static char buf[32];
	char *cs=*str;
	for (i=0;i<4;i++) {
		if (!*cs && !isdigit(*cs)) return NULL;
		hms[i]=strtol(cs,&cs,10);
		if (!i && (*cs != ':')) {
			hms[3]=hms[0] % timeres;
			n=hms[0]/timeres;
			hms[2]=n % 60;
			n=n /60;
			hms[1]= n %60;
			hms[0]= n / 60;
			break;
		}
		if (i==3) break;
		if (*cs++ != "::."[i]) return NULL;
	}
	sprintf(buf,"%02d:%02d:%02d.%02d",hms[0],hms[1],hms[2],hms[3]);
	while (*cs && strchr("\t ",*cs)) cs++;
	*str=cs;
	return buf;
}

char *jacosub_simplify(char *str,int timeres)
{
	GString *ostr;int space,lbra;
	char *c,buf[32],buf2[64];
	ostr=g_string_sized_new(strlen(str));
	while (*str && isspace(*str)) str++;
	g_string_printf(ostr,"#TIMERES %d\n",timeres);
	
	while (*str) {
		if (!isdigit(*str)) {
bad_loop:			while (*str && !strchr("\r\n",*str)) str++;
rn_loop:			while (*str && strchr("\r\n",*str)) str++;
			continue;
		}
		c=get_hmst(&str,timeres);
		if (!c) goto bad_loop;
		strcpy(buf,c);
		c=get_hmst(&str,timeres);
		if (!c) c=buf;
		while (*str && isspace(*str)) str++;
		lbra=0;
		if (*str=='{') {
		    char *cx=strchr(str,'}');
		    if (cx && cx-str < 32) {
			lbra=1;
			cx++;
			sprintf(buf2,"%s %s ",buf,c);
			for (cx=buf2+strlen(buf2);*str && *str!='}';) {
			    *cx++=*str++;
			}
			*cx++=*str++;
			*cx++=' ';
			*cx++=0;
		    }
		}
		if (!lbra) {
		    sprintf(buf2,"%s %s {~}",buf,c);
		}
		// teraz trzeba skopiować pierwszy ciąg czasowy do bufora
		// jeśli istnieje drugi to go dodać do bufora
		// jeśli nie to zduplikować pierwszy
		// i przejść do najbliższego znaku oznaczającego początek
		// napisu.


		// Jeśli takiego znaku nie ma (tzn. mamy "\r\n")
		// to do następnej linii i continue
		// Początek napisu:
		// jeśli znak jest '{' leziemy za najbliższy '}'
		// jeśli znak jest spacja lub "/" pomijamy
		// jeśli znak
		// jeśli znak jest '\\', pomijamy go i sprawdzamy
		// czy następny nie jest "\r\n" lub >7bit. Jeśli jest, break,
		// inaczej go pomijamy
		// w przeciwnym razie mamy początek napisu

		while (*str && !strchr("\r\n",*str)) {
			if (strchr("\t /",*str)) {
				str++;
				continue;
			}
			if (*str=='{') {
				while (*str && !strchr("}\r\n",*str)) str++;
				if (*str!='}') break;
				str++;
				continue;
			}
			if (*str=='\\') {
				str++;
				if (!*str || strchr("\r\n",*str)) break;
				if (!((*str) & 0x80)) str++;
				continue;
			}
			break;
		}
		if (!*str) break;
		if (strchr("\r\n",*str)) goto rn_loop;

		// do bufora dowalamy " {~} " i do ostr


		g_string_append(ostr,buf2);

		space=2;
		while (*str && !strchr("\r\n",*str)) {
			// Teraz leziemy po stringu aż do napotkania "\r\n"
			// Na początek ustawiamy sobie 'space' na zero.
			// Każde napotkanie spacji powoduje pominięcie znaku
			// i ustawienie space na 1
			if (strchr("\t ",*str)) {
				if (!space) space=1;
				str++;
				continue;
			}
			if (*str == '/' && space) {
				str++;
				continue;
			}
			if (*str=='\\') {
				str++;
				if (!*str || strchr("\r\n",*str)) {
					break;
				}
				if (!((*str) & 0x80)) {
					if (*str == 'n') space=2;
					str++;
				}
				if (!space) space=1;
				continue;
			}
			if (*str=='{') {
				while (*str && !strchr("}\r\n",*str)) str++;
				if (*str!='}') break;
				str++;
				if (!space) space=1;
				continue;
			}
			if (space == 2 && *str=='-' && str[1]==' ') {
				str+=2;
				continue;
			}
			if (space) g_string_append_c(ostr,' ');
			space=0;
			g_string_append_c(ostr,*str++);
		}

		g_string_append_c(ostr,'\n');
		while (*str && strchr("\r\n",*str)) str++;

		// Napotkanie ciągu "\\<znak>" powoduje pominięcie ciągu
		// i ustawienie space na 1
		// Jeśli mamy '/' i space ==1, pomijamy go
		// Jeśli mamy '{', szukamy najbliższego '}',
		// ustawiamy str za nim i space =1
		// W przeciwnym przypadku jeśli space ==1 dodajemy ' ',
		// ustawiamy space na 0 i dodajemy znak.
		// Po napotkaniu "\r\n" pomijamy go i dodajemy "\n"
		//continue
	}

	return g_string_free(ostr,FALSE);
}

static int jaco_count_syllables(char *str)
{
	int syls=0;
	for (;*str && !strchr("\r\n",*str);str++) {
		if (my_digit(*str)) {
			syls+=3;
			continue;
		}
		if (strchr("iI",*str)) {
			if (!str[1] && !my_vowel(str[1])) syls++;
			continue;
		}
		if (!my_vowel(*str)) continue;
		if (strchr("aA",*str)) {
			if (str[1] && strchr("uU",str[1])) continue;
		}
		syls++;
	}
	return syls;
}

static int compute_phrase_length(char *str)
{
	return jaco_count_syllables(str) * 200;
}

int get_current_timeres(void)
{
	GtkTextIter start,final;
	char *buf;int ti=0;
	if (get_current_editor()) return 0;
	gtk_text_buffer_get_start_iter(current_editor->buf,&start);
	final=start;
	gtk_text_iter_forward_line(&final);
	buf=gtk_text_iter_get_text(&start,&final);
	if (!buf) return 0;
	if (!strncmp(buf,"#TIMERES",8)) ti=strtol(buf+8,NULL,10);
	g_free(buf);
	return ti;
}

int get_jaco_timer(char *str,int timeres)
{
	int hms[4],i;
	for (i=0;i<4;i++) {
		if (!*str && !isdigit(*str)) return -1;
		hms[i]=strtol(str,&str,10);
		if (!i && (*str != ':')) {
			return (hms[0] * 1000)/timeres;
		}
		if (i==3) break;
		if (*str++ != "::."[i]) return -1;
	}
	return 1000*(hms[0]*3600 + hms[1] * 60 + hms[2])+(hms[3]*1000)/timeres;
}

static int jaco_compute_line_duration(char *line,char *eol)
{
	int oc,msec;
	char eoline[(eol-line)+1],*istr;
	line+=strspn(line,"0123456789\t .:");
	for (;;) {
		if (*line == '{') {
			line=strchr(line,'}');
			if (!line) return -1;
			line++;
			continue;
		}
		if (!strchr(" \t/",*line)) break;
		line++;
	}
	if (line >= eol) return -1;
	memcpy(eoline,line,eol-line);
	eoline[eol-line]=0;
	oc=to_iso2(eoline,NULL);
	if (oc<1) return -1;
	istr=g_malloc(oc+1);
	to_iso2(eoline,istr);
	msec=compute_phrase_length(istr);
	g_free(istr);
	return msec;


}

int jacosub_find_dialcon(char *txt,int *size,int timeres,int use_strlen)
{

	char *aline,*bline,*alend;
	int lch,t1,t2,msec,nsec;
	aline=txt;


	for (;;) {
		for (;;) {
			if (!*aline) return -1;
			if (isdigit(*aline)) break;
			aline=strpbrk(aline,"\r\n");
			if (!aline) return -1;
			aline+=strspn(aline,"\r\n");
		}

		bline=aline;
		alend=bline;
		lch=0;
		while (*bline && !strchr("\r\n",*bline)) {
			if (!isspace(*bline)) {
				lch=*bline;
				alend=bline+1;
			}
			bline++;
		}
		bline+=strspn(bline,"\r\n");
		if (!*bline) return -1;
		if (!isdigit(*bline) || strchr(".?!\"",lch)) {
			aline=bline;
			continue;
		}
		t1=get_jaco_timer(aline,timeres);
		t2=get_jaco_timer(bline,timeres);
		if (t1<0 || t2<0 || t2<t1) {
			aline=bline;
			continue;
		}
		msec=t2-t1;
		nsec=jaco_compute_line_duration(aline,alend);
		if (nsec+1000 < msec) {
			aline=bline;
			continue;
		}
		bline=strchr(bline,'}');
		if (!bline) return -1;
		bline++;
        if (use_strlen) {
            *size=bline-alend;
            return alend-txt;
        }
        *size=g_utf8_strlen(alend,bline-alend);
        return g_utf8_strlen(txt,alend-txt);
	}
	return -1;
}

/* subtitle reader */



struct movie_dsc {
	int width;
	int height;
	double fps;
	char vcodec[32];
	char vtag[32];
	char acodec[32];
	double samplerate;
	int channels;
};

#ifdef USE_FFMPEG
double movie_fps(char *fname)
{
	int pipa[2];
	int pid;
	char *args[8];
	int n;
	char line[256],*li,*c;
	FILE *f;
	ignore(pipe(pipa));
	pid=fork();
	if (pid < 0) return -1.0;
	if (!pid) {
		close(pipa[0]);
		close(2);
		close(0);
		dup2(pipa[1],1);
		n=0;
		args[n++]="ffprobe";
		args[n++]="-show_streams";
		args[n++]=fname;
		args[n]=NULL;
		execvp(args[0],args);
		exit(1);
	}
	close(pipa[1]);
	f=fdopen(pipa[0],"r");
	int s_mode=0;
	int s_computed=0;
	double s_frate,s_timebase,s_duration,s_nbframes;
	int s_isvideo;
	double fps=-1;
	char *ca;
	while (fgets(line,256,f)) {
		li=trim(line);
		if (!*li) break;
		if (!strcasecmp(li,"[/STREAM]")) {
			if (s_mode == 1 && s_isvideo==1) {
				s_computed=1;
				if (s_frate > 0.0) fps=s_frate;
				else if (s_timebase > 0.0) fps=1.0/s_timebase;
				else if (s_duration > 0.0 && s_nbframes > 0.0) {
					fps=s_nbframes/s_duration;
				}
				else s_computed=0;
			}
			s_mode=0;
			continue;
		}
		if (!strcasecmp(li,"[STREAM]")) {
			if (!s_computed) {
				s_mode=1;
				s_frate=-1.0;
				s_timebase=-1.0;
				s_duration=-1.0;
				s_nbframes=-1.0;
				s_isvideo=0;
			}
			continue;
		}
		if (s_mode != 1) continue;
		c=strchr(li,'=');
		if (!c) continue;
		*c++=0;
		if (!strcmp(li,"codec_type")) {
			if (!strcmp(c,"video")) s_isvideo=1;
			continue;
		}
		if (!strcmp(li,"frame_rate")) {
			if (strcmp(c,"0/0")) {
				s_frate=my_strtod(c,&c);
				if (*c++ == '/') s_frate = s_frate / my_strtod(c,NULL);
			}
			continue;
		}
		if (!strcmp(li,"time_base")) {
			if (strcmp(c,"0/0")) {
				s_timebase=my_strtod(c,&c);
				if (*c++ == '/') s_timebase = s_timebase / my_strtod(c,NULL);
			}
			continue;
		}
		if (!strcmp(li,"duration")) {
			s_duration=my_strtod(c,NULL);
			continue;
		}
		if (!strcmp(li,"nb_frames")) {
			s_nbframes=my_strtod(c,NULL);
			continue;
		}
	}
	waitpid(pid,NULL,0);
	return fps;
}

#else
double movie_fps(char *fname)
{
	int pipa[2];
	int pid;
	char *args[8];
	int n;
	char line[256],*li,*c;
	FILE *f;
	ignore(pipe(pipa));
	pid=fork();
	if (pid < 0) return -1.0;
	if (!pid) {
		close(pipa[0]);
		close(2);
		close(0);
		dup2(pipa[1],1);
		n=0;
		args[n++]="mplayer";
		args[n++]="-identify";
		args[n++]="-frames";
		args[n++]="0";
		args[n++]="-vo";
		args[n++]="null";
		args[n++]=fname;
		args[n]=NULL;
		execvp(args[0],args);
		exit(1);
	}
	close(pipa[1]);
	f=fdopen(pipa[0],"r");
	double fps=-1;
	while(fgets(line,256,f)) {
		li=trim(line);
		c=strchr(li,'=');
		if (!c) continue;
		*c++=0;
		if (!strcmp("ID_VIDEO_FPS",li)) {
			fps=my_strtod(c,NULL);
		}
	}
	fclose(f);
	return fps;
}

#endif


static int msec(int t)
{
	return t % 1000;
}

static int sec(int t)
{
	return (t/1000) % 60;
}

static int mins(int t)
{
	return (t/60000) % 60;
}

static int hour(int t)
{
	return t/3600000;
}

static int tester_pasuje(char *s,char *patr)
{
	char z,*c;
	while (*s && isspace(*s)) s++;
	while (*patr) {
		z=*patr++;
		if (!*s) return 0;
		if (z==' ') {
			if (!isspace(*s++)) return 0;
			while (*s && isspace(*s)) s++;
			continue;
		}
		if (z=='9') {
			if (!isdigit(*s++)) return 0;
			continue;
		}
		if (z=='5') {
			if (*s < '0' || *s > '5') return 0;
			s++;
			continue;
		}
		if (z=='d') {
			if (!isdigit(*s++)) return 0;
			while (*s && isdigit(*s)) s++;
			continue;
		}
		if (z=='D') {
			while (*s && isdigit(*s)) s++;
			continue;
		}
		if (z=='E') {
			c=s;
			while (*c && isdigit(*c)) c++;
			if (isspace(*c)) {
				s=c;
				while (*s && isspace(*s)) s++;
			}
			continue;
		}
		if (z=='S') {
			if (!isdigit(*s)) return 0;
			if (*s++ <= '5') {
				if (isdigit(*s)) s++;
			}
			continue;
		}
		if (z != *s++) return 0;
	}
	return 1;
}


// testery
// MPL2: [d][d]
// Micro: {d}{D}
// TMP: 99:59:59:
// SubRip: Ed:59:59,d --> d:59:59,d
// SubViewer: d:S:S:99,d:S:S:99
// JacoSUB: d:S:S.99 d:S:S.99




struct subline {
	struct subline *next;
	int t1,t2;
	char *style;
	char *lines[8];
};

static struct subline *alloc_subline_style(char *src,int t1,int t2,char *style)
{
	struct subline *sr=g_malloc0(sizeof(struct subline));
	if (src) {
		sr->lines[0]=g_strdup(src);
	}
	sr->t1=t1;
	sr->t2=t2;
	if (style) {
	    sr->style=g_strdup(style);
	}
	return sr;
}

static struct subline *alloc_subline(char *src,int t1,int t2)
{
    return alloc_subline_style(src,t1,t2,NULL);
}

static void prepare_line(GString *gs,struct subline *sl)
{
	int i;char *c,*d;
	g_string_append_printf(gs,"%02d:%02d:%02d.%02d %02d:%02d:%02d.%02d {%s} ",
		hour(sl->t1),mins(sl->t1),sec(sl->t1),msec(sl->t1)/10,
		hour(sl->t2),mins(sl->t2),sec(sl->t2),msec(sl->t2)/10,
		sl->style?sl->style:"~");
	for (i=0;sl->lines[i] && i<8;i++) {
		if (i) g_string_append(gs,"\\n");
		c=sl->lines[i];
		if (*c=='/') c++;
		for (;*c;) {
			d=strchr(c,'{');
			if (!d) {
				g_string_append(gs,c);
				break;
			}
			if (d != c) {
				g_string_append_len(gs,c,d-c);
			}
			c=strchr(d,'}');
			if (!c) break;
			c++;
		}
	}
	g_string_append(gs,"\n");
}


static int get_hms(char **str)
{
	int h,m,s;
	while (**str && isspace(**str)) (*str)++;
	if (!isdigit(**str)) return -1;
	h=strtol(*str,str,10);
	if (*(*str)++ != ':') return -1;
	if (!isdigit(**str)) return -1;
	m=strtol(*str,str,10);
	if (m<0 || m>59) return -1;
	if (*(*str)++ != ':') return -1;
	if (!isdigit(**str)) return -1;
	s=strtol(*str,str,10);
	if (s<0 || s>59) return -1;
	return 3600 * h + 60 * m + s;
}

char *sub_getline(char **str)
{
	char *c,*d,z;
	if (!*str || !**str) return 0;
	c=*str;
	d=strpbrk(c,"\r\n");
	if (!d) {
		d=c+strlen(c);
	}
	else {
		z=*d;
		*d++=0;
		if (z == '\r' && *d=='\n') d++;
	}
	*str=d;
	return c;
}

static void split_subline(struct subline *line,char *sep)
{
	char *c=line->lines[0];
	int n=1;
	while (n<7) {
		c=strstr(c,sep);
		if (!c) break;
		*c=0;
		c+=strlen(sep);
		line->lines[n++]=c;
	}
}


static struct subline *subr_micro(char *s,double fps)
{
	struct subline *slines,**sline,*sl;
	char *line;
	int t1,t2,wfl;
	slines=NULL;
	sline=&slines;
	wfl=0;
	while ((line=sub_getline(&s))) {
		if (*line != '{') continue;
		line++;
		if (!isdigit(*line)) continue;
		t1=(1000.0 * strtol(line,&line,10))/fps;
		if (*line++ !='}') continue;
		if (*line++ !='{') continue;
		if (isdigit(*line)) t2=(1000.0 * strtol(line,&line,10))/fps;
		else t2=-1;
		if (*line++ != '}') continue;
		while (*line && isspace(*line)) line++;
		if (!*line) continue;
		if (!wfl) {
			char *cc;
			double fdx;
			wfl=1;
			if (t1 >= t2) {
				fdx=my_strtod(line,&cc);
				if (cc > line) {
					while (*cc && isspace(*cc)) continue;
					if (!*cc) {
						//printf("%f %f\n",fdx,fps);
						fdx -= fps;
						if (fdx>-1.0 && fdx < 1.0) continue;
					}
				}
			}
		}
		sl=alloc_subline(line,t1,t2);
		*sline=sl;
		sline=&(sl->next);
		split_subline(sl,"|");
	}
	for (sl=slines;sl;sl=sl->next) {
		if (sl->t2 < 0) {
			if (sl->next) sl->t2=sl->next->t1;
			else sl->t2=sl->t1+1000;
		}
	}
	return slines;
}

static struct subline *subr_mpl2(char *s,double dummy)
{
	struct subline *slines,**sline,*sl;
	char *line;
	int t1,t2;
	slines=NULL;
	sline=&slines;
	while ((line=sub_getline(&s))) {
		if (*line != '[') continue;
		line++;
		if (!isdigit(*line)) continue;
		t1=strtol(line,&line,10)*100;
		if (*line++ !=']') continue;
		if (*line++ !='[') continue;
		if (!isdigit(*line)) continue;
		t2=strtol(line,&line,10)*100;
		if (*line++ != ']') continue;
		while (*line && isspace(*line)) line++;
		if (!*line) continue;
		sl=alloc_subline(line,t1,t2);
		*sline=sl;
		sline=&(sl->next);
		split_subline(sl,"|");
	}
	return slines;
}

static struct subline *subr_tmp(char *s,double dummy)
{
	struct subline *slines,**sline,*sl;
	char *line;
	int last_msec=0;
	int t1,t2;
	slines=NULL;
	sline=&slines;
	while ((line=sub_getline(&s))) {
		t1=1000*get_hms(&line);
		if (t1<0) continue;
		if (t1 < last_msec+1000) t1+=last_msec+1000;
		last_msec=t1;
		t2=-1;
		if (*line++!=':') continue;
		while (*line && isspace(*line)) line++;
		if (!*line) continue;
		sl=alloc_subline(line,t1,t2);
		*sline=sl;
		sline=&(sl->next);
		split_subline(sl,"|");
	}
	for (sl=slines;sl;sl=sl->next) {
		if (sl->t2 < 0) {
			sl->t2=sl->t1+4000;
			if (sl->next && sl->t2 > sl->next->t1) sl->t2=sl->next->t1;
		}
	}
	return slines;
}
#if 0
static struct subline *subr_jaco(char *s,double dummy)
{
	struct subline *slines,**sline,*sl;
	char *line;
	int timeres=100;
	int t1,t2;
	slines=NULL;
	sline=&slines;
	while ((line=sub_getline(&s))) {
		if (*line=='#') {
			line++;
			if (tolower(*line) == 't') {
				while (*line && !isdigit(*line)) line++;
				n=strtol(line,&line,10);
				if (n<=100 && n >= 12) timeres=n;
			}
			continue;
		}
		t1=get_hms(&line);
		if (t1<0) continue;
		if (*line++!='.') continue;
		t1=t1*100+strtol(line,&line,10) % 100;
		while (*line && isspace(*line)) line++;
		t2=get_hms(&line);
		if (t2<0) continue;
		if (*line++!='.') continue;
		t1=t2*100+strtol(line,&line,10) % 100;
		while (*line && isspace(*line)) line++;
		sl=alloc_subline(line,t1,t2);
		*sline=sl;
		sline=&(sl->next);
		split_subline(sl,"\\n");
	}
	for (sl=slines;sl && timeres < 100;sl=sl->next) {
		if (sl->t1 % 100 >= timeres || sl->t2 % 100 >= timeres) {
			timeres=100;
			break;
		}
	}
	for (sl=slines;sl;sl=sl->next) {
		sl->t1 = ((sl->t1 /100) * 1000) + ((sl->t1 % 100) * 10)/timeres;
		sl->t2 = ((sl->t2 /100) * 1000) + ((sl->t2 % 100) * 10)/timeres;
	}
	return slines;
}
#endif

static struct subline *subr_srip(char *s,double dummy)
{
	struct subline *slines,**sline,*sl;
	char *line;
	GString *gs;
	int t1,t2;
	slines=NULL;
	sline=&slines;
	while ((line=sub_getline(&s))) {
		if (!*line) continue;
		if (!isdigit(*line)) continue;
		while (*line && isdigit(*line)) line++;
		while (*line && isspace(*line)) line++;
		if (!*line) {
			line=sub_getline(&s);
			if (!line) break;
		}
		t1=get_hms(&line);
		if (t1<0) continue;
		if (*line++ != ',') continue;
		t1=t1*1000+strtol(line,&line,10);
		while (*line && isspace(*line)) line++;
		if (strncmp(line,"-->",3)) continue;
		line+=3;
		while (*line && isspace(*line)) line++;
		t2=get_hms(&line);
		if (t2<0) continue;
		if (*line++ != ',') continue;
		t2=t2*1000+strtol(line,&line,10);
		if (!(line=sub_getline(&s))) break;
		if (!*line) continue;
		gs=g_string_new(line);
		for (;*s;) {
			line=sub_getline(&s);
			if (!line || !*line) break;
			g_string_append_printf(gs,"\n%s",line);
		}
		sl=alloc_subline(NULL,t1,t2);
		sl->lines[0]=g_string_free(gs,0);
		*sline=sl;
		sline=&(sl->next);
		split_subline(sl,"\n");
	}
	return slines;
}

static struct subline *subr_subv(char *s,double dummy)
{
	struct subline *slines,**sline,*sl;
	char *line;
	int t1,t2;
	GString *gs;
	slines=NULL;
	sline=&slines;
	while (*s && (*s =='\r' || *s=='\n' || *s=='[')) sub_getline(&s);
	while ((line=sub_getline(&s))) {
		t1=get_hms(&line);if (t1<0) continue;
		if (*line++ !='.') continue;
		t1=t1*1000 + strtol(line,&line,10) * 10;
		if (*line++!=',') continue;
		t2=get_hms(&line);if (t2<0) continue;
		if (*line++ !='.') continue;
		t2=t2*1000 + strtol(line,&line,10) * 10;
		if (!(line=sub_getline(&s))) break;
		if (!*line) continue;
		gs=g_string_new(line);
		for (;*s;) {
			line=sub_getline(&s);
			if (!line || !*line) break;
			g_string_append_printf(gs,"[br]%s",line);
		}
		sl=alloc_subline(NULL,t1,t2);
		sl->lines[0]=g_string_free(gs,0);
		*sline=sl;
		sline=&(sl->next);
		split_subline(sl,"[br]");
	}
	return slines;
}

static struct subline *subr_ass(char *s,double dummy)
{
	struct subline *slines,**sline,*sl;
	char *line;
	int t1,t2;
	int imode=0;
	int format=0,tp1=-1,tp2=-1,step=0,ts=-1;
	char *c,*d;
	
	void debra(char *c)
	{
	    char *d=c;
	    int rs=0;
	    for (;*c;c++) {
		if (*c=='{') {
		    rs=1;
		    continue;
		}
		if (*c=='}') {
		    rs=0;
		    continue;
		}
		if (!rs) *d++=*c;
	    }
	    *d=0;
	}
	
	slines=NULL;
	sline=&slines;
	while ((line=sub_getline(&s))) {
	    if (line[0] == '[') {
		imode=(!strncasecmp(line,"[events]",8))?1:0;
		continue;
	    }
	    if (!imode) continue;
	    if (!strncasecmp(line,"format:",7)) {
		for (c=line,format=0,tp1=tp2=-1;*c;) {
		    while (*c && isspace(*c)) c++;
		    if (!*c) break;
		    if (!strncasecmp(c,"start",4)) tp1=format;
		    else if (!strncasecmp(c,"end",3)) tp2=format;
		    else if (!strncasecmp(c,"style",5)) ts=format;
		    c=strchr(c,',');
		    if (!c) break;
		    c++;
		    format++;
		}
		imode=2;
		continue;
	    }
	    if (!strncasecmp(line,"dialogue:",9) && imode == 2) {
		char *style=NULL;
		line+=9;
		while (*line &&isspace(*line)) line++;
		debra(line);
		step=0;
		while (line && *line && step < format) {
		    if (step == tp1) {
			t1=get_hms(&line) * 1000;
			if (*line++=='.') {
			    t1+=strtol(line,&line,10)*10;
			}
			else break;
		    }
		    else if (step == tp2) {
			t2=get_hms(&line) * 1000;
			if (*line++=='.') {
			    t2+=strtol(line,&line,10)*10;
			}
			else break;
		    }
		    else if (step == ts) {
			style=line;
		    }
		    line=strchr(line,',');
		    if (!line) break;
		    line++;
		    step++;
		}
		if (step < format) continue;
		if (style) {
		    c=strchr(style,',');
		    if (!c) style=NULL;
		    else {
			*c=0;
			style=trim(style);
			if (!*style) style=NULL;
		    }
		}
		for (c=d=line;*c;c++) {
		    if (*c=='\\' && (c[1]=='N' || c[1]=='n')) {
			*d++=' ';
			c++;
		    }
		    else {
			*d++=*c;
		    }
		}
		*d=0;
		if (tp2 < 0) t2=t1;
		sl=alloc_subline_style(line,t1,t2,style);
		for (sline=&slines;*sline;sline=&(*sline)->next) {
		    if ((*sline)->t1 > t1) break;
		}
		sl->next=*sline;
		*sline=sl;
		continue;
	    }
	}
	return slines;
}
// testery
// MPL2: [d][d]
// Micro: {d}{D}
// TMP: 99:59:59:
// SubRip: Ed:59:59,d --> d:59:59,d
// SubViewer: d:S:S:99,d:S:S:99
// JacoSUB: d:S:S.99 d:S:S.99

static struct subtester {
	char *tester;
	int flags;
	struct subline *(*fun)(char *,double);
	char *name;
} substruct[]={
	{"[d][d]",0,subr_mpl2,"mpl2"},
	{"{d}{D}",1,subr_micro,"micro"},
	{"Ed:59:59,d --> d:59:59,d",0,subr_srip,"srip"},
	{"d:S:D.99,d:S:S.99",0,subr_subv,"subv"},
	{"99:59:59:",0,subr_tmp,"tmp"},
	{"d:S:S.99 d:S:S.99",2,NULL,"jaco"},
	{NULL,0,NULL}},
	ass={"",0,subr_ass,"ass"};



static char *_subtitle_read_buffer(char *fname,char *movie_name,char *exibuf,char **bladz)
{
	char *fbuf=NULL;char *encoding;
	gsize flen;
	char *c;int n,i;
	struct subtester *ss;
	char *rc;
	double fps=0;
	GString *gs;
	struct subline *lines,*li;
	if (!fname) {
		if (!exibuf) return NULL; 
		fbuf=g_strdup(exibuf);
		flen=strlen(exibuf);
	}
	else {
		if (!g_file_get_contents(fname,&fbuf,&flen,NULL)) {
		    *bladz=strerror(errno);
		    return NULL;
		}
	}
	encoding=(char *)get_encoding(fbuf,flen);
	if (!encoding) encoding="CP1250";
	if (!my_compare(encoding,"utf8")) {
		fbuf=to_utf8(fbuf,flen,encoding,1);
	}
	if (!memcmp(fbuf,"\xef\xbb\xbf",3)) {
	    memmove(fbuf,fbuf+3,strlen(fbuf)-2);
	}
	for (c=fbuf,n=0,ss=NULL;n<100 && !ss;n++) {
		for (i=0;substruct[i].tester;i++) {
			if (tester_pasuje(c,substruct[i].tester)) {
				ss=&substruct[i];
				break;
			}
		}
		c=strchr(c,'\n');
		if (!c) break;
		c++;
	}
	if (!ss) {
	    if (!strncasecmp(fbuf,"[Script Info]",13)) {
		ss=&ass;
	    }
	}
	if (!ss) {
		g_free(fbuf);
		*bladz="Niezidentyfikowany format pliku napisów";
		return NULL;
	}
	if (ss->flags & 2) { // jacosub bez zmiany
		rc=g_strdup(fbuf);
		g_free(fbuf);
		return rc;
	}

	if (ss->flags & 1) {
		fps=movie_fps(movie_name);
		if (fps < 0) {
			*bladz="Nie mogę odczytać FPS filmu";
			g_free(fbuf);
			return NULL;
		}
	}
	lines=ss->fun(fbuf,fps);
	g_free(fbuf);
	if (!lines) {
	    *bladz="Plik nie zawiera napisów";
	    return NULL;
	}
	gs=g_string_new("#TIMERES 100\n");
	while ((li=lines)) {
		lines=lines->next;
		prepare_line(gs,li);
		g_free(li->lines[0]);
		if (li->style) g_free(li->style);
		g_free(li);
	}
	
	return g_string_free(gs,0);
}

char *subtitle_read_buffer(char *fname,char *movie_name,char **bladz)
{
	static char *exts[]={
	    ".sub",".SUB",".srt",".SRT",
	    ".ass",".ASS",".txt",".TXT",
	    NULL};
	char *rc=NULL,*c,*cx;
	int i;
	*bladz=NULL;
	if (fname) return _subtitle_read_buffer(fname,movie_name,NULL,bladz);
	fname=g_malloc(strlen(movie_name)+4);
	strcpy(fname,movie_name);
	c=strrchr(fname,'/');
	if (!c) c=fname;
	c=strrchr(c,'.');
	if (!c) c=fname+strlen(fname);
	for (i=0;exts[i];i++) {
		strcpy(c,exts[i]);
		rc=_subtitle_read_buffer(fname,movie_name,NULL,bladz);
		if (rc) break;
	}
	
#ifdef HAVE_NAPIPRO
	if (rc) return rc;
	if (!*bladz)
	if (!gtk_check_menu_item_get_active((gpointer)m_napi_use)) {
		if (!Ask("Pytanko","Mam poszukać napisów w napiprojekt.pl?")) return rc;
	}
	cx=get_napi(movie_name);
	if (cx) {
		rc=_subtitle_read_buffer(NULL,movie_name,cx,bladz);
		if (rc && gtk_check_menu_item_get_active((gpointer)m_napi_autosave)) {
			strcpy(c,".txt");
			if (!g_file_test(fname,G_FILE_TEST_EXISTS)) {
				g_file_set_contents(fname,cx,-1,NULL);
			}
		}
		g_free(cx);
	}
	else {
	    *bladz="Nie znalazłem napisów w napiprojekt.pl";
	}
#endif
	return rc;
}

