/*
 * speaker.c - Milena Audiobook Creator
 * Copyright (C) Bohdan R. Rau 2009 <ethanak@polip.com>
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write see:
 *               <http://www.gnu.org/licenses/>.
 */

#include "config.h"
#include "gmilena.h"
#include <stdlib.h>
#include <string.h>
#include <milena.h>
#include <milena_mbrola.h>
#include <sys/stat.h>
#include <math.h>
#include <ctype.h>

char mbrola_voice[PATH_MAX+1]
#ifdef MBROLA_VOX
=MBROLA_VOX
#endif
;

int allow_html_formatting;
int lastpar;
int bookmode;
extern int ignore_oor;
int spell_empty;
static int new_ellipsis;

struct milena *milena;
struct milena_mbrola_cfg *mimbrola;
static struct phone_buffer phb;

#ifdef HAVE_MORFOLOGIK
void *morfologik_shm=NULL;
static int morfologik_checked=0;
#endif

int contrast;
double contrast_level;
void init_paragraph(void)
{
	lastpar=-1;
	if (!phb.str) {
		phb.str=g_malloc(1024);
		phb.buf_len=1024;
		phb.str_len=0;
	}
	contrast=use_ivona?0:gtk_toggle_button_get_active((gpointer)cb_kontrast);
	contrast_level=0.1*gtk_spin_button_get_value((gpointer)spin_kontrast);
}


void do_contrast(short *data,int len)
{
	while (len-- > 0) {
		double d=(*data) * (M_PI_2/32768.0);
		*data++=sin(d + contrast_level * sin(d * 4)) * 32767;
	}
}

char *get_diction_line(int gonext,int isutf)
{
	GtkTextIter pos;
	GtkTextIter end;
	char *line,*c;int cnt;
	GtkTextMark *sel=gtk_text_buffer_get_insert(tresc);
	gtk_text_buffer_get_iter_at_mark(tresc,&pos,sel);
	cnt=gtk_text_iter_get_line_offset(&pos);
	if (cnt) gtk_text_iter_backward_chars(&pos,cnt);
	end=pos;
	gtk_text_iter_forward_to_line_end(&end);
	line=gtk_text_buffer_get_slice(tresc,&pos,&end,FALSE);
	if (*line == '\n') {
bad_line:
		if (gonext) {
			gtk_text_iter_forward_line(&pos);
			gtk_text_buffer_place_cursor(tresc,&pos);
			gtk_text_view_scroll_to_iter(tresc_v,&pos,0.0,FALSE,0.0,0.0);
		}
		g_free(line);
		return NULL;
	}
	c=strstr(line,"//");
	if (c) *c=0;
	for (c=line;*c;c++) if (isspace(*c) || *c=='*') break;
	if (*c) *c=0;
	if (!*line) goto bad_line;
	for (c=line;*c;c++) {
		if (*c=='~') *c='-';
		else if (*c =='+' || *c=='_') *c=' ';
		else if (*c=='`') *c='\'';
	}
	if (isutf) {
		c=g_strdup(line);
	}
	else {
		cnt=to_iso2(line,NULL);
		if (cnt <=0) {
			g_free(line);
			return NULL;
		}
		c=g_malloc(cnt);
		to_iso2(line,c);
	}
	g_free(line);
	if (gonext) {
		gtk_text_iter_forward_line(&pos);
		gtk_text_buffer_place_cursor(tresc,&pos);
		gtk_text_view_scroll_to_iter(tresc_v,&pos,0.0,FALSE,0.0,0.0);
	}
	return c;

}

char *get_current_line(int do_rewind,GtkTextIter *linebeg)
{
	GtkTextIter pos;
	GtkTextIter end;
	GtkTextIter beg;
	char *line;
	GtkTextMark *sel=gtk_text_buffer_get_insert(tresc);
	gtk_text_buffer_get_iter_at_mark(tresc,&pos,sel);
	if (gtk_text_iter_is_end(&pos)) {
		if (!do_rewind) return NULL;
		gtk_text_iter_set_offset(&pos,0);
		if (gtk_text_iter_is_end(&pos)) {
			return NULL;
		}
		gtk_text_buffer_move_mark(tresc,sel,&pos);
	}
	if (linebeg) *linebeg=pos;
	if (!linebeg)gtk_text_view_scroll_to_mark(tresc_v,sel,0.0,TRUE,0.0,0.0);

    // poetry mode
    // na razie bez author, title i podobnych
    beg=pos;
    int poly=0;
    int brk=0;
    line=NULL;
    GtkTextIter xpos;
    for (;;) {
        end=pos;
        gtk_text_iter_forward_to_line_end(&end);
        if (allow_html_formatting && poly) {
            char *csm=NULL,*csl=gtk_text_buffer_get_slice(tresc,&pos,&end,FALSE);
            if (csl) {
                for (csm=csl;*csm && isspace(*csm);csm++);
                if (!strncmp(csm,"<fb2:author>",12)) {
                    pos=end=xpos;
                    brk=1;
                }
            }
            g_free(csl);
            if (brk) break;
        }
        if (line) g_free(line);
        line=gtk_text_buffer_get_slice(tresc,&beg,&end,FALSE);
        if (!*line || line[strlen(line)-1] != '\\') {
            break;
        }
        if (allow_html_formatting) {
            if (!poly && !strncmp(line,"<fb2:poemtitle>",15)) {
                brk=1;
                break;
            }
        }
        xpos=pos;
        if (!gtk_text_iter_forward_line(&pos)) break;
        poly=1;
    }
	gtk_text_iter_forward_line(&pos);
	gtk_text_buffer_place_cursor(tresc,&pos);
    if (poly) {
        char *c=line;
        for (;*c;c++) if (
            (*c=='\\' && (c[1]=='\r' || c[1]=='\n')) ||
            c[0]=='\r' || c[0]=='\n') *c=' ';
    }
    if (allow_html_formatting) {
        char *c=line;
        while((c=strchr(c,'<'))) {
            int ix,le=0;
            char *c1=c;
            for (ix=0;ftags[ix];ix++) {
                if ((le = _m(c,ftags[ix]))) break;
            }
            if (le) {
                memset(c,' ',le);
                c+=le;
            }
            else if (fb2_image(&c,&c1,NULL)) {
                while (c1<c) *c1++=' ';
            }
            else if ((ix=fb2_skips(&c))) {
                if (ix != 1) {
                    *c1++=ix;
                }
                while (c1<c) *c1++=' ';
            }
            else c++;
        }
	
    }
    return line;
}

void close_milena_libs(void)
{
	if (milena) milena_Close(milena);
	if (mimbrola) milena_CloseModMbrola(mimbrola);
	mimbrola=NULL;
	milena=NULL;
}

static int errf_local_dic;

void milena_errf(char *kom,char *fname,int lineno)
{
	ErrorF(NULL,"Błąd","%s\nBłąd w linii %d: %s",fname,lineno,kom);
	if (!errf_local_dic) return;
	if (get_current_editor() != 0) return;
	if (!current_editor->dic_editor) return;
	show_editor(current_editor->dic_editor);
	get_current_editor();
	GtkTextIter line;
	gtk_text_buffer_get_iter_at_line(tresc,&line,lineno-1);
	gtk_text_buffer_place_cursor(tresc,&line);
	gtk_text_view_scroll_to_iter((gpointer)tresc_v,&line,FALSE,TRUE,0.0,0.5);
}

static void find_mbrola_voice(void)
{
	static char *vpaths[]={
		"/usr/share/mbrola/voices/pl1",
		"/usr/share/mbrola/pl1/pl1",
		NULL};
	int i;
	for (i=0;vpaths[i];i++) {
		if (g_file_test(vpaths[i],G_FILE_TEST_IS_REGULAR)) {
			strcpy(mbrola_voice,vpaths[i]);
			break;
		}
	}
}

#ifdef HAVE_MORFOLOGIK

void check_morfo_shm(void)
{
	if (morfologik_checked) return;
	if (!morfologik_checked) {
		int typ=morfo_get_value();
		morfologik_checked=1;
		if (typ == 0) {
			morfologik_shm=milena_GetMorfologik(NULL,1);
			if (!morfologik_shm) morfologik_shm=milena_StartMorfologik(NULL);
		}
		else if (typ == 1) {
			morfologik_shm=milena_GetMorfologik(NULL,1);
		}
		else if (typ == 2) {
			morfologik_shm=milena_GetMorfologik(NULL,0);
		}
	}
	return;
}

#endif

int init_milena_libs(int is_dic)
{
	char ibuf[1024],obuf[1024],ixbuf[1024];
	int phmode;
	int i;
	struct miltheme *mt;
	if (!is_dic) {
		if (!mbrola_voice[0]) find_mbrola_voice();
		if (!mbrola_voice[0]) {
			Error("Błąd","Podaj położenie pliku pl1 dla Mbroli");
			return 0;
		}
		if (!g_file_test(mbrola_voice,G_FILE_TEST_IS_REGULAR)) {
			Error("Błąd","Podany plik pl1 nie istnieje.\nPodaj położenie pliku pl1 dla Mbroli");
			return 0;
		}
	}
	spell_empty=0;
	phmode=MILENA_PHR_IGNORE_INFO;
	errf_local_dic=0;
	if (gtk_toggle_button_get_active((gpointer)cb_ign)) {
		phmode|=MILENA_PHR_IGNORE_TILDE;
	}
	if (gtk_toggle_button_get_active((gpointer)cb_spell)) {
		phmode|=4;
		spell_empty=1;
	}
	//printf("Closing milena\n");
	close_milena_libs();
	//printf("Milena init\n");
	milena=milena_Init(
		milena_FilePath(use_ivona?"ive_pho.dat":"pl_pho.dat",obuf),
		milena_FilePath("pl_dict.dat",ibuf),
		milena_FilePath("pl_stress.dat",ixbuf));
	//printf("Milena=%p\n",milena);
	if (!milena) {
		Error("MilenaLibs","milena_init failed");
		return 0;

	}
	//printf("Register\n");
	milena_registerErrFun(milena,milena_errf);
	//printf("Phraser\n");
	if (!milena_ReadPhraser(milena,
		milena_FilePath("pl_phraser.dat",ibuf))) {
			milena_Close(milena);
			milena=NULL;
			Error("MilenaLibs","milena_READPHRASER failed");
			return 0;
	}
	if (!milena_ReadUserDicWithFlags(milena,
		milena_FilePath("pl_udict.dat",ibuf),is_dic?MILENA_UDIC_DICTMODE:0)) {
			milena_Close(milena);
			milena=NULL;
			Error("MilenaLibs","milena_userdic failed");
			return 0;
	}
	if (use_ivona) {
	    milena_ReadUserDic(milena,
		milena_FilePath("ive_udict.dat",ibuf));
#ifdef HAVE_NEW_IVONIZER
	    milena_ReadIvonaFin(milena,
		milena_FilePath("ive_fin.dat",ibuf));
#endif
	}
	if (!is_dic && !use_ivona) {
		mimbrola=milena_InitModMbrola(
			milena_FilePath("pl_mbrola.dat",ibuf));
		if (!mimbrola) {
			close_milena_libs();
			Error("MilenaLibs","milena_initmodmbrola failed");
			return 0;
		}
		if (!milena_ReadInton(mimbrola,
			milena_FilePath("pl_intona.dat",ibuf))) {
			close_milena_libs();
			Error("MilenaLibs","milena_readinton failed");

			return 0;
		}
		if (gtk_toggle_button_get_active((gpointer)cb_equ)) {
			milena_ModMbrolaSetFlag(mimbrola,MILENA_MBFL_EQUALIZE,MILENA_MBFL_EQUALIZE);
		}
	}
	if (gtk_toggle_button_get_active((gpointer)cb_hours)) {
		if (!milena_ReadPhraser(milena,	milena_FilePath("pl_hours.dat",ibuf))) {
			close_milena_libs();
			Error("MilenaLibs","milena read hours failed");

			return 0;
		}
	}
	if (!is_dic && !use_ivona && gtk_toggle_button_get_active((gpointer)cb_pro)) {
		if (!milena_ModMbrolaExtras(mimbrola,milena_FilePath("pl_pro_mbrola.dat",ibuf))) {
			close_milena_libs();
			Error("MilenaLibs","milena_mbrola_extras failed");

			return 0;
		}
	}
	for (i=0;i<NUM_LANGS;i++) if (gtk_toggle_button_get_active((gpointer)lang_cb[i])) {
		struct stat sb;
		sprintf(ibuf,"pl_%s_udic.dat",lang_codes[i]);
		milena_FilePath(ibuf,obuf);
		if (!stat(obuf,&sb)) {
			if (!milena_ReadUserDic(milena,obuf)) {
				close_milena_libs();
				Error("MilenaLibs","milena_userdic_lang failed");

				return 0;
			}
		}
		sprintf(ibuf,"pl_%s_stress.dat",lang_codes[i]);
		milena_FilePath(ibuf,obuf);
		if (!stat(obuf,&sb)) {
			if (!milena_ReadStressFile(milena,obuf)) {
				close_milena_libs();
			Error("MilenaLibs","milena_stress_lang failed");
				return 0;
			}
		}
		milena_SetLangMode(milena,lang_codes[i]);
	}
	for (mt=themes;mt;mt=mt->next) {
		if (gtk_toggle_button_get_active((gpointer)mt->cb)) {
			if (!milena_ReadPhraser(milena,milena_FilePath(mt->fname,ibuf))) {
				close_milena_libs();
			Error("MilenaLibs","milena_theme failed");

				return 0;
			}
		}
	}
	if (gtk_toggle_button_get_active((gpointer)cb_dic)) {
		char *fn=gtk_file_chooser_get_filename((gpointer)dic_filechooser);
		if (fn && *fn) {
			if (!milena_ReadUserDicWithFlags(milena,fn,is_dic?MILENA_UDIC_DICTMODE:MILENA_UDIC_IGNORE)) {
				close_milena_libs();
							Error("MilenaLibs","milena_userdic_extra failed");

				return 0;
			}
		}
	}
	if (phmode & 4) {
		if (!milena_ReadPhraser(milena,milena_FilePath("pl_charspell.dat",ibuf))) {
			close_milena_libs();
						Error("MilenaLibs","milena_charspell failed");

			return 0;
		}
	}
	else if (phmode & 3) milena_SetPhraserMode(milena,phmode & 3);
	new_ellipsis=gtk_toggle_button_get_active((gpointer)cb_ellip);
	bookmode=0;
#ifdef HAVE_MORFOLOGIK
	check_morfo_shm();
	if (morfologik_shm) {
		milena_SetMorfologik(milena,morfologik_shm);
	}
#endif	
	if (gtk_toggle_button_get_active((gpointer)cb_lector)) {
		bookmode=1;
		if (!is_dic && !use_ivona) milena_ModMbrolaSetFlag(
				mimbrola,-1,MILENA_MBFL_BOOKMODE);
#ifdef HAVE_MORFOLOGIK
		if (!morfologik_shm)
#endif
		milena_ReadVerbs(milena,
				milena_FilePath("pl_verbs.dat",ibuf));
	}
	if (use_ivona) {
	    char *c;
	    struct stat sb;
	    sprintf(obuf,"iv_%s_udic.dat",ivona_voice);
	    for (c=obuf;*c;c++) *c=tolower(*c);
	    if (!stat(milena_FilePath(obuf,ibuf),&sb)) {
		milena_ReadUserDic(milena,ibuf);
	    }
#ifdef HAVE_NEW_IVONIZER
	    sprintf(obuf,"iv_%s_fin.dat",ivona_voice);
	    for (c=obuf;*c;c++) *c=tolower(*c);
	    if (!stat(milena_FilePath(obuf,ibuf),&sb)) {
		milena_ReadIvonaFin(milena,ibuf);
	    }
#endif
	}


	return 1;
}

extern int ignore_oor;
int milena_add_local_dic(void)
{
	struct MyGtkEditor *edi;
	if (current_editor->editor_type == MILEDIT_MODE_DIC) edi=current_editor;
	else edi=current_editor->dic_editor;
	if (!edi) return 1;
	char *bdy=get_editor_body(edi);
	if (!strncmp(bdy,"//#DONOTUSE",11)) {
		g_free(bdy);
		return 1;
	}
	ignore_oor=1;
	int n=to_iso2(bdy,NULL);
	if (!n) {
		g_free(bdy);
		return 1;
	}
	char *ibdy=g_malloc(n);
	to_iso2(bdy,ibdy);
	g_free(bdy);
	char *c,*d;
	c=ibdy;
	int lineno=0;
	errf_local_dic=1;
	for (;;) {
		d=strchr(c,'\n');
		if (d) *d++=0;
		lineno++;
		if (milena_ReadUserDicLineWithFlags(milena,c,MILENA_UDIC_IGNORE,
			"Lokalny DICT",lineno)<0) {
			errf_local_dic=0;
			g_free(ibdy);
			return 0;
		}
		if (!d) break;
		c=d;
	}
	g_free(ibdy);
	errf_local_dic=0;
	return 1;
}


static int count_syllables(char *str)
{
	int syl=0;
	for (;*str;str++) {
		if (strchr("aeiouyYMOE",*str)) syl++;
	}
	return syl;
}

static void translate_phrase(char *phrase,char **otbuf,int *blen)
{
	static char *buf1,*buf2;
	static int len1,len2;
	int n;
	if (!len1) {
		buf1=g_malloc(len1=8192);
	}
	if (!len2) {
		buf2=g_malloc(len2=8192);
	}
	if (debug_level) fprintf(stderr,"Fraza in: %s\n",phrase);
	n=milena_Prestresser(milena,phrase,buf1,len1);
	if (n) {
		len1=n+1024;
		buf1=g_realloc(buf1,len1);
		milena_Prestresser(milena,phrase,buf1,len1);
	}
	if (debug_level) fprintf(stderr,"Prestress : %s\n",buf1);
	n=milena_TranslatePhrase(milena,(unsigned char *)buf1,buf2,len2,0);
	if (n) {
		len2=n+1024;
		buf2=g_realloc(buf2,len2);
		milena_TranslatePhrase(milena,(unsigned char *)buf1,buf2,len2,0);
	}
	if (debug_level) fprintf(stderr,"Translated : %s\n",buf1);
	n=milena_Poststresser(buf2,*otbuf,*blen);
	if (n) {
		*blen = n+1024;
		*otbuf=g_realloc(*otbuf,*blen);
		milena_Poststresser(buf2,*otbuf,*blen);
	}
}


static void translate_par(char *par,struct phone_buffer *phb)
{
	static char *phrase_buf,*sentence_buf,*second_buf;
	static int phrase_len,sentence_len,second_len;
	int this_ptyp,next_ptyp;
	int have_phrase=0;
	int get_phrase()
	{
		int nlen;
		char *opar=par;
		if (have_phrase) {
			char *c=sentence_buf;
			int n=sentence_len;
			sentence_buf=second_buf;
			second_buf=c;
			sentence_len=second_len;
			second_len=n;
			have_phrase=0;
			this_ptyp=next_ptyp;
			return 1;
		}

		nlen=milena_GetPhrase(milena,&par,phrase_buf,phrase_len,&this_ptyp);
		if (nlen<0) return 0;
		if (nlen) {
            par=opar;
			phrase_len=nlen+1024;
			phrase_buf=g_realloc(phrase_buf,phrase_len);
			milena_GetPhrase(milena,&par,phrase_buf,phrase_len,&this_ptyp);
		}
		translate_phrase(phrase_buf,&sentence_buf,&sentence_len);
		return 1;
	}

	int get_next_phrase()
	{
		int nlen;
        char *c=par;
		nlen=milena_GetPhrase(milena,&par,phrase_buf,phrase_len,&next_ptyp);
		if (nlen<0) return 0;
		if (nlen) {
			phrase_len=nlen+1024;
            par=c;
			phrase_buf=g_realloc(phrase_buf,phrase_len);
			milena_GetPhrase(milena,&par,phrase_buf,phrase_len,&next_ptyp);
		}
		translate_phrase(phrase_buf,&second_buf,&second_len);
		have_phrase=1;
		return 1;

	}
	if (!phrase_len) {
		phrase_buf=g_malloc(phrase_len=8192);
		sentence_buf=g_malloc(sentence_len=8192);
		second_buf=g_malloc(second_len=8192);
	}
	for (;;) {
		if (!get_phrase()) return;

		if ((this_ptyp & 7) == 1) {
			if (!get_next_phrase()) this_ptyp=(this_ptyp & 0xf8) | 5;
			else {
				int b=0;
				if ((next_ptyp & 7) == 2) {
					if (count_syllables(second_buf)<6) b=1;
				}
				//if (b) this_ptyp=(this_ptyp & 0xf8) | 4;
				if (b) this_ptyp |= 128;
			}

		}
		if (!new_ellipsis && (this_ptyp & 7)==7) {
			this_ptyp=(this_ptyp & 0xf8) | 4;
		}
		milena_ModMbrolaGenPhraseP(mimbrola,sentence_buf,phb,this_ptyp);
		if (this_ptyp == 0 || this_ptyp == 2 || this_ptyp == 3) {
			if (phb->str_len+10 < phb->buf_len) {
				phb->buf_len+=128;
				phb->str=g_realloc(phb->str,phb->buf_len);
			}
			strcpy(phb->str+phb->str_len,";EOS\n");
			phb->str_len+=5;
		}
	}
}

char *translate_subtitle(char *str)
{
#ifdef HAVE_IVONA
    if (use_ivona) {
        return ivona_translate_string(str);
    }
#endif
    phb.str_len=0;
	translate_par(str,&phb);
	return phb.str;
}
struct phone_buffer *translate_paragraph(char *str)
{
	char *psf=str;
	int partyp=milena_GetParType(milena,&psf,spell_empty);
	int pau;
	phb.str_len=0;
	if (!partyp) {
		if (lastpar>0) lastpar=0;
		return NULL;
	}
	if (lastpar<0) {
		pau=0;
	}
	else if (!bookmode) pau=MILENA_MBRK_NORMAL;
	else {
		if (lastpar==0) pau=MILENA_MBRK_LONG;
		else if (lastpar == partyp) pau=MILENA_MBRK_NORMAL;
		else if (partyp == MILENA_PARTYPE_DIALOG) pau=MILENA_MBRK_PREDIAL;
		else pau=MILENA_MBRK_POSTDIAL;
	}

	lastpar=partyp;
	phb.str_len=0;
	if (pau) {
		milena_ModMbrolaBreakP(mimbrola,&phb,pau);
	}
	translate_par(psf,&phb);
	return &phb;
}

char *_mpd(char *pat,char *str)
{
    while (*pat) {
        if (!*str) return  NULL;
        int z=*pat++;
        if (z==' ') {
            while (*pat && *pat==' ') pat++;
            if (!isspace(*str++)) return NULL;
            while (*str && isspace(*str)) str++;
            continue;
        }
        if (z=='d') {
            if (!isdigit(*str++)) return NULL;
            continue;
        }
	if (z=='*' && *pat) {
	    while (*str && *str != *pat) str++;
	    continue;
	}
        if (z!=*str++) return NULL;
    }
    while (*str && isspace(*str)) str++;
    return str;
}


int uniParType(char **str,int chaptermark)
{
	int dash=0;
	int znak;
	int sonly=0;
	int hcm=0;
    char *s=_mpd("dd:dd:dd.dd dd:dd:dd.dd {*}",*str);
    if (s) {
        while (*s) {
            *str=s;
            znak=get_unichar(&s);
            if (!znak) return 0;
            if (milena_alnum(znak)) return MILENA_PARTYPE_NORMAL;
        }
        return 0;
    }
	while (**str) {
		s=*str;
		znak=get_unichar(str);
		if (!znak) return 0;
		if (znak == ' ' || znak == 0xa0) continue;
		if (!sonly && znak==chaptermark) {
			sonly=1;
			hcm=1;
			continue;
		}
		sonly=1;
		if (znak=='-' || znak== 0x2013 || znak == 0x2014 || znak == 0x2212) {
			dash++;
			continue;
		}
		//if (znak_is_alnum(znak)) {
        if (milena_alnum(znak)) {
			*str=s;
			if (hcm) return MILENA_PARTYPE_CHAPTER;
			return dash?MILENA_PARTYPE_DIALOG:MILENA_PARTYPE_NORMAL;
		}
	}
	return 0;
}

void yield(void)
{
	while (gtk_events_pending ())
		gtk_main_iteration ();
}

struct mbrola_handler *mbr;

static short bxbuf[16384];int len;
static void flush_speaker(void)
{
	int nv=1;
#ifdef HAVE_IVONA
    if (use_ivona) {
        ivona_finish();
        return;
    }
#endif
	while (nv) {
		if (nv) {
			if (!flush_MBR(mbr)) nv=0;
		}
		for (;;) {
			int n,len;
			n=read_MBR(mbr,bxbuf,4096,&len);
			if (n<0) {
				printf("Mbrola error R\n");
				exit(0);
			}
			if (n>0) break;
			yield();
			if (is_speaking) {
				if (contrast) do_contrast(bxbuf,len);
				audioparam(bxbuf,len);
#ifdef USE_RESAMPLER
				if (use_resampler && resample_factor < 0.99 || resample_factor > 1.01) len=do_resample(bxbuf,len);
#endif
				audio_play(bxbuf,len);
			}
		}
	}
}

static void finish_speaker(void)
{
	flush_speaker();
	audio_play(NULL,0);
	if (!use_ivona) close_MBR(mbr);
}
int speak_aloud(struct phone_buffer *phb,int syncmode)
{
	int pos;
	char buf[256];
	int get_line()
	{
		int l;char *c,*d;
		if (pos>=phb->str_len) return 0;
		c=phb->str+pos;
		d=strchr(c,'\n');
		if (!d) return 0;
		d++;
		l=d-c;
		strncpy(buf,c,l);
		buf[l]=0;
		pos+=l;
		return 1;
	}
    if (debug_level) fprintf(stderr,"PHB %s\n",phb->str);
	pos=0;
	if (!get_line()) return 1;
	while (pos < phb->str_len) {
		for (;;) {
			int n=write_MBR(mbr,buf);
			if (n<0) {
				printf("Mbrola error W\n");
				exit(0);
			}
			if (n) break;
			if (!get_line()) {
				break;
			}
		}
		for (;;) {
			int n,len;
			yield();if (!is_speaking) return 0;
			n=read_MBR(mbr,bxbuf,4096,&len);
			if (n<0) {
				printf("Mbrola error R\n");
				exit(0);
			}
			if (n>0) break;
#ifdef USE_RESAMPLER
			if (use_resampler && resample_factor < 0.99 || resample_factor > 1.01) len=do_resample(bxbuf,len);
#endif
			if (contrast) do_contrast(bxbuf,len);
			audioparam(bxbuf,len);
			if (!audio_play(bxbuf,len)) return 0;
		}
	}
	if (syncmode) flush_speaker();
	return 1;
}


/*
 mbrola_real_freq=16000 * vocal_track_length;
 resample_factor=vocal_track_length * resample_value;
 */

gdouble current_mbrola_speed;
gdouble vocal_track_length=1.0;//1.0;
int mbrola_real_freq=1.0*16000;
gdouble resample_factor=1.0;
int use_resampler=0;
gdouble computed_resample_factor=1.0;

void init_mbrola_tp(void)
{
	char buf[256];int n;
#ifdef USE_RESAMPLER
	//printf("RS %f %f %d %f\n",vocal_track_length,resample_factor,mbrola_real_freq,computed_resample_factor);
	if (use_resampler)
		current_mbrola_speed=gtk_spin_button_get_value((gpointer)spin_tempo) * computed_resample_factor;
	else
#endif
	current_mbrola_speed=gtk_spin_button_get_value((gpointer)spin_tempo);
    n=current_mbrola_speed * 1000;
	sprintf(buf,";;T=%d.%03d\n",n/1000, n%1000);
    write_MBR(mbr,buf);
    n=gtk_spin_button_get_value((gpointer)spin_pitch)* 1000;
	sprintf(buf,";;F=%d.%03d\n",n/1000,n%1000);
	write_MBR(mbr,buf);
}


/* TODO: dołączyć do dystrybucji Mileny? */

char *get_phrase_uni(char **str,int *mode)
{
	int n=to_iso2(*str,NULL);
	char *bdx,*edx,*phr;
	int this_ptyp,nlen,plen;
	if (n<=0) {
		*str+=strlen(*str);
		return NULL;
	}
	bdx=g_malloc(n);
	to_iso2(*str,bdx);
	edx=bdx;
	nlen=milena_GetPhrase(milena,&edx,NULL,0,&this_ptyp);
	if (nlen <= 0) {
		*str+=strlen(*str);
		g_free(bdx);
		return NULL;
	}
	phr=g_malloc(nlen);
	edx=bdx;
	milena_GetPhrase(milena,&edx,phr,nlen,&this_ptyp);
	*mode=this_ptyp;
	plen=edx-bdx;
	g_free(bdx);
	to_iso2_mp(*str,NULL,&edx,plen);
	*str=edx;
	return phr;
}

void poczytaj_mi_milenko(void) /* HQ lektor */
{
	GtkTextIter linebeg;
	char *curline;
	char *str,*spoken=NULL,*second_str;
	int partype;
	int do_rewind=1,pau,this_ptyp,second_ptyp;
	char *phr;
	static char *sentence_buf;
	static int sentence_len;
	static char *second_buf;
	static int second_len;
	int tag_set;
	int chaptermark;
	int has_second;
	GtkTextIter sr,ed;

	if (!sentence_buf) sentence_buf=g_malloc(sentence_len=1024);
	if (!second_buf) second_buf=g_malloc(second_len=1024);
	curline=NULL;
	tag_set=0;
	chaptermark=0;
	audioparam_init(0);

	if (gtk_combo_box_get_active((gpointer)combo_split)) {
		char *c=(char *)gtk_entry_get_text((gpointer)char_split);
		if (!*c || ((*c) & 0x80)) {
			Error("Błąd","Nielegalny znak podziału");
			return;
		}
		chaptermark=*c;
	}
	while (is_speaking) {
		if (curline) g_free(curline);
	        curline=get_current_line(do_rewind,&linebeg);
		if (!curline) break;
		spoken=curline;
		char *c=strchr(curline,'\n');
		if (c) *c=0;
		do_rewind=0;
		yield();
		if (!is_speaking) break;
		str=curline;
		partype=uniParType(&str,chaptermark);
		if (!partype) {
			if (lastpar>0) lastpar=0;
			continue;
		}
        if (sleep_mode && sleep_start + sleep_mode <= time(0)) {
            if (Ask("Sleep","Przerwać czytanie?")) {
                is_speaking=0;
                break;
            }
            sleep_start=time(0);
        }
		if (lastpar<0) {
			pau=0;
		}
		else if (!bookmode) pau=MILENA_MBRK_NORMAL;
		else {
			if (lastpar==0 || partype==MILENA_PARTYPE_CHAPTER) pau=MILENA_MBRK_LONG;
			else if (lastpar == partype) pau=MILENA_MBRK_NORMAL;
			else if (partype == MILENA_PARTYPE_DIALOG) pau=MILENA_MBRK_PREDIAL;
			else pau=MILENA_MBRK_POSTDIAL;
		}
		if (partype==MILENA_PARTYPE_CHAPTER) partype=0;
		lastpar=partype;
		phb.str_len=0;
		if (pau) {
			milena_ModMbrolaBreakP(mimbrola,&phb,pau);
		}
		has_second=0;
		while (*str) {

			spoken=str;
			//printf("Od: %d %s\n",spoken-curline,str);
			if (has_second) {
				int x;char *y;
				str=second_str;
				this_ptyp=second_ptyp;
				x=sentence_len;sentence_len=second_len;second_len=x;
				y=sentence_buf;sentence_buf=second_buf;second_buf=y;
				has_second=0;
			}
			else {
				phr=get_phrase_uni(&str,&this_ptyp);
				if (!phr) {
					continue;
				}
				translate_phrase(phr,&sentence_buf,&sentence_len);
				g_free(phr);
			}
			sr=linebeg;
			gtk_text_iter_forward_chars(&sr,g_utf8_strlen(curline,spoken-curline));
			ed=sr;
			gtk_text_iter_forward_chars(&sr,g_utf8_strlen(spoken,str-spoken));
			gtk_text_view_scroll_to_iter(tresc_v,&sr,0.2,FALSE,0,0);
			gtk_text_buffer_apply_tag_by_name(tresc,"speaking",&sr,&ed);
			tag_set=1;
			yield();
			if (!is_speaking) break;

			if (debug_level) printf("Fraza: %s (%d)\n",sentence_buf,this_ptyp);
			//printf("Rest: %s\n\n",str);
			if (!new_ellipsis && (this_ptyp & 7)==7) {
				this_ptyp=(this_ptyp & 0xf8) | 4;
			}
			else if (*str && (this_ptyp & 7) == 1) {
				second_str=str;
				phr=get_phrase_uni(&second_str,&second_ptyp);
				if (phr) {
					has_second=1;
					translate_phrase(phr,&second_buf,&second_len);
					g_free(phr);
					if (count_syllables(second_buf)<6 && (second_ptyp & 7) == 2) this_ptyp |= 128;
				}
				else this_ptyp = (this_ptyp & 0xf8) | 5;
			}

			milena_ModMbrolaGenPhraseP(mimbrola,sentence_buf,&phb,this_ptyp);
			if (!speak_aloud(&phb,1)) is_speaking=0;
			gtk_text_buffer_remove_tag_by_name(tresc,"speaking",&sr,&ed);
			tag_set=0;
			phb.str_len=0;
			if (!is_speaking) break;
		}
	}
	if (tag_set) {
		gtk_text_buffer_remove_tag_by_name(tresc,"speaking",&sr,&ed);
	}
	if (!is_speaking && curline && spoken) {
		int n=g_utf8_strlen(curline,spoken-curline);
		gtk_text_iter_forward_chars(&linebeg,n);
		gtk_text_buffer_place_cursor(tresc,&linebeg);
	}
	if (curline) g_free(curline);
}

static int sleep_times[]={300,600,900,1800,2700,3600};
void start_reading(int gonext)
{
	int ced;
	struct phone_buffer *phonemes;
	ced=get_current_editor();
	if (ced !=0 && ced != MILEDIT_MODE_DIC) return;
#ifdef HAVE_IVONA
    check_ivona_enabled();
#endif
	if (!init_milena_libs(0)) return;
	if (!milena_add_local_dic()) {
		close_milena_libs();
		return;
	}
    if (!use_ivona) {
        mbr=init_MBR(mbrola_voice,mbrola_real_freq);
        if (!mbr) {
            close_milena_libs();
            Error("Mbrola","Brak");
            return;
        }
        init_mbrola_tp();
    }
	is_speaking=1;
	ignore_oor=1;
	speech_buttons_enable(TRUE);
	if (ced == MILEDIT_MODE_DIC) {
		char *str=get_diction_line(gonext,0);
        if (use_ivona) {
#ifdef HAVE_IVONA
            short *wave;int len,ofset,rest;
            wave=ivona_get_wave_from_string(ivona_translate_string(str),&len,&ofset,&rest);
            yield();
            if (wave) {
                if (is_speaking) {
                    ivona_push_wave(wave+(ofset/2),len-(ofset+rest)/2);
                    finish_speaker();
                }
                // ivona uses malloc, not g_malloc!
                free(wave);
            }
#endif
            if (str) g_free(str);
            goto finale;
        }
		if (str) phonemes=translate_paragraph(str);
		else phonemes=NULL;
		yield();
		if (is_speaking && phonemes) {
			speak_aloud(phonemes,1);
			finish_speaker();
		}
		if (str) g_free(str);
		goto finale;
	}
    allow_html_formatting=gtk_check_menu_item_get_active((gpointer)m_epub_format);
	init_paragraph();

    if (gtk_check_menu_item_get_active((gpointer)m_sleep)) {
        sleep_mode=sleep_times[sleep_current];
        sleep_start=time(0);
    }
    else {
        sleep_mode=0;
    }
#ifdef HAVE_IVONA
    //ivona_sync_mode=0;
    if (use_ivona) poczytaj_mi_ivonko(gonext);
	else
#endif
    if (!use_ivona) poczytaj_mi_milenko();
    finish_speaker();

finale:
#ifdef USE_RESAMPLER
	close_resampler();
#endif
	close_milena_libs();
	speech_buttons_enable(FALSE);
	is_speaking=0;
	gtk_widget_grab_focus((gpointer)gimma_current_editor()->view);
    store_zakladka();
}


void stop_speaking(void)
{
	is_speaking=0;
}

void speak_text(char *str)
{
	struct phone_buffer *phonemes;
	char *c;
	int utf=1;
	for (c=str;*c;) {
		int p,n=(*c++) & 0xff;
		if (!(n & 0x80)) continue;
		if ((n & 0xe0)==0xc0) p=1;
		else if ((n & 0xf0)==0xe0) p=2;
		else if ((n & 0xf8)==0xf0) p=3;
		else if ((n & 0xfc)==0xf8) p=4;
		else if ((n & 0xfe)==0xfc) p=5;
		else {
			utf=0;
			break;
		}
		for (;p && *c;p--) {
			n=((*c++) & 0xc0);
			if (n != 0x80) {
				utf=0;
				break;
			}
		}
		if (!utf) break;
	}

	
	
#ifdef HAVE_IVONA
    check_ivona_enabled();
#endif
	if (!init_milena_libs(0)) return;
	if (get_current_editor() >= 0) {
		if (!milena_add_local_dic()) {
			close_milena_libs();
			return;
		}
	}
	if (utf) {
		int cnt;
		cnt=to_iso2(str,NULL);
		if (cnt <=0) {
			close_milena_libs();
			return;
		}
		c=g_malloc(cnt);
		to_iso2(str,c);
		str=c;
	}
    if (!use_ivona) {
        mbr=init_MBR(mbrola_voice,mbrola_real_freq);
        if (!mbr) {
            close_milena_libs();
            Error("Mbrola","Brak");
            return;
        }
        init_mbrola_tp();
    }
	is_speaking=1;
	ignore_oor=1;
	speech_buttons_enable(TRUE);
    if (use_ivona) {
#ifdef HAVE_IVONA
        short *wave;int len,ofset,rest;
        wave=ivona_get_wave_from_string(ivona_translate_string(str),&len,&ofset,&rest);
        yield();
        if (wave) {
            if (is_speaking) {
                ivona_push_wave(wave+(ofset/2),len-(ofset+rest)/2);
                finish_speaker();
            }
            // ivona uses malloc, not g_malloc!
            free(wave);
        }
#endif
        goto finale;
    }
	if (str) phonemes=translate_paragraph(str);
	else phonemes=NULL;
	yield();
	if (is_speaking && phonemes) {
		speak_aloud(phonemes,1);
		finish_speaker();
	}
		
finale:
#ifdef USE_RESAMPLER
	close_resampler();
#endif
	close_milena_libs();
	speech_buttons_enable(FALSE);
	is_speaking=0;
	if (utf) g_free(str);
}
