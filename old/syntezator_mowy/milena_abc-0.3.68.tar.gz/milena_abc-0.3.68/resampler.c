/*
 * resampler.c - Milena Audiobook Creator
 * Copyright (C) Bohdan R. Rau 2009 <ethanak@polip.com>
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write see:
 *               <http://www.gnu.org/licenses/>.
 */

#include "config.h"
#include "gmilena.h"
#include <stdlib.h>
#include <samplerate.h>

static int resampler_initialized;
static int resampler_error;

static SRC_STATE *resampler;
static SRC_DATA res_data;


int init_resampler(void)
{
    if (resampler_initialized) return 1;
    resampler=src_new (SRC_SINC_MEDIUM_QUALITY, 1, &resampler_error) ;
    res_data.data_in=malloc(8192*sizeof(float));
    res_data.data_out=malloc(4*8192*sizeof(float));
    res_data.src_ratio=1.0/resample_factor;
    resampler_initialized=1;
    return 1;
}

int close_resampler(void)
{
    if (!resampler_initialized) return;
    src_delete(resampler);
    free(res_data.data_in);
    free(res_data.data_out);
    resampler_initialized=0;
    return;
}

static short rebuf[65536];
int do_resample(short *buffer,int count)
{
    
    init_resampler();
    int i;
    for (i=0;i<count;i++) res_data.data_in[i]=buffer[i];
    res_data.input_frames=i;
    res_data.output_frames=4*8192;
    res_data.end_of_input=0;
    src_process(resampler,&res_data);
    count=res_data.output_frames_gen;
    for (i=0;i<count;i++) buffer[i]=res_data.data_out[i];
    return count;
}


