/*
 * aacplus.c - Milena Audiobook Creator
 * Copyright (C) Bohdan R. Rau 2010 <ethanak@polip.com>
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write see:
 *               <http://www.gnu.org/licenses/>.
 */

#include "config.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <assert.h>
#ifndef DEMODES
#include "gmilena.h"
#endif
#include <libaacplus/cfftn.h>
#include <libaacplus/FloatFR.h>
#include <libaacplus/resampler.h>

#include <libaacplus/aacenc.h>
#include <libaacplus/sbr_main.h>

#include <libaacplus/adts.h>

#include <libaacplus/aac_ram.h>
#include <libaacplus/aac_rom.h>

#define CORE_DELAY   (1600)
#define INPUT_DELAY  ((CORE_DELAY)*2 +6*64-2048+1)     /* ((1600 (core codec)*2 (multi rate) + 6*64 (sbr dec delay) - 2048 (sbr enc delay) + magic*/
#define MAX_DS_FILTER_DELAY 16                         /* the additional max resampler filter delay (source fs)*/

#define CORE_INPUT_OFFSET_PS (0)  /* (96-64) makes AAC still some 64 core samples too early wrt SBR ... maybe -32 would be even more correct, but 1024-32 would need additional SBR bitstream delay by one frame */


#ifdef DEMODES
int stereo_mode=1;
int stereo_upsample=1;
#define g_perror perror
void Error(char *h,char *c)
{
    printf("%s: %s\n",h,c);
}
#endif


static float inputBuffer[(AACENC_BLOCKSIZE*2 + MAX_DS_FILTER_DELAY + INPUT_DELAY)*MAX_CHANNELS];
static char outputBuffer[(6144/8)*MAX_CHANNELS+ADTS_HEADER_SIZE];
static IIR21_RESAMPLER IIR21_reSampler[MAX_CHANNELS];
static AACENC_CONFIG     config;

static   FILE *hADTSFile=NULL;

static  int bitrate;
static  int nChannelsAAC, nChannelsSBR;
static  int sampleRateAAC;
static  int bandwidth = 0;

static  unsigned int numAncDataBytes=0;
static  unsigned char ancDataBytes[MAX_PAYLOAD_SIZE];
static  unsigned int ancDataLength = 0;

static   short TimeDataPcm[AACENC_BLOCKSIZE*2*MAX_CHANNELS];

static  int numSamplesRead;
static  int coreWriteOffset = 0;
static  int coreReadOffset = 0;
static  int envWriteOffset = 0;
static  int envReadOffset = 0;
static  int writeOffset=INPUT_DELAY*MAX_CHANNELS;

static  struct AAC_ENCODER *aacEnc = 0;

static  int bDoUpsample = 0;
static  int upsampleReadOffset = 0;

static  int inSamples;
static  int nSamplesPerChannel;

static int in_SampleRate;
static int nChannels;
static HANDLE_SBR_ENCODER hEnvEnc;
static int aac_readpos;

int init_aac_encoder(char *fname)
{
    hEnvEnc=NULL;
    in_SampleRate=(stereo_upsample && stereo_mode)?32000:16000;
    bitrate=16000; // minimalna wartość
#if (MAX_CHANNELS==1)
    if (stereo_mode) {
        Error("LibAACPlus","Twoja biblioteka nie obsługuje stereo");
        return 0;
    }
#endif
    AacInitDefaultConfig(&config);
    nChannelsAAC=1;
    nChannels = nChannelsSBR = stereo_mode?2:1;
    if (in_SampleRate == 16000) {
        bDoUpsample = 1;
        in_SampleRate = 32000;
    }
    sampleRateAAC = in_SampleRate;
    config.bitRate = bitrate;
    config.nChannelsIn=stereo_mode?2:1;
    config.nChannelsOut=nChannelsAAC;
    config.bandWidth=bandwidth;


  /*
    set up SBR configuration
  */

    if(!IsSbrSettingAvail (bitrate, nChannelsAAC, sampleRateAAC, &sampleRateAAC)) {
        Error("LibAACPlus","Nie znalazłem odpowiadającej konfiguracji SBR");
        return 0;
    }

    {
        sbrConfiguration sbrConfig;

        envReadOffset = 0;
        coreWriteOffset = 0;

        if(stereo_mode) {
            envReadOffset = (MAX_DS_FILTER_DELAY + INPUT_DELAY)*MAX_CHANNELS;
            coreWriteOffset = CORE_INPUT_OFFSET_PS;
            writeOffset = envReadOffset;
        }
        InitializeSbrDefaults (&sbrConfig);
        sbrConfig.usePs = stereo_mode;
        AdjustSbrSettings(&sbrConfig,
                      bitrate,
                      nChannelsAAC,
                      sampleRateAAC,
                      AACENC_TRANS_FAC,
                      24000);

        EnvOpen  (&hEnvEnc,
              inputBuffer + coreWriteOffset,
              &sbrConfig,
              &config.bandWidth);

    }



    if (bDoUpsample) {
        if (stereo_mode) {
            Error("LibAACPlus","Błąd programu - 16kHz w trybie stereo");
            return 0;
        }
        InitIIR21_Resampler(&(IIR21_reSampler[0]));

#if (MAX_CHANNELS==2)
        InitIIR21_Resampler(&(IIR21_reSampler[1]));
#endif

        assert(IIR21_reSampler[0].delay <=MAX_DS_FILTER_DELAY);
        if (stereo_mode) {
            writeOffset   += AACENC_BLOCKSIZE * MAX_CHANNELS;
            upsampleReadOffset  = writeOffset;
            envWriteOffset  = envReadOffset;
        } else {
            writeOffset        += AACENC_BLOCKSIZE * MAX_CHANNELS;
            coreReadOffset      = writeOffset; 
            upsampleReadOffset  = writeOffset - (((INPUT_DELAY-IIR21_reSampler[0].delay) >> 1) * MAX_CHANNELS);
            envWriteOffset      = ((INPUT_DELAY-IIR21_reSampler[0].delay) &  0x1) * MAX_CHANNELS;
            envReadOffset       = 0;
        }
    }


    config.sampleRate = sampleRateAAC;
    config.sampleRate = sampleRateAAC;
    if (AacEncOpen( &aacEnc,config)) {
        Error("LibAACPlus","Nie mogę zainicjalizować AAC");
        AacEncClose(aacEnc);
        return 0;
    }
    
    hADTSFile = fopen(fname, "wb");
    if (!hADTSFile) {
        g_perror(fname);
        AacEncClose(aacEnc);
        return 0;
    }



/*
  fprintf(stdout,"input : \nsr = %ld, nc = %ld\n",
           (bDoUpsample) ? in_SampleRate/2 : in_SampleRate, nChannels);
  fprintf(stdout,"output file %s: \nbr = %ld sr-OUT = %d  nc-OUT = %ld\n",
          fname, bitrate, (!bDoUpsample) ? sampleRateAAC*2 : sampleRateAAC, nChannelsSBR);
  fflush(stdout);
*/
    init_plans();
    memset(TimeDataPcm,0,sizeof(TimeDataPcm));
    inSamples = AACENC_BLOCKSIZE * nChannels * 2;
    if (bDoUpsample) {
        inSamples =  inSamples>>1;
    }
    adts_hdr((void *)outputBuffer, &config);
    aac_readpos=0;
    return 1;

}

void encode_aac_frame()
{
    int i,outSamples,numOutBytes;
    numSamplesRead=inSamples;
    for (i=0; i<numSamplesRead; i++) {
        inputBuffer[i+writeOffset] = (float) TimeDataPcm[i];
    }
#if (MAX_CHANNELS==2)

      /* copy from short to float input buffer, reordering necessary since the encoder takes interleaved data */
    if(nChannels == 1) {
        for (i=0; i<numSamplesRead; i++) {
            inputBuffer[writeOffset+2*i] = (float) TimeDataPcm[i];
        }
    }
#endif
    if (bDoUpsample) {
        int ch;
        for(ch=0;ch < nChannels;ch++){
            IIR21_Upsample( &(IIR21_reSampler[ch]),
                        inputBuffer+upsampleReadOffset+ch,
                        numSamplesRead/nChannels,
                        MAX_CHANNELS,
                        inputBuffer+envWriteOffset+ch,
                        &outSamples,
                        MAX_CHANNELS);

        }
    }
    EnvEncodeFrame (hEnvEnc,
                    inputBuffer + envReadOffset,
                    inputBuffer + coreWriteOffset,
                    MAX_CHANNELS,
                    &numAncDataBytes,
                    ancDataBytes);
    if(numAncDataBytes == 0)
    {
      numAncDataBytes=ancDataLength;
    }
    if (hEnvEnc && stereo_mode) {
        AacEncEncode(aacEnc,
                   inputBuffer,
                   1, /* stride */
                   ancDataBytes,
                   &numAncDataBytes,
                   (unsigned *) (outputBuffer+ADTS_HEADER_SIZE),
                   &numOutBytes);

        if(hEnvEnc)
            memcpy( inputBuffer,inputBuffer+AACENC_BLOCKSIZE,CORE_INPUT_OFFSET_PS*sizeof(float));
    }
    else
    {
        AacEncEncode(aacEnc,
                   inputBuffer+coreReadOffset,
                   MAX_CHANNELS,
                   ancDataBytes,
                   &numAncDataBytes,
                   (unsigned *) (outputBuffer+ADTS_HEADER_SIZE),
                   &numOutBytes);


        if(hEnvEnc) {
            if (bDoUpsample) {
                memmove( &inputBuffer[envReadOffset],
                   &inputBuffer[envReadOffset+AACENC_BLOCKSIZE*MAX_CHANNELS*2],
                   (envWriteOffset-envReadOffset)*sizeof(float));
                memmove( &inputBuffer[upsampleReadOffset],
                   &inputBuffer[upsampleReadOffset+AACENC_BLOCKSIZE*MAX_CHANNELS],
                   (writeOffset-upsampleReadOffset)*sizeof(float));
            }
            else {
                memmove( inputBuffer,inputBuffer+AACENC_BLOCKSIZE*2*MAX_CHANNELS,writeOffset*sizeof(float));
            }
        }
    }
    if (numOutBytes) {
        adts_hdr_up(outputBuffer, numOutBytes);
        fwrite(outputBuffer, 1, numOutBytes+ADTS_HEADER_SIZE, hADTSFile);
    }
}

int aac_encode(short *buf,int nsamples)
{
    while (nsamples >0) {
        int nsm=nsamples;
        int serial_size;
        short *dwWrite;
        if (nsm > inSamples - aac_readpos) {
            nsm=inSamples - aac_readpos;
        }
        memcpy(TimeDataPcm+aac_readpos,buf,2*nsm);
        aac_readpos+=nsm;
        buf+=nsm;
        nsamples-=nsm;
        if (aac_readpos == inSamples) {
            encode_aac_frame();
            aac_readpos=0;
        }
    }
    return 1;
}

int finish_aac(void)
{
    if (aac_readpos) {
        memset(TimeDataPcm+aac_readpos,0,sizeof(TimeDataPcm)-2*aac_readpos);
        encode_aac_frame();
    }
    memset(TimeDataPcm,0,sizeof(TimeDataPcm));
    encode_aac_frame();
    AacEncClose(aacEnc);
    fclose(hADTSFile);
    destroy_plans();	
    if(hEnvEnc)
	EnvClose(hEnvEnc);
    return 1;  
}


#ifdef DEMODES
main()
{
    init_aac_encoder("../test.aac");
}
#endif
