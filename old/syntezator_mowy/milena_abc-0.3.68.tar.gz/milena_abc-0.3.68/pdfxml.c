/*
 * pdfxml.c - Milena Audiobook Creator
 * Copyright (C) Bohdan R. Rau 2010 <ethanak@polip.com>
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write see:
 *               <http://www.gnu.org/licenses/>.
 */
#include "config.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <glib.h>

static struct pdftext {
    int left,top,width,height,flags;
    char *str;
} *pdf_lines;
int pdf_lines_count,pdf_lines_size;

#define PDXML_PAGESTART 1
#define PDXML_NEWPARA 2
#define PDXML_NEWPART 4
#define PDXML_CONNECT 8

static char *htrim(char *c)
{
    char *d,*s;
    int spa=-1,n;
    d=s=c;
    while (*c) {
        if (isspace(*c)) {
            c++;
            if (!spa) spa=1;
            continue;
        }

	if (c[0] == '&' && c[1]=='#') {
	    char *dq;int znak;
	    if (tolower(c[2])=='x') {
		znak=strtol(c+3,&dq,16);
	    }
	    else {
		znak=strtol(c+2,&dq,10);
	    }
	    if (*dq == ';' && znak > 0 && (znak < 0xD800 || (znak >= 0xFB00 && znak <=0xFB04))) {
		static char *liga[]={"ff","fi","fl","ffi","ffl"};
		dq++;
		c=dq;
		if (znak <= 32) {
		if (!spa) spa=1;
		    continue;
		}
		if (spa>0) *d++=' ';
		spa=0;
		if (znak >= 0xFB00 && znak <= 0xFB04) {
		    strcpy(d,liga[znak-0xFB00]);
		    d+=strlen(d);
		    continue;
		}
		if (znak < 128) {
		    *d++=znak;
		}
		else if (znak < 0x800) {
		    *d++=0xc0 | (znak >> 6);
		    *d++=0x80 | (znak & 0x3f);
		}
		else {
		    *d++=0xe0 | (znak >> 12);
		    *d++=0x80 | ((znak >> 6) & 0x3f);
		    *d++=0x80 | (znak & 0x3f);
		}
		continue;
	    }
	}


        if (spa>0) *d++=' ';
        spa=0;
        if (*c=='&') {
            if (!strncmp(c,"&amp;",5)) {
                *d++='&';
                c+=5;continue;
            }
            if (!strncmp(c,"&lt;",4)) {
                *d++='<';
                c+=4;
                continue;
            }
            if (!strncmp(c,"&gt;",4)) {
                *d++='>';
                c+=4;
                continue;
            }
            if (!strncmp(c,"&quot;",6)) {
                *d++='"';
                c+=6;
                continue;
            }
        }
        if (*c=='<') {
            c++;
            while (*c && *c!='>') c++;
            if (!*c) break;
            c++;
            continue;
        }
        if (!((*c) & 0x80)) {
            *d++=*c++;
            continue;
        }
        n=0;
        if (((*c) & 0xe0) == 0xc0) n=1;
        else if (((*c) & 0xf0) == 0xe0) n=2;
        else if (((*c) & 0xf8) == 0xf0) n=3;
        else if (((*c) & 0xfc) == 0xf8) n=4;
        else if (((*c) & 0xfe) == 0xfc) n=5;
        else n=0;
        *d++=*c++;
        while (*c && n>0) {
            *d++=*c++;
            n--;
        }
        
    }
    *d=0;
    return s;
}

static void add_pdf_line(char *str,int flags)
{
    int w=0,h=0,l=0,t=0;
    char *c;
    c=strchr(str,'>');
    if (!c) return;
    *c++=0;
    for (;;) {
        while (*str && !isspace(*str)) str++;
        if (!*str) break;
        while (*str && isspace(*str)) str++;
        if (!*str) break;
        if (!strncmp(str,"left=\"",6)) l=strtol(str+6,&str,10);
        else if (!strncmp(str,"top=\"",5)) t=strtol(str+5,&str,10);
        else if (!strncmp(str,"width=\"",7)) w=strtol(str+7,&str,10);
        else if (!strncmp(str,"height=\"",8)) h=strtol(str+8,&str,10);
    }
    if(pdf_lines_count >= pdf_lines_size) {
        pdf_lines_size+=1024;
        if (pdf_lines) pdf_lines=g_realloc(pdf_lines,sizeof(*pdf_lines) * pdf_lines_size);
        else pdf_lines=g_malloc(sizeof(*pdf_lines) * pdf_lines_size);
    }
    pdf_lines[pdf_lines_count].left=l;
    pdf_lines[pdf_lines_count].top=t;
    pdf_lines[pdf_lines_count].width=w;
    pdf_lines[pdf_lines_count].height=h;
    pdf_lines[pdf_lines_count].flags=flags;
    pdf_lines[pdf_lines_count++].str=htrim(c);
//    printf("%d %d %d %d %d: [%s]\n",l,t,w,h,flags,c);
}

gint pdf_tollerance=4, pdf_newpara=20;

char *pdxml2txt(char *buf)
{
    int fg;char *c;
    int i,mleft,mrite,j,blen,k,mtop,mbot;
    char *body;
    extern char *new_pdf_parser(char *);
    return new_pdf_parser(buf);
    pdf_lines=NULL;
    pdf_lines_count=0;
    pdf_lines_size=0;
    fg=0;
    blen=strlen(buf);
    body=g_malloc(blen);
    c=body;
    mbot=0;
    
    int is_da(char *str)
    {
	int len=strlen(str);
	if (len < 40) return 0;
	if (!isspace(str[len-2]) && str[len-1] == '-') {
	    str[len-1]=0;
	    return 1;
	}
	return 0;
    }
    while (*buf) {
        buf=strchr(buf,'<');
        if (!buf) break;
        buf++;
        if (!strncmp(buf,"page",4)) {
            fg=PDXML_PAGESTART;
            continue;
        }
        if (strncmp(buf,"text",4)) continue;
        c=buf;
        buf=strstr(buf,"</text");
        if (!buf) break;
        *buf++=0;
        add_pdf_line(c,fg);
        fg=0;
    }
    if (!pdf_lines_count) {
        return g_strdup ("Pusty PDF");
    }
    mleft=99999;mrite=0;
    for (i=0;i<pdf_lines_count;i++) {
        if (pdf_lines[i].left < mleft) mleft=pdf_lines[i].left;
        if (pdf_lines[i].left + pdf_lines[i].width > mrite) mrite=pdf_lines[i].left + pdf_lines[i].width;
        //if (i < pdf_lines_count-1) printf("%d\n",pdf_lines[i+1].top - pdf_lines[i].top); // 20
	if (i < pdf_lines_count-1 && !pdf_lines[i+1].flags && abs(pdf_lines[i+1].top - pdf_lines[i].top)<pdf_newpara && pdf_lines[i+1].left >= pdf_lines[i].left+pdf_lines[i].width-5 && pdf_lines[i+1].left > pdf_lines[i].left) {
            pdf_lines[i+1].flags |= PDXML_CONNECT;
            continue;
        }
    }
    
    for (i=j=1;i<pdf_lines_count;i++) {
        if (!(pdf_lines[i].flags & PDXML_CONNECT)) {
            pdf_lines[j++]=pdf_lines[i];
            continue;
        }
	// eliminacja przeniesienia wyrazu
        if (!is_da(pdf_lines[i-1].str)) strcat(pdf_lines[i-1].str," ");
        strcat(pdf_lines[i-1].str,pdf_lines[i].str);
        pdf_lines[i-1].width=pdf_lines[i].left+pdf_lines[i].width-pdf_lines[i-1].left;
    }
    pdf_lines_count=j;
    k=0;
    for (i=j=0;i<pdf_lines_count;i++) {
        if (!*pdf_lines[i].str) {
            k=1;
            continue;
        }
        if (k) pdf_lines[i].flags |= PDXML_NEWPARA | PDXML_NEWPART;
        pdf_lines[j++]=pdf_lines[i];
        k=0;
    }
    pdf_lines_count=j;
    mtop=0;
    for (j=0,i=1;i<pdf_lines_count;i++) {
        if (pdf_lines[i].flags & PDXML_PAGESTART) continue;
        k=pdf_lines[i].top-pdf_lines[i-1].top;
        mtop+=k;
        j++;
        if (pdf_lines[i].top > mbot) mbot=pdf_lines[i].top;
    }
    mtop=mtop/j;
    for (i=1;i<pdf_lines_count;i++) {
        if (pdf_lines[i].flags & PDXML_NEWPARA) continue;
        if (pdf_lines[i].left > mleft+5) pdf_lines[i].flags |= PDXML_NEWPARA;
        if (!(pdf_lines[i].flags & PDXML_PAGESTART)) {
            if (pdf_lines[i].top > pdf_lines[i-1].top+mtop+pdf_tollerance) {
                pdf_lines[i].flags |= PDXML_NEWPARA | PDXML_NEWPART;
            }
        }
        else if ((pdf_lines[i-1].flags & PDXML_PAGESTART) || pdf_lines[i-1].top < mtop - pdf_newpara) {
            pdf_lines[i].flags |= PDXML_NEWPARA | PDXML_NEWPART;
        }
        
    }
    
    char *clast=NULL;
    for (c=body,i=0;i<pdf_lines_count;i++) {
        if (i) {
            if (pdf_lines[i].flags & PDXML_NEWPART) *c++='\n';
            if (pdf_lines[i].flags & PDXML_NEWPARA) *c++='\n';
            else {
		if (!clast || !is_da(clast)) *c++=' ';
		else c--;
	    }
        }
	clast=c;
        strcpy(c,pdf_lines[i].str);
        c+=strlen(c);
    }
    if (pdf_lines) g_free(pdf_lines);
    return body;
    
}
