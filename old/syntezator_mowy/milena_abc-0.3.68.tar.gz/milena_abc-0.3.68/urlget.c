/*
 * urlget.c - Milena Audiobook Creator
 * Copyright (C) Bohdan R. Rau 2009-2011 <ethanak@polip.com>
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write see:
 *               <http://www.gnu.org/licenses/>.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>
#include <glib.h>
#include <ctype.h>
//#include "gmilena.h"

#ifndef PACKAGE_VERSION
#define PACKAGE_VERSION "1.0"
#endif

static int connect_nb(int fd,struct sockaddr *sinadr,int msec)
{
	int flags,ret,error;
	fd_set wset;
	struct timeval tv;
	socklen_t len=sizeof(error);
	flags=fcntl(fd,F_GETFL,0);
	if (flags < 0) return -1;
	FD_ZERO(&wset);
	FD_SET(fd,&wset);
	tv.tv_sec=msec/1000;
	tv.tv_usec=(msec % 1000) * 1000;
	if (fcntl(fd,F_SETFL,flags | O_NONBLOCK)<0) return -1;
	ret = connect(fd, sinadr, sizeof(*sinadr));
	if (ret < 0 && errno != EINPROGRESS) return -1;
	if (ret == 0) goto done;
	ret = select(fd + 1, NULL, &wset, NULL, &tv);
	if (ret<0) return -1;
    if (ret == 0) {
        errno = ETIMEDOUT;
        return -1;
    }
    if (!FD_ISSET(fd, &wset)) return -1;
    if(getsockopt(fd, SOL_SOCKET, SO_ERROR, &error, &len) < 0) return -1;
done:
    if (fcntl(fd,F_SETFL,flags)<0) return -1;
    return 0;
}

static int _f(FILE *f,char *s)
{
	int n;
	while (*s) {
		n=fwrite(s,1,strlen(s),f);
		if (n <= 0) return 0;
		s+=n;
	}
	return 1;
}

char *wget(char *url,int *size)
{
	struct sockaddr_in sinadr;
	char *host;
	char *path;
	char *request;
	char buffer[8192];

	char *trim(char *str)
	{
		char *c,*d;
		while (*str && isspace(*str)) str++;
		for (c=d=str;*c;c++) if (!isspace(*c)) d=c+1;
		*d=0;
		return str;
	}

	if (!strncmp(url,"http://",7)) url+=7;
	path=strchr(url,'/');
	if (path) {
		host=g_malloc((path-url)+1);
		memcpy(host,url,path-url);
		host[path-url]=0;
	}
	else {
		host=g_strdup(url);
		path="/";
	}
	int port=80;
	char *c=strchr(host,':');
	if (c) {
		*c++=0;
		port=strtol(c,NULL,10);
	}
    if (!inet_aton(host,&sinadr.sin_addr)) {
        struct hostent *h = gethostbyname(host);
        if (!h) {
			g_free(host);
			return 0;
		}
        memcpy(&(sinadr.sin_addr), h->h_addr, sizeof(struct in_addr));
        endhostent();
	}
    sinadr.sin_family = AF_INET;
    sinadr.sin_port = htons(port);

	GString *gs=g_string_sized_new(2048);
	g_string_printf(gs,"GET %s HTTP/1.1\r\nHost: %s\r\nConnection: close\r\n",path,host);
	g_string_append(gs,"User-Agent: Mozilla/5.0 (compatible; Milena AudioBook Creator "PACKAGE_VERSION")\r\n\r\n");
	request=g_string_free(gs,FALSE);
	//printf("%s\n",request);
	g_free(host);

    int fd;FILE *f;
    if ((fd = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
		g_free(request);
        return NULL;
    }
    if (connect_nb(fd, (struct sockaddr *) &sinadr,5000) < 0) {
        close(fd);
        g_free(request);
        return NULL;
    }
    f=fdopen(fd,"r+");
	if (!_f(f,request)) {
		g_free(request);
		fclose(f);
		return NULL;
	}
	g_free(request);
	int clen=0;
	int chun=0;
	if (!fgets(buffer,8192,f)) {
		fclose(f);
		return NULL;
	}
	if (strncmp("HTTP/1.1 200 ",buffer,13)) {
		fclose(f);
		return NULL;
	}
	for (;;) {
		if (!fgets(buffer,8192,f)) {
			fclose(f);
			return NULL;
		}
		char *hdr=trim(buffer);
		if (!*hdr) break;
		//printf("[%s]\n",hdr);
		if (!strncasecmp(hdr,"content-length:",15)) {
			clen=strtol(hdr+15,NULL,10);
		}
		else if (!strncasecmp(hdr,"transfer-encoding:",18)) {
			hdr=trim(hdr+18);
			if (!strcasecmp(hdr,"chunked")) chun=1;
			else {
				// unknown encoding
				fclose(f);
				return NULL;
			}
		}
	}
	if (clen) {
		char *s=g_malloc(clen+1);
		char *cs=s;
		int n,nl;
		nl=clen;
		while (nl > 0) {
			n=fread(cs,1,clen,f);
			if (n <= 0) {
				g_free(cs);
				return NULL;
			}
			nl-=n;
			cs+=n;
		}
		fclose(f);
		*cs=0;
		if (size) *size=clen;
		return s;
	}
	if (chun) {
		char *s=NULL;
		clen=0;
		for (;;) {
			for (;;) {
				if (!fgets(buffer,256,f)) {
					if (s) g_free(s);
					fclose(f);
					return NULL;
				}
				if (*buffer!='\r' && *buffer!='\n') break;
			}
			int r=strtol(buffer,NULL,16);
			if (!r) break;
			if (s) s=g_realloc(s,clen+r+1);
			else s=g_malloc(r+1);
			if (!fread(s+clen,r,1,f)) {
				g_free(s);
				fclose(f);
				return NULL;
			}
			clen+=r;

		}
		fclose(f);
		if (!s) return NULL;
		s[clen]=0;
		if (size) *size=clen;
		return s;
	}
	// unknown data
	fprintf(stderr,"Transfer encoding not set\n");
	fclose(f);
	return NULL;

}
/*
main(int argc,char *argv[])
{
	int d;
	printf("%s\n",wget(argv[1],&d));
}
*/
