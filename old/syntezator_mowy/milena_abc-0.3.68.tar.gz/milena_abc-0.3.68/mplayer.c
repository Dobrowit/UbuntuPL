/*
 * mplayer.c - Milena Audiobook Creator
 * Copyright (C) Bohdan R. Rau 2010 <ethanak@polip.com>
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write see:
 *               <http://www.gnu.org/licenses/>.
 */

#include "config.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <gtk/gtk.h>
#include "gmilena.h"
#include <errno.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <samplerate.h>
#include <math.h>
#include <sys/resource.h>
#include <ctype.h>
#ifdef HAVE_SNDFILE
#include <sndfile.h>
#endif

/*

plik movie_status:
1 - wczytane napisy
2 - wczytane napisy i audio
3 - utworzona ścieżka dźwiękowa
4 - utworzony film

*/
//char movie_name[PATH_MAX+1];
//char movie_workdir[PATH_MAX+1];

extern GtkWidget *m_video_caud,*m_video_cmov,*m_video_open;

double smix_speed=0.9;
double smix_maxspeed=0.75;
int smix_droptime=500,smix_risetime=3000,smix_mindist=3000;
int smix_audio_margin=400;
double smix_volume_factor=4.0;
double smix_max_origin_vol=1.0;
int smix_napi_delay=900;
double smix_ivona_speed=1.0;
double smix_ivona_maxspeed=1.0;

static int vmode=0;

static void fine_mpla(void);

static int rt(void){
	return TRUE;
}

/*
 * nowa wersja
 * open - zawsze
 * !is_main -> audio && video disabled
 * !movie -> audio && video disabled
 */
void enable_video_menues(int is_main,struct MyGtkEditor *editor)
{
		char buf[1024];
		int t1=0,t2=0,t3=0;
		if (is_main<0) {
			is_main = (get_current_editor() == 0);
		}
		if (!editor) {
			editor=gimma_current_editor();
		}
		t3=1;
		t1=0;
		t2=0;
		if (is_main && editor->movie_workdir[0]) {
			int p=0;
			sprintf(buf,"%s/dumpsub.txt",editor->movie_workdir);
			if (!strcmp(buf,editor->save_name) ||
				!strcmp(buf,editor->load_name)) {
					p=1;
			}
			if (!p) {
				sprintf(buf,"%s/dumpsub.jss",editor->movie_workdir);
				if (!strcmp(buf,editor->save_name) ||
					!strcmp(buf,editor->load_name)) {
						p=1;
				}
			}
			if (p) {
				sprintf(buf,"%s/audiodump.wav",editor->movie_workdir);
				if (g_file_test(buf,G_FILE_TEST_IS_REGULAR))t1=1;
			}
			sprintf(buf,"%s/newaudio.wav",editor->movie_workdir);
			if (g_file_test(buf,G_FILE_TEST_IS_REGULAR))t2=1;
		}
		gtk_widget_set_sensitive(m_video_caud,t1);
		gtk_widget_set_sensitive(m_video_cmov,t2);
		gtk_widget_set_sensitive(m_video_open,t3);
}

gint def_subonly=0;

void mplayer_read_movie(GtkWidget *widget,void *dummy)
{
    return mplayer_read_movie_and_titles(widget,dummy,NULL);
}

char *video_mimetypes[]={
	    "video/vnd.rn-realvideo","video/x-ms-asf-plugin","video/x-msvideo",
	    "video/msvideo","application/x-mplayer2","application/x-ms-wmv",
	    "video/x-ms-asf","video/x-ms-wm","video/x-ms-wmv","video/x-ms-wmp",
	    "video/x-ms-wvx","video/mpeg","video/x-mpeg","video/x-mpeg2",
	    "video/mp4","video/3gpp","video/fli","video/x-fli","video/x-flv",
	    "video/vnd.vivo","video/x-matroska","video/matroska","video/x-mng",
	    "video/webm","video/x-webm","video/mp2t","video/vnd.mpegurl",
	    "video/x-ogm+ogg",NULL};


int is_it_movie(char *fname)
{
    GFile *file = g_file_new_for_path (fname);
    GFileInfo *file_info = g_file_query_info (file,
                                              "standard::*",
                                              0,
                                              NULL,
                                              NULL);
    if (!file_info) return 0;
    const char *content_type = g_file_info_get_content_type (file_info);
    int i;
    for (i=0;video_mimetypes[i];i++) {
	if (!strcmp(content_type,video_mimetypes[i])) break;
    }
    if (!video_mimetypes[i]) {
	return 0;
    }
    return 1;
}

    
static int movie_name_display(const GtkFileFilterInfo *info, gpointer dummy)
{
    int i;
    char buf[1024];
    char *c;
    static char *exts[]={"sub","srt","ass","txt",
	"SUB","SRT","ASS","TXT",NULL};
    for (i=0;video_mimetypes[i];i++) {
	if (!strcmp(info->mime_type,video_mimetypes[i])) break;
    }
    if (!video_mimetypes[i]) {
	return 0;
    }
    if (strlen(info->filename) > 1019) return 0;
    strcpy(buf,info->filename);
    c=strrchr(buf,'.');
    if (strlen(c) > 5) {
	strcat(buf,".");
	c=buf+strlen(buf);
    }
    else c++;
    for (i=0;exts[i];i++) {
	strcpy(c,exts[i]);
	if (g_file_test(buf,G_FILE_TEST_IS_REGULAR)) return TRUE;
    }
    return 0;
}


void mplayer_read_movie_and_titles(GtkWidget *widget,void *dummy,void *subname_ini)
{
	char *fname=NULL;
	char *subname=NULL;
	GtkFileFilter *filter,*nfilter;
	static int autosub=1;
	char buf[1024];
	int subonly = 1;
	struct stat sb;
	int dialog_pos=1;
	char *dialog_names[6];
	int dialog_ids[6];
	int n;
	GtkWidget *dialog;
	int mplayer_status=0;
	char movie_name[PATH_MAX+1];
	char movie_workdir[PATH_MAX+1];
	
	if (subname_ini) subname=g_strdup(subname_ini);


	void erase_file(char *fn)
	{
		sprintf(buf,"%s/%s",movie_workdir,fn);
		unlink(buf);
	}
#ifdef USE_FFMPEG
	if (!check_program("ffmpeg","ffmpeg")) return;
	if (!check_program("ffprobe","ffmpeg")) return;
	if (!check_program("mencoder","mencoder")) return;
#else
	if (!check_program("mplayer","mplayer")) return;
	if (!check_program("mencoder","mencoder")) return;
#endif
    if (!dummy) {
        dialog=gtk_file_chooser_dialog_new(
            "Wybierz film",
            GTK_WINDOW(main_window),GTK_FILE_CHOOSER_ACTION_OPEN,
            GTK_STOCK_CANCEL, GTK_RESPONSE_CANCEL,
            GTK_STOCK_OPEN, GTK_RESPONSE_ACCEPT,
            NULL);
        GtkWidget *autosub_cb=gtk_check_button_new_with_label("Automatycznie załaduj napisy");
        GtkWidget *onlysub_cb=gtk_check_button_new_with_label("Tylko napisy (bez tworzenia audio)");
        gtk_toggle_button_set_active((gpointer) autosub_cb,autosub);
        gtk_toggle_button_set_active((gpointer) onlysub_cb,0);

        GtkWidget *hbox=gtk_vbox_new(0,2);
        gtk_box_pack_start(GTK_BOX(hbox),autosub_cb,FALSE,FALSE,0);
        gtk_box_pack_start(GTK_BOX(hbox),onlysub_cb,FALSE,FALSE,0);

        gtk_file_chooser_set_local_only((gpointer)dialog,TRUE);
	nfilter=gtk_file_filter_new();
	gtk_file_filter_set_name(nfilter,"Filmy z napisami");
	gtk_file_filter_add_custom(nfilter,
	    GTK_FILE_FILTER_FILENAME | GTK_FILE_FILTER_MIME_TYPE,
	    movie_name_display,NULL,NULL);
	gtk_file_chooser_add_filter((gpointer) dialog,nfilter);
	filter=gtk_file_filter_new();
	gtk_file_filter_set_name(filter,"Wszystkie filmy");
	for (n=0;video_mimetypes[n];n++) {
	    gtk_file_filter_add_mime_type(filter,video_mimetypes[n]);
	}
	gtk_file_chooser_add_filter((gpointer) dialog,filter);
/*
        gtk_file_chooser_add_filter((gpointer) dialog,
            filter=make_filter("Pliki video",
	    "*.avi","*.AVI",
	    "*.rmvb","*.RMVB",
	    "*.mkv","*.MKV",
	    NULL));
*/
        gtk_file_chooser_add_filter((gpointer) dialog,
            make_filter("Wszystkie pliki","*",NULL));
        gtk_file_chooser_set_filter((gpointer) dialog,filter);
        gtk_file_chooser_set_extra_widget((gpointer) dialog,hbox);
        gtk_widget_show_all(hbox);
        if (gtk_dialog_run((gpointer)dialog)==GTK_RESPONSE_ACCEPT) {
            fname=gtk_file_chooser_get_filename((gpointer)dialog);
            autosub=gtk_toggle_button_get_active((gpointer)autosub_cb);
            subonly=gtk_toggle_button_get_active((gpointer)onlysub_cb);
        }
        gtk_widget_destroy(dialog);
        if (!fname) {
            enable_video_menues(-1,NULL);
            return;
        }
    } else {
        if (!g_path_is_absolute(dummy)) {
            gchar *cd=g_get_current_dir();

            fname=g_build_filename(cd,dummy,NULL);
            g_free(cd);
        }
        else fname=g_strdup(dummy);
	if (subname_ini && !strcmp(subname_ini,"?")) {
		autosub=0;
		subname_ini=NULL;
	}
	else {
		autosub=1;
	}
        subonly=def_subonly;
    }
	if (!autosub) {
		dialog=gtk_file_chooser_dialog_new(
			"Wybierz plik napisów",
			GTK_WINDOW(main_window),GTK_FILE_CHOOSER_ACTION_OPEN,
			GTK_STOCK_CANCEL, GTK_RESPONSE_CANCEL,
			GTK_STOCK_OPEN, GTK_RESPONSE_ACCEPT,
			NULL);
		gtk_file_chooser_set_local_only((gpointer)dialog,TRUE);
		gtk_file_chooser_add_filter((gpointer) dialog,
			filter=make_filter("Pliki napisów","*.txt","*.srt","*.sub","*.ass",NULL));
		gtk_file_chooser_add_filter((gpointer) dialog,
			make_filter("Wszystkie pliki","*",NULL));
		gtk_file_chooser_set_filter((gpointer) dialog,filter);
		char *fld=g_path_get_dirname(fname);
		gtk_file_chooser_set_current_folder((gpointer)dialog,fld);
		g_free(fld);
		if (gtk_dialog_run((gpointer)dialog)==GTK_RESPONSE_ACCEPT){
			subname=gtk_file_chooser_get_filename((gpointer)dialog);
		}
		gtk_widget_destroy(dialog);
		if (!subname) {
			g_free(fname);
			enable_video_menues(-1,NULL);
			return;
		}

	}
	strcpy(movie_name,fname);
	g_free(fname);
	char *cs=strrchr(movie_name,'/');
	if (!cs) {
        if (!dummy) {
            if (subname) g_free(subname);
            enable_video_menues(-1,NULL);
            return;
        }
        cs=movie_name;
	}
	else cs++;

	char *ds=strrchr(cs,'.');
	if (ds && ds !=cs) n=ds-cs;
	else n=strlen(cs);
	sprintf(movie_workdir,"%s/tmp/milena_movie/%-*.*s",getenv("HOME"),n,n,cs);

	n=g_mkdir_with_parents(movie_workdir,0700);
	if (n<0) {
perr:	if (subname) g_free(subname);
		ErrorF(NULL,"Błąd","Błąd tworzenia katalogu roboczego:\n%s",strerror(errno));
		enable_video_menues(-1,NULL);
		return;
	}
	int pid;
	int rc=subonly?1:3;
	int sub_exists=0;
	int wav_exists=0;


	sprintf(buf,"%s/dumpsub.jss",movie_workdir);
	if (g_file_test(buf,G_FILE_TEST_IS_REGULAR) && !stat(buf,&sb)) {
		time_t t1=sb.st_mtime,t2;
		sub_exists=1;
		sprintf(buf,"%s/dumpsub.txt",movie_workdir);
		if (g_file_test(buf,G_FILE_TEST_IS_REGULAR) && !stat(buf,&sb)) {
			t2=sb.st_mtime;
			if (t2 >= t1) {
				sub_exists |= 2;
				sprintf(buf,"%s/dumpsub.dic",movie_workdir);
				if (g_file_test(buf,G_FILE_TEST_IS_REGULAR) && !stat(buf,&sb)) {
					//t3=sb.st_mtime;
					//if (t3 >= t2) {
						sub_exists |= 4;
					//}
				}
			}
		}
	}
	if (!subonly) {
		sprintf(buf,"%s/audiodump.wav",movie_workdir);
		if (g_file_test(buf,G_FILE_TEST_IS_REGULAR)) {
			wav_exists=1;
		}
	}
	dialog_names[0]="Anuluj";
	dialog_ids[0]=GTK_RESPONSE_CANCEL;

	void add_button(char *a,int b)
	{
		dialog_names[dialog_pos]=a;
		dialog_ids[dialog_pos++]=b;
		dialog_names[dialog_pos]=NULL;
	}


	if (sub_exists) {
		if (subonly) {
			add_button("Utwórz nowe",1);
			add_button("Istniejące",4);
		}
		else {
			if (wav_exists) {
				add_button("Utwórz nowe",3);
				add_button("Pozostaw napisy",2);
				add_button("Pozostaw audio",1);
				add_button("Istniejące",4);
			}
			else {
				add_button("Utwórz nowe",3);
				add_button("Utwórz tylko audio",2);
				add_button("Istniejące",4);
			}
		}
	}
	if (dialog_pos>1) {
		dialog=gtk_dialog_new_with_buttons("Pytanko",
			(gpointer)main_window,
			GTK_DIALOG_DESTROY_WITH_PARENT,
			dialog_names[0],dialog_ids[0],
			dialog_names[1],dialog_ids[1],
			dialog_names[2],dialog_ids[2],
			dialog_names[3],dialog_ids[3],
			dialog_names[4],dialog_ids[4],NULL);
		GtkWidget *label=gtk_label_new(
			(wav_exists && sub_exists) ?"Znaleziono istniejące pliki audio i napisów":
			wav_exists?"Znaleziono istniejący plik audio":
			"Znaleziono istniejący plik napisów");
		GtkWidget *ca=gtk_dialog_get_content_area (GTK_DIALOG (dialog));
		gtk_container_add (GTK_CONTAINER (ca), label);
		gtk_widget_show_all(dialog);
		rc=gtk_dialog_run(GTK_DIALOG(dialog));
		gtk_widget_destroy(dialog);
		if (rc < 1 || rc > 4) {
			enable_video_menues(-1,NULL);
			return;
		}
	}


	rc = rc & 3;
	if (rc & 1) {
		FILE *f;
		char *bladz=NULL;
		char *subs=subtitle_read_buffer(subname,movie_name,&bladz);
		if (subname) g_free(subname);
		subname=NULL;
		if (!subs) {
			if (!bladz) bladz="Nie znaleziono ani jednej linii z napisami";
			ErrorF(NULL,"Napisy","Nie mogę czytać napisów:\n%s",bladz);
			enable_video_menues(-1,NULL);
			return;
		}
		sprintf(buf,"%s/dumpsub.jss",movie_workdir);
		if (!(f=fopen(buf,"w"))) {
			ErrorF(NULL,"Napisy","Nie mogę zapisać pliku:\n%s",strerror(errno));
			g_free(subs);
			enable_video_menues(-1,NULL);
			return;
		}
		ignore(fwrite(subs,strlen(subs),1,f));
		fclose(f);
		g_free(subs);
	}
#ifdef USE_FFMPEG
	if (rc & 2) {
		sprintf(buf,"%s/audiodump.wav",movie_workdir);
		char *envp[16];
		int n=0;
		envp[n++]="ffmpeg";
		envp[n++]="-i";
		envp[n++]=movie_name;
		envp[n++]="-vn";
		envp[n++]="-y";
		envp[n++]=buf;
		envp[n++]=NULL;
		int pipa[2];
		char abuff[1024];
		ignore(pipe(pipa));
		pid=fork();
		if (pid < 0) {
			goto perr;
		}
		if (!pid) {
			//close(0);
			//close(2);
			close(pipa[0]);
			dup2(pipa[1],1);
			dup2(pipa[1],2);
			if (chdir(movie_workdir)) {
				exit(1);
			}
			execvp(envp[0],envp);
			exit(0);
		}
		close(pipa[1]);
        setpriority(PRIO_PROCESS,pid,10);
		FILE *fr=fdopen(pipa[0],"r");
		GtkWidget *progr=gtk_dialog_new_with_buttons(
		"FFMpeg",
			(gpointer)main_window,
			GTK_DIALOG_MODAL,
			"Przerwij",100,
			NULL);
		GtkWidget *progr_box=gtk_dialog_get_content_area((gpointer)progr);
		GtkWidget *progr_label=gtk_label_new("Zrzut audio: 0:00:00");
		gtk_label_set_selectable((gpointer)progr_label,TRUE);
		gtk_box_pack_start(GTK_BOX(progr_box),(gpointer)progr_label,FALSE,FALSE,0);
		gtk_widget_show_all(progr_box);
		int pbreak=0;
		int audiosecs=0;

		void saudio(int n)
		{
			if (audiosecs < n-5) {
				audiosecs=n;
				sprintf(abuff,"Zrzut audio: %d:%02d:%02d",
					n/3600,(n%3600)/60,n%60);
				gtk_label_set_text((gpointer) progr_label,abuff);
			}
		}
		void progbreak(GtkWidget *w,gint id,gpointer udata)
		{
			if (id == 100) pbreak=1;
		}

		g_signal_connect_swapped(G_OBJECT(progr), "delete-event",
			G_CALLBACK(rt), NULL);
		g_signal_connect_swapped(G_OBJECT(progr), "response",
			G_CALLBACK(progbreak), NULL);

		gtk_widget_show_all((gpointer)progr);
		while (fgets(abuff,256,fr)) {
			char *c=strstr(abuff,"time=");
			if (c) {
				saudio(strtol(c+5,NULL,10));
			}
			yield();
			if (pbreak) {
				kill(pid,KILL_SIGNAL);
				break;
			}
		}
		waitpid(pid,&mplayer_status,0);
		fclose(fr);
		gtk_widget_hide_all((gpointer)progr);
		gtk_widget_destroy(progr);
		if (pbreak) {
			kill(pid,KILL_SIGNAL);
			waitpid(pid,NULL,0);
			if (rc & 1) {
				erase_file("dumpsub.jss");
			}
			if (rc & 2) {
				erase_file("audiodump.wav");
			}
			enable_video_menues(-1,NULL);
			ignore(system("reset"));
			return;
		}
	}
#else
	/* use mplayer */

	if (rc & 2) {
		char *envp[32];
		int vpos;
		envp[0]="mplayer";
		vpos=1;
		envp[vpos++]="-ao";
		envp[vpos++]="pcm:fast:waveheader";
		envp[vpos++]="-vo";
		envp[vpos++]="null";
		envp[vpos++]="-vc";
		envp[vpos++]="null";
		envp[vpos++]=movie_name;
		envp[vpos]=NULL;
		int pipa[2];
		char abuff[1024];
		ignore(pipe(pipa));
		pid=fork();
		if (pid < 0) {
			goto perr;
		}
		if (!pid) {
			//close(0);
			close(2);
			close(pipa[0]);
			dup2(pipa[1],1);
			if (chdir(movie_workdir)) {
				exit(1);
			}
			execvp(envp[0],envp);
			exit(0);
		}
		close(pipa[1]);
        setpriority(PRIO_PROCESS,pid,10);
		FILE *fr=fdopen(pipa[0],"r");
		GtkWidget *progr=gtk_dialog_new_with_buttons(
		"Mplayer",
			(gpointer)main_window,
			GTK_DIALOG_MODAL,
			"Przerwij",100,
			NULL);
		GtkWidget *progr_box=gtk_dialog_get_content_area((gpointer)progr);
		GtkWidget *progr_label=gtk_label_new("Zrzut audio: 0:00:00");
		gtk_label_set_selectable((gpointer)progr_label,TRUE);
		gtk_box_pack_start(GTK_BOX(progr_box),(gpointer)progr_label,FALSE,FALSE,0);
		gtk_widget_show_all(progr_box);
		int pbreak=0;
		int audiosecs=0;

		void saudio(int n)
		{
			if (audiosecs < n-5) {
				audiosecs=n;
				sprintf(abuff,"Zrzut audio: %d:%02d:%02d",
					n/3600,(n%3600)/60,n%60);
				gtk_label_set_text((gpointer) progr_label,abuff);
			}
		}
		void progbreak(GtkWidget *w,gint id,gpointer udata)
		{
			if (id == 100) pbreak=1;
		}

		g_signal_connect_swapped(G_OBJECT(progr), "delete-event",
			G_CALLBACK(rt), NULL);
		g_signal_connect_swapped(G_OBJECT(progr), "response",
			G_CALLBACK(progbreak), NULL);

		gtk_widget_show_all((gpointer)progr);
		while (fgets(abuff,256,fr)) {
			char *c=strstr(abuff,"A:");
			if (c) {
				saudio(strtol(c+2,NULL,10));
			}
			yield();
			if (pbreak) {
				kill(pid,KILL_SIGNAL);
				break;
			}
		}
		waitpid(pid,&mplayer_status,0);
		fclose(fr);
		gtk_widget_hide_all((gpointer)progr);
		gtk_widget_destroy(progr);
		if (pbreak) {
			kill(pid,KILL_SIGNAL);
			waitpid(pid,NULL,0);
			if (rc & 1) {
				erase_file("dumpsub.jss");
			}
			if (rc & 2) {
				erase_file("audiodump.wav");
			}
			Info("Mplayer","Operacja anulowana");
			if (subname) {
				g_free(subname);
			}
			enable_video_menues(-1,NULL);
			ignore(system("reset"));
			return;
		}
		if (mplayer_status) {
			if (rc & 1) {
				erase_file("dumpsub.jss");
			}
			if (rc & 2) {
				erase_file("audiodump.wav");
			}
			Info("Mplayer","Błąd wykonania mplayera");
			if (subname) {
				g_free(subname);
			}
			enable_video_menues(-1,NULL);
			ignore(system("reset"));
			return;
		}
	}
#endif
	if (subname) {
		g_free(subname);
	}
	fname="dumpsub.jss";
	auto_load_dic=0;
	if (!(rc & 1)) {
		if (sub_exists & 2) {
			fname="dumpsub.txt";
			auto_load_dic= (sub_exists & 4);
		}
	}

	sprintf(buf,"%s/%s",movie_workdir,fname);
	open_file(NULL,g_strdup(buf));
	strcpy(current_editor->movie_name,movie_name);
	strcpy(current_editor->movie_workdir,movie_workdir);
	enable_video_menues(-1,NULL);
	auto_window_title();
}

static struct jacosub {
	int timer;
	//char *text;
        char *pho;
        int orig_msec;
        double speed;
        int real_msec;
        int max_sample;
        int start_sample;
        int num_samples;
        double volmpx;
} *jacos;
static int jacos_count;
static int njacos;
static void jacos_free(void)
{
	int i;
	for (i=0;i<njacos;i++) if (jacos[i].pho) free(jacos[i].pho);
	njacos=0;
}

static int compute_msec(char *c)
{
    int plen=100;
    char *d;
    for (;*c;c=d+1) {
        d=strchr(c,'\n');
        if (!d) break;
        while (*c && isspace(*c) && *c!='\n') c++;
        if (*c==';' || *c=='\n') continue;
        while (*c != '\n' && !isdigit(*c))  c++;
        if (!*c || *c=='\n') continue;
        plen+=strtol(c,&c,10);
    }
    return plen;
}

static int do_make_jacos;
static GtkWidget *jacomaker_dialog;
static GtkWidget *jacomaker_label;
static void jacomaker_break(GtkWidget *w,gint id,gpointer udata)
{
	if (Ask2("Pytanie","Na pewno przerywasz?",jacomaker_dialog)) do_make_jacos=0;
}

void show_jacomaker_dialog(int np)
{
	if (np<0) np=0;
    char buf[256];
    static gint64 tv;
    sprintf(buf,"Przetworzono %d kwestii",np);
    if (!jacomaker_dialog) {
        jacomaker_dialog=gtk_dialog_new_with_buttons("Ustalanie czasów",
			(gpointer)main_window,
			GTK_DIALOG_DESTROY_WITH_PARENT | GTK_DIALOG_MODAL,
			"Przerwij",100,NULL);
        g_signal_connect_swapped(G_OBJECT(jacomaker_dialog), "delete-event",
            G_CALLBACK(rt), NULL);
        g_signal_connect_swapped(G_OBJECT(jacomaker_dialog), "response",
            G_CALLBACK(jacomaker_break), NULL);

        jacomaker_label=(gpointer)gtk_label_new(buf);
        gtk_label_set_selectable((gpointer)jacomaker_label,TRUE);
        GtkWidget *box=gtk_vbox_new(0,2);
        gtk_box_pack_start(GTK_BOX(box),(gpointer)jacomaker_label,FALSE,FALSE,0);
        GtkWidget *ca=gtk_dialog_get_content_area (GTK_DIALOG (jacomaker_dialog));
        gtk_container_add (GTK_CONTAINER (ca), box);
        gtk_widget_show_all(jacomaker_dialog);
        do_make_jacos=1;
        tv=g_get_real_time();
	}
    else {
		if (g_timer_can_step(&tv,2500)) {
			gtk_label_set_text((gpointer)jacomaker_label,buf);
		}
    }
	yield();
}
void hide_jacomaker_dialog(void)
{
	if (jacomaker_dialog) {
		gtk_widget_hide_all((gpointer) jacomaker_dialog);
		gtk_widget_destroy(jacomaker_dialog);
		jacomaker_dialog=NULL;
	}
}


int make_jacolist(void)
{
	char *str=get_current_iso2();
	char *cs,*nd,*ph;
	int timeres,msec,dura,i,maxmili,devmili;
	if (!jacos_count) {
		jacos=calloc(sizeof(*jacos),jacos_count=1024);
		njacos=0;
	}
	else {
		jacos_free();
	}
	if (!str) return 0;
	if (strncmp(str,"#TIMERES",8)) {
		free(str);
		return 0;
	}
	timeres=strtol(str+8,&cs,10);

	if (!timeres) {
		free(str);
		return 0;
	}
#ifdef HAVE_IVONA
    if (use_ivona) {
        show_jacomaker_dialog(-1);
        do_make_jacos=1;
    }
#endif
	for (;cs && *cs;) {
		cs+=strspn(cs,"\r\n");
		if (!*cs) break;
		if (!isdigit(*cs)) {
bad_loop:	cs=strpbrk(cs,"\r\n");
			if (!cs) break;
			continue;
		}
		msec=get_jaco_timer(cs,timeres)+smix_napi_delay;
		if (msec < 0) goto bad_loop;
		cs+=strspn(cs,"0123456789 .:\t");
		for (;*cs;) {
			cs+=strspn(cs,"\t /-");
			if (*cs != '{') break;
			for (;*cs;) {
				if (strchr("\r\n",*cs)) break;
				if (*cs++=='}') break;
			}
		}
		nd=strpbrk(cs,"\r\n");
		if (!nd) nd=cs+strlen(cs);
		if (nd == cs) continue;
		if (*nd) *nd++=0;
		ph=translate_subtitle(cs);
		cs=nd;
		if (!ph) continue;
#ifdef HAVE_IVONA
        if (use_ivona) {
            yield();
            if (!do_make_jacos) {
                free(str);
                jacos_free();
                hide_jacomaker_dialog();
                return 0;
            }
            dura=ivona_compute_msec(ph,current_editor->movie_workdir);
            /*
            if (dura < 0) {
				printf("Dura = %d dla '%s'\n",dura,ph);
                free(str);
                jacos_free();
                hide_jacomaker_dialog();
                return 0;
            }
            printf("DURA %d %s\n",dura,ph);
            */

        }
        else {
            dura=compute_msec(ph);
        }
#else
		dura=compute_msec(ph);
#endif
		if (dura <= 50) continue;
		if (jacos_count <= njacos) {
			jacos_count+=1024;
			jacos=realloc(jacos,sizeof(*jacos) * jacos_count);
		}
		memset(&jacos[njacos],0,sizeof(*jacos));
		jacos[njacos].timer=msec;
		jacos[njacos].pho=strdup(ph);
		jacos[njacos].orig_msec=dura;
		njacos++;
#ifdef HAVE_IVONA
        if (use_ivona) show_jacomaker_dialog(njacos);
#endif

	}
#ifdef HAVE_IVONA
    if (use_ivona) hide_jacomaker_dialog();
#endif
	free(str);
	if (!njacos) return 0;
    maxmili=0;
#ifdef HAVE_IVONA
    if (use_ivona) {
        for (i=0;i<njacos-1;i++) {
            if (jacos[i].timer + jacos[i].orig_msec/smix_ivona_speed <= jacos[i+1].timer) {
                jacos[i].speed=smix_ivona_speed;
            }
            else {
                double t=(jacos[i+1].timer - jacos[i].timer)/(double)jacos[i].orig_msec;
                if (t >= 1.0/smix_ivona_maxspeed) {
                    jacos[i].speed=1.0/t;
                }
                else {
                    jacos[i].speed=smix_ivona_maxspeed;
                }
            }
            jacos[i].real_msec=jacos[i].orig_msec / jacos[i].speed;
            if (jacos[i].timer + jacos[i].real_msec > jacos[i+1].timer) {
                devmili=(jacos[i].timer+jacos[i].real_msec)-jacos[i+1].timer;
                if (devmili > maxmili) maxmili=devmili;
                jacos[i+1].timer=jacos[i].timer + jacos[i].real_msec;
            }
        }
        jacos[i].speed=smix_ivona_speed;
        jacos[i].real_msec=jacos[i].orig_msec / jacos[i].speed;
        return maxmili;
    }
#endif
    for (i=0;i<njacos-1;i++) {
        if (jacos[i].timer + smix_speed * jacos[i].orig_msec <= jacos[i+1].timer) {
            jacos[i].speed=smix_speed;
        }
        else {
            double t=(jacos[i+1].timer - jacos[i].timer)/(double)jacos[i].orig_msec;
            if (t >= smix_maxspeed) {
                jacos[i].speed=t;
            }
            else {
                jacos[i].speed=smix_maxspeed;
            }
        }
        jacos[i].real_msec=jacos[i].orig_msec* jacos[i].speed;
        if (jacos[i].timer + jacos[i].real_msec > jacos[i+1].timer) {
			devmili=(jacos[i].timer+jacos[i].real_msec)-jacos[i+1].timer;
			if (devmili > maxmili) maxmili=devmili;
			jacos[i+1].timer=jacos[i].timer + jacos[i].real_msec;
		}
    }
    jacos[i].speed=smix_speed;
    jacos[i].real_msec=jacos[i].orig_msec* jacos[i].speed;
    return maxmili;
}

#ifndef O_BINARY
#define O_BINARY 0
#endif


static int smix_input_channels;
static int smix_input_samplefreq;
static long smix_input_samples;
static int smix_input_fd,smix_output_fd;
static double smix_volume_mpx;
static int smix_computed_margin;

#ifdef HAVE_SNDFILE
static SNDFILE *smix_sndf_in,*smix_sndf_out;
static double smix_prescaler;
#endif

static int smix_break;
static int mplaudio_percent;

static GtkWidget *mplaudio_dialog,*mplaudio_pgm;
static int smix_break_imm;
static void mplaudio_break(GtkWidget *w,gint id,gpointer udata)
{
	if (id != 100) return;
	if (smix_break_imm) {
		smix_break=1;
		return;
	}
	if (Ask2("Pytanie","Na pewno przerywasz?",mplaudio_dialog)) smix_break=1;
}
static GtkLabel *mplaudio_label;
void show_mplaudio_dialog(char *txt,int imedia)
{
	mplaudio_percent=0;
	smix_break_imm=imedia;
	mplaudio_dialog=gtk_dialog_new_with_buttons("Przetwarzanie",
			(gpointer)main_window,
			GTK_DIALOG_DESTROY_WITH_PARENT | GTK_DIALOG_MODAL,
			"Przerwij",100,NULL);
	g_signal_connect_swapped(G_OBJECT(mplaudio_dialog), "delete-event",
	      G_CALLBACK(rt), NULL);
	g_signal_connect_swapped(G_OBJECT(mplaudio_dialog), "response",
	      G_CALLBACK(mplaudio_break), NULL);

	mplaudio_label=(gpointer)gtk_label_new(txt);
	gtk_label_set_selectable((gpointer)mplaudio_label,TRUE);
	GtkWidget *box=gtk_vbox_new(0,2);
	gtk_box_pack_start(GTK_BOX(box),(gpointer)mplaudio_label,FALSE,FALSE,0);
	mplaudio_pgm=gtk_progress_bar_new();
	init_progressbar((gpointer)mplaudio_pgm);
	gtk_box_pack_start(GTK_BOX(box),(gpointer)mplaudio_pgm,FALSE,FALSE,0);

	GtkWidget *ca=gtk_dialog_get_content_area (GTK_DIALOG (mplaudio_dialog));
	gtk_container_add (GTK_CONTAINER (ca), box);
	gtk_widget_set_size_request((gpointer)mplaudio_pgm, 320,-1);
	gtk_widget_show_all(mplaudio_dialog);


}
void hide_mplaudio_dialog(void)
{
	if (mplaudio_dialog) {
		gtk_widget_hide_all((gpointer) mplaudio_dialog);
		gtk_widget_destroy(mplaudio_dialog);
		mplaudio_dialog=NULL;
	}
}
void show_mplaudio_percent(double pc)
{
	int ipc=pc*100.0;
	if (ipc>100) ipc=100;
	else if (ipc<0) ipc=0;
	if (ipc == mplaudio_percent) return;
    mplaudio_percent=ipc;
	gtk_progress_bar_set_fraction((gpointer)mplaudio_pgm,ipc/100.0);
}

void show_mplaudio_label(char *txt)
{
	gtk_label_set_text((gpointer)mplaudio_label,txt);
	yield();
}

#ifdef HAVE_SNDFILE


static double compute_max_sample(int fra,int nsamples,int interact,int use_prescaler)
{
	int buflen=1048576;
    static float *lbuffer;
    int tlen;
    double mx;
    if (!lbuffer) lbuffer=malloc(sizeof(float)*buflen);
	if (fra+nsamples > smix_input_samples) nsamples=smix_input_samples-fra;
	mx=0;
	tlen=nsamples*smix_input_channels;
	sf_seek(smix_sndf_in,fra,SEEK_SET);
	while (nsamples>0) {
		int p=buflen,r,i;
		if (p>smix_input_channels * nsamples) {
			p=smix_input_channels * nsamples;
		}
		r=sf_read_float(smix_sndf_in,lbuffer,p);
		if (r != p) {
            if (interact) hide_mplaudio_dialog();
            Error("Odczyt MaxSample",(char *)sf_strerror(smix_sndf_in));
            return -1;
		}
		if (debug_level) printf("Sample value %f\n",lbuffer[0]);
		for (i=0;i<r;i++) {
			if (lbuffer[i]<0) {
				if (lbuffer[i]<-mx) mx=-lbuffer[i];
			}
			else {
				if (lbuffer[i]>mx) mx=lbuffer[i];
			}
		}
		if (interact) show_mplaudio_percent((double)(tlen-nsamples)/(double)tlen);
		yield();
		if (smix_break) {
			mx=-1;
			break;
		}
		nsamples-=r;
	}
	if (use_prescaler) return mx * smix_prescaler;
	return mx;
}


int open_input_wave(char *name)
{
	struct SF_INFO info;
	SNDFILE *f;
	memset(&info,0,sizeof(info));
	f=sf_open(name,SFM_READ,&info);
	if (!f) {
		ErrorF(NULL,"Błąd","Błąd pliku audiodump.wav:\n%s",strerror(errno));
dupa2:		if (f) sf_close(f);
		return 0;
	}
	//sf_command(f,SFC_SET_SCALE_FLOAT_INT_READ,NULL,SF_TRUE);
	smix_input_channels=info.channels;
	if (smix_input_channels != 1 && smix_input_channels != 2) {
		Error("Błąd audiodump","To nie jest PCM MONO/STEREO\n");
		goto dupa2;
	}
    smix_sndf_in=f;
	smix_input_samples=info.frames;
	smix_input_samplefreq=info.samplerate;
	smix_computed_margin=(smix_input_samplefreq * smix_audio_margin)/1000;
	double max_sample=compute_max_sample(0,smix_input_samples,1,0);
	if (max_sample < 0) goto dupa2;
	if (max_sample <= 0) {
        max_sample=1;
	}
	smix_prescaler=32767.0/max_sample;
	max_sample=32767;
    smix_volume_mpx=(32767*smix_volume_factor)/(max_sample * (1.0+smix_volume_factor));
    if (debug_level) printf("Volume mpx %f, ms=%f\n",smix_volume_mpx,max_sample);
	return 1;
}

#else

static off_t smix_input_wave_start;

static int g32(char *buf)
{
	return (buf[0] & 255) |
		((buf[1] & 255) << 8) |
		((buf[2] & 255) <<16) |
		((buf[3] & 255) <<24);
}

static int g16(char *buf)
{
	return (buf[0] & 255) |
		((buf[1] & 255) << 8);
}

static int compute_max_sample(int fra,int nsamples,int interact)
{
	long startpos=2*smix_input_channels*fra;
	size_t n;
    int mx,tlen;
	int buflen=1048576;
    static short *lbuffer;
    if (!lbuffer) lbuffer=malloc(2*buflen);
    if (startpos<0) startpos=0;
	if (fra+nsamples > smix_input_samples) nsamples=smix_input_samples-fra;
	n=nsamples*smix_input_channels;
	lseek(smix_input_fd,startpos+smix_input_wave_start,SEEK_SET);
	mx=1;
	tlen=n;
	while (n>0) {
		int p=1048576,r,i;
		if (p>2*n) p=2*n;
		r=read(smix_input_fd,lbuffer,p);
		if (r<=0) {
              if (errno == EAGAIN) {
                  sleep(4);
                  printf("Sleeping, wait for %d at %ld\n",p,startpos+smix_input_wave_start);
                  r=read(smix_input_fd,lbuffer,p);
              }
              if (r<=0) {
                if (interact) hide_mplaudio_dialog();
                Error("Odczyt",strerror(errno));
                return -1;
            }
        }
		r=r/2;
		for (i=0;i<r;i++) {
			if (lbuffer[i]<0) {
				if (lbuffer[i]<-mx) mx=-lbuffer[i];
			}
			else {
				if (lbuffer[i]>mx) mx=lbuffer[i];
			}
		}
		n-=r;
		if (interact) show_mplaudio_percent((double)(tlen-n)/(double)tlen);
		yield();
		if (smix_break) {
			mx=-1;
			break;
		}
	}
	return mx;
}

int open_input_wave(char *name)
{
	int fd=open(name,O_RDONLY | O_BINARY);
	int wlen,max_sample;
	char buf[1024];
	if (fd<0) {
dupa:
		ErrorF(NULL,"Błąd","Błąd pliku audiodump.wav:\n%s",strerror(errno));
dupa2:		if (fd >= 0) close(fd);
		return 0;
	}
	if (read(fd,buf,20)!=20) goto dupa;
	if (memcmp(buf,"RIFF",4)) {
		Error("Błąd audiodump","To nie jest plik RIFF");
		goto dupa2;
	}
	if (memcmp(buf+8,"WAVE",4)) {
		Error("Błąd audiodump","To nie jest plik WAV");
		goto dupa2;
	}
	if (memcmp(buf+12,"fmt ",4)) {
kop:	Error("Błąd audiodump","Błędny plik WAV");
		goto dupa2;
	}
	wlen=g32(buf+16);
	if (wlen<12 || wlen > 64) goto kop;
	if (read(fd,buf,wlen)!=wlen) goto dupa;
	if (g16(buf) != 1) {
		Error("Błąd audiodump","To nie jest PCM WAV");
		goto dupa2;
	}
	smix_input_channels=g16(buf+2);
	if (smix_input_channels != 1 && smix_input_channels != 2) {
		Error("Błąd audiodump","To nie jest PCM MONO/STEREO\n");
		goto dupa2;
	}
	smix_input_samplefreq=g32(buf+4);
	if (g16(buf+12) != 2*smix_input_channels) {
		Error("Błąd audiodump","To nie jest PCM 16bit");
		goto dupa2;
	}
	if (read(fd,buf,8)!=8) goto dupa;
	if (memcmp(buf,"data",4)) goto kop;
	wlen=g32(buf+4);
	smix_input_samples=wlen/(2*smix_input_channels);
	smix_input_wave_start=lseek(fd,0,SEEK_CUR);
	smix_input_fd=fd;
	smix_computed_margin=(smix_input_samplefreq * smix_audio_margin)/1000;
	max_sample=compute_max_sample(0,smix_input_samples,1);
	if (max_sample <= 0) {
        max_sample=32767;
		//close(fd);
		//return 0;
	}
    smix_volume_mpx=(32767*smix_volume_factor)/(max_sample * (1.0+smix_volume_factor));
	return 1;
}

#endif

static int plan_lastpos=0;
#define PLAN_VOL_NORMAL 0
#define PLAN_VOL_FADE 1
#define PLAN_VOL_MIX 2

static struct planen {
    int plan;
    double vol1;
    double vol2;
    int duration;
    int jaco;
} *plany;

static int plany_cnt,plany_size;

void add_plan(int plan,double vol1, double vol2,int duration,int mix)
{
    if (!plany_size) {
        plany_size=1024;
        plany=malloc(plany_size * sizeof(*plany));
    }
    else if (plany_cnt >= plany_size) {
        plany_size+=1024;
        plany=realloc(plany,plany_size * sizeof(*plany));
    }
    plany[plany_cnt].plan=plan;
    plany[plany_cnt].vol1=vol1;
    plany[plany_cnt].vol2=vol2;
    plany[plany_cnt].duration=duration;
    plany[plany_cnt].jaco=mix;
    plany_cnt++;
    plan_lastpos+=duration;
    if (debug_level) printf("Add plan: %d %.3f %.3f %04d %d\n",plan,vol1,vol2,mix,duration);
}


static int init_plan(void)
{
	int i;
    for (i=0;i<njacos;i++) {
        double vmp;
        jacos[i].start_sample=(jacos[i].timer * (double)smix_input_samplefreq)/1000;
        jacos[i].num_samples=(jacos[i].real_msec * (double)smix_input_samplefreq)/1000;
        if (jacos[i].start_sample + jacos[i].num_samples > smix_input_samples) break;
        jacos[i].max_sample=compute_max_sample(jacos[i].start_sample-smix_computed_margin,jacos[i].num_samples+2*smix_computed_margin,0,1);
        if (jacos[i].max_sample < 0) return 0;
        if (jacos[i].max_sample<100) jacos[i].volmpx=smix_volume_mpx*smix_max_origin_vol;
        else {
            vmp=(32767.0/(1.0+smix_volume_factor)) / jacos[i].max_sample;
            if (vmp > smix_volume_mpx*smix_max_origin_vol) vmp=smix_volume_mpx*smix_max_origin_vol;
            jacos[i].volmpx=vmp;
        }
    }
    if (i<njacos) {
		int j;
		char buf[256];
		sprintf(buf,"Ucięto %d końcowe kwestie.\nCzy mam kontynuować?",njacos-i);
		if (!Ask("Pytanie",buf)) return 0;
		for (j=i;j<njacos;j++) {
			if (jacos[j].pho) free(jacos[j].pho);
			jacos[j].pho=NULL;
		}
		njacos=i;
	}

    for (i=njacos-2;i>=0;i--) {
        if (jacos[i].timer+jacos[i].real_msec > jacos[i+1].timer-500) jacos[i].volmpx=jacos[i+1].volmpx;
    }
	double lastvol=smix_volume_mpx;
    int rise_d=((double)smix_risetime * (double)smix_input_samplefreq)/1000;
    int drop_d=((double)smix_droptime * (double)smix_input_samplefreq)/1000;
    int mini_d=rise_d + drop_d + (smix_mindist * (double)smix_input_samplefreq)/1000;
    int nstart;
    plany_cnt=0;plan_lastpos=0;

    for (i=0;i<njacos;i++) {
		show_mplaudio_percent((double)i/(double)njacos);
		yield();
		if (smix_break) return 0;
        if (!i) {
            if (jacos[i].start_sample > drop_d) {
                add_plan(PLAN_VOL_NORMAL,smix_volume_mpx*smix_max_origin_vol,0.0,jacos[i].start_sample-drop_d,0);
                add_plan(PLAN_VOL_FADE,smix_volume_mpx*smix_max_origin_vol,jacos[i].volmpx,drop_d,0);
            }
            else {
                add_plan(PLAN_VOL_NORMAL,jacos[i].volmpx,0.0,jacos[i].start_sample,0);
            }
        }
        else {
            nstart=jacos[i].start_sample-plan_lastpos;
            if (nstart >= mini_d) {
                add_plan(PLAN_VOL_FADE,lastvol,smix_volume_mpx*smix_max_origin_vol,rise_d,0);
                add_plan(PLAN_VOL_NORMAL,smix_volume_mpx*smix_max_origin_vol,0.0,nstart- (rise_d + drop_d),0);
                add_plan(PLAN_VOL_FADE,smix_volume_mpx*smix_max_origin_vol,jacos[i].volmpx,drop_d,0);
            }
            else if (nstart) {
                add_plan(PLAN_VOL_FADE,lastvol,jacos[i].volmpx,nstart,0);
            }
        }
        add_plan(PLAN_VOL_MIX,jacos[i].volmpx,smix_volume_factor/(1.0+smix_volume_factor),jacos[i].num_samples,i);
        lastvol=jacos[i].volmpx;
    }
    nstart=smix_input_samples-plan_lastpos;
    if (nstart > rise_d) {
        add_plan(PLAN_VOL_FADE,lastvol,smix_volume_mpx*smix_max_origin_vol,rise_d,0);
        add_plan(PLAN_VOL_NORMAL,smix_volume_mpx*smix_max_origin_vol,0.0,nstart-rise_d,0);
    }
    else if (nstart>0) {
        add_plan(PLAN_VOL_NORMAL,lastvol,0.0,nstart,0);
    }
	return 1;
}


static void mbrola_fk(int *to_mbr,int *from_mbr,double tempo,double pitch)
{
	char b1[32],b2[32];int tem=100*tempo,pit=100*pitch;
	close(to_mbr[1]);
	close(from_mbr[0]);
	dup2(to_mbr[0],0);
	dup2(from_mbr[1],1);
	sprintf(b1,"%d.%02d",tem/100,tem%100);
	sprintf(b2,"%d.%02d",pit/100,pit%100);

	execlp("mbrola","mbrola","-f",b2,"-t",b1,"-e",mbrola_voice,"-","-",NULL);
	exit(1);
}

static char *wavebuffer;
static int wavebuflen;
static int wave_size;
static int milena_wave_pos,milena_wave_len;
static short *milena_wave_buffer;
static float resample_input[4096];
static float resample_buffer[4096];
static short resample_output[4096];
static int resample_count;
static int resample_pos;

static int make_wave(char *pho,double tempo,double pitch)
{
	int from_mbr[2],to_mbr[2],pid,i,imx;
	char buffer[4096];
#ifdef HAVE_IVONA
    if (use_ivona) {
        int len;
        if (current_editor->movie_workdir[0]) {
            strcpy(buffer,current_editor->movie_workdir);
        }
        else {
            strcpy(buffer,"/tmp");
        }
        short *wave=ivona_get_subtitle_wave(pho,tempo,&len,buffer);
        if (!wave) return -2;
        if (!wavebuffer) {
            wavebuffer=malloc(wavebuflen=2*len);
        }
        else if (2*len > wavebuflen) {
            wavebuflen=2*len;
            wavebuffer=realloc(wavebuffer,wavebuflen);
        }
        memcpy(wavebuffer,wave,2*len);
        milena_wave_buffer=(short *)wavebuffer;
        milena_wave_len=len;
        resample_count=0;
        resample_pos=0;
        audioparam(milena_wave_buffer,milena_wave_len);
        return 0;
    }
#endif
	ignore(pipe(to_mbr));
	ignore(pipe(from_mbr));
	pid=fork();
	if (pid<0) {
		close(to_mbr[0]);
		close(to_mbr[1]);
		close(from_mbr[0]);
		close(from_mbr[1]);
		return -1;
	}
	if (!pid) mbrola_fk(to_mbr,from_mbr,tempo,pitch);
	close(to_mbr[0]);
	close(from_mbr[1]);
	ignore(write(to_mbr[1],pho,strlen(pho)));
	ignore(write(to_mbr[1],"_ 50\n",5));
	close(to_mbr[1]);
	wave_size=0;
	for (;;) {
		int n=read(from_mbr[0],buffer,4096);
		if (n<=0) break;
		if (!wavebuflen) {
			wavebuffer=malloc(wavebuflen=65536);
		}
		else if (wavebuflen < n+wave_size) {
			wavebuflen+=65536;
			wavebuffer=realloc(wavebuffer,wavebuflen);
		}
		memcpy(wavebuffer+wave_size,buffer,n);
		wave_size+=n;
	}
	resample_count=0;
	resample_pos=0;
	close(from_mbr[0]);
	waitpid(pid,NULL,0);
	if (!wave_size) return -2;
	milena_wave_buffer=(short *)wavebuffer;
	milena_wave_len=wave_size/2;
	if (contrast) do_contrast(milena_wave_buffer,milena_wave_len);
	audioparam(milena_wave_buffer,milena_wave_len);
	imx=0;
    for (i=0;i<milena_wave_len;i++) {
        if (milena_wave_buffer[i] > imx) imx=milena_wave_buffer[i];
        else if (-milena_wave_buffer[i] > imx) imx=-milena_wave_buffer[i];
    }
    if (!imx) {
        milena_wave_len=0;
        return 0;
    }
    if (imx < 32767) {
        double mpx=32767.0/(double) imx;
        for (i=0;i<milena_wave_len;i++) milena_wave_buffer[i]=milena_wave_buffer[i]*mpx;
    }

	return 0;
}

static int create_milena_wave(int n)
{
	struct jacosub *jaco=&jacos[n];
	make_wave(jaco->pho,jaco->speed,gtk_spin_button_get_value((gpointer)spin_pitch));
	milena_wave_pos=0;
	if (debug_level) printf("Speaker: Kwestia %d len %d\n",n,milena_wave_len);
	return 1;
}


static SRC_STATE *resampler;
static SRC_DATA res_data;

static int resample_data(void)
{
    static int resampler_error;
    int nm;
    if (!resampler) {
        resampler=src_new (SRC_SINC_MEDIUM_QUALITY, 1, &resampler_error) ;
        if (!resampler) {
            ErrorF(NULL,"Błąd","Resampler zdechł, numer błędu %d\n",resampler_error);
            return 0;
        }
#ifdef HAVE_IVONA
        double freq=16000;
        if (use_ivona) {
            freq=(double)ivona_getfreq();
        }
        res_data.src_ratio=smix_input_samplefreq/freq;
#else
        res_data.src_ratio=smix_input_samplefreq/16000.0;
#endif
        res_data.data_out=resample_buffer;
        res_data.data_in=resample_input;
    }
    if (!milena_wave_pos) src_reset(resampler);
    nm=milena_wave_len-milena_wave_pos;
    if (nm > 4096) nm=4096;
    res_data.end_of_input=0;
    if (nm<=0) {
        res_data.end_of_input=1;
        nm=0;
    }
    src_short_to_float_array(milena_wave_buffer+milena_wave_pos,resample_input,nm);
    res_data.input_frames=nm;
    res_data.output_frames=4096;
    src_process(resampler,&res_data);
    //int er=src_process(resampler,&res_data);
	//printf("ER %d %s\n%d %d/%d\n",er,src_strerror(er),
	//	nm,res_data.output_frames_gen,res_data.input_frames_used);
	resample_count=res_data.output_frames_gen;
    src_float_to_short_array(resample_buffer,resample_output,resample_count);
    resample_pos=0;
    //printf("Resampler at %d-%d(%d) - %d,%d\n",
	//	milena_wave_pos,milena_wave_len,
	//	res_data.input_frames_used,
	//	resample_count,nm);
    milena_wave_pos+=res_data.input_frames_used;
    if (!nm && !resample_count) milena_wave_pos++;
	return 1;
}

static int milena_get_sample(short *sample)
{
    if (milena_wave_pos > milena_wave_len) {
        *sample=0;
        return 0;
    }
    if (resample_pos >= resample_count) {
        if (!resample_data()) return -1;
		if (milena_wave_pos > milena_wave_len) {
			*sample=0;
			return 0;
		}
    }
    *sample=resample_output[resample_pos++];
    return 1;
}

#define IN_BUFFER_SIZE 1048576
#define OU_BUFFER_SIZE 1048576

static float input_buffer[IN_BUFFER_SIZE];
static short output_buffer[OU_BUFFER_SIZE];
static int buffer_pos,buffer_len;
static int outbuf_pos;
static float sample_L,sample_R;
static short milena_sample;
static int output_fd_pos;

static int get_sample(void)
{
    if (buffer_pos >= buffer_len) {
		int n;
#ifdef HAVE_SNDFILE
		ignore(sf_seek(smix_sndf_in,0,SEEK_CUR));
		n=sf_read_float(smix_sndf_in,input_buffer,IN_BUFFER_SIZE/2);
        if (n<=0) return 0;
        buffer_len=n;
#else
        n=read(smix_input_fd,(char *)input_buffer,IN_BUFFER_SIZE);
        if (n<=0) return 0;
        buffer_len=n/2;
#endif
        buffer_pos=0;
    }
    if (buffer_pos < buffer_len) {
        sample_L=input_buffer[buffer_pos++]*smix_prescaler;
        if (smix_input_channels == 2) sample_R=input_buffer[buffer_pos++]*smix_prescaler;
    }
    return 1;
}
static int put_sample(void)
{
    output_buffer[outbuf_pos++]=sample_L;
    if (smix_input_channels == 2) output_buffer[outbuf_pos++]=sample_R;
    if (outbuf_pos>=(OU_BUFFER_SIZE/2)) {
        int n;
#ifdef HAVE_SNDFILE
		n=sf_write_short(smix_sndf_out,output_buffer,outbuf_pos);
#else
        n=write(smix_output_fd,output_buffer,outbuf_pos*2)/2;
#endif
        if (n!= outbuf_pos) {
            Error("Błąd",strerror(errno));
            return 0;
        }
        output_fd_pos+=outbuf_pos/smix_input_channels;
        show_mplaudio_percent((double)output_fd_pos/(double)smix_input_samples);
        yield();
        outbuf_pos=0;
    }
    return 1;
}


static void multiply_sample(double mpx)
{
    sample_L *= mpx;
    sample_R *= mpx;
}

static int add_milena_sample(double mpx)
{
    int n;
    n=milena_get_sample(&milena_sample);
	if (!n) return 1;
    if (n<0) {
        return 0;
    }
    n=milena_sample * mpx;
    sample_L += n;
    sample_R += n;
    return 1;
}

static int realizer_d;

int realize_plan(struct planen *plan)
{
    int i,maxcan;
    //show_mplaudio_percent((double)realizer_d/(double)smix_input_samples);
	yield();
	if (smix_break) return 0;
    if (debug_level) {
		printf("Realizer: %d samples at sample %d: %s %.2f %.2f\n",plan->duration,realizer_d,(plan->plan == PLAN_VOL_NORMAL)?"Nor":(plan->plan == PLAN_VOL_FADE)?"Fad":"Mix",plan->vol1,plan->vol2);
		maxcan=0;
	}
    realizer_d+=plan->duration;
    
    if (plan->plan == PLAN_VOL_MIX) {
        create_milena_wave(plan->jaco);
    }
    for (i=0;i<plan->duration;i++) {
        if (!get_sample()) return 0;
        switch(plan->plan) {
            case PLAN_VOL_NORMAL:
                multiply_sample(plan->vol1);
                break;
            case PLAN_VOL_FADE:
                multiply_sample(plan->vol1 + ((plan->vol2-plan->vol1) * i)/plan->duration);
                break;
            default:
                multiply_sample(plan->vol1);
                add_milena_sample(plan->vol2);
        }
        if (!put_sample()) return 0;
        if (debug_level) {
			if (sample_L > maxcan) maxcan=sample_L;
			else if (-sample_L > maxcan) maxcan=-sample_L;
			if (smix_input_channels == 2) {
				if (sample_R > maxcan) maxcan=sample_R;
				else if (-sample_R > maxcan) maxcan=-sample_R;
			}
		}
        if (smix_break) {
			return 0;
		}
    }
    if (debug_level) printf("Mixer: Maximum sample value=%d\n",maxcan);
    //if (plan->plan == PLAN_VOL_MIX) {
    //   free_milena_wave();
    //}
    return 1;
}


static int start_planer(char *outname)
{
#ifdef HAVE_SNDFILE
	SF_INFO info;
    if (sf_seek(smix_sndf_in,0,SEEK_SET)<0) {
		Error("Seek",(char *)sf_strerror(smix_sndf_in));
		return 0;
	}
	memset(&info,0,sizeof(info));
	info.samplerate=smix_input_samplefreq;
	info.channels=smix_input_channels;
	info.format=SF_FORMAT_WAV | SF_FORMAT_PCM_16;
	smix_sndf_out=sf_open(outname,SFM_WRITE,&info);
	if (!smix_sndf_out) {
        Error("Błąd",strerror(errno));
        return 0;
    }
#else
    char buf[1024];
    smix_output_fd=open(outname,O_WRONLY | O_CREAT | O_TRUNC, 0644);
    if (smix_output_fd < 0) {
        Error("Błąd",strerror(errno));
        return 0;
    }
    lseek(smix_input_fd,0,SEEK_SET);
    ignore(read(smix_input_fd,buf,smix_input_wave_start));
    ignore(write(smix_output_fd,buf,smix_input_wave_start));
#endif
	output_fd_pos=0;
	outbuf_pos=0;
    show_mplaudio_label("Realizacja");
    show_mplaudio_percent(0.0);
    realizer_d=0;
    return 1;
}

int finish_planer(void)
{
    if (outbuf_pos>0) {
#ifdef HAVE_SNDFILE
        int n=sf_write_short(smix_sndf_out,output_buffer,outbuf_pos);
        if (n!= outbuf_pos) {
            Error("Błąd FinishPlanner",(char *)sf_strerror(smix_sndf_out));
            return 0;
        }
    }
	sf_close(smix_sndf_out);
#else
        int n=write(smix_output_fd,output_buffer,outbuf_pos*2);
        if (n!= 2* outbuf_pos) {
            Error("Błąd",strerror(errno));
            return 0;
        }
    }
    close(smix_output_fd);
#endif
    return 1;
}

static void fine_mpla(void)
{
	char buf[1024];
#ifdef HAVE_SNDFILE
	if (smix_sndf_in) {
		sf_close(smix_sndf_in);
		smix_sndf_in=NULL;
	}
	if (smix_sndf_out) {
		sf_close(smix_sndf_out);
		smix_sndf_out=NULL;
		sprintf(buf,"%s/newaudio.wav",current_editor->movie_workdir);
		unlink(buf);
	}
#else
	if (smix_input_fd>=0) {
		close(smix_input_fd);
		smix_input_fd=-1;
	}
	if (smix_output_fd>=0) {
		close(smix_output_fd);
		smix_output_fd=-1;
		sprintf(buf,"%s/newaudio.wav",current_editor->movie_workdir);
		unlink(buf);
	}
#endif
	if (resampler) {
		src_delete(resampler);
		resampler=NULL;
	}
	hide_mplaudio_dialog();
	close_milena_libs();
	enable_video_menues(-1,NULL);
}

void mplayer_make_audio(GtkWidget *widget, void *dummy)
{
	char buf[256];int mdel,i;
#ifdef HAVE_IVONA
    check_ivona_enabled();
#endif
	if (!init_milena_libs(0)) return;
	if (!milena_add_local_dic()) {
		close_milena_libs();
		return;
	}
	init_paragraph();
	smix_input_fd=-1;
	smix_output_fd=-1;
	start_busy_cursor();
	yield();
	mdel=make_jacolist();
	end_busy_cursor();
	if (!njacos) {
		Error("Błąd","Nie utworzono ani jednej kwestii");
		close_milena_libs();
		return;
	}
	if (!AskF(NULL,"Pytanie","Ilość kwestii: %d\nMaksymalne opóźnienie: %d msec",
		njacos,mdel)) {
		close_milena_libs();
		return;
	}
	smix_break=0;
	sprintf(buf,"%s/audiodump.wav",current_editor->movie_workdir);
	show_mplaudio_dialog("Normalizuję oryginał",0);
	yield();
	if (!open_input_wave(buf)) {
		fine_mpla();
		return;
	}
#ifdef HAVE_IVONA
    if (use_ivona) {
        audioparam_init_f(2,ivona_getfreq());
    }
    else
#endif
	audioparam_init(2);
	show_mplaudio_label("Inicjalizuję plan");
	if (!init_plan()) {
		fine_mpla();
		return;
	};
	sprintf(buf,"%s/newaudio.wav",current_editor->movie_workdir);
	if (!start_planer(buf)) {
		fine_mpla();
		return;
	}
	yield();
	buffer_pos=buffer_len=0;
	for (i=0;i<plany_cnt;i++) {
		yield();
		if (smix_break) {
			fine_mpla();
			return;
		}
		if (!realize_plan(&plany[i])) {
			fine_mpla();
			return;
		}
	}
	if (!finish_planer()) {
		fine_mpla();
		return;
	}
#ifdef HAVE_SNDFILE
	sf_close(smix_sndf_out);
	smix_sndf_out=NULL;
#else
	close(smix_output_fd);
	smix_output_fd=-1;
#endif
	fine_mpla();
	Info("Informacja","Przetwarzanie zakończone");
}

static int get_movie_dim(int *ww,int *hh)
{
	int w=-1,h=-1;
	int pipa[2];
	int pid;
	char *args[8];
	int n;
	char line[256],*li,*c;
	FILE *f;
	ignore(pipe(pipa));
	pid=fork();
	if (pid < 0) return -1.0;
	if (!pid) {
		close(pipa[0]);
		close(2);
		close(0);
		dup2(pipa[1],1);
		n=0;
		args[n++]="mplayer";
		args[n++]="-identify";
		args[n++]="-frames";
		args[n++]="0";
		args[n++]="-vo";
		args[n++]="null";
		args[n++]=current_editor->movie_name;
		args[n]=NULL;
		execvp(args[0],args);
		exit(1);
	}
	close(pipa[1]);
	f=fdopen(pipa[0],"r");
	while(fgets(line,256,f)) {
		li=trim(line);
		c=strchr(li,'=');
		if (!c) continue;
		*c++=0;
		if (!strcmp("ID_VIDEO_WIDTH",li)) {
			w=strtol(c,NULL,10);
		}
		else if (!strcmp("ID_VIDEO_HEIGHT",li)) {
			h=strtol(c,NULL,10);
		}
	}
	fclose(f);
	if (w<=0 || h <= 0) return -1;
	*ww=w;
	*hh=h;
	return 0;
}


static void run_mencoder(char *fname)
{
	char *mencs[64];
	char buforek[1024];
	char brbuf[32];
	char vfbuf[64];
	int brates[9]={0,600,600,760,912,600,760,912,1000};
	int modes[9]={0,1,2,2,2,0,0,0,3};
	int ve;
#ifdef USE_FFMPEG
	int dura=0;
#endif
	int pipa[2];
	int pid;
	int width=-1,height=-1;
	FILE *f;
	char *c;
	if (vmode) {
		if (get_movie_dim(&width,&height)) {
			Error("Błąd","Nie moge pobrać rozmiarów video");
			return;
		}
	}
	ignore(pipe(pipa));
	pid=fork();
	if (pid < 0) {
		Error("Błąd",strerror(errno));
		return;
	}
	if (!pid) {
		close(pipa[0]);
#ifndef USE_FFMPEG
		close(0);
		close(2);
		dup2(pipa[1],1);
#else
		dup2(pipa[1],1);
		dup2(pipa[1],2);
#endif
		ve=1;
		sprintf(buforek,"%s/newaudio.wav",current_editor->movie_workdir);
#ifdef USE_FFMPEG
		mencs[0]="ffmpeg";
		mencs[ve++]="-i";
		mencs[ve++]=current_editor->movie_name;
		mencs[ve++]="-i";
		mencs[ve++]=buforek;
		mencs[ve++]="-vcodec";
		mencs[ve++]="copy";
		mencs[ve++]="-acodec";
		mencs[ve++]="libmp3lame";
		mencs[ve++]="-ab";
		mencs[ve++]="128k";
		mencs[ve++]="-y";
		mencs[ve++]="-map";
		mencs[ve++]="0:0";
		mencs[ve++]="-map";
		mencs[ve++]="1:0";
		mencs[ve++]=fname;
#else
		mencs[0]="mencoder";
		mencs[ve++]="-audiofile";
		mencs[ve++]=buforek;
		mencs[ve++]="-ovc";
		if (!vmode) {
			mencs[ve++]="copy";
		}
		else {
			if (modes[vmode] < 3) {
			    mencs[ve++]="xvid";
			    mencs[ve++]="-xvidencopts";
			    sprintf(brbuf,"bitrate=%d",brates[vmode] * 1000);
			    mencs[ve++]=brbuf;
			}
			else {
			    mencs[ve++]="x264";
			}
			if (modes[vmode]) {
				int nh,nw,crop=0;
				nw=width;
				if (modes[vmode] > 2) {
					nh=(width * 2) /3;
				}
				else if (modes[vmode] > 1) {
					nh=(width * 9) /16;
				}
				else {
					nh = (width * 3) /5;
				}
				vfbuf[0]=0;
				if (nh < height) {
					crop = ((height - nh) * 3)/8;
					if (crop < 5) crop=0;
					if (crop) sprintf(vfbuf,"crop=%d:%d:0:%d",nw,nh,crop);
					else sprintf(vfbuf,"crop=%d:%d",nw,nh);
				}
				else if (nh > height) {
					if (modes[vmode] > 2) {
						nw = (height * 3) /2;
					}
					else if (modes[vmode] > 1) {
						nw=(height * 16) / 9;
					}
					else {
						nw=(height * 5) / 3;
					}
					nh=height;
					sprintf(vfbuf,"crop=%d:%d",nw,nh);
				}
				int sc=0;
				int maxw=720;
				if (vmode > 2) maxw=480;
				if (nw > maxw) {
					nh=(nh * maxw) / nw;
					nw=maxw;
					sc=1;
				}
				if (modes[vmode] == 2) {
					nh=(nh * 16) /15;
					sc=1;
				}
				if (sc) {
					if (vfbuf[0]) strcat(vfbuf,",");
					sprintf(vfbuf+strlen(vfbuf),"scale=%d:%d",nw,nh);
				}
				if (vfbuf[0]) {
					mencs[ve++]="-vf";
					mencs[ve++]=vfbuf;
				}
			}
		}
		mencs[ve++]="-oac";
		if (0) { //modes[vmode] == 3) {
		    mencs[ve++] = "lavc";
		    mencs[ve++] = "-lavcopts";
		    mencs[ve++] = "acodec=ac3";
		}
		else {
		    mencs[ve++]="mp3lame";
		}
		mencs[ve++]="-o";
		mencs[ve++]=fname;
		mencs[ve++]=current_editor->movie_name;
		if (gtk_check_menu_item_get_active((gpointer)m_video_submkv)) {
		    mencs[ve++]="-nosub";
		}
#endif
		mencs[ve++]=NULL;
		execvp(mencs[0],mencs);
		exit(1);
	}
    setpriority(PRIO_PROCESS,pid,10);
	close(pipa[1]);
	f=fdopen(pipa[0],"r");
	int lpc=-1;
	//int lmi=-1;
	smix_break=0;
	show_mplaudio_dialog("Tworzę film wynikowy",1);
	while(fgets(buforek,256,f)) {
		yield();
		if (smix_break) {
			kill(pid,KILL_SIGNAL);
			break;
		}
#ifdef USE_FFMPEG
		if (!dura) {
			int t;
			c=strstr(buforek,"Duration:");
			if (!c) continue;
			c=strchr(c,':')+1;
			while (*c && isspace(*c)) c++;
			if (!isdigit(*c)) continue;
			t=3600 * strtol(c,&c,10);
			if (*c++ != ':') continue;
			t += 60 * strtol(c,&c,10);
			if (*c++ != ':') continue;
			t += strtol(c,&c,10);
			dura=t;
			continue;
		}
		c=strstr(buforek,"time=");
		if (!c) continue;
		show_mplaudio_percent(strtod(c+5,NULL)/(double)dura);
		//show_mplaudio_percent(0/100.0);
#else
		c=strstr(buforek,"Pos:");
		if (!c) continue;
		c=strchr(c,'(');
		if (!c) continue;
		while (*c && !isdigit(*c)) c++;
		if (!*c) continue;
		int perc=strtol(c,&c,10);
		if (*c++!='%') continue;
		c=strstr(c,"Trem:");
		if (!c) continue;
		while (*c && !isdigit(*c)) c++;
		if (!*c) continue;
		//int mins=strtol(c,&c,10);
		if (perc != lpc) {
			lpc=perc;
			show_mplaudio_percent(perc/100.0);
		}
#endif
	}
	waitpid(pid,NULL,0);
	fclose(f);
	hide_mplaudio_dialog();
	if (smix_break) {
		Error("Przerwanie","Enkoder przerwany");
		ignore(system("reset"));
	}
	else {
		Info("Informacja","Film został utworzony");
	}

}

/*
 *
 * Video:
 * MID LQ 5:3 - 600 kbit, aspekt 5:3, maxw 720
 * MID LQ 16:9 - 600 kbit, aspekt 16:9, maxw 720
 * MID MQ 16:9 - 760 kbit, aspekt 16:9, maxw 720
 * MID HQ 16:9 - 920 kbit, aspekt 16:9, maxw 720
 * Xvid LQ - 600 kbit
 * Xvid MQ - 760 kbit
 * Xvid HQ - 920 kbit
 */


void mplayer_make_video(GtkWidget *widget, void *dummy)
{
	int n;
	char path[1024];
	GtkWidget *dialog=gtk_file_chooser_dialog_new(
		"Wybierz plik do zapisu filmu",
		GTK_WINDOW(main_window),GTK_FILE_CHOOSER_ACTION_SAVE,
		GTK_STOCK_CANCEL, GTK_RESPONSE_CANCEL,
		GTK_STOCK_SAVE, GTK_RESPONSE_ACCEPT,
		NULL);
	GtkFileFilter *filter;
	gtk_file_chooser_set_local_only((gpointer)dialog,TRUE);
	gtk_file_chooser_add_filter((gpointer) dialog,
		filter=make_filter("Pliki AVI","*.avi","*.AVI",NULL));
	gtk_file_chooser_add_filter((gpointer) dialog,
		make_filter("Wszystkie pliki","*",NULL));
	gtk_file_chooser_set_filter((gpointer) dialog,filter);

	GtkWidget *labelbox=gtk_hbox_new(0,2);
	GtkWidget *precombo=combo(vmode,
	    "Kopiuj",
	    "MID LQ 5:3",
	    "MID LQ 16:9","MID MQ 16:9","MID HQ 16:9",
	    "XVid LQ","XVid MQ","XVid HQ","Galaxy Mini",NULL);
    GtkWidget *lab=gtk_label_new("Video:");
    gtk_box_pack_start(GTK_BOX(labelbox),lab,FALSE,FALSE,0);
    gtk_box_pack_start(GTK_BOX(labelbox),precombo,FALSE,FALSE,0);

    GtkWidget *hbox=gtk_vbox_new(0,2);
    gtk_box_pack_start(GTK_BOX(hbox),labelbox,FALSE,FALSE,0);
    gtk_file_chooser_set_extra_widget((gpointer) dialog,hbox);
    gtk_widget_show_all(hbox);


	gtk_file_chooser_set_do_overwrite_confirmation((gpointer)dialog,TRUE);
#if GTK_CHECK_VERSION(2,18,0)
	gtk_file_chooser_set_create_folders((gpointer)dialog,TRUE);
#endif
	if ((n=gtk_dialog_run((gpointer)dialog))==GTK_RESPONSE_ACCEPT){
		strcpy(path,gtk_file_chooser_get_filename((gpointer)dialog));
		vmode=gtk_combo_box_get_active((gpointer)precombo);
	}
	gtk_widget_destroy(dialog);
	if (n==GTK_RESPONSE_ACCEPT) {
		run_mencoder(path);
	}
}

void mplayer_settings(GtkWidget *widget, void *dummy)
{
	int rc;
#ifdef HAVE_IVONA
#define _posadder_ 2
#else
#define _posadder_ 0
#endif

	GtkWidget *dialog=gtk_dialog_new_with_buttons("Ustawienia lektora",
			(gpointer)main_window,
			GTK_DIALOG_DESTROY_WITH_PARENT,
			GTK_STOCK_CANCEL,GTK_RESPONSE_CANCEL,
			GTK_STOCK_OK,GTK_RESPONSE_OK,NULL);
	GtkWidget *ca=gtk_dialog_get_content_area (GTK_DIALOG (dialog));

	GtkWidget *vbox=gtk_vbox_new(0,2);
	GtkWidget *stable=gtk_table_new(2,2,0);
	GtkWidget *label;

	label=gtk_label_new("Tempo normalne");
	gtk_table_attach_defaults((gpointer)stable,label,0,1,0,1);
	GtkWidget *w_tempo=gtk_spin_button_new_with_range(0.5,1.5,0.01);
	gtk_table_attach_defaults((gpointer)stable,w_tempo,1,2,0,1);
	gtk_spin_button_set_value((gpointer)w_tempo,smix_speed);
	connect_label(label,w_tempo);

	label=gtk_label_new("Tempo maksymalne");
	gtk_table_attach_defaults((gpointer)stable,label,0,1,1,2);
	GtkWidget *w_tempo2=gtk_spin_button_new_with_range(0.5,1.5,0.01);
	gtk_table_attach_defaults((gpointer)stable,w_tempo2,1,2,1,2);
	gtk_spin_button_set_value((gpointer)w_tempo2,smix_maxspeed);
	connect_label(label,w_tempo2);

#ifdef HAVE_IVONA
	label=gtk_label_new("Tempo norm. Ivony");
	gtk_table_attach_defaults((gpointer)stable,label,0,1,2,3);
	GtkWidget *w_ivo_tempo=gtk_spin_button_new_with_range(0.9,1.5,0.01);
	gtk_table_attach_defaults((gpointer)stable,w_ivo_tempo,1,2,2,3);
	gtk_spin_button_set_value((gpointer)w_ivo_tempo,smix_ivona_speed);
	connect_label(label,w_ivo_tempo);

	label=gtk_label_new("Tempo maks. Ivony");
	gtk_table_attach_defaults((gpointer)stable,label,0,1,3,4);
	GtkWidget *w_ivo_tempo2=gtk_spin_button_new_with_range(0.9,1.7,0.01);
	gtk_table_attach_defaults((gpointer)stable,w_ivo_tempo2,1,2,3,4);
	gtk_spin_button_set_value((gpointer)w_ivo_tempo2,smix_ivona_maxspeed);
	connect_label(label,w_ivo_tempo2);
#endif


	label=gtk_label_new("Stosunek lektor/podkład");
	gtk_table_attach_defaults((gpointer)stable,label,0,1,_posadder_+2,_posadder_+3);
	GtkWidget *w_fact=gtk_spin_button_new_with_range(1.5,8.0,0.1);
	gtk_table_attach_defaults((gpointer)stable,w_fact,1,2,_posadder_+2,_posadder_+3);
	gtk_spin_button_set_value((gpointer)w_fact,smix_volume_factor);
	connect_label(label,w_fact);

	label=gtk_label_new("Max. głośność oryginału");
	gtk_table_attach_defaults((gpointer)stable,label,0,1,_posadder_+3,_posadder_+4);
	GtkWidget *w_fvol=gtk_spin_button_new_with_range(0.5,1.0,0.05);
	gtk_table_attach_defaults((gpointer)stable,w_fvol,1,2,_posadder_+3,_posadder_+4);
	gtk_spin_button_set_value((gpointer)w_fvol,smix_max_origin_vol);
	connect_label(label,w_fvol);

	label=gtk_label_new("Czas wyciszania");
	gtk_table_attach_defaults((gpointer)stable,label,0,1,_posadder_+4,_posadder_+5);
	GtkWidget *w_drop=gtk_spin_button_new_with_range(100,5000,10);
	gtk_table_attach_defaults((gpointer)stable,w_drop,1,2,_posadder_+4,_posadder_+5);
	gtk_spin_button_set_value((gpointer)w_drop,(double)smix_droptime);
	connect_label(label,w_drop);

	label=gtk_label_new("Czas powrotu głośności");
	gtk_table_attach_defaults((gpointer)stable,label,0,1,_posadder_+5,_posadder_+6);
	GtkWidget *w_rise=gtk_spin_button_new_with_range(100,10000,10);
	gtk_table_attach_defaults((gpointer)stable,w_rise,1,2,_posadder_+5,_posadder_+6);
	gtk_spin_button_set_value((gpointer)w_rise,(double)smix_risetime);
	connect_label(label,w_rise);

	label=gtk_label_new("Minimalny odstęp powrót-wyciszenie");
	gtk_table_attach_defaults((gpointer)stable,label,0,1,_posadder_+6,_posadder_+7);
	GtkWidget *w_dist=gtk_spin_button_new_with_range(100,10000,10);
	gtk_table_attach_defaults((gpointer)stable,w_dist,1,2,_posadder_+6,_posadder_+7);
	gtk_spin_button_set_value((gpointer)w_dist,(double)smix_mindist);
	connect_label(label,w_dist);

	label=gtk_label_new("Margines obliczeń");
	gtk_table_attach_defaults((gpointer)stable,label,0,1,_posadder_+7,_posadder_+8);
	GtkWidget *w_marg=gtk_spin_button_new_with_range(0,5000,10);
	gtk_table_attach_defaults((gpointer)stable,w_marg,1,2,_posadder_+7,_posadder_+8);
	gtk_spin_button_set_value((gpointer)w_marg,(double)smix_audio_margin);
	connect_label(label,w_marg);

	label=gtk_label_new("Opóźnienie czytania");
	gtk_table_attach_defaults((gpointer)stable,label,0,1,_posadder_+8,_posadder_+9);
	GtkWidget *w_delay=gtk_spin_button_new_with_range(0,2000,50);
	gtk_table_attach_defaults((gpointer)stable,w_delay,1,2,_posadder_+8,_posadder_+9);
	gtk_spin_button_set_value((gpointer)w_delay,(double)smix_napi_delay);
	connect_label(label,w_delay);

	gtk_box_pack_start(GTK_BOX(vbox),stable,FALSE,FALSE,0);

	gtk_container_add (GTK_CONTAINER (ca), vbox);

	gtk_widget_show_all(dialog);
	for (;;) {
		double s1,s2,s3,s4,fa,vo;
		rc=gtk_dialog_run(GTK_DIALOG(dialog));
		if (rc != GTK_RESPONSE_OK) {
			gtk_widget_destroy(dialog);
			return;
		}
		s1=gtk_spin_button_get_value((gpointer)w_tempo);
		s2=gtk_spin_button_get_value((gpointer)w_tempo2);
		fa=gtk_spin_button_get_value((gpointer)w_fact);
		vo=gtk_spin_button_get_value((gpointer)w_fvol);
		if (s1 < s2-0.001) {
			Error("Błąd","Wartość w polu \"tempo maksymalne\"\nnie może być wyższa\nod wartości w polu \"Tempo normalne\"");
			continue;
		}
		if (s2 > s1) s2=s1;
#ifdef HAVE_IVONA
		s3=gtk_spin_button_get_value((gpointer)w_ivo_tempo);
		s4=gtk_spin_button_get_value((gpointer)w_ivo_tempo2);
        if (s3 > s4) {
			Error("Błąd","Wartość w polu \"tempo maks. Ivony\"\nnie może być niższa\nod wartości w polu \"Tempo norm. Ivony\"");
			continue;
        }
        smix_ivona_speed=s3;
        smix_ivona_maxspeed=s4;
#endif
		smix_speed=s1;
		smix_maxspeed=s2;
		smix_volume_factor=fa;
		smix_max_origin_vol=vo;
		smix_droptime=gtk_spin_button_get_value_as_int((gpointer)w_drop);
		smix_risetime=gtk_spin_button_get_value_as_int((gpointer)w_rise);
		smix_mindist=gtk_spin_button_get_value_as_int((gpointer)w_dist);
		smix_audio_margin=gtk_spin_button_get_value_as_int((gpointer)w_marg);
		smix_napi_delay=gtk_spin_button_get_value_as_int((gpointer)w_delay);
		gtk_widget_destroy(dialog);
		break;
	}
	return;
}

void mplayer_delete_workdir(GtkWidget *widget, void *dummy)
{
    if (!Ask("Uwaga","Czy mam skasować katalog ~/tmp/milena_movie\n\
razem z całą zawartością?\n\
W wyniku tego polecenia skasowane zostaną\n\
wszystkie pliki robocze!")) return;
    ignore(system("rm -rf ~/tmp/milena_movie"));
    enable_video_menues(-1,NULL);
}


