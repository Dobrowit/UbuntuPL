/*
 * badscan.c - Milena Audiobook Creator
 * Copyright (C) Bohdan R. Rau 2010 <ethanak@polip.com>
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write see:
 *               <http://www.gnu.org/licenses/>.
 */
#include "config.h"
#include <gtk/gtk.h>
#include <string.h>
#include <stdlib.h>
#include "gmilena.h"
#include <milena.h>
#include <ctype.h>
#include <iconv.h>
#include <glib.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <errno.h>

// enchant interface
#ifdef HAVE_ENCHANT
#include <enchant.h>

static EnchantBroker *Broker;
static EnchantDict *Dict;
int bad_enchant=0;
#endif


/*
 * Do przeróbki na morfologika
 */
int ench_init_dic(void)
{
#ifdef HAVE_ENCHANT
	if (bad_enchant) return 0;
	if (!Broker) {
		Broker=enchant_broker_init();
		if (!Broker) {
			bad_enchant=1;
			return 0;
		}
		Dict=enchant_broker_request_dict(Broker,"pl_PL");
		if (!Dict) {
			enchant_broker_free(Broker);
			bad_enchant=2;
			return 0;
		}
	}
	return 1;
#else
	return 0;
#endif 
}

int ench_known_word(char *word)
{
#ifdef HAVE_ENCHANT
	if (!Dict) return 0;
	return !enchant_dict_check(Dict,word,-1);
#endif
	return 0;
}

int ench_suggest_word(char *word,char *outword)
{
#ifdef HAVE_ENCHANT	
	if (ench_init_dic()) {
		size_t ndis;
		char **st=enchant_dict_suggest(Dict,word,-1,&ndis);
		if (ndis && st) {
			strcpy(outword,st[0]);
			free(st);
			return 1;
		}
	}
#endif
	return 0;
}
static char **verbs;
static int many_verbs,verbs_size;
static char *verb_memo;
static int verb_memo_pos;

static char **vexts;
static int vexts_no;

static char **known_words;
static int known_words_no,known_words_size;


static char *internal_bwords[]={
    "łan","łana","łanowi","łanem","łanie","ładownik*","Ładownik*","byty","en:memoriał","en:Memoriał","Byty",
    "en:Annę","en:Irenę","en:Marię","fr:Marię","fr:Annę",
    NULL};

static struct bad_word {
    struct bad_word *next;
    short leng;
    short langid;
    char str[1];
} *bad_words;


static void free_bad_words(void)
{
    struct bad_word *bw;
    while ((bw=bad_words)) {
        bad_words=bad_words->next;
        g_free(bw);
    }
}

static int dic_cmp(const void *v1,const void *v2)
{
	return strcmp(*(char **)v1,*(char **)v2);
}

static void add_ibword(char *str)
{
    int n,i;char *c;
    int langid=-1;
    struct bad_word *bw;
    c=strchr(str,':');
    if (c) {
        *c++=0;
        for (i=0;i<NUM_LANGS;i++) if (!strcmp(str,lang_codes[i])) {
            langid=i;
            break;
        }
        str=c;
    }
    if (!*str) return;
    n=strlen(str)-1;
    if (str[n]=='*') {
        str[n]=0;
    }
    else {
        n=0;
    }
    bw=g_malloc(sizeof(*bw)+strlen(str));
    bw->next=bad_words;
    bad_words=bw;
    strcpy(bw->str,str);
    bw->leng=n;
    bw->langid=langid;
}        

static int read_bad_words(char *fname,int dontfree)
{
    char ibuf[256];
    FILE *f=fopen(fname,"r");
    if (!f) return 0;
    if (!dontfree) free_bad_words();
    while(fgets(ibuf,256,f)) {
        char *c;
        c=strstr(ibuf,"//");
        if (c) *c=0;
        c=trim(ibuf);
        if (*c) add_ibword(c);
    }
    fclose(f);
    return 1;
}


static void init_bad_words(void)
{
	int i;char ibuf[256];
	free_bad_words();
    if (read_bad_words(DATADIR "/suspic.dat",0)) return;
    for (i=0;internal_bwords[i];i++) {
        strcpy(ibuf,internal_bwords[i]);
        add_ibword(ibuf);
    }
}
char scanner_path[256];
int readScanner(void)
{
    GtkWidget *dialog=gtk_file_chooser_dialog_new(
			"Wybierz plik",
			GTK_WINDOW(main_window),GTK_FILE_CHOOSER_ACTION_OPEN,
			GTK_STOCK_CANCEL, GTK_RESPONSE_CANCEL,
			GTK_STOCK_OPEN, GTK_RESPONSE_ACCEPT,
			NULL);
    gtk_file_chooser_set_local_only((gpointer)dialog,TRUE);
    if (scanner_path[0]) {
    	gtk_file_chooser_set_filename((gpointer)dialog,scanner_path);
    }
    if (gtk_dialog_run((gpointer)dialog)!=GTK_RESPONSE_ACCEPT) {
        gtk_widget_destroy(dialog);
        return 0;
    }
    strcpy(scanner_path,gtk_file_chooser_get_filename((gpointer)dialog));
    gtk_widget_destroy(dialog);
    init_bad_words();
    if (read_bad_words(scanner_path,1)) {
        Info("Informacja","Plik został wczytany");
        return 1;
    }
    Error("Błąd","Nie mogę wczytać pliku podejrzanych");
    return 0;
}

#define VERB_MEMO_SIZE 65536

static void init_verbmem(void)
{
    if (verbs) return;
    many_verbs=0;
    verbs_size=8192;
    verbs=g_malloc(sizeof(*verbs) * verbs_size);
    verb_memo=g_malloc(VERB_MEMO_SIZE);
    verb_memo_pos=0;
}
static int read_verbs(void)
{
    char ibuf[256];
    char wbuf[512];
    FILE *f;
    char *s,*c,*vr;
    static int was_error=0;
    int i,lverb,lext;
    iconv_t ic;

    int v_append_verb(char *vr)
    {
        char *dst,*c;
        size_t slen,dlen;
        int len;
        slen=strlen(vr);
        dlen=511;
        dst=wbuf;
        iconv(ic,&vr,&slen,&dst,&dlen);
        if (*vr) {
            Error("Błąd","Błąd działania Iconv");
            was_error=1;
            return 0;
        }
        *dst=0;
        len=strlen(wbuf)+1;
        if (verb_memo_pos+len >= VERB_MEMO_SIZE) {
            verb_memo=g_malloc(VERB_MEMO_SIZE);
            verb_memo_pos=0;
        }
        c=verb_memo+verb_memo_pos;
        strcpy(c,wbuf);
        verb_memo_pos+=len;
        if (many_verbs >= verbs_size) {
            verbs_size+=8192;
            verbs=g_realloc(verbs,sizeof(*verbs)*verbs_size);
        }
        verbs[many_verbs++]=c;
        return 1;
    }

    int v_append_ext(char *vr)
    {
        char *dst,*c;
        size_t slen,dlen;
        int len;
        slen=strlen(vr);
        dlen=511;
        dst=wbuf;
        iconv(ic,&vr,&slen,&dst,&dlen);
        if (*vr) {
            Error("Błąd","Błąd działania Iconv");
            was_error=1;
            return 0;
        }
        *dst=0;
        len=strlen(wbuf)+1;
        if (verb_memo_pos+len >= VERB_MEMO_SIZE) {
            verb_memo=g_malloc(VERB_MEMO_SIZE);
            verb_memo_pos=0;
        }
        c=verb_memo+verb_memo_pos;
        strcpy(c,wbuf);
        verb_memo_pos+=len;
        vexts[vexts_no++]=c;
        return 1;
    }


    if (was_error) return 0;
    
    ic=iconv_open("UTF-8","ISO-8859-2");
    if (ic == (iconv_t)-1) {
        Error("Błąd","Iconv nie działa");
        was_error=1;
        return 0;
    }
    init_verbmem();

    s=milena_FilePath("pl_dict.dat",ibuf);
    f=fopen(s,"r");
    if (!f) {
        Error("Błąd","Nie mogę wczytać pliku słownika");
        was_error=1;
        return 0;
    }
    while (fgets(ibuf,256,f)) {
        c=ibuf;
        while (*c && isspace(*c)) c++;
        if (!*c) continue;
        vr=c;
        while (*c && !isspace(*c)) c++;
        s=c-1;
        if (*c=='\xe6') continue;
        if (!*c) continue;
        *c++=0;
        for (;*c && *c!='v' && *c!='V';c++);
        if (!*c) continue;
        if (!v_append_verb(vr)) {
            fclose(f);
            return 0;
        }
    }
    fclose(f);
    s=milena_FilePath("pl_verbs.dat",ibuf);
    f=fopen(s,"r");
    if (!f) goto final;
    (void)fgets(ibuf,256,f);
    lverb=strtol(ibuf,NULL,10);
    (void)fgets(ibuf,256,f);
    lext=strtol(ibuf,NULL,10);
    for (i=0;i<lverb;i++) {
        if (!fgets(ibuf,256,f)) break;
        c=trim(ibuf);
        if (!c) continue;
        if (c[strlen(c)-1] == '\xe6') continue;
        if (!v_append_verb(c)) {
            fclose(f);
            return 0;
        }
    }
    vexts=g_malloc(lext * sizeof(*vexts));
    vexts_no=0;
    while (fgets(ibuf,256,f)) {
        if (vexts_no > lext) break;
        c=trim(ibuf);
        if (*c=='\xe6') continue;
        if (!v_append_ext(c)) {
            fclose(f);
            return 0;
        }
    }
    qsort(vexts,vexts_no,sizeof(*vexts),dic_cmp);
    fclose(f);
final:    
    qsort(verbs,many_verbs,sizeof(*verbs),dic_cmp);
    if (bad_words) return 1;
    init_bad_words();
    if (scanner_path[0]) {
        read_bad_words(scanner_path,1);
    }
    return 1;
}

static int read_bdic(void)
{
    char *bdy,*mfbdy,ibuf[1024],abuf[1024],wbuf[512];
    struct stat sb;
    int fd,i,n,mflen;
    iconv_t ic;
    
    GHashTable *g_mchoice;

    int add_kw(char *vr)
    {
        char *dst,*c;
        size_t slen,dlen;
        int len;
        slen=strlen(vr);
        dlen=511;
        dst=wbuf;
        iconv(ic,&vr,&slen,&dst,&dlen);
        if (*vr) {
            Error("Błąd","Błąd działania Iconv");
            return 0;
        }
        *dst=0;
        len=strlen(wbuf)+1;
        if (verb_memo_pos+len >= VERB_MEMO_SIZE) {
            verb_memo=g_malloc(VERB_MEMO_SIZE);
            verb_memo_pos=0;
        }
        c=verb_memo+verb_memo_pos;
        strcpy(c,wbuf);
        verb_memo_pos+=len;
        if (known_words_no >=known_words_size) {
            known_words_size+=10000;
            known_words=g_realloc(known_words,sizeof(*known_words) * known_words_size);
        }
        known_words[known_words_no++]=c;
        return 1;
    }
    
    int add_all_kw(char *c,char *buf,char *pos)
    {
        char *d,*epos;int znak;
        for (;*c;c++) {
            if (*c=='[' || *c == '`' || *c=='(' || *c== '#') break;
            znak=my_tolower(*c);
            if (!znak) return 1;
            *pos++=znak;
        }
        if (*c=='`') {
            c++;
            if (!add_all_kw(c,buf,pos)) return 0;
            *pos++='\'';
            return add_all_kw(c,buf,pos);
        }
        if (*c=='#') {
            c++;
            if (*c++!='(') return 1;
            d=strchr(c,')');
            if (!d) return 1;
            *d++=0;
            c=g_hash_table_lookup(g_mchoice,c);
            if (!c) return 1;
            for (;;) {
                epos=pos;
                while (*c && *c != '|') {
                    znak=my_tolower(*c++);
                    if (!znak) return 1;
                    *epos++=znak;
                }
                if (!add_all_kw(d,buf,epos)) return 0;
                if (!*c++) break;
            }
            return 1;
        }
        if (*c=='(') {
            
            c++;
            d=strchr(c,')');
            if (!d) return 1;
            *d++=0;
            for (;;) {
                epos=pos;
                while (*c && *c != '|') {
                    znak=my_tolower(*c++);
                    if (!znak) return 1;
                    *epos++=znak;
                }
                if (!add_all_kw(d,buf,epos)) return 0;
                if (!*c++) break;
            }
            return 1;
        }
        if (*c=='[') {
            c++;
            d=strchr(c,']');
            if (!d) return 1;
            *d++=0;
            for (;*c;c++) {
                znak=my_tolower(*c);
                if (!znak) continue;
                *pos=znak;
                if (!add_all_kw(d,buf,pos+1)) return 0;
            }
            return 1;
        }
        
        if (!*c) {
            *pos=0;
            if (!add_kw(buf)) 
            return 1;
        }
        return 1;
    }


    if (known_words) return 1;
    ic=iconv_open("UTF-8","ISO-8859-2");
    if (ic == (iconv_t)-1) {
        Error("Błąd","Iconv nie działa");
        return 0;
    }
    init_verbmem();
	known_words_no=0;
    if (!ench_init_dic()) {
		sprintf(ibuf,"%s-words/pl_basewords.dat",milena_GetDataPath());
		if (stat(ibuf,&sb)) {
			Error("Błąd","Brak basewords");
			return 0;
		}
		mflen=sb.st_size;
		fd=open(ibuf,O_RDONLY);
		if (fd<0) {
			Error("Basewords",strerror(errno));
			return 0;
		}
		bdy=mfbdy=g_malloc(mflen);
		read(fd,bdy,mflen);
		close(fd);
		n=strtol(bdy,NULL,10);
		known_words_size=n+10000;
		bdy+=10;
		known_words=g_malloc(sizeof(*known_words) * known_words_size);
		for (i=0;i<n;i++) {
			if (!add_kw(bdy)) {
				break;
			}
			bdy+=strlen(bdy)+1;
		}
		g_free(mfbdy);
	}
	else {
		known_words_size=10000;
		known_words=g_malloc(sizeof(*known_words) * known_words_size);
	}
	
    char *s=milena_FilePath("pl_dict.dat",ibuf);
    FILE *f=fopen(s,"r");
    if (f) {
        while (fgets(ibuf,256,f)) {
            char *c=strpbrk(ibuf,"\t ");
            if (!c) continue;
            *c=0;
            c=trim(ibuf);
            if (!*c) continue;
            if (!add_kw(c)) break;
        }
        fclose(f);
    }
    s=milena_FilePath("pl_udict.dat",ibuf);
    f=fopen(s,"r");
    if (f) {
        g_mchoice=g_hash_table_new_full(
            g_str_hash,
            g_str_equal,
            g_free,
            g_free);
            
        while (fgets(ibuf,1024,f)) {
            char *c=strstr(ibuf,"//");
            if (c) *c=0;
            c=trim(ibuf);
            if (!*c) continue;
            if (*c == '#') {
                c++;
                char *d=strpbrk(c,"\t "),*e;
                if (!d) continue;
                *d++=0;
                d=trim(d);
                if (*d++!='(') continue;
                e=strchr(d,')');
                if (!e) continue;
                *e=0;
                g_hash_table_insert(g_mchoice,g_strdup(c),g_strdup(d));
                continue;
            }
            c=strpbrk(ibuf,"\t ");
            if (!c) continue;
            *c++=0;
            if (strstr(c,"$S")) continue;
            c=trim(ibuf);
            if (strpbrk(c,"~+_-")) continue;
            if (!add_all_kw(c,abuf,abuf)) break;
        }
        fclose(f);
        g_hash_table_destroy(g_mchoice);
    }
    
    add_kw("w");
    add_kw("z");
    qsort(known_words,known_words_no,sizeof(*known_words),dic_cmp);
    return 1;
}

static char *my_get_word(char *str,char *wrdbuf,int *que)
{
    gunichar g=0;
    char *c=str;
    if (que) *que=0;
    while (*c) {
        g=g_utf8_get_char(c);
        if (!g_unichar_isalnum(g)) break;
        c=g_utf8_next_char(c);
    }
    if (!que || g != '?') goto fine;
    g=g_utf8_get_char(c+1);
    if (!g_unichar_isalnum(g)) goto fine;
    c++;
    while (*c) {
        g=g_utf8_get_char(c);
        if (!g_unichar_isalnum(g)) break;
        c=g_utf8_next_char(c);
    }
    *que=1;
    
fine:    
    memcpy(wrdbuf,str,c-str);
    wrdbuf[c-str]=0;
    return c;
}

static int wordbuf_is_verb(char *wbuf)
{
    char buffy[1024];
    char *c;
    int mid,lo,hi,n;
    gunichar g;
    c=buffy;
    while (*wbuf) {
        g=g_unichar_tolower(g_utf8_get_char(wbuf));
        c+=g_unichar_to_utf8(g,c);
        wbuf=g_utf8_next_char(wbuf);
    }
    *c=0;
#ifdef HAVE_MORFOLOGIK
    int nmorf=morfologik_is_verb(buffy);
    if (nmorf >= 0) return nmorf;
#endif


    lo=0;
    hi=many_verbs-1;
    while (lo <=hi) {
        mid=(lo+hi)/2;
        n=strcmp(buffy,verbs[mid]);
        if (n<0) hi=mid-1;
        else if (n>0) lo=mid+1;
        else return 1;
    }
    c=g_utf8_strreverse(buffy,-1);
    strcpy(buffy,c);
    g_free(c);
    lo=0;
    hi=vexts_no-1;
    while (lo <=hi) {
        mid=(lo+hi)/2;
        n=strncmp(buffy,vexts[mid],strlen(vexts[mid]));
        if (n<0) hi=mid-1;
        else if (n>0) lo=mid+1;
        else return 1;
    }
    
    return 0;
}

static unsigned int langmask;

static char *bad_strings[]={ "ąu","ąi",
    NULL};

static int vdic_list_ok;
static struct vdic_l {
    struct vdic_l *next;
    char *str;
} *vdic_list;

static void free_vdic_list(void)
{
    struct vdic_l *vl;
    while ((vl=vdic_list)) {
        vdic_list=vdic_list->next;
        g_free(vl->str);
        g_free(vl);
    }
    vdic_list_ok=0;
}

static void get_vdic_list(void)
{
	struct vdic_l *vl;
        char *c,*d,*cs;
        if (!current_editor->dic_editor) return;
        char *body=get_editor_body(current_editor->dic_editor);
        for (c=body;c && *c;c=cs) {
            cs=strchr(c,'\n');
            if (!cs) break;
            *cs++=0;
            d=strstr(c,"//");
            if (d) *d=0;
            for (d=c;*d && !isspace(*d);d++);
            if (!*d) continue;
            *d++=0;
            if (!*c) continue;
            while (*d && isspace(*d)) d++;
            if (!*d) continue;
            vl=g_malloc(sizeof(*vl));
            vl->str=g_strdup(c);
            vl->next=vdic_list;
            vdic_list=vl;
        }
        g_free(body);
    
}
static int word_is_known_to_dic(char *str)
{
    struct vdic_l *vl;
    if (!vdic_list_ok) {
        get_vdic_list();
        vdic_list_ok=1;
    }
    for (vl=vdic_list;vl;vl=vl->next) {
        if (!strcmp(vl->str,str)) return 1;
    }
    return 0;
    
}

static int is_wide_text(char *c,int *wrlen)
{
    char *start=c;
    char *c1;
    int i;
    gunichar g;
    for (i=0,c1=c;;i++) {
        g=g_utf8_get_char(c1);
        if (!g_unichar_isalpha(g)) break;
        c1=g_utf8_next_char(c1);
        if (*c1!=' ' && *c1 != '\t') {
            g=g_utf8_get_char(c1);
            if (!g_unichar_isalnum(g)) c=c1;
            break;
        }
        c=c1;
        while (*c1==' ' || *c1=='\t') c1++;
    }
    if (i<3) return 0;
    if (wrlen) *wrlen=g_utf8_strlen(start,c-start);
    return 1;
}

static int is_known_word(char *wrd)
{
    int hi,lo,mid,n;
    lo=0;
    hi=known_words_no-1;
    while (lo <=hi) {
        mid=(lo+hi)/2;
        n=strcmp(wrd,known_words[mid]);
        if (n<0) hi=mid-1;
        else if (n>0) lo=mid+1;
        else return 1;
    }
    return ench_known_word(wrd);
    //return 0;
}

static int word_is_glue(char *wrd)
{
    
    int is_glued(char *str)
    {
        char bs[1024];
        char *ss=str;
        while (*str) {
            str=g_utf8_next_char(str);
            if (!*str) break;
            memcpy(bs,ss,str-ss);
            bs[str-ss]=0;
            if (!is_known_word(bs)) continue;
            if (is_known_word(str)) {
                return 1;
            }
            if (is_glued(str)) return 1;
        }
        return 0;
    }
    
    if (!wrd) return 0;
    int rc=is_glued(wrd);
    return rc;
}        

int unichar_dash(gunichar g)
{
     return g=='-' || g==0xaf ||
            g==0x2013 || g==0x2014 ||
            g==0x2212 || g== 2015;

}        
char *can_glue_word(char *wrd,char *rest,int ikw)
{
    char *s,wbuf[1024],xbuf[1024];
    gunichar g;
    
    while (*rest) {
        g=g_utf8_get_char(rest);
        if (!g_unichar_isspace(g) && !unichar_dash(g)) break;
        rest=g_utf8_next_char(rest);
    }
    if (!*rest) return 0;
    s=rest;
    for (;;) {
        g=g_utf8_get_char(s);
        if (g_unichar_islower(g)) {
            s=g_utf8_next_char(s);
            continue;
        }
        if (g_unichar_isalnum(g)) return 0;
        break;
    }
    if (rest == s) return 0;
    strcpy(wbuf,wrd);
    memcpy(xbuf,rest,s-rest);
    xbuf[s-rest]=0;
    
    //printf("Rest is %d:%s - %d:%s\n",wbuf,xbuf);
    if (ikw && is_known_word(xbuf)) return NULL;
    strcat(wbuf,xbuf);
    return is_known_word(wbuf)?s:NULL;
}    

int init_badscan_data(void)
{
    if (!verbs && !read_verbs()) return 0;
    read_bdic();
    free_vdic_list();
    return 1;
}

int word_is_really_glue(char *word)
{
    int rc=0;
    if (word_is_known_to_dic(word)) return rc;
    word=g_utf8_strdown(word,-1);
    if (!is_known_word(word) && word_is_glue(word)) rc=1;
    g_free(word);
    return rc;
}

int word_is_unknown(char *word)
{
    int rc=0;
//    if (word_is_known_to_dic(word)) return rc;
    word=g_utf8_strdown(word,-1);
    if (!is_known_word(word)) rc=1;
    g_free(word);
    return rc;
}
int split_glued_word(char *word,char *lword,char *buf)
{
    char *d=lword+strlen(lword);
    char *c=word+strlen(word);
    char bf[1024];
    int msplit=0,n;
    if (/*word_is_known_to_dic(word) || */is_known_word(lword)) {
        strcpy(buf,word);
        return 1;
    }
    while (c>word && d>lword) {
        c=g_utf8_prev_char(c);
        d=g_utf8_prev_char(d);
        if (c <= word  || d <= lword) break;
#if 0
        memcpy(bf,word,c-word);
        bf[c-word]=0;
        if (!word_is_known_to_dic(bf)) {
#endif
            memcpy(bf,lword,d-lword);
            bf[d-lword]=0;
            if (!is_known_word(bf)) continue;
#if 0
        }
#endif
        n=split_glued_word(c,d,bf);
        if (!n) continue;
        if (!msplit || n <= msplit) {
            memcpy(buf,word,c-word);
            buf[c-word]=0;
            strcat(buf," ");
            strcat(buf,bf);
            msplit=n+1;
            if (msplit == 2) break;
        }
    }
    return msplit;
}

char *unglue_word_perfectly(char *word)
{
    char *lword=g_utf8_strdown(word,-1);
    static char buf[1024];
    int nret;
    nret=split_glued_word(word,lword,buf);
    g_free(lword);
    if (nret) return buf;
    return NULL;
}


char *unglue_word(char **cin)
{
    char *lword=g_utf8_strdown(*cin,-1);
    char *d,*ew;
    char wrd1[1024];
    static char wrd2[1024];
    d=*cin + strlen(*cin);
    ew=lword+strlen(lword);
    for (;;) {
        memcpy(wrd1,lword,ew-lword);
        wrd1[ew-lword]=0;
        memcpy(wrd2,*cin,d - *cin);
        wrd2[d - *cin]=0;
        if (!is_known_word(wrd1)) goto rloop;
        if (!*ew || is_known_word(ew) || word_is_glue(ew)) break;
        if (ew<=lword) {
            d=*cin + strlen(*cin);
            break;
        }
rloop:
        d=g_utf8_prev_char(d);
        ew=g_utf8_prev_char(ew);
    }
    g_free(lword);
    *cin=d;
    return wrd2;
}

int find_bad_construction(char *str,int *wrlen)
{
    char wordbuf[1024];
    gunichar g;
    char *c=str;
    int pos,i,que;
    struct bad_word *bw;
    int paranoid=gtk_check_menu_item_get_active((gpointer)m_paranoid);
    int bezglut=!gtk_check_menu_item_get_active((gpointer)m_bezglut);
    void lowercase(char *str)
    {
        char *cs=g_utf8_strdown(str,-1);
        strcpy(str,cs);
        g_free(cs);
    }
    
    if (!verbs && !read_verbs()) return -1;
    read_bdic();
    free_vdic_list();
    for (i=0,langmask=0;i<NUM_LANGS;i++) {
        if (gtk_toggle_button_get_active((gpointer)lang_cb[i])) {
            langmask |= 1<<i;
        }
    }
    while (*c) {
        g=g_utf8_get_char(c);
        if (!g_unichar_isalnum(g)) break;
        c=g_utf8_next_char(c);
    }
    while (*c) {
        while (*c) {
            g=g_utf8_get_char(c);
            if (g_unichar_isalnum(g)) break;
            c=g_utf8_next_char(c);
        }
        if (!*c) return -1;
        pos=c-str;
        if (is_wide_text(c,wrlen)) {
            return pos;
        }
        c=my_get_word(c,wordbuf,&que);
        if (que) {
            if (wrlen) *wrlen=g_utf8_strlen(wordbuf,-1);
            return pos;
        }
        //printf("%s\n",wordbuf);
        if (!strcasecmp(wordbuf,"nic")) {
            while (*c && *c==' ') c++;
            if (c) g=g_utf8_get_char(c);
            else g=' ';
            if (g_unichar_isalnum(g)) {
                int pos1=c-str;
                c=my_get_word(c,wordbuf,&que);
                if (que) {
                    if (wrlen) *wrlen=g_utf8_strlen(wordbuf,-1);
                    return pos1;
                }
                if (wordbuf_is_verb(wordbuf)) {
                    if (wrlen) *wrlen=3;
                    return pos;
                }
                pos=pos1;
            }
        }
        if (word_is_known_to_dic(wordbuf)) continue;
        if (wrlen) *wrlen=g_utf8_strlen(wordbuf,-1);
        //printf("%s %d\n",wordbuf,strpbrk(wordbuf,"0123456789"));
        if (strpbrk(wordbuf,"0123456789")) {
			char *cs;
			for (cs=wordbuf;*cs;cs++) if (!isdigit(*cs)) return pos;
            continue;
		}
        for (i=0;bad_strings[i];i++) if (strstr(wordbuf,bad_strings[i])) return pos;
        for (bw=bad_words;bw;bw=bw->next) {
            if (bw->langid>=0) {
                if (!(langmask & (1<<bw->langid))) continue;
            }
            if (bw->leng) {
                if (!strncmp(wordbuf,bw->str,bw->leng)) return pos;
            }
            else {
                if (!strcmp(wordbuf,bw->str)) return pos;
            }
        }
        lowercase(wordbuf);
        int ikw=is_known_word(wordbuf);
        if (!ikw && !bezglut) {
            if (word_is_glue(wordbuf)) return pos;
        }
        char *s;
        if (paranoid) ikw=0;
        if ((s=can_glue_word(wordbuf,c,ikw))) {
            if (wrlen) *wrlen+=g_utf8_strlen(c,s-c);
            return pos;
        }
    }
    return -1;
}

static struct ocr_error {
    struct ocr_error *next;
    char *good;
    char *bad;
} *ocr_error;

static struct ocr_error init_ocr_error[]={
    
// dziwactwa popplera
    
    {NULL,"ć","d"},
    {NULL,"ń","o"},
    {NULL,"Ć","D"},
    {NULL,"Ń","O"},

// ewidentne babole

    {NULL,"q","ą"},
    {NULL,"q","g"},
    {NULL,"Q","O"},
    {NULL,"Q","G"},
    {NULL,"l","1"},
    {NULL,"I","1"},
    {NULL,"O","0"},

    {NULL,"rn","m"},
    {NULL,"m","rn"},
    {NULL,"ni","m"},
    {NULL,"m","ni"},
    {NULL,"m","in"},
    {NULL,"in","m"},
    {NULL,"lc","k"},
    {NULL,"k","lc"},
    {NULL,"le","k"},
    {NULL,"k","le"},
    {NULL,"li","h"},
    {NULL,"h","li"},

// podobne ogonki

    {NULL,"a","ą"},
    {NULL,"ą","a"},
    {NULL,"e","ę"},
    {NULL,"ę","e"},
    {NULL,"c","ć"},
    {NULL,"ć","c"},
    {NULL,"s","ś"},
    {NULL,"ś","s"},
    {NULL,"o","ó"},
    {NULL,"ó","o"},
    {NULL,"z","ż"},
    {NULL,"ż","z"},
    {NULL,"z","ź"},
    {NULL,"ź","z"},
    {NULL,"ż","ź"},
    {NULL,"ź","ż"},
    {NULL,"n","ń"},
    {NULL,"ń","n"},

    {NULL,"A","Ą"},
    {NULL,"Ą","A"},
    {NULL,"E","Ę"},
    {NULL,"Ę","E"},
    {NULL,"C","Ć"},
    {NULL,"Ć","C"},
    {NULL,"S","Ś"},
    {NULL,"Ś","S"},
    {NULL,"O","Ó"},
    {NULL,"Ó","O"},
    {NULL,"Z","Ż"},
    {NULL,"Ż","Z"},
    {NULL,"Z","Ź"},
    {NULL,"Ź","Z"},
    {NULL,"Ż","Ź"},
    {NULL,"Ź","Ż"},
    {NULL,"N","Ń"},
    {NULL,"Ń","N"},

    {NULL,"l","ł"},
    {NULL,"ł","l"},
    {NULL,"t","ł"},
    {NULL,"ł","t"},
    
    
    {NULL,NULL,NULL}};


static struct _ocr_bad_w {
	struct _ocr_bad_w *next;
	int langid;
	char *bad;
	char *good;
} *_ocr_bad_wds;

static void read_ocr_bw(void)
{
	void add_me(char *bf)
	{
		char *sp=strpbrk(bf," \t"),*c;
		struct _ocr_bad_w *w;
		int langid=-1,i;
		if (!sp) return;
		*sp++=0;
		sp=trim(sp);
		if (!*sp) return;
		c=strchr(bf,':');
		if (c) {
		    *c++=0;
		    c=trim(c);
		    if (!*c) return;
		    for (i=0;i<NUM_LANGS;i++) if (!strcmp(bf,lang_codes[i])) {
			langid=1<<i;
			break;
		    }
		    bf=c;
		}
		w=g_malloc(sizeof(*w));
		w->next=_ocr_bad_wds;
		_ocr_bad_wds=w;
		w->langid=langid;
		w->bad=g_strdup(bf);
		w->good=g_strdup(sp);
	}
	if (!_ocr_bad_wds) {
		FILE *f;
		char buffer[256],*c;
		f=fopen(DATADIR "/ocrbadword.dat","r");
		if (f) {
			while (fgets(buffer,256,f)) {
				c=trim(buffer);
				if (*c && *c!='#') add_me(c);
			}
			fclose(f);
		}
		if (!_ocr_bad_wds) {
			strcpy(buffer,"cie cię");
			add_me(buffer);
		}
	}
}

int is_bad_ocr_word(char *word,int langmask)
{
    struct _ocr_bad_w *badw;
	if (!_ocr_bad_wds) read_ocr_bw();
	for (badw=_ocr_bad_wds;badw;badw=badw->next) {
	    int i;
	    if ((!langmask && badw->langid) || !(langmask & badw->langid)) continue;
	    for (i=0;badw->bad[i];i++) {
		if (badw->bad[i] == '*') {
		    return 1;
		}
		if (badw->bad[i] != word[i]) {
		    break;
		}
	    }
	    if (!word[i]) {
		return 1;
	    }
	}
	return 0;
}

static void read_ocr_error(void)
{
    FILE *f;
    int i;char *c;
    char buf[256];
    void add_oe(char *bad,char *good)
    {
        struct ocr_error *oe;
        if (!bad) {
            bad=strpbrk(good,"\t ");
            if (!bad) return;
            *bad++=0;
            while (*bad && isspace(*bad)) bad++;
        }
        if (!*bad || !*good) return;
        oe=g_malloc(sizeof(oe));
        oe->next=ocr_error;
        ocr_error=oe;
        oe->bad=g_strdup(bad);
        oe->good=g_strdup(good);
    }
    read_ocr_bw();
    f=fopen(DATADIR "/ocrerror.dat","r");
    if (!f) {
        for (i=0;init_ocr_error[i].good;i++) {
            add_oe(init_ocr_error[i].bad,init_ocr_error[i].good);
        }
        return;
    }
    while (fgets(buf,256,f)) {
        c=strstr(buf,"//");
        if (c) *c=0;
        c=trim(buf);
        if (*c) add_oe(NULL,c);
    }
    fclose(f);
}

        
int try_find_ocr_error(char *wbuf,int use_spellchecker,int langmask)
{
    char outbuf[1024];
    char *cw,*c,*d;
    int len;
    struct ocr_error *oe;
    struct _ocr_bad_w *badw;
    
    int pasuje(char *pat,char *str)
    {
	int i;
	for (i=0;pat[i];i++) {
	    if (pat[i]=='*') {
		return i;
	    }
	    if (pat[i] != str[i]) {
		return 0;
	    }
	}
	if (!str[i]) return i;
	return 0;
    }
    
    if (!ocr_error) {
        read_ocr_error();
    }
    

	for (badw=_ocr_bad_wds;badw;badw=badw->next) {
	    if ((!langmask && badw->langid) || !(langmask & badw->langid)) continue;
	    int n=pasuje(badw->bad,wbuf);
	    if (n>0) {
		strcpy(outbuf,badw->good);
		strcat(outbuf,wbuf+n);
		strcpy(wbuf,outbuf);
		return 1;
	    }
	}
#ifdef HAVE_ENCHANT
    if (use_spellchecker && ench_suggest_word(wbuf,wbuf)) {
		return 1;
    }
#endif
    cw=wbuf;
    for (;*cw;) {
        len=cw-wbuf;
        memcpy(outbuf,wbuf,len);
        for (oe=ocr_error;oe;oe=oe->next) {
            c=wbuf+len;
            d=oe->bad;
            while (*d) {
                if (!*c) break;
                if (*c++ != *d) break;
                d++;
            }
            if (*d) continue;
            strcpy(outbuf+len,oe->good);
            strcat(outbuf,c);
            if (!word_is_unknown(outbuf)) {
                strcpy(wbuf,outbuf);
                return 1;
            }
        }
        cw=g_utf8_next_char(cw);
    }
    return 0;
}

