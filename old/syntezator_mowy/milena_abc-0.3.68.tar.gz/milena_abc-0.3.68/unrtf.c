/*
 * unrtf.c - Milena Audiobook Creator
 * Copyright (C) Bohdan R. Rau 2009 <ethanak@polip.com>
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write see:
 *               <http://www.gnu.org/licenses/>.
 */

#include "config.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <iconv.h>
#include <glib.h>
#include "gmilena.h"

#define FOOT_NORMAL 1
#define FOOT_AUDIO 2
#define FOOT_ATEND 4
#define FOOT_IGNORE 0
#define FOOT_INAUDIO 8
#define FOOT_INLINE 16

static struct fcharset {
	int fcs;
	int cp;
} fcharsets[]={
{0,1252},
{1,0},
{161,1253},
{162,1254},
{163,1258},
{177,1255},
{186,1257},
{204,1251},
{238,1250},
{-1,-1}};

static struct fontdef {
	struct fontdef *next;
	int f;
	int codepage;
	iconv_t ic;
} *fds;

static void free_fontdefs(void)
{
	struct fontdef *fd;
	while ((fd=fds)) {
		fds=fds->next;
		if (fd->ic) iconv_close(fd->ic);
		g_free(fd);
	}
}


static void add_fontdef(int f,int fch)
{
	int i,cp;
	struct fontdef *fd;
	for (i=0;;i++) {
		if (fcharsets[i].fcs<0) return;
		if (fcharsets[i].fcs==fch) {
			cp=fcharsets[i].cp;
			break;
		}
	}
	fd=g_malloc(sizeof(*fd));
	fd->next=fds;
	fds=fd;
	fd->f=f;
	fd->codepage=cp;
	fd->ic=NULL;
}

static int this_font;


static int footNoteMode = FOOT_IGNORE;
static char *footString="przypis";

static char *global_str;
static int global_len;

static int get_chara(void)
{
	if (global_len<=0) return EOF;
	global_len--;
	return (*global_str++) & 255;
	
}

static void un_getchar(int dummy)
{
	global_str--;
	global_len++;
}

int setFootNote(char *c)
{
	switch(*c) {
		case 'd': footNoteMode=FOOT_IGNORE;return 1;
		case 'a': footNoteMode=FOOT_AUDIO;return 1;
		case 'e': footNoteMode=FOOT_ATEND;return 1;
		case 'n': footNoteMode=FOOT_NORMAL;return 1;
		case 'i': footNoteMode=FOOT_INLINE;return 1;
	}
	return 0;
}

static int fail(char *c)
{
#ifdef __WIN32
	MessageBox(NULL,c,NULL,MB_OK | MB_ICONERROR);
#else
	fprintf(stderr,"Failed: %s\n",c);
#endif
	return 0;
}

static int seof()
{
	return fail("RTF: unexpected EOF");
}

#define STACK_SIZE 1024

static struct stack_item {
	short mode;
	short cp;
	struct fontdef *fd;
} stack[STACK_SIZE];
static int stack_pos;

static void get_fontdef(int param)
{
	struct fontdef *fd;
	for (fd=fds;fd;fd=fd->next) if (fd->f == param) break;
	if (!fd) return;
	stack[stack_pos].fd=fd;
}


#define KMODE_IGNORE 1
#define KMODE_CHAR 2
#define KMODE_BIN 3
#define KMODE_ACP 4
#define KMODE_FOOTNOTE 5
#define KMODE_SKIPDEST 6
#define KMODE_SETFONT 7
#define KMODE_DEFFONT 8
#define KMODE_CHARSET 9
#define KMODE_NEWPAGE 10
#define KMODE_BOLD 11
#define KMODE_ITALIC 12


#define RD_SKIP 1
#define RD_FOOT 2
#define RD_FONT 4
#define RD_INFOOT 8
#define RD_BOLD 16
#define RD_ITALIC 32

static struct keyword {
	char *keyword;
	int mode;
	int equiv;
} keywords[]={
	{"ansi",KMODE_IGNORE,0},
	{"ansicpg",KMODE_ACP,0},
	{"author",KMODE_SKIPDEST,0},
	{"b",KMODE_BOLD,0},
	{"bin",KMODE_BIN,0},
	//{"bkmkend",KMODE_IGNORE,0},
	//{"bkmkstart",KMODE_IGNORE,0},
	{"buptim",KMODE_SKIPDEST,0},
	{"colortbl",KMODE_SKIPDEST,0},
	{"cols",KMODE_IGNORE,0},
	{"comment",KMODE_SKIPDEST,0},
	{"creatim",KMODE_SKIPDEST,0},
	{"doccomm",KMODE_SKIPDEST,0},
	{"emdash",KMODE_CHAR,'-'},
	{"endash",KMODE_CHAR,'-'},
	{"f",KMODE_DEFFONT,0},
	{"facingp",KMODE_IGNORE,0},
	{"fcharset",KMODE_CHARSET,0},
	{"fi",KMODE_IGNORE,0},
	{"fonttbl",KMODE_SETFONT,0},
	{"footer",KMODE_SKIPDEST,0},
	{"footerf",KMODE_SKIPDEST,0},
	{"footerl",KMODE_SKIPDEST,0},
	{"footerr",KMODE_SKIPDEST,0},
	{"footnote",KMODE_FOOTNOTE,0},
	{"ftncn",KMODE_SKIPDEST,0},
	{"ftnsep",KMODE_SKIPDEST,0},
	{"ftnsepc",KMODE_SKIPDEST,0},
	{"header",KMODE_SKIPDEST,0},
	{"headerf",KMODE_SKIPDEST,0},
	{"headerl",KMODE_SKIPDEST,0},
	{"headerr",KMODE_SKIPDEST,0},
	{"i",KMODE_ITALIC,0},
	{"info",KMODE_SKIPDEST,0},
	{"keywords",KMODE_SKIPDEST,0},
	{"landscape",KMODE_IGNORE,0},
	{"ldblquote",KMODE_CHAR,'"'},
	{"li",KMODE_IGNORE,0},
	{"line",KMODE_CHAR,0x0a},
	{"lquote",KMODE_CHAR,'\''},
	{"margb",KMODE_IGNORE,0},
	{"margl",KMODE_IGNORE,0},
	{"margr",KMODE_IGNORE,0},
	{"margt",KMODE_IGNORE,0},
	{"operator",KMODE_SKIPDEST,0},
	{"page",KMODE_NEWPAGE,0},
	{"paperh",KMODE_IGNORE,0},
	{"paperw",KMODE_IGNORE,0},
	{"par",KMODE_CHAR,0x0a},
	{"pgndec",KMODE_IGNORE,0},
	{"pgnlcltr",KMODE_IGNORE,0},
	{"pgnlcrm",KMODE_IGNORE,0},
	{"pgnstart",KMODE_IGNORE,0},
	{"pgnucltr",KMODE_IGNORE,0},
	{"pgnucrm",KMODE_IGNORE,0},
	{"pgnx",KMODE_IGNORE,0},
	{"pgny",KMODE_IGNORE,0},
	{"pict",KMODE_SKIPDEST,0},
	{"printim",KMODE_SKIPDEST,0},
	{"private",KMODE_SKIPDEST,0},
	{"qc",KMODE_IGNORE,0},
	{"qj",KMODE_IGNORE,0},
	{"ql",KMODE_IGNORE,0},
	{"qr",KMODE_IGNORE,0},
	{"rdblquote",KMODE_CHAR,'"'},
	{"revtim",KMODE_SKIPDEST,0},
	{"ri",KMODE_IGNORE,0},
	{"rquote",KMODE_CHAR,'\''},
	{"rtf",KMODE_IGNORE,0},
	{"rxe",KMODE_SKIPDEST,0},
	{"sbkcol",KMODE_IGNORE,0},
	{"sbkeven",KMODE_IGNORE,0},
	{"sbknone",KMODE_IGNORE,0},
	{"sbkodd",KMODE_IGNORE,0},
	{"sbkpage",KMODE_IGNORE,0},
	{"sect",KMODE_NEWPAGE,0},
	{"sectd",KMODE_NEWPAGE,0},
	{"stylesheet",KMODE_SKIPDEST,0},
	{"subject",KMODE_SKIPDEST,0},
	{"tab",KMODE_CHAR,' '},
	{"tc",KMODE_SKIPDEST,0},
	{"title",KMODE_SKIPDEST,0},
	{"txe",KMODE_SKIPDEST,0},
	{"u",KMODE_IGNORE,0},
	{"xe",KMODE_SKIPDEST,0}
		
};

#define KEYNUM (sizeof(keywords)/sizeof(keywords[0]))

int umode;

static int whatMode(char *keyword,int *outch)
{
	int low,hig,mid;
	//printf("[kword %s] %-20.20s\n",keyword,global_str);
	for (low=0,hig=KEYNUM-1;low<=hig;) {
		int n;
		mid=(low+hig)/2;
		n=strcmp(keywords[mid].keyword,keyword);
		if (!n) {
			*outch=keywords[mid].equiv;
			if ((!pdf_keep_boldit || (stack[stack_pos].mode & RD_INFOOT)) && (
				keywords[mid].mode == KMODE_BOLD ||
				keywords[mid].mode == KMODE_ITALIC)) {
					return KMODE_IGNORE;
			}
			return keywords[mid].mode;
		}
		if (n>0) hig=mid-1;else low=mid+1;
	}
	if (umode) {
		umode=0;
		stack[stack_pos].mode |=RD_SKIP;
		return KMODE_SKIPDEST;
	}
	return KMODE_IGNORE;
}

static int codePage=1250;
static int nline=0,wspace=0;
static iconv_t ic;

static char *txt_memo;
static int txt_size;
static int txt_pos;

static int fnCount;

static struct footNote {
	struct footNote *next;
	int number;
	int txtlen;
	int txtsize;
	char *txt;
} *footNotes;


static void add_char(int c)
{
	if (!txt_pos && isspace(c)) return;
	if (txt_pos>=txt_size-1) {
		txt_size+=65536;
		txt_memo=g_realloc(txt_memo,txt_size);
	}
	txt_memo[txt_pos++]=c;
}

static void add_str(char *str,int len)
{
	while (len-- > 0) add_char(*str++);
}

static void newFootnote()
{
	struct footNote *ft;
	char buf[64];
	ft=g_malloc(sizeof(*ft));
	ft->next=footNotes;
	footNotes=ft;
	ft->number=++fnCount;
	ft->txtlen=0;
	ft->txtsize=1024;
	ft->txt=g_malloc(ft->txtsize);
	if (footNoteMode & FOOT_AUDIO) {
		sprintf(buf," %s %d",footString,fnCount);
	}
	else sprintf(buf,"[%d]",fnCount);
	add_str(buf,strlen(buf));
}

static void footChar(z)
{
	if (footNoteMode & (FOOT_INLINE | FOOT_INAUDIO)) {
		add_char(z);
		return;
	}
	if (!footNotes) return;
	if (footNotes->txtlen>=footNotes->txtsize) {
		footNotes->txtsize*=2;
		footNotes->txt=g_realloc(footNotes->txt,footNotes->txtsize);
	}
	
	footNotes->txt[footNotes->txtlen++]=z;
}

static int emitChar(int c);
static int emitStr(char *c,int len);

static void freeFootnotes()
{
	struct footNote *ft;
	while ((ft=footNotes)) {
		footNotes=footNotes->next;
		g_free(ft->txt);
		g_free(ft);
	}
		
}
static int flushFootNote(struct footNote *ft)
{
	char ftbuf[64];
	if (ft->next) {
		if (!flushFootNote(ft->next)) return 0;
		ft->next=NULL;
	}
	if (footNoteMode & FOOT_AUDIO) {
		sprintf(ftbuf,"%s %d: ",footString,ft->number);
	}
	else sprintf(ftbuf,"[%d] ",ft->number);
	if (!emitStr(ftbuf,-1)) return 0;
	if (!emitStr(ft->txt,ft->txtlen)) return 0;
	emitChar('\n');
	g_free(ft->txt);
	g_free(ft);
	return 1;
}

static int flushingFoots;

static int flushFootnotes(void)
{
	flushingFoots=1;
	if (footNoteMode != FOOT_AUDIO)	emitStr("---\n",4);
	if (!flushFootNote(footNotes)) return 0;
	footNotes=NULL;
	flushingFoots=0;
	return 1;
}


static int last_nl=0;
static int in_text=0;
static int emitUniChar(int c,int is_unicode)
{
	size_t l1,l2;
	iconv_t *iic;
	char *c1,*c2;
	char inbuf[4],outbuf[32];
	static char incode[16];
	
	if (c==13) {
		nline++;
		last_nl=1;
		return 1;
	}
	if (c==10) {
		if (!last_nl) nline++;
		last_nl=0;
		return 1;
	}
	if (isspace(c) && nline) return 1;
	if (nline) {
		if (in_text) {
			add_char('\n');
			nline--;
			if (!flushingFoots && footNotes && (footNoteMode & (FOOT_NORMAL | FOOT_AUDIO))) {
				if (!flushFootnotes()) return 0;
			}
			if (nline) add_char('\n');
		}
		nline=0;
		wspace=0;
	}
	in_text=1;
	if (isspace(c)) {
		wspace=1;
		return 1;
	}
	if (wspace) add_char(' ');
	wspace=0;
	if (is_unicode) {
		if (c<=0x7f) {
			add_char(c);
		}
		else if (c <=0x7ff) {
			add_char((c>>6) | 0xc0);
			add_char((c & 0x3f) | 0x80);
		}
		else if (c <= 0xffff) {
			add_char((c>>12) | 0xe0);
			add_char(((c>>6) & 0x3f) | 0x80);
			add_char((c & 0x3f) | 0x80);
		}
		else {
			add_char('?');
		}
		return 1;
	}
	if (!stack[stack_pos].fd) iic=&ic;
	else iic=&stack[stack_pos].fd->ic;
	if (!*iic) {
		int cp=0;
		if (stack[stack_pos].fd) cp=stack[stack_pos].fd->codepage;
		if (!cp) cp=codePage;
		if (!codePage) {
			fail("RTF: no codepage");
			return 0;
		}
		if (cp != 10000)sprintf(incode,"CP%d",cp);
		else strcpy(incode,"MACINTOSH");
		*iic=iconv_open("UTF-8",incode);
		if (*iic == (iconv_t)-1) {
			perror("iconv open");
			return 0;
		}
	}


	inbuf[0]=c;
	l1=1;
	c1=inbuf;
	l2=32;
	c2=outbuf;

	if (iconv(*iic,&c1,&l1,&c2,&l2)==(size_t)-1) {
#ifndef __WIN32
		fprintf(stderr,"%s => %s\n",incode,"UTF-8");
		fprintf(stderr,"%02x\n",inbuf[0] & 255);
#endif
		perror("iconv");
		c1++;
        l1--;
        *c2++='?';
        l2++;
        //return 0;
	}
	l2=32-l2;
	if (l2==2 && outbuf[0]==',' && outbuf[1]==',') {
		outbuf[0]='"';
		c2=outbuf+1;
	}
	for (c1=outbuf;c1<c2;c1++) add_char(*c1);
	return 1;
}

static int last_modifier;


static int emitChar(int c)
{
	return emitUniChar(c,0);
}

static int emitStr(char *c,int len)
{
	if (len<0) len=strlen(c);
	while (len-- > 0) if (!emitChar(*c++)) return 0;
	return 1;
}


static void pre_enter(void)
{
	if ((stack[stack_pos].mode & (RD_BOLD | RD_ITALIC)) == (RD_BOLD | RD_ITALIC)) {
		if (last_modifier == RD_ITALIC) emitStr("</i></b>",8);
		else emitStr("</b></i>",8);
	}
	else if (stack[stack_pos].mode & RD_BOLD) {
		emitStr("</b>",4);
	}
	else if (stack[stack_pos].mode & RD_ITALIC) {
		emitStr("</i>",4);
	}
}

static void post_enter(void)
{
	if ((stack[stack_pos].mode & (RD_BOLD | RD_ITALIC)) == (RD_BOLD | RD_ITALIC)) {
		if (last_modifier == RD_ITALIC) emitStr("<b><i>",6);
		else emitStr("<i><b>",6);
	}
	else if (stack[stack_pos].mode & RD_BOLD) {
		emitStr("<b>",3);
	}
	else if (stack[stack_pos].mode & RD_ITALIC) {
		emitStr("<i>",3);
	}
}


static void ifnDestSkip()
{
	umode=1;
}

static int parseChar(int z)
{
	if (!(stack[stack_pos].mode & 7)) {
		if (z == '\n') pre_enter();
		emitChar(z);
		if (z == '\n') post_enter();
		return 1;
	}
	else if (stack[stack_pos].mode & RD_FOOT) footChar(z);
	return 1;
}

static int parseChars(char *s)
{
	while(*s) parseChar(*s++);
	return 1;
}

static int parseUniChar(int z)
{
	if (!(stack[stack_pos].mode & 7)) return emitUniChar(z,1);
	else if (stack[stack_pos].mode & RD_FOOT) footChar(z);
	return 1;
}

static int gethex(void)
{
	char cs[3];
	int z;char *c;
	if ((z=get_chara())==EOF) {
		seof();
		return EOF;
	}
	cs[0]=z;
	if ((z=get_chara())==EOF) {
		seof();
		return EOF;
	}
	cs[1]=z;
	cs[2]=0;
	
	z=strtol(cs,&c,16);
	if (*c) {
		fprintf(stderr,"Bad hex [%02X %02X]\n",cs[0]&255, cs[1]&255);
		//fail("RTF: bad hex character");
		return '?';
		return EOF;
	}
	return z;
}

static int readKeyword(char *kword,int *par)
{
	int z,n,p,h;
	z=get_chara();
	if (z==EOF) seof();
	if (!isalpha(z)) {
		*kword++=z;
		*kword=0;
		return 0;
	}
	*kword++=z;
	for (;;) {
		if ((z=get_chara())==EOF) {
			seof();
			return -1;
		}
		if (!isalpha(z)) break;
		*kword++=z;
	}
	*kword=0;
	n=h=0;
	if (z=='-') {
		n=1;
		if ((z=get_chara())==EOF) {
			seof();
			return -1;
		}
	}
	if (isdigit(z)) {
		p=z-'0';
		for (;;) {
			if ((z=get_chara())==EOF) {
				seof();
				return -1;
			}
			if (!isdigit(z)) break;
			p=10*p+(z-'0');
		}
		if (n) p=-p;
		h=1;
		*par=p;
	}
	if (z!=' ') un_getchar(z);
	return h;
}


static int parseKeyword(void)
{
	char kword[32];int param=0,hpar=0,z=0;
	hpar=readKeyword(kword,&param);
	if (hpar == -1) return 0;
	if (!isalpha(*kword)) {
		switch(*kword) {
			case '\'': z=gethex();if (z==EOF) return 0;
				return parseChar(z);
			case '*': ifnDestSkip();return 1;
			case '~': parseChar(' ');return 1;
			case '-': return 1;
		}
		return parseChar(*kword);
	}
	if (*kword=='u' && !kword[1]) {
		parseUniChar(param);
		if (global_len >=4 && global_str[0]=='\\' && global_str[1]=='\'' && isxdigit(global_str[2]) && isxdigit(global_str[3])) {
			global_len -=4;
			global_str+=4;
			if (global_len >=4 && global_str[0]=='\\' && global_str[1]=='\'' && isxdigit(global_str[2]) && isxdigit(global_str[3])) {
			    global_len -=4;
			    global_str+=4;
			}
		}
		else if (global_len >1) {
		    global_len -= 1;
		    global_str += 1;
		}
		return 1;
	}
	switch(whatMode(kword,&z)) {
		case KMODE_BIN:
			if (!hpar || param<0) {
				fail("RTF: illegal binary length");
				return 0;
			}
			while (--param>=0) get_chara();
			return 1;
		case KMODE_CHAR:
			return parseChar(z);
		case KMODE_ACP:
			if (!hpar) {
				fail("RTF: no param with codepage");
				return 0;
			}
			codePage=param;
			return 1;
		case KMODE_SETFONT:
			stack[stack_pos].mode |=RD_FONT;
			return 1;
		case KMODE_DEFFONT:
			if (stack[stack_pos].mode & RD_FONT) {
				this_font=param;
				return 1;
			}
			else {
				get_fontdef(param);
			}
			return 1;
		case KMODE_CHARSET:
			if (stack[stack_pos].mode & RD_FONT) add_fontdef(this_font,param);
			return 1;
		case KMODE_SKIPDEST:
			stack[stack_pos].mode |=RD_SKIP;
			return 1;
		case KMODE_BOLD:
			if (!(stack[stack_pos].mode & RD_BOLD )) {
				stack[stack_pos].mode |= RD_BOLD;
				parseChars("<b>");
				last_modifier = RD_BOLD;
			}
			
			return 1;
		case KMODE_ITALIC:
			if (!(stack[stack_pos].mode & RD_ITALIC )) {
				stack[stack_pos].mode |= RD_ITALIC;
				parseChars("<i>");
				last_modifier = RD_ITALIC;
				return 1;
			}
		case KMODE_FOOTNOTE:
			if (stack[stack_pos].mode & ~(RD_BOLD | RD_ITALIC)) {
				stack[stack_pos].mode |=RD_SKIP;
			}
			else {
				if (footNoteMode == FOOT_IGNORE) {
					stack[stack_pos].mode |=RD_SKIP;
				}
				else if (footNoteMode & (FOOT_INLINE | FOOT_INAUDIO)) {
					char buf[64];
					if (footNoteMode & FOOT_INAUDIO) sprintf(buf," %s: ",footString);
					else if (txt_pos && txt_memo[txt_pos-1] != '*') strcpy(buf,"*[");
					else strcpy(buf,"[");
					stack[stack_pos].mode|=RD_INFOOT;
					if (!emitStr(buf,-1)) return 0;
				}
				else {
					newFootnote();
					stack[stack_pos].mode|=RD_FOOT;
				}
			}
			return 1;
		case KMODE_NEWPAGE:
			parseChar('\n');
			parseChar('\n');
			return 1;
		default:
			return 1;
	}
	
}

static int push_stack()
{
	if (stack_pos >=STACK_SIZE-1) return fail("RTF: stack overflow");
	stack[stack_pos+1]=stack[stack_pos];
	stack_pos++;
	return 1;
}

static int pull_stack()
{
	if (!stack_pos) return fail("RTF: stack underflow");
	stack_pos--;
	if (((stack[stack_pos+1].mode & (RD_BOLD | RD_ITALIC)) == (RD_BOLD | RD_ITALIC)) &&
		((stack[stack_pos+1].mode & (RD_BOLD | RD_ITALIC)) == 0)) {
			if (last_modifier == RD_ITALIC) parseChars("</i></b>");
			else parseChars("</b></i>");
	}
	else {
		if ((stack[stack_pos+1].mode & RD_ITALIC) && !(stack[stack_pos].mode & RD_ITALIC)) {
			parseChars("</i>");
			last_modifier=stack[stack_pos].mode & RD_BOLD;
		}
		if ((stack[stack_pos+1].mode & RD_BOLD) && !(stack[stack_pos].mode & RD_BOLD)) {
			parseChars("</b>");
			last_modifier=stack[stack_pos].mode & RD_ITALIC;
		}
	}
	if ((stack[stack_pos+1].mode & RD_INFOOT) && !(stack[stack_pos].mode & RD_INFOOT) && footNoteMode == FOOT_INLINE) add_str("] ",2);
	return 1;
}

static int parseFileString(char *str,int len)
{
	int z;
	global_str=str;
	global_len=len;
	while((z=get_chara())!=EOF) {
		switch(z) {
			case '{': if (!push_stack()) return 0;continue;
			case '}': if (!pull_stack()) return 0;continue;
			case '\\':if (!parseKeyword()) return 0;continue;
			case 0x0a:
			case 0x0d: continue;
		}
		parseChar(z);
	}
	return 1;
}

char *read_rtf(char *str,int len)
{
	txt_size=65536;
	txt_pos=0;
	txt_memo=g_malloc(txt_size);
	stack_pos=0;
	stack[stack_pos].mode=0;
	if (!parseFileString(str,len)) {
		g_free(txt_memo);
		free_fontdefs();
		if (footNotes) freeFootnotes();
		return NULL;
	}
	if (nline) add_char('\n');
	if (footNotes) {
		if (!flushFootnotes()) {
			g_free(txt_memo);
			free_fontdefs();
			if (footNotes) freeFootnotes();
			return NULL;
		}
	}
	free_fontdefs();
	txt_memo[txt_pos]=0;
	return txt_memo;
}
