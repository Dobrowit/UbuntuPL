/*
 * audioplay.c - Milena Audiobook Creator
 * Copyright (C) Bohdan R. Rau 2010-2011 <ethanak@polip.com>
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write see:
 *               <http://www.gnu.org/licenses/>.
 */

#include "config.h"
#include "gmilena.h"

#ifdef HAVE_MAD
#include <mad.h>

struct mad_buffer {
  unsigned char const *start;
  unsigned long length;
};
static enum mad_flow mad_input(void *data,struct mad_stream *stream)
{
	struct mad_buffer *buffer = data;

	if (!buffer->length) return MAD_FLOW_STOP;
	mad_stream_buffer(stream, buffer->start, buffer->length);
	buffer->length = 0;
	return MAD_FLOW_CONTINUE;
}
static inline signed int mad_scale(mad_fixed_t sample)
{
	/* round */
	sample += (1L << (MAD_F_FRACBITS - 16));

	/* clip */
	if (sample >= MAD_F_ONE) sample = MAD_F_ONE - 1;
	else if (sample < -MAD_F_ONE) sample = -MAD_F_ONE;

	/* quantize */
	return sample >> (MAD_F_FRACBITS + 1 - 16);
}

static short mad_buffer[8192];
static int mad_buffer_count;
static int mad_rate;
static int mad_ao_initialized;
static void mad_ao_initialize(int channels,int rate)
{
	mad_rate=rate;
	mad_buffer_count=0;
	mad_ao_initialized=1;
}

static void push_sample(int sample)
{
	mad_buffer[mad_buffer_count++]=sample;
	if (mad_buffer_count >= 8192) {
		audio_play_sfr(mad_buffer,mad_buffer_count,mad_rate);
		mad_buffer_count=0;
	}
}

static void mad_finalize(void)
{
	if (mad_buffer_count > 0) {
		audio_play_sfr(mad_buffer,mad_buffer_count,mad_rate);
		mad_buffer_count=0;
	}
	audio_play_sfr(NULL,0,0);
}


static
enum mad_flow mad_output(void *data,
		     struct mad_header const *header,
		     struct mad_pcm *pcm)
{
	unsigned int nchannels, nsamples,srate;
	mad_fixed_t const *left_ch, *right_ch;

	srate=pcm->samplerate;
	nchannels = pcm->channels;
	nsamples  = pcm->length;
	left_ch   = pcm->samples[0];
	right_ch  = pcm->samples[1];

	if (!mad_ao_initialized) {
		mad_ao_initialize(nchannels,srate);
	}
	while (nsamples--) {
		push_sample(mad_scale(*left_ch++));
	}
	return MAD_FLOW_CONTINUE;
}

static
enum mad_flow mad_error(void *data,
		    struct mad_stream *stream,
		    struct mad_frame *frame)
{
  struct buffer *buffer = data;

  /* return MAD_FLOW_BREAK here to stop decoding (and propagate an error) */

  return MAD_FLOW_CONTINUE;
}


void mp3_play(char *data,int len)
{
	struct mad_buffer buffer;
	struct mad_decoder decoder;
	int result;
	buffer.start  = data;
	buffer.length = len;
	mad_ao_initialized=0;
	audio_close_device();
	mad_decoder_init(&decoder, &buffer,
		mad_input, 0 /* header */, 0 /* filter */, mad_output,
		mad_error, 0 /* message */);
	mad_decoder_run(&decoder, MAD_DECODER_MODE_SYNC);
	mad_decoder_finish(&decoder);
	audio_close_device();
}
#else
#ifdef HAVE_MPG123
#include <mpg123.h>
static int mpg123_initialized;

void mp3_play(char *data,int len)
{
    int err,channels,encoding;
    long rate;
    mpg123_handle *mh;
    int mh_bufsize;
    void *mh_buffer;
    size_t done;
    if (mpg123_initialized == 2) return;
    if (!mpg123_initialized) {
        err=mpg123_init();
        if (err != MPG123_OK) {
            mpg123_initialized=2;
            return;
        }
        mpg123_initialized=1;
    }
    mh=mpg123_new(NULL,NULL);
    if (!mh) return;
    if (mpg123_param(mh,MPG123_ADD_FLAGS,MPG123_MONO_MIX,0.0) != MPG123_OK) goto delete_mh;
    if (mpg123_open_feed(mh) != MPG123_OK) goto delete_mh;
    if (mpg123_feed(mh,(void *)data,len)!=MPG123_OK) goto close_mh;
    if (mpg123_getformat(mh, &rate, &channels, &encoding) != MPG123_OK ) goto close_mh;
    mpg123_format_none(mh);
    encoding=MPG123_ENC_SIGNED_16;
    if (mpg123_format(mh, rate, 1, encoding) != MPG123_OK) goto close_mh;
    if (mpg123_getformat(mh, &rate, &channels, &encoding) != MPG123_OK) goto close_mh;
    if (encoding != MPG123_ENC_SIGNED_16 || channels != 1) {
        fprintf(stderr,"mpg123: cannot set mono 16-bit signed encoding\n");
        goto close_mh;
    }
    mh_bufsize=4*mpg123_outblock(mh);
    mh_buffer=malloc(mh_bufsize);
    audio_close_device();
    while (mpg123_read(mh,mh_buffer,mh_bufsize,&done) == MPG123_OK) {
        audio_play_sfr(mh_buffer,done/2,rate);
    }
    audio_close_device();
close_mh:
    mpg123_close(mh);
delete_mh:
    mpg123_delete(mh);
}

#endif
#endif
