#!/bin/bash

if ! which milena >/dev/null 2>/dev/null ; then
	echo "A Milenę to krasnoludki zainstalują?"
	exit 1
fi

curl=''

#instalujemy konkretnego libcurla

if dpkg -l | grep libcurl.*-dev.*ubuntu >/dev/null ; then
	echo Biblioteka CURL jest zainstalowana
else
	a=`dpkg -l | awk '/libcurla3-/ {print $2}' | awk -F- '{print $2}'`
	if [ "$a" = "" ] ; then
		curl='libcurl4-gnutls-dev'
	else
		curl=libcurl4-$a-dev
	fi
fi
sudo apt-get install libgtk2.0-dev \
    libgtksourceview2.0-dev \
    libpcre3-dev \
    libmp3lame-dev \
    libepub-dev \
    libsamplerate0-dev \
    libwebkit-dev \
    libao-dev \
    libsndfile1-dev \
    libmpg123-dev  $curl || exit 1
./configure --prefix=/usr --disable-gtk3 && \
	make && \
	sudo make install || exit 1

arch=`uname -m`
if [ "$arch" = "x86_64" ] ; then
	lib=/usr/lib64
	if [ ! -d $lib ] ; then
		lib=/usr/lib
	fi
else
	lib=/usr/lib
fi
if [ ! -f $lib/libamrwb_mil.so ] ; then
	cd amrlib
	if sh ./get_amr.sh ; then
		sudo cp libamrwb_mil.so $lib/libamrwb_mil.so
		sudo ldconfig
	fi
fi

echo "Instalacja zakończona"
