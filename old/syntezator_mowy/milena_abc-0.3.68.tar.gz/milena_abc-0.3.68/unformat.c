/*
 * unformat.c - Milena Audiobook Creator
 * Copyright (C) Bohdan R. Rau 2009-2011 <ethanak@polip.com>
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write see:
 *               <http://www.gnu.org/licenses/>.
 */

#include "config.h"
#include <glib.h>
//#include <glib/gunicode.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <gtk/gtk.h>
#include "gmilena.h"

static char *next_no_page(char *str)
{
    int digit_found;
    char *c,*strin;
    strin=str;
    for (digit_found=0;*str;) {
        int line_type=0;
        for (c=str;*c && *c!='\n';c++) {
            if (line_type == 2 || *c==' ') continue;
            if (my_digit(*c)) line_type=1;
            else line_type=2;
        }
        if (*c=='\n') c++;
        if (line_type == 2) {
            if (!digit_found) return strin;
            return str;
        }
        if (line_type == 1) digit_found=1;
        str=c;
    }
    return str;
}

#define LI_EMPTY 1
#define LI_BLANK 2
#define LI_CHAPTER 4
#define LI_SHORT 8
#define LI_DASH 0x10
#define LI_CONT 0x20
#define LI_CONN 0x500
#define LI_GLUE 0x100
#define LI_SPLIT 0x200
#define LI_DBLE 0x300
#define LI_IGN 0x400
#define LI_IMARK 0x700

static int line_type(char *line,int marker,int autopar)
{
    int flags=0,le;
    if (!*line) return LI_EMPTY;
    if (marker && marker == *line) return LI_CHAPTER;
    if (*line == ' ') flags |= LI_BLANK;
    if (autopar && strlen(line) < autopar) flags |= LI_SHORT;
    if (*line == '-') flags |= LI_DASH;
    le=strlen(line);
    if (le>2) {
        if (line[le-1] == '-' && my_alnum(line[le-2])) flags |= LI_CONT;
    }
    return flags;
}

char *unformat_me(char *str,int no_pages,int autopar,int marker)
{
    
    char *s_in,*s_out,**lines;
    int space,*markers;
    int nlines,plines;
    GString *gs;
    
    void undash(char *s)
    {
        s+=strlen(s)-1;
        *s=0;
    }
    
    // normalize spaces at eol
    for (space=0,nlines=2,s_in=s_out=str;*s_in;) {
        if (*s_in=='\r') {
            s_in++;
            if (*s_in=='\n') s_in++;
            *s_out++='\n';
            space=0;
            if (no_pages) s_in=next_no_page(s_in);
            nlines++;
            continue;
        }
        if (*s_in=='\n') {
            *s_out++=*s_in++;
            space=0;
            if (no_pages) s_in=next_no_page(s_in);
            nlines++;
            continue;
        }
        if (*s_in==' ' || *s_in=='\t') {
            space=1;
            s_in++;
            continue;
        }
        if (space) {
            *s_out++=' ';
            space=0;
        }
        *s_out++=*s_in++;
    }
    *s_out=0;
    lines=g_malloc0(sizeof(*lines) * nlines);
    markers=g_malloc0(sizeof(*markers) * nlines);
    nlines=0;
    int line_start=1;
    for (s_in=str;*s_in == '\n';s_in++);
    for (s_in=str,nlines=0;*s_in;s_in++) {
        if (line_start) {
            lines[nlines++]=s_in;
            line_start=0;
        }
        if (*s_in == '\n') {
            line_start=1;
            *s_in=0;
        }
    }
    for (nlines=0;lines[nlines];nlines++) {
        markers[nlines]=line_type(lines[nlines],marker,autopar);
    }
    int mp,md=markers[0];
    for (nlines=1;lines[nlines];nlines++) {
        mp=md;
        md=markers[nlines];
        
        if (md == LI_EMPTY) {
            if (!autopar && mp != LI_EMPTY) markers[nlines] |= LI_IGN;
            else markers[nlines] |= LI_SPLIT;
            continue;
        }
        
        if (md == LI_CHAPTER) {
            markers[nlines] |= LI_DBLE;
            continue;
        }
        
        if (md == LI_BLANK && autopar != 0) {
            markers[nlines] |= LI_SPLIT;
            continue;
        }
        
        if (mp == LI_EMPTY || (mp & LI_SHORT)) {
            markers[nlines] |= LI_SPLIT;
            continue;
        }
        
        if (mp == LI_CHAPTER) {
            markers[nlines] |= LI_DBLE;
            continue;
        }
        
        if (mp == LI_CONT) {
            if (my_alpha(lines[nlines][0]) || (lines[nlines][0] == '-' && my_alpha(lines[nlines][1]))) {
                undash(lines[nlines-1]);
                markers[nlines] |= LI_GLUE;
                continue;
            }
        }
        markers[nlines] |= LI_CONN;
    }
    for (nlines=plines=1;lines[nlines];nlines++) {
        if ((markers[nlines] & LI_IMARK) != LI_IGN) {
            lines[plines]=lines[nlines];
            if (markers[plines-1] & LI_CHAPTER) {
                markers[plines++]=(markers[nlines] & ~LI_IMARK) | LI_DBLE;
            }
            else {
                markers[plines++]=markers[nlines];
            }
        }
    }
    lines[plines]=0;
    for (nlines=1;lines[nlines];nlines++) {
        if (markers[nlines] & LI_EMPTY) {
            int i;
            for (i=nlines;lines[i];i++) {
                if (!(markers[i] & LI_EMPTY)) break;
                markers[i]=LI_IGN | LI_EMPTY;
            }
            markers[i]=(markers[i] & ~LI_IMARK) | LI_DBLE;
            nlines=i;
        }
    }
    gs=g_string_sized_new(strlen(str)+1);
    g_string_append(gs,lines[0]);
    for (nlines=1;lines[nlines];nlines++) {
        int m=markers[nlines] & LI_IMARK;
        if (m == LI_IGN) continue;
        if (m == LI_CONN) g_string_append_c(gs,' ');
        else if (m == LI_SPLIT) g_string_append_c(gs,'\n');
        else if (m == LI_DBLE) g_string_append(gs,"\n\n");
        g_string_append(gs,lines[nlines]);
    }
    g_free(str);
    return g_string_free(gs,FALSE);
}
