/*
 * gmilena.h - Milena Audiobook Creator
 * Copyright (C) Bohdan R. Rau 2009-2011 <ethanak@polip.com>
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write see:
 *               <http://www.gnu.org/licenses/>.
 */
#ifndef GMILENA_H
#define GMILENA_H 1
#ifdef HAVE_GTK3
#include <gdk/gdkkeysyms-compat.h>
#endif
#include <gtk/gtk.h>
#include <gtksourceview/gtksourceview.h>

extern GdkCursor *watch_cursor;

extern GtkWidget *m_ac_search,*m_ac_atk,*m_ac_nop,*m_tiface,
*m_morfologik_persistent,
*m_ocrtodic[4],
*m_epub_dash,*m_epub_just,*m_epub_procover,*m_epub_format,*m_fb2_el,
*m_sleep,*m_browser,*m_paranoid,*m_bezglut,
*m_napi_use,*m_napi_autosave,
*m_python,*python_menu,*m_video_submkv;
extern char font_name[];
extern void connect_label(gpointer a,gpointer b);
extern GtkWidget *main_window,*notek;
extern GtkTextBuffer *tresc;
extern GtkTextView *tresc_v;
extern GtkWidget *spin_tempo,*spin_pitch;
#define NUM_LANGS 10
#define HALF_LANGS ((NUM_LANGS+1)/2)
extern GtkWidget *lang_cb[NUM_LANGS];
extern char *lang_codes[NUM_LANGS];
extern GtkWidget *cb_hours,*cb_pro, *cb_ign, *cb_dic, *cb_lector, *cb_spell, *cb_ellip, *cb_equ;
extern GtkWidget *dic_filechooser;
extern GtkWidget *cb_kontrast,*spin_kontrast;
extern GtkWidget *combo_mp3,*cb_stereo,*combo_amr,*cb_dtx,*combo_split,*char_split,
	*combo_autonum,*combo_prolog,*combo_epilog;
extern GtkWidget *statusbar,*statusbar_ove,*statusbar_line,*statusbar_col;
extern GtkFileFilter *make_filter(char *name,...);
extern int to_iso2(char *instr,char *outstr);
extern int to_iso2_mp(char *instr,char *outstr,char **instrpos,int maxpos);
extern int my_compare(char *s1,char *s2);
extern int get_unichar(char **s);
extern int znak_is_alnum(int znak);
extern void yield(void);
extern void *morfo_create_menu(void);
extern int Ask(char *title,char *question);
extern void Error(char *title,char *error);
extern void Info(char *title,char *info);
extern int Ask2(char *title,char *question,gpointer w);
extern void Error2(char *title,char *error,gpointer w);
extern void Info2(char *title,char *info,gpointer w);
extern int AskF(gpointer w,char *title,char *format,...);
extern void InfoF(gpointer w,char *title,char *format,...);
extern void ErrorF(gpointer w,char *title,char *format,...);

extern int GetNumber(char *title,char *labelstr);
extern char * AskString(char *title,char *labelstr);
extern char * AskString2(char *title,char *labelstr,gpointer window);
extern char * AskStringP(char *title,char *label,char *ptr);
extern char * AskStringP2(char *title,char *labelstr,char *ptr,gpointer window);

extern void open_file(GtkWidget *dummy,void *data);
extern void new_file(GtkWidget *dummy,void *data);
extern void save_file(GtkWidget *dummy,void *data);
extern int fbody_is_hash(char *c,int hash);
extern int textbuf_is_empty(gpointer buf);
extern void notek_set_tab_label(char *text);
extern void simplify_path(char *fname);
extern void convert_to_iso2(GtkWidget *dummy,void *data);
extern void close_current_editor(GtkWidget *dummy,void *data);
extern void make_dash(GtkWidget *dummy, void *data);
extern void apply_dash(GtkWidget *dummy, void *data);
extern void unformat_text(GtkWidget *dummy, void *data);
extern void correct_jacosub(GtkWidget *dummy, void *data);
extern void make_dict(GtkWidget *dummy, void *data);
extern void dict_from_selection(GtkWidget *dummy, void *data);
extern void dict_suggest_word(GtkWidget *dummy, void *data);
extern void swap_editors(GtkWidget *dummy, void *data);
extern void ChooseFont(GtkWidget *widget,void *dummy);
extern void ApplyFont(char *);
extern void StartSearch(GtkWidget *widget,void *dummy);
extern void StartReplace(GtkWidget *widget,void *dummy);
extern void editor_ulcase(GtkWidget *widget,void *data);
extern void editor_fake_latin(GtkWidget *widget,void *data);
extern void editorNormalizeText(GtkWidget *widget, void *data);
extern void menu_active_notek(GtkWidget *widget,void *dummy);
extern void find_current_word(GtkWidget *widget,void *dummy);
extern void find_entity(GtkWidget *widget,void *dummy);
extern void find_scanner_error(GtkWidget *widget,void *dummy);
extern void find_dialog_connection(GtkWidget *widget,void *dummy);
extern void go_to_line(GtkWidget *widget,void *dummy);
extern void save_prefs(GtkWidget *widget,void *dummy);
extern void open_dic(GtkWidget *widget,void *dummy);
extern void set_pulse_margin(GtkWidget *widget,void *dummy);
extern void set_mbrola_voice(GtkWidget *widget,void *dummy);
extern void book_create(GtkWidget *widget,void *dummy);
extern void acc_make_wrap(void);
extern void openSearchLibWindow(GtkWidget *widget,void *dummy);
extern void editor_delete_line(GtkWidget *widget,void *data);
extern void edit_autonumber(void);
extern void edit_autochapter(GtkWidget *widget,void *data);
extern void editor_glue_dashspace(GtkWidget *widget,void *data);
extern int init_badscan_data(void);
extern int word_is_really_glue(char *word);
extern void glue_to_dict(GtkWidget *dummy,void *data);
extern void unglue_with_dict(GtkWidget *dummy,void *data);
extern char *unglue_word(char **cin);
extern char *unglue_word_perfectly(char *word);
extern int word_is_unknown(char *word);
extern int try_find_ocr_error(char *wbuf,int use_spellchecker,int langmask);
extern int is_bad_ocr_word(char *word,int langmask);
extern int unichar_dash(gunichar g);
extern char *get_word_at_cursor(GtkTextBuffer *t,int highlight);
extern struct MyGtkEditor *get_subeditor(struct MyGtkEditor *editor,int mode);
extern void g_perror(char *);
extern char *get_actual_body(void);
extern void start_reading(int);
extern void stop_speaking(void);
extern void load_prefs(void);
extern void show_position_on_sb(struct MyGtkEditor *ed);
extern int is_speaking;
extern struct MyGtkEditor *gimma_current_editor(void);
extern struct MyGtkEditor *CreateEditor(int mode,struct MyGtkEditor *owner,char *label);
extern void show_editor(struct MyGtkEditor *editor);
extern void switch_editor(void *dummy,void *bw);
extern int find_html_entity(char *in,char **out);
extern void speak_text(char *str);
extern void show_url(char *s);
extern int bad_enchant;
extern int morfo_get_value(void);

extern struct mbrola_handler {
	int to_mbrola;
	int from_mbrola;
	int pid;
	int flush_status;
	int error;
} *mbr;
int write_MBR(struct mbrola_handler *mbr,char *buf);
int flush_MBR(struct mbrola_handler *mbr);
int read_MBR(struct mbrola_handler *mbr,short *buf,int len,int *outlen);
struct mbrola_handler *init_MBR(char *voice,int freq);
void close_MBR(struct mbrola_handler *mbr);

extern int enable_pulse(void);
extern int audio_play(short *samples,int nsamples);
extern int audio_play_sfr(short *samples,int nsamples,int rate);
extern int audio_close_device(void);
extern char *ask_encoding(void);

extern struct MyGtkEditor {
	struct MyGtkEditor *next;
	GtkTextView *view;
	GtkTextBuffer *buf;
	GtkScrolledWindow *window;
	int editor_type;
    int saveas_iso2;
    int initial_offset;
    int editor_number;
	struct MyGtkEditor *dash_editor;
	struct MyGtkEditor *dic_editor;
	struct MyGtkEditor *owneditor;
	GtkTextTag *speaktag;
	char load_name[PATH_MAX+1];
	char save_name[PATH_MAX+1];
	char movie_name[PATH_MAX+1];
	char movie_workdir[PATH_MAX+1];
} *editors,*current_editor;

#define MILEDIT_MODE_NORMAL 0
#define MILEDIT_MODE_DASH 1
#define MILEDIT_MODE_DIC 2

extern int get_current_editor();
extern char *get_current_iso2();
extern char *get_editor_body(struct MyGtkEditor*);
extern char *get_current_path(void);


extern void store_zakladka(void);
extern void read_zakladka(void);
extern int init_zakladki_cb(void);

extern struct milena *milena;
extern struct milena_mbrola_cfg *mimbrola;

int init_milena_dic(int is_dic);

extern char last_file_path[];

extern int my_alpha(int);
extern int my_alnum(int);
extern int my_upper(int);
extern int my_space(int);
extern int my_digit(int);
extern int my_vowel(int);
extern int my_tolower(int);
extern int readable(char *);
const char *get_encoding(char *buf,size_t len);

extern void insertPartChapter(GtkWidget *widget,void *dummy);


extern void remove_subeditor(struct MyGtkEditor *editor);
extern void set_buffer_text(gpointer buf,char *str,int len,int undoable);
void editor_scroll_to_cursor(struct MyGtkEditor *edi);

extern void start_busy_cursor(void);
extern void end_busy_cursor(void);

extern char mbrola_voice[];

extern int ignore_oor;
extern int count_bad_char;

void StartProgressMeter(int count);
void SetProgress(int file,double pos);
void StopProgressMeter(void);
extern int allow_run;

extern void init_paragraph(void);
extern struct phone_buffer *translate_paragraph(char *str);
extern char *translate_subtitle(char *str);
extern int contrast;
extern double contrast_level;
extern gdouble current_mbrola_speed;

extern int init_lame_encoder(char *fname,int rate,char *artist,char *album,char *title,int track,int samplefreq);
extern int lame_encode(short *buf,int nsamples);
extern int lame_finish(void);
extern double lame_get_seconds(void);

extern int init_amrwb(void);
extern int start_amrwb(char *fname,int mode,int dtx);
extern int encode_amrwb(short *buf,int nsamples);
extern int finish_amrwb(void);
extern double amr_get_seconds(void);

extern double compute_percent(void);

extern int init_aac_encoder(char *fname);
extern int aac_encode(short *buf,int nsamples);
extern int finish_aac();

extern struct miltheme {
	struct miltheme *next;
	GtkWidget *cb;
	char *fname;
	char *tname;
	char *title;
} *themes;

extern gchar **initial_fnames;
extern gint auto_load_dic,no_load_dic;
extern int auto_set_langs(char *);

extern int multipartial_on;
extern double multipartial_value,multipartial_margin;
extern char *read_epub(char *, char **);
extern char *read_mobi(char *, char **);

extern int id3_tag_mode;

#ifdef HAVE_GTK3
#define word_wrap (gtk_check_menu_item_get_active((gpointer)m_ac_nop)?\
GTK_WRAP_NONE:GTK_WRAP_WORD_CHAR)
#else
#define word_wrap (gtk_check_menu_item_get_active((gpointer)m_ac_nop)?\
GTK_WRAP_NONE:\
gtk_check_menu_item_get_active((gpointer)m_ac_atk)?\
GTK_WRAP_WORD:GTK_WRAP_WORD_CHAR)
#endif
#define a11y_not_found gtk_check_menu_item_get_active((gpointer)m_ac_search)

void *reverb_init(double rvb,double damp,double room,double depth,int upsample);
void reverb_flow(void *vreff, const short * ibuf,short * obuf, size_t len);
void reverb_free(void *vreff);

extern int stereo_mode,stereo_upsample;
extern double stereo_rev,stereo_hfd,stereo_room,stereo_depth;
extern int dont_close_audiodevice;

extern gdouble vocal_track_length;
extern int mbrola_real_freq;
extern gdouble resample_factor;
extern gdouble computed_resample_factor;
extern int use_resampler;
extern int init_resampler(void);
extern int close_resampler(void);
extern int do_resample(short *,int);

extern char *pdxml2txt(char *);
extern char *new_pdf_parser(char *);
extern gint pdf_ignore_font_size;
extern gint pdf_ignore_chunk_height;
extern gint pdf_autonumber_pages;
extern gint pdf_max_line_height;
extern gint pdf_max_paragraph_height;
extern gint pdf_show_heights;
extern gint pdf_keep_boldit;


extern gint old_pdf_behav,
    tesseract_pdf,tesseract_pdfp,
    cuneiform_pdf,cuneiform_pdfp,
    no_drm;

extern char *to_utf8(char *fbuf,int flen,char *cset,int freeme);
extern int find_bad_construction(char *str,int *wrlen);
extern char *trim(char *str);
extern double my_strtod(char *str,char **ptr);
void mystrcpy(char *dst,char *src);
extern char scanner_path[256];
extern int readScanner(void);
extern int debug_level;
extern int check_program(char *program,char *pakiet);
extern char kindle_path[256];

extern char *this_pos;

extern GtkWidget *combo(int defpos,...);

extern char *jacosub_simplify(char *,int);
extern int jacosub_timeres(char *,int *);
extern int get_current_timeres(void);
extern int jacosub_find_dialcon(char *txt,int *size,int timeres,int use_strlen);
extern void autocorrect_dialog_connections(GtkWidget *widget,void *dummy);
extern int get_jaco_timer(char *str,int timeres);

extern struct audioparam {
	int low_freq;
	int high_freq;
	double lgain;
	double mgain;
	double hgain;
    double mbrola_gain;
	int used;
} audioparam_table[3];
extern void audioparam_init(int which);
extern void audioparam_init_f(int which,int freq);
extern void audioparam(short *buf,int count);
extern void audioparam_ask(int which);

extern void gotoforvo(void *,void *);
char *get_diction_line(int gonext,int isutf);
extern void initialize_curl(void);
extern int curl_fetch_file(char *url,void **data,int *len);

#ifdef USE_SUBMIXER
extern void mplayer_read_movie(GtkWidget *widget, void *dummy);
extern void mplayer_read_movie_and_titles(GtkWidget *widget,void *dummy,void *subname_ini);
extern void mplayer_make_audio(GtkWidget *widget, void *dummy);
extern void mplayer_make_video(GtkWidget *widget, void *dummy);
extern void mplayer_settings(GtkWidget *widget, void *dummy);
extern void enable_video_menues(int,struct MyGtkEditor *);
extern void mplayer_delete_workdir(GtkWidget *widget, void *dummy);
extern int is_it_movie(char *fname);
extern gint def_subonly;


extern double smix_speed;
extern double smix_maxspeed;
#ifdef HAVE_IVONA
extern double smix_ivona_speed;
extern double smix_ivona_maxspeed;
#endif
extern int smix_droptime,smix_risetime,smix_mindist;
extern int smix_audio_margin;
extern double smix_volume_factor;
extern double smix_max_origin_vol;
extern int smix_napi_delay;

#endif


extern void initialize_libre_list(void);
extern void auto_window_title(void);


extern char *get_current_line(int do_rewind,GtkTextIter *linebeg);
extern char *get_phrase_uni(char **str,int *mode);
extern int uniParType(char **str,int chaptermark);
extern void speech_buttons_enable(int is_speaking);
extern char *tesseract(char *filename,int nump,int cuneiform);



#ifdef HAVE_MORFOLOGIK
extern void *morfologik_shm;
extern void check_morfo_shm(void);
extern void init_morfologik();

#endif


#ifdef HAVE_IVONA
#include "sonic.h"
#include "libivolektor.h"
extern GtkWidget *notek_ivona,
    *spin_ivona_speed,
    *spin_ivona_pauser,
    *spin_ivona_psent,
    *ivona_voice_combo;
#endif

extern int use_ivona,ivona_enabled;
extern char *ivona_voice,**ivona_voicelist;
extern double ivona_pauser;
extern double ivona_speed;

extern int ivona_prepare_paragraph(char *str);
extern int ivona_speak_paragraph(int pause);
extern int check_ivona_enabled(void);
extern void ivona_finish(void);
extern void poczytaj_mi_ivonko(int fast_start);
//extern void ivona_params(GtkWidget *widget,void *data);
extern void ivona_breath_refresh(void);
int ivolektor_init(void);
extern int ivona_record_paragraph(char *para);
extern int ivona_record_part(int npart);
extern int ivona_getfreq(void);
extern int ivona_push_last_wav(int ofset);
extern int ivona_push_silence(int len);
extern int ivona_push_wave(short *wave,int len);
extern short *ivona_get_wave_from_string(char *ivostr,int *leng,int *ofset,int *resty);
extern int lastpar,spell_empty,bookmode;
extern int currently_making_book;

extern char *ftags[];

extern int encode_audio(short *inp,int count);

extern int check_split_possible(char *body,char *marker);
extern char *make_html(char *title,char *body,char *template,int endash,int formatting,int pred,int succ,char *fname);
extern void book_free_html(char **html);
extern char **book_create_html(char *title,char *author,int endash,int formatting,char *fname);
extern void save_file_html(GtkWidget *dummy,void *data);
extern void save_file_fb2(GtkWidget *dummy,void *data);
extern int save_file_fb2_meta(char *buffer);
extern char *ivona_translate_string(char *iso2str);

#define IV_PAU_NORMAL 1
#define IV_PAU_DIALOG 2
#define IV_PAU_PREDIAL 3
#define IV_PAU_POSTDIAL 4
#define IV_PAU_LONG 5
#define IV_PAU_SENTENCE 6
#define IV_PAU_SENDIAL 7

extern int ivona_std_pauses[];

extern int ivona_pause_lens[];
extern int ivona_sync_mode;
extern short *ivona_get_subtitle_wave(char *ivostr,double speed,int *length,char *movie_path);
extern int ivona_compute_msec(char *isostr,char *movie_path);
/* tu trzeba jeszcze MILENA_PARTYPE_CHAPTER - dodać do mileny? */
#ifndef MILENA_PARTYPE_CHAPTER
#define MILENA_PARTYPE_CHAPTER 10
#endif

extern int sleep_mode,sleep_start,sleep_current;
extern void mp3_play(char *data,int len);
extern void browser(char *);

void editorFindCover(GtkWidget *widget, void *param);
void editorInsertImage(GtkWidget *widget, void *dummy);

extern void init_progressbar(gpointer p);

extern int is_slowtimer(void);
#if !GLIB_CHECK_VERSION(2,28,0)
extern gint64 g_get_real_time(void);
#endif

#ifdef HAVE_GTK3
#define gtk_combo_box_new_text gtk_combo_box_text_new
#define gtk_combo_box_append_text(a,b) gtk_combo_box_text_append(a,NULL,b)
#define gtk_combo_box_get_active_text gtk_combo_box_text_get_active_text
#define gtk_widget_hide_all gtk_widget_hide
#define gtk_source_iter_backward_search gtk_text_iter_backward_search
#define gtk_source_iter_forward_search gtk_text_iter_forward_search
#define gtk_hbox_new(a,b) my_gtk_box_new(GTK_ORIENTATION_HORIZONTAL,a,b)
#define gtk_vbox_new(a,b) my_gtk_box_new(GTK_ORIENTATION_VERTICAL,a,b)

extern GtkWidget * my_gtk_box_new(GtkOrientation orient,gint homo,gint spacing);

#endif

struct FB2_person {
    char *first_name;
    char *middle_name;
    char *last_name;
    char *nick_name;
    char *home_page;
    char *email;
};

struct FB2_Genre {
    char *name;
    int weight;
};

struct FB2Context {
    int context;
    int author_no,author_si;
    int genre_no,genre_si;
    int translator_no,translator_si;
    struct FB2_person *authors;
    struct FB2_person *translators;
    struct FB2_Genre *genres;
    char *title;
    char *origin;
    char *id;
    char *cover;
    char *seq_name;
    int firstanno;
    int nofootnotes;
    int seq_number;
};

struct fb2_imagelist {
    struct fb2_imagelist *next;
    int id;
    char fname[256];
};

extern void create_uuid(unsigned char *c,char *name);


extern struct FB2Context *FB2ReadContext(char *fname);
extern struct FB2Context *FB2_DuplicateContext(struct FB2Context *ctx);
extern void FB2FreeContext(struct FB2Context *ctx);
extern struct FB2Context *FB2ContextInit(void);
extern void FB2WriteContext(char *fname,struct FB2Context *ctx);
extern struct FB2Context *FB2InitContextFromHeadline(char *str);
extern GString *FB2MakeHeader(struct FB2Context *ctx,char *date,int do_anno,char *body,struct fb2_imagelist **images);
extern struct FB2Context *FB2EditContext(struct FB2Context *ctx,int *do_foot,int *do_anno);


extern int fb2_image(char **sstr,char **outstr,char **outsrc);
extern void create_fb2_sections(GString *gs,char *body,int spliter,int do_foot,int do_anno,struct fb2_imagelist **images);
extern void create_fb2_section(GString *gs,char *part,int split,int footnote,int annotation,struct fb2_imagelist **images,int *depth,int *htitle);
extern int FB2_finalize(GString *gs,char *cover,struct fb2_imagelist *images);
extern int fb2_can_have_footnotes(char *body);
extern int fb2_skips(char **str);

extern void g_string_append_htmlescape(GString *gc,char *c);
extern gunichar g_utf8_fetch_char(char **ptr);
extern int g_utf8_strncasecmp(char *a1,char *a2,int n);
extern int g_timer_can_step(gint64 *gt,int msec);

extern int _m(char *c,char *pat);
char *unformat_me(char *str,int no_pages,int autopar,int marker);
extern void ICPAddPreview(GtkFileChooser *chooser);

extern int setFootNote(char *c);


extern int init_milena_libs(int is_dic);
extern void close_milena_libs(void);
extern int milena_add_local_dic(void);
extern void init_mbrola_tp(void);
extern void do_contrast(short *data,int len);

extern int use_pulse,pulse_margin;

extern char *wget(char *url,int *len);

extern char *get_napi(char *fname);

static inline void ignore(register int r) {}
extern char *subtitle_read_buffer(char *fname,char *movie_name,char **bladz);

extern void show_toc(void);

extern void initialize_python(void);



#define HAVE_SUBREADER 1
#define KILL_SIGNAL 9
#endif
