/*
 * mobireader.c - Milena Audiobook Creator
 * Copyright (C) Bohdan R. Rau 2014 <ethanak@polip.com>
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write see:
 *               <http://www.gnu.org/licenses/>.
 */

#include "config.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <glib.h>
#include <errno.h>
#include <unistd.h>
#include <sys/wait.h>
#include <ctype.h>
#include "html.h"

char *read_mobi(char *fname,char **error)
{
    char dirname[256],*dn;
    char command[512];
    char *args[4];
    pid_t pid;
    int status;
    void rmd(void)
    {
	sprintf(command,"rm -rf %s",dirname);
	system(command);
    }
    
    void append_xhtml(char *c,char **outb)
    {
	int n=html2txt(c,NULL);
	char *s;
	if (n<=0) return;
	if (!*outb) {
	    *outb=g_malloc(n+1);
	    s=*outb;
	}
	else {
	    *outb=g_realloc(*outb,strlen(*outb)+n);
	    s=*outb+strlen(*outb);
	}
	html2txt(c,s);
    }

    if (!g_file_test(fname,G_FILE_TEST_IS_REGULAR)) {
	*error="Podany plik nie istnieje";
	return NULL;
    }
    sprintf(dirname,"%s/tmp/milena_XXXXXX",getenv("HOME"));
    dn=mkdtemp(dirname);
    if (!dn) {
        strcpy(dirname,"/tmp/milena_XXXXXX");
        dn=mkdtemp(dirname);
    }
    if (!dn) {
	*error=strerror(errno);
        return NULL;
    }
    args[0]="ebook-convert";
    args[1]=fname;
    args[2]=dirname;
    args[3]=NULL;
    pid=fork();
    if (pid < 0) {
comerr:	*error=strerror(errno);
	rmd();
	return NULL;
    }
    if (pid == 0) {
	execvp("ebook-convert",args);
	exit(1);
    }
    if (waitpid(pid,&status,0) < 0) goto comerr;
    if (!WIFEXITED(status) || WEXITSTATUS(status) != 0) {
	*error="ebook-convert zwrócił błąd";
	rmd();
	return NULL;
    }
    sprintf(command,"%s/content.opf",dirname);
    char *fstr,*bid,*eid,*bq,*eq;
    if (!g_file_get_contents(command,&fstr,NULL,NULL)) {
	*error="Błąd otwarcia content.opf";
	rmd();
	return NULL;
    }
    GHashTable *idlist=g_hash_table_new_full(g_str_hash,g_str_equal,g_free,g_free);
    for (bid=fstr;bid && *bid;) {
	char *href=NULL,*id=NULL,*type=NULL;
	bid=strstr(bid,"<item");
	if (!bid) break;
	bid+=5;
	if (!isspace(*bid)) continue;
	for (;;) {
	    while (bid && *bid && isspace(*bid)) bid++;
	    if (*bid == '>' || *bid=='/') break;
	    eid=strchr(bid,'=');
	    if (!eid) break;
	    bq=eid+1;
	    if (*bq != '"') break;
	    bq += 1;
	    eq=strchr(bq,'"');
	    if (!eq) break;
	    if (!strncmp(bid,"id=",3)) {
		id=g_strndup(bq,eq-bq);
	    }
	    else if (!strncmp(bid,"media-type=",11)) {
		type=g_strndup(bq,eq-bq);
	    }
	    else if (!strncmp(bid,"href=",5)) {
		sprintf(command,"%s/%-*.*s",dirname,eq-bq,eq-bq,bq);
		href=g_strdup(command);
	    }
	    bid=eq+1;
	}
	if (!href || !id || !type || !strstr(type,"html")) {
	    g_free(href);
	    g_free(id);
	    g_free(type);
	    continue;
	}
	g_free(type);
	g_hash_table_replace(idlist,id,href);
	//printf("Idlist [%s] = [%s]\n",id,href);
    }


    char *output=NULL;

    for (bid=fstr;bid && *bid;) {
	char *id=NULL;
	bid=strstr(bid,"<itemref");
	if (!bid) break;
	bid+=8;
	if (!isspace(*bid)) continue;
	for (;;) {
	    while (bid && *bid && isspace(*bid)) bid++;
	    if (*bid == '>' || *bid=='/') break;
	    eid=strchr(bid,'=');
	    if (!eid) break;
	    bq=eid+1;
	    if (*bq != '"') break;
	    bq += 1;
	    eq=strchr(bq,'"');
	    if (!eq) break;
	    *eq++=0;
	    if (!strncmp(bid,"idref=",6)) {
		id=bq;
	    }
	    bid=eq;
	}
	if (!id) continue;
	char *plik=g_hash_table_lookup(idlist,id);
	if (!plik) continue;
	char *cnt;
	if (!g_file_get_contents(plik,&cnt,NULL,NULL)) {
	    g_free(output);
	    g_hash_table_destroy(idlist);
	    goto comerr;
	}
	append_xhtml(cnt,&output);
	g_free(cnt);
    }
    g_free(fstr);
    g_hash_table_destroy(idlist);
    rmd();
    //*error="Mobireader OK";
    return output;
}
