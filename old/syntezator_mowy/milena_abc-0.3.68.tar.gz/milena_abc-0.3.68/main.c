/*
 * main.c - Milena Audiobook Creator
 * Copyright (C) Bohdan R. Rau 2009-2013 <ethanak@polip.com>
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write see:
 *               <http://www.gnu.org/licenses/>.
 */

#include "config.h"
#include <gtk/gtk.h>
#include <gdk/gdkkeysyms.h>
#include <stdarg.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include "gmilena.h"
#include <dirent.h>
#include <milena.h>
#include <ctype.h>


#ifdef HAVE_GTK3
// compatibility functions
GtkWidget * my_gtk_box_new(GtkOrientation orient,gint homo,gint spacing)
{
	GtkWidget *box=gtk_box_new(orient, spacing);
	gtk_box_set_homogeneous((gpointer)box, homo);
	return box;
}
#endif

GdkCursor *watch_cursor;
GtkWidget *main_window;
GtkWidget *uframe,*notek;
GtkTextBuffer *tresc;
GtkTextView *tresc_v;
GtkWidget *spin_tempo,*spin_pitch;
#ifdef HAVE_IVONA
GtkWidget *notek_ivona,
    *spin_ivona_speed,
    *spin_ivona_pauser,
    *spin_ivona_psent,
    *ivona_voice_combo,
    *ivona_breath_combo,
    *ivona_breath_button,
    *ivona_breath_spin;
int ivona_breath_last;
#endif
#ifdef HAVE_PYTHON
static int disable_python;
#endif
GtkWidget *lang_cb[NUM_LANGS];
char *lang_codes[NUM_LANGS]={"en","fr","es","it","se","ru","de","hu","ro","pt"};
char *lang_names[NUM_LANGS]={"Angielski","Francuski","Hiszpański","Włoski","Szwedzki",
	"Rosyjski","Niemiecki","Węgierski","Rumuński","Portugalski"};

GtkWidget *cb_hours,*cb_pro, *cb_ign, *cb_dic, *cb_lector, *cb_spell , *cb_ellip, *cb_equ;

GtkWidget *dic_filechooser;

GtkWidget *cb_kontrast,*spin_kontrast;

GtkWidget *combo_mp3,*cb_stereo,*combo_amr,*cb_dtx,*combo_split,*char_split,
	*combo_autonum,*combo_prolog,*combo_epilog;

GtkWidget *menubar,*filemenu,*speechmenu,*toolbar,*helpmenu,*accessmenu,*lookmenu;
#ifdef USE_SUBMIXER
GtkWidget *videomenu;
#endif

int sleep_mode,sleep_current,sleep_start;

int use_ivona,ivona_enabled;
char *ivona_voice;
char **ivona_voicelist;
double ivona_pauser=0.4;
double ivona_speed=1.3;
int ivona_std_pauses[IV_PAU_SENDIAL+1];

GtkWidget *m_play,*t_play,*m_stop,*t_stop,*t_prop,*m_open,*m_include,*m_new,*m_edit,*t_open,*t_new,
	*m_close,*t_close,*m_save,*m_saveas,*m_savehtml,*m_saveepub,*m_savefb2,*m_edswitch,
    *m_opendic,*t_save,*t_saveas,*m_search,*m_normalize_blanks,
	*m_dash,*m_dict,*m_dict2,*m_dict3,*m_bezglut,*m_menudict,
    *m_paranoid,*m_adash,*m_unfor,*m_edswap,*m_gotodash,*m_seltodict,*m_gluetodict,*m_ungluedict,*m_dicsuggest,
	*m_findcur,*m_voice,*m_stereo,*m_mp3,*m_amr,*m_help,*m_entity,*m_scanner,*m_access,*m_ac_search,
	*m_partfb2,*m_upart,*m_fpart,*m_fcite,*m_fcite1,*m_fpoem,*m_fauthor,*m_fepi,*m_fepi1,
#ifndef HAVE_GTK3
	*m_ac_atk,
#endif
    *m_morfologik[4],*m_morfmenu,*m_morfwidget,
    *m_ac_nop,*m_ac_go_edi,*t_prop,*m_tiface,*m_togtool,
	*m_fullscreen,*m_use_pulse,*m_pulse_margin,
	*m_unjaco,*m_autonumba,*m_dialconn,*m_dialcall,
    *m_ocrtodic[4],*m_autochapter,*m_showtoc,*m_case,*m_bold,*m_italic,
    *m_epub_dash,*m_epub_just,*m_epub_procover,*m_epub_format,*m_fb2_el,
	*m_equ1,*m_equ2,*m_equ3,*m_wymowa,*m_sleep,*m_sleep2,*m_browser,*m_slowtimer
#ifdef USE_SUBMIXER
	,*m_video,*m_video_open,*m_video_caud,*m_video_cmov,*m_video_settings,*m_video_submkv
#endif
#ifdef USE_RESAMPLER
	,*m_resample
#endif
#ifdef HAVE_PYTHON
	,*m_python,*python_menu
#endif
#ifdef HAVE_NAPIPRO
	,*m_napi_use,*m_napi_autosave
#endif
	;

GtkWidget *statusbar,*statusbar_ove,*statusbar_line,*statusbar_col;

struct miltheme *themes;
gint debug_level=0;

void mystrcpy(char *dst,char *src)
{
	while ((*dst++ = *src++));
}

double my_strtod(char *string,char **endPtr)
{
	char *cs,*ds;
	int sign=0,nx=0;
	double fc=0,dbl;
	long long mx=0;
	int dn=0;
	int fp=0;
	int shift=0;
	int eneg=0;
	int i;
	//static int maxExponent = 511;
	static double powersOf10[] = {10.,100.,1.0e4,1.0e8,1.0e16,
		1.0e32,1.0e64,1.0e128,1.0e256};
	
	cs=string;
	while (*cs && isspace(*cs)) cs++;
	if (*cs=='+' || *cs=='-') {
		if (*cs++=='+') sign=1;
		else sign=-1;
	}
	for (;*cs;) {
		if (*cs == '.' || *cs == ',') {
			if (fp) break;
			fp=1;
			cs++;
			continue;
		}
		if (!isdigit(*cs)) break;
		if (dn>=18) {
			if (!fp) shift -= 1;
			continue;
		}
		if (fp) shift += 1;
		dn += 1;
		mx=(mx * 10) + (*cs++) - '0';
	}
	if (!dn) {
		if (endPtr) *endPtr=string;
		return 0.0;
	}
	ds=cs;
	nx=0;
	if (*ds=='e' || *ds=='E') {
		ds++;
		if (*ds=='-') {
			ds++;eneg=1;shift=-shift;
		}
		else if (*ds=='+') {
			ds++;
		}
		if (*ds && isdigit(*ds)) {
			cs=ds;
			while (*cs && isdigit(*cs)) {
				nx = 10*nx + (*cs++) - '0';
			}
		}
	}
	nx -= shift;
	if (nx<0) {
		nx=-nx;
		eneg=1-eneg;
	}
	if (endPtr) *endPtr=cs;
	if (nx > 511) {
		errno=ERANGE;
		return 0.0;
	}
	fc=mx;
	dbl=1.0;
	for (i=0;i<9;i++) if (nx & (1<<i)) {
		dbl *= powersOf10[i];
	}
	if (eneg) fc /= dbl;
	else fc *= dbl;
	if (sign == -1) fc=-fc;
	return fc;
}

char *trim(char *str)
{
	char *c,*d;
	while (*str && isspace(*str)) str++;
	for (c=d=str;*c;c++) if (!isspace(*c)) d=c+1;
	*d=0;
	return str;
}

int GetNumberD(char *title,char *labelstr,char *dn)
{
	GtkWidget *dialog=gtk_dialog_new_with_buttons(
		title,
		(gpointer)main_window,
		GTK_DIALOG_MODAL,
		GTK_STOCK_OK,GTK_RESPONSE_ACCEPT,
		GTK_STOCK_CANCEL,GTK_RESPONSE_REJECT,
		NULL);
	GtkWidget *box=gtk_dialog_get_content_area((gpointer)dialog);
	GtkWidget *hbox=gtk_hbox_new(0,2);
	gtk_box_pack_start(GTK_BOX(box),(gpointer)hbox,FALSE,FALSE,0);
	GtkWidget *label=gtk_label_new(labelstr);
	GtkWidget *entry=gtk_entry_new();
	connect_label(label,entry);
	gtk_box_pack_start(GTK_BOX(hbox),label,FALSE,FALSE,0);
	gtk_box_pack_start(GTK_BOX(hbox),entry,FALSE,FALSE,0);
	gtk_widget_show_all((gpointer)box);
	int n=-1;
	if (dn) gtk_entry_set_text((gpointer)entry,dn);
	gtk_dialog_set_default_response((gpointer)dialog,GTK_RESPONSE_ACCEPT);
	gtk_entry_set_activates_default((gpointer)entry,TRUE);
	if (gtk_dialog_run((gpointer)dialog) == GTK_RESPONSE_ACCEPT) {
		char const *str=gtk_entry_get_text((gpointer)entry);
		char *estr;
		n=strtol(str,&estr,10);
		if (estr==str) n=-1;
	}
	gtk_widget_destroy(dialog);
	return n;
}

int GetNumber(char *title,char *labelstr)
{
	return GetNumberD(title,labelstr,NULL);
}

char *AskStringP2(char *title,char *labelstr,char *ptr,gpointer window)
{
	char *c;
	GtkWidget *dialog=gtk_dialog_new_with_buttons(
		title,
		window,
		GTK_DIALOG_MODAL,
		GTK_STOCK_OK,GTK_RESPONSE_ACCEPT,
		GTK_STOCK_CANCEL,GTK_RESPONSE_REJECT,
		NULL);
	GtkWidget *box=gtk_dialog_get_content_area((gpointer)dialog);
	GtkWidget *hbox=gtk_hbox_new(0,2);
	gtk_box_pack_start(GTK_BOX(box),(gpointer)hbox,FALSE,FALSE,0);
	GtkWidget *label=gtk_label_new(labelstr);
	GtkWidget *entry=gtk_entry_new();
    gtk_entry_set_text((gpointer)entry,ptr);
	connect_label(label,entry);
	gtk_box_pack_start(GTK_BOX(hbox),label,FALSE,FALSE,0);
	gtk_box_pack_start(GTK_BOX(hbox),entry,FALSE,FALSE,0);
	gtk_widget_show_all((gpointer)box);
	gtk_dialog_set_default_response((gpointer)dialog,GTK_RESPONSE_ACCEPT);
	gtk_entry_set_activates_default((gpointer)entry,TRUE);
	c=NULL;
	if (gtk_dialog_run((gpointer)dialog) == GTK_RESPONSE_ACCEPT) {
		c=g_strdup(gtk_entry_get_text((gpointer)entry));
	}
	gtk_widget_destroy(dialog);
	return c;
}


char *AskString2(char *title,char *label,gpointer window)
{
    return AskStringP2(title,label,"",window);
}
char *AskStringP(char *title,char *label,char *ptr)
{
	return AskStringP2(title,label,ptr,(gpointer)main_window);
}
char *AskString(char *title,char *label)
{
	return AskString2(title,label,(gpointer)main_window);
}

static int _Ask(gpointer w,char *title,char *format,va_list va)
{
	GtkWidget *dialog;
	int n;
    char *str=g_strdup_vprintf(format,va);
	dialog = gtk_message_dialog_new(w,
		GTK_DIALOG_DESTROY_WITH_PARENT,
		GTK_MESSAGE_QUESTION,
		GTK_BUTTONS_YES_NO,
            	"%s",str);
	gtk_window_set_title(GTK_WINDOW(dialog), title);
	n=gtk_dialog_run(GTK_DIALOG(dialog));
	gtk_widget_destroy(dialog);
    g_free(str);
	return n==GTK_RESPONSE_YES;
}


int AskF(gpointer w,char *title,char *format,...)
{
    va_list ap;
    int n;
    if (!w) w=(gpointer)main_window;
    va_start(ap,format);
    n=_Ask(w,title,format,ap);
    va_end(ap);
    return n;
}

int Ask2(char *title,char *question,gpointer w)
{
	return AskF(w,title,"%s",question);
}

int Ask(char *title,char *question)
{
	return AskF(NULL,title,"%s",question);
}


static void _Error(gpointer w,char *title,char *format,va_list va)
{
	GtkWidget *dialog;
    char *str=g_strdup_vprintf(format,va);
	dialog = gtk_message_dialog_new(w,
		GTK_DIALOG_DESTROY_WITH_PARENT,
		GTK_MESSAGE_ERROR,
		GTK_BUTTONS_OK,
            	"%s",str);
	gtk_window_set_title(GTK_WINDOW(dialog), title);
	gtk_dialog_run(GTK_DIALOG(dialog));
	gtk_widget_destroy(dialog);
    g_free(str);
}

void ErrorF(gpointer w,char *title,char *format,...)
{
    va_list ap;
    if (!w) w=(gpointer)main_window;
    va_start(ap,format);
    _Error(w,title,format,ap);
    va_end(ap);
}

void Error(char *title,char *error)
{
	ErrorF(NULL,title,"%s",error);
}

void Error2(char *title,char *error,gpointer w)
{
	ErrorF(w,title,"%s",error);
}

static void _Info(gpointer w,char *title,char *format,va_list va)
{
    char *str=g_strdup_vprintf(format,va);
	GtkWidget *dialog = gtk_message_dialog_new(w,
		GTK_DIALOG_DESTROY_WITH_PARENT,
		GTK_MESSAGE_INFO,
		GTK_BUTTONS_OK,
            	"%s",str);
	gtk_window_set_title(GTK_WINDOW(dialog), title);
	gtk_dialog_run(GTK_DIALOG(dialog));
	gtk_widget_destroy(dialog);
    g_free(str);
}


void InfoF(gpointer w,char *title,char *format,...)
{
    va_list ap;
    if (!w) w=(gpointer)main_window;
    va_start(ap,format);
    _Info(w,title,format,ap);
    va_end(ap);
}

void Info(char *title,char *info)
{
	InfoF(NULL,title,"%s",info);
}

void Info2(char *title,char *info,gpointer w)
{
	InfoF(w,title,"%s",info);
}

void g_perror(char *s) {
	char buf[1024];
	sprintf(buf,"%s:\n%s",s,strerror(errno));
	Error("Błąd",buf);
}

int close_main_window(void)
{
	audio_play(NULL,0);
	if (!Ask("Pytanie","Naprawdę kończysz?")) return TRUE;
	gtk_main_quit();
	exit(0);
}

static void set_dicfile_active(GtkWidget *dummy)
{
	gtk_widget_set_sensitive(dic_filechooser,
		(!is_speaking) && gtk_toggle_button_get_active((gpointer)cb_dic));
}

static void set_kontrast_active(GtkWidget *dummy)
{
	gtk_widget_set_sensitive(spin_kontrast,
		gtk_toggle_button_get_active((gpointer)cb_kontrast));
}


static void set_lector_active(GtkWidget *dummy)
{
	gtk_widget_set_sensitive(cb_lector,
		!gtk_toggle_button_get_active((gpointer)cb_spell));
	gtk_widget_set_sensitive(cb_spell,
		!gtk_toggle_button_get_active((gpointer)cb_lector));
}

static void toggle_interface_menu(GtkWidget *widget)
{
	if (gtk_check_menu_item_get_active((gpointer)widget)) {
		gtk_toggle_tool_button_set_active((gpointer)t_prop,TRUE);
		gtk_widget_show(uframe);
	}
	else {
		gtk_toggle_tool_button_set_active((gpointer)t_prop,FALSE);
		gtk_widget_hide(uframe);
	}


}

static void toggle_toolbar(GtkWidget *widget)
{
	if (gtk_check_menu_item_get_active((gpointer)widget)) {
		gtk_widget_show(toolbar);
	}
	else {
		gtk_widget_hide(toolbar);
	}

}

static void toggle_fullscreen(GtkWidget *widget)
{
	if (gtk_check_menu_item_get_active((gpointer)widget)) {
		gtk_window_fullscreen((gpointer)main_window);
	}
	else {
		gtk_window_unfullscreen((gpointer)main_window);
	}

}

static void toggle_iface(GtkWidget *widget)
{
	if (gtk_toggle_tool_button_get_active((gpointer)widget)) {
		gtk_check_menu_item_set_active((gpointer)m_tiface,TRUE);
		gtk_widget_show(uframe);
	}
	else {
		gtk_check_menu_item_set_active((gpointer)m_tiface,FALSE);
		gtk_widget_hide(uframe);
	}
}

static void toggle_audiodevice(GtkWidget *widget)
{
	use_pulse=gtk_check_menu_item_get_active((gpointer)widget);
}

void connect_label(gpointer a,gpointer b)
{
	AtkObject *label;
	AtkObject *widget;
	label=gtk_widget_get_accessible(a);
	widget=gtk_widget_get_accessible(b);
	atk_object_add_relationship(label,ATK_RELATION_LABEL_FOR,widget);
	atk_object_add_relationship(widget,ATK_RELATION_LABELLED_BY,label);
	if (gtk_label_get_mnemonic_keyval(a) != GDK_VoidSymbol) {
		gtk_label_set_mnemonic_widget(a,b);
	}
}

GtkWidget *combo(int defpos,...)
{
	GtkWidget *c=gtk_combo_box_new_text();
	va_list ap;
	va_start(ap,defpos);
	for (;;) {
		char *s=va_arg(ap,char *);
		if (!s) break;
		gtk_combo_box_append_text((gpointer)c,s);
	}
	va_end(ap);
	gtk_combo_box_set_active((gpointer)c,defpos);
	return c;
}

static void AskSleep(void)
{
	GtkWidget *dialog=gtk_dialog_new_with_buttons(
		"Sleep",
		(gpointer)main_window,
		GTK_DIALOG_MODAL,
		GTK_STOCK_OK,GTK_RESPONSE_ACCEPT,
		GTK_STOCK_CANCEL,GTK_RESPONSE_REJECT,
		NULL);
	GtkWidget *box=gtk_dialog_get_content_area((gpointer)dialog);
	GtkWidget *hbox=gtk_hbox_new(0,2);
	gtk_box_pack_start(GTK_BOX(box),(gpointer)hbox,FALSE,FALSE,0);
	GtkWidget *label=gtk_label_new("Czas czytania (min)");
    GtkWidget *combo_sleep=combo(sleep_current,"5","10","15","30","45","60",NULL);
    connect_label(label,combo_sleep);
	gtk_box_pack_start(GTK_BOX(hbox),label,FALSE,FALSE,0);
	gtk_box_pack_start(GTK_BOX(hbox),combo_sleep,FALSE,FALSE,0);
	gtk_widget_show_all((gpointer)box);
	if (gtk_dialog_run((gpointer)dialog) == GTK_RESPONSE_ACCEPT) {
        sleep_current=gtk_combo_box_get_active((gpointer)combo_sleep);
	}
	gtk_widget_destroy(dialog);
	return;
}


static void set_autonum_active(GtkWidget *dummy)
{
	int v1=gtk_combo_box_get_active((gpointer)combo_split);
	int v2=0;
	if (v1) v2=gtk_combo_box_get_active((gpointer)combo_autonum);
	gtk_widget_set_sensitive(char_split,v1);
	gtk_widget_set_sensitive(combo_autonum,v1);
	gtk_widget_set_sensitive(combo_prolog,v2);
	gtk_widget_set_sensitive(combo_epilog,v2);
}


int is_speaking;

void speech_buttons_enable(int is_speaking)
{
	struct MyGtkEditor *editor=gimma_current_editor();
	int mode=-1;
	if (editor) mode=editor->editor_type;
	gtk_widget_set_sensitive(t_stop,is_speaking);
	gtk_widget_set_sensitive(m_stop,is_speaking);
	gtk_widget_set_sensitive(t_play,!is_speaking);
	gtk_widget_set_sensitive(m_play,!is_speaking);
	gtk_widget_set_sensitive(m_sleep,!is_speaking);
	gtk_widget_set_sensitive(m_sleep2,!is_speaking);
	gtk_widget_set_sensitive(m_new,!is_speaking);
	gtk_widget_set_sensitive(m_open,!is_speaking);
	gtk_widget_set_sensitive(m_include,!is_speaking && (mode==MILEDIT_MODE_NORMAL));
	gtk_widget_set_sensitive(m_opendic,!is_speaking);
	gtk_widget_set_sensitive(m_edit,!is_speaking);
	gtk_widget_set_sensitive(m_menudict,!is_speaking);
	gtk_widget_set_sensitive(m_search,!is_speaking);
	gtk_widget_set_sensitive(m_save,!is_speaking);
	gtk_widget_set_sensitive(m_saveas,!is_speaking);
	gtk_widget_set_sensitive(m_savehtml,!is_speaking);
	gtk_widget_set_sensitive(m_saveepub,!is_speaking);
	gtk_widget_set_sensitive(m_savefb2,!is_speaking);
	gtk_widget_set_sensitive(t_open,!is_speaking);
	gtk_widget_set_sensitive(t_new,!is_speaking);
	gtk_widget_set_sensitive(t_save,!is_speaking);
	gtk_widget_set_sensitive(t_saveas,!is_speaking);
	gtk_widget_set_sensitive(m_close,!is_speaking);
	gtk_widget_set_sensitive(m_edswitch,!is_speaking);
	gtk_widget_set_sensitive(t_close,!is_speaking);
	gtk_widget_set_sensitive(m_voice,!is_speaking);
	gtk_widget_set_sensitive(m_stereo,!is_speaking);
	gtk_widget_set_sensitive(m_equ1,!is_speaking);
	gtk_widget_set_sensitive(m_equ2,!is_speaking);
#ifdef HAVE_PYTHON
	gtk_widget_set_sensitive(m_python,!is_speaking);
#endif
#ifdef USE_RESAMPLER
	gtk_widget_set_sensitive(m_resample,!is_speaking);
#endif
#ifdef USE_SUBMIXER
	gtk_widget_set_sensitive(m_video,!is_speaking);
#endif
#ifdef HAVE_IVONA
    if (ivona_enabled) {
        gtk_widget_set_sensitive(ivona_breath_combo,!is_speaking);
        gtk_widget_set_sensitive(ivona_breath_spin,!is_speaking);
        gtk_widget_set_sensitive(ivona_breath_button,!is_speaking);
    }
#endif
	gtk_widget_set_sensitive(m_help,!is_speaking);
	gtk_widget_set_sensitive(m_amr,!is_speaking && (mode==MILEDIT_MODE_NORMAL));
	gtk_widget_set_sensitive(m_mp3,!is_speaking && (mode==MILEDIT_MODE_NORMAL));

	gtk_widget_set_sensitive(dic_filechooser,
		(!is_speaking) && gtk_toggle_button_get_active((gpointer)cb_dic));

	gtk_widget_set_sensitive(notek,!is_speaking);

}

static void speech_play()
{
	if (is_speaking) return;
	start_reading(0);
}

static void speech_stop()
{
	is_speaking=0;
}

double stereo_rev=50.0,stereo_hfd=50,stereo_room=100,stereo_depth=100;

#ifdef USE_RESAMPLER

void compute_resample_par(void)
{
	resample_factor=computed_resample_factor/vocal_track_length;
	mbrola_real_freq=16000/vocal_track_length;
}

static void resampler_dialog(void)
{
	GtkWidget *dialog=gtk_dialog_new_with_buttons(
		"Resampler",
		(gpointer)main_window,
		GTK_DIALOG_MODAL,
		GTK_STOCK_OK,GTK_RESPONSE_ACCEPT,
		GTK_STOCK_CANCEL,GTK_RESPONSE_REJECT,
		NULL);
	GtkWidget *box=gtk_dialog_get_content_area((gpointer)dialog);
	GtkWidget *vbox=gtk_vbox_new(0,2);
	gtk_box_pack_start(GTK_BOX(box),(gpointer)vbox,FALSE,FALSE,0);

	GtkWidget *usesamp_cb=gtk_check_button_new_with_label("Włącz resampling");
	gtk_box_pack_start(GTK_BOX(vbox),usesamp_cb,FALSE,FALSE,0);
	GtkWidget *stable=gtk_table_new(2,2,0);
	gtk_box_pack_start(GTK_BOX(vbox),stable,FALSE,FALSE,0);

	GtkWidget *label=gtk_label_new("Długość toru wokalnego");
	gtk_table_attach_defaults((gpointer)stable,label,0,1,0,1);
	GtkWidget *spin_vtr=gtk_spin_button_new_with_range(0.6,1.6,0.01);
	gtk_table_attach_defaults((gpointer)stable,spin_vtr,1,2,0,1);
	connect_label(label,spin_vtr);
	label=gtk_label_new("Mnożnik częstotliwości");
	gtk_table_attach_defaults((gpointer)stable,label,0,1,1,2);
	GtkWidget *spin_mpx=gtk_spin_button_new_with_range(0.6,1.4,0.01);
	gtk_table_attach_defaults((gpointer)stable,spin_mpx,1,2,1,2);
	connect_label(label,spin_mpx);
	gtk_toggle_button_set_active((gpointer)usesamp_cb,use_resampler);
	gtk_spin_button_set_value((gpointer)spin_vtr,vocal_track_length);
	gtk_spin_button_set_value((gpointer)spin_mpx,computed_resample_factor);
	gtk_widget_show_all(box);
	int n=gtk_dialog_run((gpointer)dialog);
	if (n==GTK_RESPONSE_ACCEPT) {
		use_resampler=gtk_toggle_button_get_active((gpointer)usesamp_cb);
		computed_resample_factor=gtk_spin_button_get_value((gpointer)spin_mpx);
		vocal_track_length=gtk_spin_button_get_value((gpointer)spin_vtr);
		compute_resample_par();
/*
		stereo_rev=gtk_spin_button_get_value((gpointer)spin_rev);
		stereo_hfd=gtk_spin_button_get_value((gpointer)spin_hfd);
		stereo_room=gtk_spin_button_get_value((gpointer)spin_room);
		stereo_depth=gtk_spin_button_get_value((gpointer)spin_depth);
		      */
	}
	gtk_widget_destroy(dialog);

}

#endif

static void equalizer_dialog(GtkWidget *widget,void *data)
{
	int n=(int)data;
	audioparam_ask(n);
}


static void stereo_dialog(void)
{

	GtkWidget *dialog=gtk_dialog_new_with_buttons(
		"Ustawienia trybu Stereo",
		(gpointer)main_window,
		GTK_DIALOG_MODAL,
		GTK_STOCK_OK,GTK_RESPONSE_ACCEPT,
		GTK_STOCK_CANCEL,GTK_RESPONSE_REJECT,
		NULL);
	GtkWidget *box=gtk_dialog_get_content_area((gpointer)dialog);
	GtkWidget *vbox=gtk_vbox_new(0,2);
	gtk_box_pack_start(GTK_BOX(box),(gpointer)vbox,FALSE,FALSE,0);

	GtkWidget *stable=gtk_table_new(2,2,0);
	gtk_box_pack_start(GTK_BOX(vbox),stable,FALSE,FALSE,0);
	GtkWidget *label=gtk_label_new("Pogłos");
	gtk_table_attach_defaults((gpointer)stable,label,0,1,0,1);
	GtkWidget *spin_rev=gtk_spin_button_new_with_range(0.0,100.0,1.0);
	gtk_table_attach_defaults((gpointer)stable,spin_rev,1,2,0,1);
	connect_label(label,spin_rev);
	label=gtk_label_new("Damping HF");
	gtk_table_attach_defaults((gpointer)stable,label,0,1,1,2);
	GtkWidget *spin_hfd=gtk_spin_button_new_with_range(0.0,100.0,1.0);
	gtk_table_attach_defaults((gpointer)stable,spin_hfd,1,2,1,2);
	connect_label(label,spin_hfd);
	label=gtk_label_new("Skala pomieszczenia");
	gtk_table_attach_defaults((gpointer)stable,label,0,1,2,3);
	GtkWidget *spin_room=gtk_spin_button_new_with_range(0.0,100.0,1.0);
	gtk_table_attach_defaults((gpointer)stable,spin_room,1,2,2,3);
	connect_label(label,spin_room);
	label=gtk_label_new("Głębokość stereo");
	gtk_table_attach_defaults((gpointer)stable,label,0,1,3,4);
	GtkWidget *spin_depth=gtk_spin_button_new_with_range(0.0,100.0,1.0);
	gtk_table_attach_defaults((gpointer)stable,spin_depth,1,2,3,4);
	connect_label(label,spin_depth);
	gtk_spin_button_set_value((gpointer)spin_rev,stereo_rev);
	gtk_spin_button_set_value((gpointer)spin_hfd,stereo_hfd);
	gtk_spin_button_set_value((gpointer)spin_room,stereo_room);
	gtk_spin_button_set_value((gpointer)spin_depth,stereo_depth);

	gtk_widget_show_all(box);
	int n=gtk_dialog_run((gpointer)dialog);
	if (n==GTK_RESPONSE_ACCEPT) {
		stereo_rev=gtk_spin_button_get_value((gpointer)spin_rev);
		stereo_hfd=gtk_spin_button_get_value((gpointer)spin_hfd);
		stereo_room=gtk_spin_button_get_value((gpointer)spin_room);
		stereo_depth=gtk_spin_button_get_value((gpointer)spin_depth);
	}
	gtk_widget_destroy(dialog);
}


static void about_me(void)
{
	GtkWidget *dialog=gtk_about_dialog_new();
	char buf[256];
	gtk_about_dialog_set_program_name(GTK_ABOUT_DIALOG(dialog),"Milena ABC");
	gtk_about_dialog_set_version(GTK_ABOUT_DIALOG(dialog),PACKAGE_VERSION);
	gtk_about_dialog_set_copyright(GTK_ABOUT_DIALOG(dialog),"(C) Bohdan R. Rau 2009-2018");
	sprintf(buf,"Kreator audioksiążek oparty na TTS Milena\nwersja bibliotek %s",milena_GetVersion());
	gtk_about_dialog_set_comments(GTK_ABOUT_DIALOG(dialog),buf);
	gtk_about_dialog_set_website(GTK_ABOUT_DIALOG(dialog),"http://milena.polip.com");
	gtk_dialog_run(GTK_DIALOG(dialog));
	gtk_widget_destroy(dialog);
}

void show_url(char *s)
{
#ifdef USE_WEBKIT
    if (!gtk_check_menu_item_get_active((gpointer)m_browser)) {
        browser(s);
    }
else
#endif
	gtk_show_uri(NULL,s,GDK_CURRENT_TIME,NULL);
}

static void help_me(void)
{
    show_url("file://" HTMLDIR "/index.html");
}

static void show_milena_home(void)
{
	show_url("http://milena.polip.com");
}

static void acc_go_editor(void)
{
	struct MyGtkEditor *edi=gimma_current_editor();
	if (!edi) return;
	gtk_widget_grab_focus((gpointer)edi->view);
}

static void acc_go_synth(void)
{
	int n=gtk_toggle_tool_button_get_active((gpointer)t_prop);
	if (!n) gtk_toggle_tool_button_set_active((gpointer)t_prop,TRUE);
#ifdef HAVE_IVONA
    if (ivona_enabled) gtk_widget_grab_focus(notek_ivona);
    else
#endif
	gtk_widget_grab_focus(spin_tempo);
}

static void acc_go_conv(void)
{
	int n=gtk_toggle_tool_button_get_active((gpointer)t_prop);
	if (!n) gtk_toggle_tool_button_set_active((gpointer)t_prop,TRUE);
	gtk_widget_grab_focus(cb_kontrast);
}

#ifdef HAVE_IVONA
static void ivona_breath_default(void)
{
    int n=gtk_combo_box_get_active((gpointer)ivona_breath_combo);
    ivona_pause_lens[n+1]=ivona_std_pauses[n+1];
    gtk_spin_button_set_value(
        (gpointer)ivona_breath_spin,
        (double)ivona_pause_lens[n+1]);
}

void ivona_breath_refresh(void)
{
    int n=gtk_combo_box_get_active((gpointer)ivona_breath_combo);
    if (ivona_breath_last >= 0) {
        ivona_pause_lens[ivona_breath_last+1]=
            gtk_spin_button_get_value_as_int((gpointer)ivona_breath_spin);
    }
    if (ivona_breath_last == n) return;
    ivona_breath_last=n;
    gtk_spin_button_set_value(
        (gpointer)ivona_breath_spin,
        (double)ivona_pause_lens[n+1]);
}
#endif

#ifdef HAVE_MORFOLOGIK

int morfo_get_value(void)
{
	int i;
	for (i=0;i<4;i++) if (gtk_check_menu_item_get_active((gpointer)m_morfologik[i])) return i;
	return -1;
}

void morfo_set_value(int i)
{
	gtk_check_menu_item_set_active((gpointer)m_morfologik[i],TRUE);
}

void *morfo_create_menu(void)
{
	static char *labels[]={
		"Umieść w pamięci dzielonej",
		"Użyj kopii z pamięci dzielonej",
		"Użyj pamięci lokalnej",
		"Nie używaj"};
	int i;
	GSList *group=NULL;
	m_morfmenu=gtk_menu_new();
	m_morfwidget=gtk_menu_item_new_with_label("Morfologik");
	gtk_menu_item_set_submenu(GTK_MENU_ITEM(m_morfwidget), m_morfmenu);
	for (i=0;i<4;i++) {
		m_morfologik[i]=gtk_radio_menu_item_new_with_label(group,labels[i]);
		group=gtk_radio_menu_item_get_group((gpointer)m_morfologik[i]);
		gtk_menu_shell_append(GTK_MENU_SHELL(m_morfmenu),m_morfologik[i]);
	}
	return m_morfwidget;
}

#endif

static void make_main_frame(void)
{
	GtkWidget *frame;
	GtkWidget *lbox;

	GtkWidget *spins;
	GtkWidget *label_tempo,*label_pitch;

	GtkWidget *langframe,*langtb,*leftframe,*riteframe,*mp3tb;

	GtkWidget *tfr1,*tfr2,*tfr3,*label;

	int i,n;

	gtk_window_set_title(GTK_WINDOW(main_window),"Milena - Kreator audioksiążek");
	frame=gtk_vbox_new(0,2);
	gtk_container_add(GTK_CONTAINER(main_window),frame);

// menu
	GtkAccelGroup *accel=gtk_accel_group_new();
	gtk_window_add_accel_group (GTK_WINDOW (main_window), accel);
	menubar=gtk_menu_bar_new();
	filemenu=gtk_menu_new();
	lookmenu=gtk_menu_new();
	GtkWidget *editmenu=gtk_menu_new();
	GtkWidget *searchmenu=gtk_menu_new();
	GtkWidget *dictmenu=gtk_menu_new();
    GtkWidget *epubmenu=gtk_menu_new();
	speechmenu=gtk_menu_new();
	helpmenu=gtk_menu_new();
	accessmenu=gtk_menu_new();

#ifdef USE_SUBMIXER
	videomenu=gtk_menu_new();
#endif


	GtkWidget *m_file = gtk_menu_item_new_with_mnemonic("_Plik");
	m_new = gtk_image_menu_item_new_from_stock(GTK_STOCK_NEW, NULL);
	m_open = gtk_image_menu_item_new_from_stock(GTK_STOCK_OPEN, NULL);
	m_include = gtk_image_menu_item_new_with_label("Wstaw");
	gtk_widget_add_accelerator (m_open, "activate", accel,
                              GDK_o, GDK_CONTROL_MASK, GTK_ACCEL_VISIBLE);
	m_close = gtk_image_menu_item_new_from_stock(GTK_STOCK_CLOSE, NULL);
	gtk_widget_add_accelerator (m_close, "activate", accel,
                              GDK_w, GDK_CONTROL_MASK, GTK_ACCEL_VISIBLE);
	m_save=gtk_image_menu_item_new_from_stock(GTK_STOCK_SAVE, NULL);
	gtk_widget_add_accelerator (m_save, "activate", accel,
                              GDK_s, GDK_CONTROL_MASK, GTK_ACCEL_VISIBLE);
	m_saveas=gtk_image_menu_item_new_from_stock(GTK_STOCK_SAVE_AS, NULL);
	m_savehtml=gtk_image_menu_item_new_with_label("Eksport do HTML");
	m_saveepub=gtk_image_menu_item_new_with_label("Eksport do EPUB");
	m_savefb2=gtk_image_menu_item_new_with_label("Eksport do FB2");
    m_opendic=gtk_image_menu_item_new_with_label("Wczytaj DICT");
        m_edswitch=gtk_image_menu_item_new_with_label("Przełącz edytor");
	gtk_widget_add_accelerator (m_edswitch, "activate", accel,
                              GDK_j, GDK_CONTROL_MASK, GTK_ACCEL_VISIBLE);
	GtkWidget *m_quit=gtk_image_menu_item_new_from_stock(GTK_STOCK_QUIT, NULL);
	gtk_widget_add_accelerator (m_quit, "activate", accel,
                              GDK_q, GDK_CONTROL_MASK, GTK_ACCEL_VISIBLE);
	gtk_menu_item_set_submenu(GTK_MENU_ITEM(m_file), filemenu);
	gtk_menu_shell_append(GTK_MENU_SHELL(filemenu), m_new);
	gtk_menu_shell_append(GTK_MENU_SHELL(filemenu), m_open);
	gtk_menu_shell_append(GTK_MENU_SHELL(filemenu), m_include);
	gtk_menu_shell_append(GTK_MENU_SHELL(filemenu), gtk_separator_menu_item_new());
	gtk_menu_shell_append(GTK_MENU_SHELL(filemenu), m_edswitch);
	gtk_menu_shell_append(GTK_MENU_SHELL(filemenu), gtk_separator_menu_item_new());
	gtk_menu_shell_append(GTK_MENU_SHELL(filemenu), m_save);
	gtk_menu_shell_append(GTK_MENU_SHELL(filemenu), m_saveas);
	gtk_menu_shell_append(GTK_MENU_SHELL(filemenu), m_savehtml);
	gtk_menu_shell_append(GTK_MENU_SHELL(filemenu), m_saveepub);
	gtk_menu_shell_append(GTK_MENU_SHELL(filemenu), m_savefb2);
	gtk_menu_shell_append(GTK_MENU_SHELL(filemenu), gtk_separator_menu_item_new());
	gtk_menu_shell_append(GTK_MENU_SHELL(filemenu), m_opendic);
	gtk_menu_shell_append(GTK_MENU_SHELL(filemenu), gtk_separator_menu_item_new());
	gtk_menu_shell_append(GTK_MENU_SHELL(filemenu), m_close);
	gtk_menu_shell_append(GTK_MENU_SHELL(filemenu), m_quit);
	gtk_menu_shell_append(GTK_MENU_SHELL(menubar), m_file);

	GtkWidget *m_view=gtk_menu_item_new_with_mnemonic("_Wygląd");
	m_tiface=gtk_check_menu_item_new_with_label("Pokaż właściwości");
	m_fullscreen=gtk_check_menu_item_new_with_label("Przełącz pełny ekran");
	gtk_widget_add_accelerator (m_tiface, "activate", accel,
                              GDK_u, GDK_CONTROL_MASK, GTK_ACCEL_VISIBLE);
	gtk_widget_add_accelerator (m_fullscreen, "activate", accel,
                              GDK_F11, 0, GTK_ACCEL_VISIBLE);
	gtk_menu_item_set_submenu(GTK_MENU_ITEM(m_view), lookmenu);
	m_togtool=gtk_check_menu_item_new_with_label("Pokazuj toolbar");
	gtk_menu_shell_append(GTK_MENU_SHELL(lookmenu),m_togtool);
	gtk_menu_shell_append(GTK_MENU_SHELL(lookmenu), m_tiface);
	gtk_menu_shell_append(GTK_MENU_SHELL(lookmenu), m_fullscreen);

	gtk_menu_shell_append(GTK_MENU_SHELL(menubar), m_view);


	m_edit=gtk_menu_item_new_with_mnemonic("_Edycja");
	GtkWidget *m_iso2=gtk_menu_item_new_with_label("Sprowadź do LATIN2");
	GtkWidget *m_fake_1250=gtk_menu_item_new_with_label("Popraw fałszywy CP1250");
	GtkWidget *m_fake_iso2=gtk_menu_item_new_with_label("Popraw fałszywy ISO-2");
    m_normalize_blanks=gtk_menu_item_new_with_label("Normalizuj spacje");
	m_dash=gtk_menu_item_new_with_label("Utwórz DASH");
	m_adash=gtk_menu_item_new_with_label("Zastosuj DASH");
	GtkWidget *m_educa=gtk_menu_item_new_with_label("Wielkie litery");
	GtkWidget *m_edlca=gtk_menu_item_new_with_label("Małe litery");
	GtkWidget *m_edmca=gtk_menu_item_new_with_label("Kapitaliki");
	GtkWidget *m_edsca=gtk_menu_item_new_with_label("Zdania");
	
	m_bold=gtk_menu_item_new_with_label("Epub: Bold");
	m_italic=gtk_menu_item_new_with_label("Epub: Italic");

	GtkWidget *m_casemenu=gtk_menu_new();
	m_case=gtk_menu_item_new_with_label("Wielkość liter");
	gtk_menu_item_set_submenu(GTK_MENU_ITEM(m_case), m_casemenu);

	gtk_menu_shell_append(GTK_MENU_SHELL(m_casemenu),m_educa);
	gtk_menu_shell_append(GTK_MENU_SHELL(m_casemenu),m_edlca);
	gtk_menu_shell_append(GTK_MENU_SHELL(m_casemenu),m_edmca);
	gtk_menu_shell_append(GTK_MENU_SHELL(m_casemenu),m_edsca);
	
	GtkWidget *m_partfb2menu=gtk_menu_new();
	m_partfb2=gtk_menu_item_new_with_label("Wstaw marker FB2");
	gtk_menu_item_set_submenu(GTK_MENU_ITEM(m_partfb2), m_partfb2menu);
	
	m_upart=gtk_menu_item_new_with_label("/part");
	gtk_widget_add_accelerator (m_upart, "activate", accel,
                              //GDK_7, GDK_CONTROL_MASK | GDK_MOD1_MASK, GTK_ACCEL_VISIBLE);
                              GDK_ampersand, GDK_CONTROL_MASK, GTK_ACCEL_VISIBLE);
	m_fpart=gtk_menu_item_new_with_label("part+chapter");
	gtk_widget_add_accelerator (m_fpart, "activate", accel,
                              GDK_7, GDK_CONTROL_MASK, GTK_ACCEL_VISIBLE);
	m_fcite=gtk_menu_item_new_with_label("cite");
	gtk_widget_add_accelerator (m_fcite, "activate", accel,
                              GDK_6, GDK_CONTROL_MASK, GTK_ACCEL_VISIBLE);
	m_fcite1=gtk_menu_item_new_with_label("citation");
	gtk_widget_add_accelerator (m_fcite1, "activate", accel,
                              //GDK_6, GDK_CONTROL_MASK | GDK_MOD1_MASK, GTK_ACCEL_VISIBLE);
                              GDK_asciicircum, GDK_CONTROL_MASK, GTK_ACCEL_VISIBLE);
	m_fepi=gtk_menu_item_new_with_label("epi");
	gtk_widget_add_accelerator (m_fepi, "activate", accel,
                              GDK_5, GDK_CONTROL_MASK, GTK_ACCEL_VISIBLE);
	m_fepi1=gtk_menu_item_new_with_label("epigraph");
	gtk_widget_add_accelerator (m_fepi1, "activate", accel,
                              //GDK_5, GDK_CONTROL_MASK | GDK_MOD1_MASK, GTK_ACCEL_VISIBLE);
                              GDK_percent, GDK_CONTROL_MASK, GTK_ACCEL_VISIBLE);
	m_fauthor=gtk_menu_item_new_with_label("author");
	gtk_widget_add_accelerator (m_fauthor, "activate", accel,
                              GDK_8, GDK_CONTROL_MASK, GTK_ACCEL_VISIBLE);
	m_fpoem=gtk_menu_item_new_with_label("poem title");
	gtk_widget_add_accelerator (m_fpoem, "activate", accel,
                              //GDK_8, GDK_CONTROL_MASK | GDK_MOD1_MASK, GTK_ACCEL_VISIBLE);
                              GDK_asterisk, GDK_CONTROL_MASK, GTK_ACCEL_VISIBLE);
	gtk_menu_shell_append(GTK_MENU_SHELL(m_partfb2menu),m_fepi);
	gtk_menu_shell_append(GTK_MENU_SHELL(m_partfb2menu),m_fepi1);
	gtk_menu_shell_append(GTK_MENU_SHELL(m_partfb2menu),m_fcite);
	gtk_menu_shell_append(GTK_MENU_SHELL(m_partfb2menu),m_fcite1);
	gtk_menu_shell_append(GTK_MENU_SHELL(m_partfb2menu),m_fpart);
	gtk_menu_shell_append(GTK_MENU_SHELL(m_partfb2menu),m_upart);
	gtk_menu_shell_append(GTK_MENU_SHELL(m_partfb2menu),m_fauthor);
	gtk_menu_shell_append(GTK_MENU_SHELL(m_partfb2menu),m_fpoem);
	
	


	gtk_widget_add_accelerator (m_educa, "activate", accel,
                              GDK_1, GDK_CONTROL_MASK, GTK_ACCEL_VISIBLE);
	gtk_widget_add_accelerator (m_edlca, "activate", accel,
                              GDK_2, GDK_CONTROL_MASK, GTK_ACCEL_VISIBLE);
	gtk_widget_add_accelerator (m_edmca, "activate", accel,
                              GDK_3, GDK_CONTROL_MASK, GTK_ACCEL_VISIBLE);
	gtk_widget_add_accelerator (m_edsca, "activate", accel,
                              GDK_4, GDK_CONTROL_MASK, GTK_ACCEL_VISIBLE);
	gtk_widget_add_accelerator (m_bold, "activate", accel,
                              GDK_b, GDK_CONTROL_MASK, GTK_ACCEL_VISIBLE);
	gtk_widget_add_accelerator (m_italic, "activate", accel,
                              GDK_i, GDK_CONTROL_MASK, GTK_ACCEL_VISIBLE);
	m_unfor=gtk_menu_item_new_with_label("Usuń formatowanie");
	m_unjaco=gtk_menu_item_new_with_label("Korekta Jacosub");
    m_autonumba=gtk_menu_item_new_with_label("Autonumeracja rodziałów");
    m_autochapter=gtk_menu_item_new_with_label("Podziel automatycznie");
	GtkWidget *m_deline=gtk_menu_item_new_with_label("Usuń linię");
	gtk_widget_add_accelerator (m_deline, "activate", accel,
                              GDK_y, GDK_CONTROL_MASK, GTK_ACCEL_VISIBLE);
	GtkWidget *m_glueparts=gtk_menu_item_new_with_label("Sklej zaznaczenie");
	gtk_widget_add_accelerator (m_glueparts, "activate", accel,
                              GDK_9, GDK_CONTROL_MASK, GTK_ACCEL_VISIBLE);
    GtkWidget *m_font=gtk_menu_item_new_with_label("Czcionka edytora");
	GtkWidget *m_prefs=gtk_menu_item_new_with_label("Zapisz ustawienia");
	m_edswap=gtk_menu_item_new_with_label("Plik <-> DIC");
	gtk_widget_add_accelerator (m_edswap, "activate", accel,
                              GDK_e, GDK_CONTROL_MASK, GTK_ACCEL_VISIBLE);
	m_gotodash=gtk_menu_item_new_with_label("Plik -> DASH");
	gtk_widget_add_accelerator (m_gotodash, "activate", accel,
                              GDK_e, GDK_CONTROL_MASK | GDK_SHIFT_MASK, GTK_ACCEL_VISIBLE);

	GtkWidget *m_gotoforvo=gtk_menu_item_new_with_label("w forvo.com");
	gtk_widget_add_accelerator(m_gotoforvo, "activate", accel,
                              GDK_m, GDK_CONTROL_MASK, GTK_ACCEL_VISIBLE);
	GtkWidget *m_gotohowjs=gtk_menu_item_new_with_label("w howjsay.com");
	gtk_widget_add_accelerator(m_gotohowjs, "activate", accel,
                              GDK_m, GDK_SHIFT_MASK | GDK_CONTROL_MASK, GTK_ACCEL_VISIBLE);

	gtk_menu_item_set_submenu(GTK_MENU_ITEM(m_edit), editmenu);
	gtk_menu_shell_append(GTK_MENU_SHELL(editmenu), m_iso2);
	gtk_menu_shell_append(GTK_MENU_SHELL(editmenu), m_fake_1250);
	gtk_menu_shell_append(GTK_MENU_SHELL(editmenu), m_fake_iso2);
    gtk_menu_shell_append(GTK_MENU_SHELL(editmenu), m_normalize_blanks);
	gtk_menu_shell_append(GTK_MENU_SHELL(editmenu), gtk_separator_menu_item_new());
	gtk_menu_shell_append(GTK_MENU_SHELL(editmenu),m_dash);
	gtk_menu_shell_append(GTK_MENU_SHELL(editmenu),m_adash);
	gtk_menu_shell_append(GTK_MENU_SHELL(editmenu),m_unfor);
	gtk_menu_shell_append(GTK_MENU_SHELL(editmenu),m_unjaco);
	gtk_menu_shell_append(GTK_MENU_SHELL(editmenu),m_autonumba);
	gtk_menu_shell_append(GTK_MENU_SHELL(editmenu),m_autochapter);
	gtk_menu_shell_append(GTK_MENU_SHELL(editmenu), gtk_separator_menu_item_new());
	gtk_menu_shell_append(GTK_MENU_SHELL(editmenu),m_deline);
	gtk_menu_shell_append(GTK_MENU_SHELL(editmenu),m_glueparts);
	gtk_menu_shell_append(GTK_MENU_SHELL(editmenu), gtk_separator_menu_item_new());
	gtk_menu_shell_append(GTK_MENU_SHELL(editmenu),m_edswap);
	gtk_menu_shell_append(GTK_MENU_SHELL(editmenu),m_gotodash);
	gtk_menu_shell_append(GTK_MENU_SHELL(editmenu), gtk_separator_menu_item_new());
	gtk_menu_shell_append(GTK_MENU_SHELL(editmenu),m_case);
	gtk_menu_shell_append(GTK_MENU_SHELL(editmenu),m_bold);
	gtk_menu_shell_append(GTK_MENU_SHELL(editmenu),m_italic);
	/*gtk_menu_shell_append(GTK_MENU_SHELL(editmenu),m_educa);
	gtk_menu_shell_append(GTK_MENU_SHELL(editmenu),m_edlca);
	gtk_menu_shell_append(GTK_MENU_SHELL(editmenu),m_edmca);
	gtk_menu_shell_append(GTK_MENU_SHELL(editmenu),m_edsca);*/
	gtk_menu_shell_append(GTK_MENU_SHELL(editmenu), gtk_separator_menu_item_new());
	gtk_menu_shell_append(GTK_MENU_SHELL(editmenu),m_font);
	gtk_menu_shell_append(GTK_MENU_SHELL(editmenu), gtk_separator_menu_item_new());
	gtk_menu_shell_append(GTK_MENU_SHELL(editmenu),m_prefs);
	gtk_menu_shell_append(GTK_MENU_SHELL(menubar), m_edit);


	m_menudict=gtk_menu_item_new_with_mnemonic("Sł_ownik");
	gtk_menu_item_set_submenu(GTK_MENU_ITEM(m_menudict), dictmenu);
	m_dict=gtk_menu_item_new_with_label("Utwórz DICT");
	m_dict3=gtk_menu_item_new_with_label("Utwórz pusty DICT");
	m_dict2=gtk_menu_item_new_with_label("Utwórz bazowany DICT");
    m_seltodict=gtk_menu_item_new_with_label("Zaznaczenie do DICT");
    m_dicsuggest=gtk_menu_item_new_with_label("Sugeruj poprawkę w DICT");
    m_gluetodict=gtk_menu_item_new_with_label("Utwórz DICT z nieznanych wyrazów");
    m_ocrtodic[0]=gtk_check_menu_item_new_with_label("Uwzględniaj błędy OCR i popplera");
    m_ocrtodic[1]=gtk_check_menu_item_new_with_label("Uwzględniaj sklejone wyrazy");
    m_ocrtodic[2]=gtk_check_menu_item_new_with_label("Uwzględniaj nieznane wyrazy");
    m_ocrtodic[3]=gtk_check_menu_item_new_with_label("Uwzględniaj podzielone wyrazy");
    m_ungluedict=gtk_menu_item_new_with_label("Zastosuj DICT do korekty");
	gtk_widget_add_accelerator (m_seltodict, "activate", accel,
                              GDK_0, GDK_CONTROL_MASK, GTK_ACCEL_VISIBLE);
	gtk_widget_add_accelerator (m_dicsuggest, "activate", accel,
                              GDK_8, GDK_CONTROL_MASK, GTK_ACCEL_VISIBLE);

	gtk_menu_shell_append(GTK_MENU_SHELL(dictmenu),m_dict);
	gtk_menu_shell_append(GTK_MENU_SHELL(dictmenu),m_dict2);
	gtk_menu_shell_append(GTK_MENU_SHELL(dictmenu),m_dict3);
	gtk_menu_shell_append(GTK_MENU_SHELL(dictmenu), gtk_separator_menu_item_new());
	gtk_menu_shell_append(GTK_MENU_SHELL(dictmenu),m_gluetodict);

	for (i=0;i<4;i++) {
		gtk_menu_shell_append(GTK_MENU_SHELL(dictmenu),m_ocrtodic[i]);
		if (i) gtk_check_menu_item_set_active((gpointer)m_ocrtodic[i],TRUE);
	}
	gtk_menu_shell_append(GTK_MENU_SHELL(dictmenu),m_ungluedict);
	gtk_menu_shell_append(GTK_MENU_SHELL(dictmenu), gtk_separator_menu_item_new());
	gtk_menu_shell_append(GTK_MENU_SHELL(dictmenu),m_seltodict);
	gtk_menu_shell_append(GTK_MENU_SHELL(dictmenu),m_dicsuggest);
	gtk_menu_shell_append(GTK_MENU_SHELL(dictmenu), gtk_separator_menu_item_new());



	GtkWidget *m_wymenu=gtk_menu_new();
	m_wymowa=gtk_menu_item_new_with_label("Znajdź wymowę");
	gtk_menu_item_set_submenu(GTK_MENU_ITEM(m_wymowa), m_wymenu);

	gtk_menu_shell_append(GTK_MENU_SHELL(m_wymenu),m_gotoforvo);
	gtk_menu_shell_append(GTK_MENU_SHELL(m_wymenu),m_gotohowjs);
	gtk_menu_shell_append(GTK_MENU_SHELL(dictmenu),m_wymowa);

#ifdef HAVE_MORFOLOGIK
	gtk_menu_shell_append(GTK_MENU_SHELL(dictmenu), gtk_separator_menu_item_new());
	gtk_menu_shell_append(GTK_MENU_SHELL(dictmenu), morfo_create_menu());
#endif

	gtk_menu_shell_append(GTK_MENU_SHELL(menubar), m_menudict);

	m_search=gtk_menu_item_new_with_mnemonic("_Szukaj");
	GtkWidget *m_find=gtk_menu_item_new_with_label("Znajdź");
	gtk_widget_add_accelerator (m_find, "activate", accel,
                              GDK_f, GDK_CONTROL_MASK, GTK_ACCEL_VISIBLE);
	GtkWidget *m_find_n=gtk_menu_item_new_with_label("Znajdź następny");
	gtk_widget_add_accelerator (m_find_n, "activate", accel,
                              GDK_g, GDK_CONTROL_MASK, GTK_ACCEL_VISIBLE);
	GtkWidget *m_find_p=gtk_menu_item_new_with_label("Znajdź poprzedni");
	gtk_widget_add_accelerator (m_find_p, "activate", accel,
                              GDK_g, GDK_CONTROL_MASK | GDK_SHIFT_MASK, GTK_ACCEL_VISIBLE);
	GtkWidget *m_find_r=gtk_menu_item_new_with_label("Znajdź i zamień");
	gtk_widget_add_accelerator (m_find_r, "activate", accel,
                              GDK_r, GDK_CONTROL_MASK, GTK_ACCEL_VISIBLE);
	m_findcur=gtk_menu_item_new_with_label("Znajdź bieżący");
	gtk_widget_add_accelerator (m_findcur, "activate", accel,
                              GDK_b, GDK_CONTROL_MASK, GTK_ACCEL_VISIBLE);
	m_entity=gtk_menu_item_new_with_label("Znajdź encję");
	gtk_widget_add_accelerator (m_entity, "activate", accel,
                              GDK_n, GDK_CONTROL_MASK, GTK_ACCEL_VISIBLE);
	m_scanner=gtk_menu_item_new_with_label("Znajdź podejrzanego");
	gtk_widget_add_accelerator (m_scanner, "activate", accel,
                              GDK_n, GDK_CONTROL_MASK|GDK_SHIFT_MASK, GTK_ACCEL_VISIBLE);
	m_dialconn=gtk_menu_item_new_with_label("Znajdź połączenie kwestii");
	gtk_widget_add_accelerator (m_dialconn, "activate", accel,
                              GDK_d, GDK_CONTROL_MASK|GDK_SHIFT_MASK, GTK_ACCEL_VISIBLE);
	m_dialcall=gtk_menu_item_new_with_label("Automatycznie połącz kwestie");
	m_paranoid=gtk_check_menu_item_new_with_label("Paranoiczna podejrzliwość");
	m_bezglut=gtk_check_menu_item_new_with_label("Podejrzliwie szukaj sklejek");
	m_showtoc=gtk_menu_item_new_with_label("Spis treści");

	GtkWidget *m_searchlib=gtk_menu_item_new_with_label("Biblioteka wyrażeń");
	GtkWidget *m_gotoline=gtk_menu_item_new_with_label("Skocz do linii");
	gtk_widget_add_accelerator (m_gotoline, "activate", accel,
                              GDK_l, GDK_CONTROL_MASK, GTK_ACCEL_VISIBLE);
	GtkWidget *m_scanread=gtk_menu_item_new_with_label("Wczytaj plik podejrzanych");
	gtk_menu_item_set_submenu(GTK_MENU_ITEM(m_search), searchmenu);
	gtk_menu_shell_append(GTK_MENU_SHELL(searchmenu),m_find);
	gtk_menu_shell_append(GTK_MENU_SHELL(searchmenu),m_find_n);
	gtk_menu_shell_append(GTK_MENU_SHELL(searchmenu),m_find_p);
	gtk_menu_shell_append(GTK_MENU_SHELL(searchmenu),m_find_r);
	gtk_menu_shell_append(GTK_MENU_SHELL(searchmenu), gtk_separator_menu_item_new());
	gtk_menu_shell_append(GTK_MENU_SHELL(searchmenu),m_findcur);
	gtk_menu_shell_append(GTK_MENU_SHELL(searchmenu),m_entity);
	gtk_menu_shell_append(GTK_MENU_SHELL(searchmenu),m_scanner);
	gtk_menu_shell_append(GTK_MENU_SHELL(searchmenu),m_dialconn);
	gtk_menu_shell_append(GTK_MENU_SHELL(searchmenu),m_dialcall);
	gtk_menu_shell_append(GTK_MENU_SHELL(searchmenu), gtk_separator_menu_item_new());
	gtk_menu_shell_append(GTK_MENU_SHELL(searchmenu),m_gotoline);
	gtk_menu_shell_append(GTK_MENU_SHELL(searchmenu),m_showtoc);
	gtk_menu_shell_append(GTK_MENU_SHELL(searchmenu), gtk_separator_menu_item_new());
	gtk_menu_shell_append(GTK_MENU_SHELL(searchmenu),m_paranoid);
	gtk_menu_shell_append(GTK_MENU_SHELL(searchmenu),m_bezglut);
	gtk_menu_shell_append(GTK_MENU_SHELL(searchmenu),m_scanread);
	gtk_menu_shell_append(GTK_MENU_SHELL(searchmenu),m_searchlib);
	gtk_menu_shell_append(GTK_MENU_SHELL(searchmenu), gtk_separator_menu_item_new());
	gtk_menu_shell_append(GTK_MENU_SHELL(menubar), m_search);

	GtkWidget *m_speech=gtk_menu_item_new_with_mnemonic("_Mowa");
	m_play=gtk_image_menu_item_new_from_stock(GTK_STOCK_MEDIA_PLAY, NULL);
	m_stop=gtk_image_menu_item_new_from_stock(GTK_STOCK_MEDIA_STOP, NULL);
	m_sleep=gtk_check_menu_item_new_with_label("Sleep");
    m_mp3=gtk_menu_item_new_with_label(
#ifdef USE_FAAC
					   "Utwórz MP3/AAC"
#else
					   "Utwórz MP3"
#endif
					   );
	m_amr=gtk_menu_item_new_with_label("Utwórz Nokia Audiobook");
	m_use_pulse=gtk_check_menu_item_new_with_label("Wyjście PulseAudio");
	m_pulse_margin=gtk_menu_item_new_with_label("Margines PA (msec)");
	m_voice=gtk_menu_item_new_with_label("Ścieżka do pl1");
	m_stereo=gtk_menu_item_new_with_label("Ustawienia STEREO");
	m_equ1=gtk_menu_item_new_with_label("Equalizer mowy");
	m_equ2=gtk_menu_item_new_with_label("Equalizer nagrań");
    m_sleep2=gtk_menu_item_new_with_label("Ustawienie sleep");
	gtk_menu_item_set_submenu(GTK_MENU_ITEM(m_speech), speechmenu);
	gtk_menu_shell_append(GTK_MENU_SHELL(speechmenu), m_play);
	gtk_widget_add_accelerator (m_play, "activate", accel,
                              GDK_p, GDK_CONTROL_MASK, GTK_ACCEL_VISIBLE);
	gtk_menu_shell_append(GTK_MENU_SHELL(speechmenu), m_stop);
	gtk_widget_add_accelerator (m_stop, "activate", accel,
                              GDK_Escape, 0, GTK_ACCEL_VISIBLE);

	gtk_menu_shell_append(GTK_MENU_SHELL(speechmenu), m_sleep);
	gtk_menu_shell_append(GTK_MENU_SHELL(speechmenu), gtk_separator_menu_item_new());
	gtk_menu_shell_append(GTK_MENU_SHELL(speechmenu), m_mp3);
	gtk_menu_shell_append(GTK_MENU_SHELL(speechmenu), m_amr);
	gtk_menu_shell_append(GTK_MENU_SHELL(speechmenu), gtk_separator_menu_item_new());
#ifdef HAVE_PULSE
	if (enable_pulse()) {
		gtk_menu_shell_append(GTK_MENU_SHELL(speechmenu), m_use_pulse);
		gtk_menu_shell_append(GTK_MENU_SHELL(speechmenu), m_pulse_margin);
	}
#endif
	gtk_menu_shell_append(GTK_MENU_SHELL(speechmenu), m_voice);
	gtk_menu_shell_append(GTK_MENU_SHELL(speechmenu), m_stereo);
	gtk_menu_shell_append(GTK_MENU_SHELL(speechmenu), m_equ1);
	gtk_menu_shell_append(GTK_MENU_SHELL(speechmenu), m_equ2);
	gtk_menu_shell_append(GTK_MENU_SHELL(speechmenu), m_sleep2);
#ifdef USE_RESAMPLER
	m_resample=gtk_menu_item_new_with_label("Ustawienia resamplera");
	gtk_menu_shell_append(GTK_MENU_SHELL(speechmenu), m_resample);
#endif


	gtk_menu_shell_append(GTK_MENU_SHELL(menubar), m_speech);


    GtkWidget *m_meepub=gtk_menu_item_new_with_mnemonic("eP_ub");
	gtk_menu_item_set_submenu(GTK_MENU_ITEM(m_meepub), epubmenu);


    m_epub_dash=gtk_check_menu_item_new_with_label("Krótki myślnik");
    m_epub_just=gtk_check_menu_item_new_with_label("Wyrównanie obustronne");
    m_epub_procover=gtk_check_menu_item_new_with_label("Koryguj okładkę");
    m_epub_format=gtk_check_menu_item_new_with_label("Dopuszczaj tagi formatujące");
    m_fb2_el=gtk_check_menu_item_new_with_label("Pusta linia za akapitem w FB2");
    GtkWidget *m_findcover=gtk_menu_item_new_with_label("Znajdź okładkę w Google");
    GtkWidget *m_findcover2=gtk_menu_item_new_with_label("Znajdź okładkę w Bing");
    GtkWidget *m_insimage=gtk_menu_item_new_with_label("Wstaw obrazek FB2");

    gtk_menu_shell_append(GTK_MENU_SHELL(epubmenu), m_epub_dash);
    gtk_menu_shell_append(GTK_MENU_SHELL(epubmenu), m_epub_just);
    gtk_menu_shell_append(GTK_MENU_SHELL(epubmenu), m_epub_procover);
    gtk_menu_shell_append(GTK_MENU_SHELL(epubmenu), m_epub_format);
    gtk_menu_shell_append(GTK_MENU_SHELL(epubmenu), m_fb2_el);
	gtk_menu_shell_append(GTK_MENU_SHELL(epubmenu), gtk_separator_menu_item_new());
	gtk_menu_shell_append(GTK_MENU_SHELL(epubmenu),m_findcover);
	gtk_menu_shell_append(GTK_MENU_SHELL(epubmenu),m_findcover2);
	gtk_menu_shell_append(GTK_MENU_SHELL(epubmenu),m_insimage);
	gtk_menu_shell_append(GTK_MENU_SHELL(epubmenu),m_partfb2);


	gtk_menu_shell_append(GTK_MENU_SHELL(menubar),m_meepub);

#ifdef USE_SUBMIXER
	m_video=gtk_menu_item_new_with_mnemonic("_Video");
	gtk_menu_item_set_submenu(GTK_MENU_ITEM(m_video), videomenu);
	m_video_open=gtk_menu_item_new_with_label("Otwórz film");
	m_video_caud=gtk_menu_item_new_with_label("Utwórz ścieżkę dźwiękową");
	m_video_cmov=gtk_menu_item_new_with_label("Utwórz film");
	m_video_settings=gtk_menu_item_new_with_label("Ustawienia lektora");
	m_video_submkv=gtk_check_menu_item_new_with_label("Nie kopiuj napisów z MKV");
	m_equ3=gtk_menu_item_new_with_label("Equalizer lektora");
	GtkWidget *m_delmovies=gtk_menu_item_new_with_label("Usuń wszystkie pliki robocze");

	gtk_menu_shell_append(GTK_MENU_SHELL(videomenu), m_video_open);
	gtk_menu_shell_append(GTK_MENU_SHELL(videomenu), m_video_caud);
	gtk_menu_shell_append(GTK_MENU_SHELL(videomenu), m_video_cmov);
	gtk_menu_shell_append(GTK_MENU_SHELL(videomenu), gtk_separator_menu_item_new());
	gtk_menu_shell_append(GTK_MENU_SHELL(videomenu), m_video_submkv);
	gtk_menu_shell_append(GTK_MENU_SHELL(videomenu), m_video_settings);
	gtk_menu_shell_append(GTK_MENU_SHELL(videomenu), m_equ3);
#ifdef HAVE_NAPIPRO
	m_napi_use=gtk_check_menu_item_new_with_label("Automatycznie pobieraj napisy");
	m_napi_autosave=gtk_check_menu_item_new_with_label("Zapisuj napisy po pobraniu");
	gtk_menu_shell_append(GTK_MENU_SHELL(videomenu), gtk_separator_menu_item_new());
	gtk_menu_shell_append(GTK_MENU_SHELL(videomenu), m_napi_use);
	gtk_menu_shell_append(GTK_MENU_SHELL(videomenu), m_napi_autosave);

#endif
	gtk_menu_shell_append(GTK_MENU_SHELL(videomenu), gtk_separator_menu_item_new());
	gtk_menu_shell_append(GTK_MENU_SHELL(videomenu), m_delmovies);

	gtk_menu_shell_append(GTK_MENU_SHELL(menubar),m_video);
#endif

	m_access=gtk_menu_item_new_with_mnemonic("_Dostępność");
	gtk_menu_item_set_submenu(GTK_MENU_ITEM(m_access), accessmenu);

	GtkWidget *m_ac_go_edi=gtk_menu_item_new_with_label("Przejdź do edytora");
	gtk_widget_add_accelerator (m_ac_go_edi, "activate", accel,
                              GDK_h, GDK_CONTROL_MASK, GTK_ACCEL_VISIBLE);
	gtk_menu_shell_append(GTK_MENU_SHELL(accessmenu),m_ac_go_edi);

	GtkWidget *m_ac_go_synth=gtk_menu_item_new_with_label("Przejdź do parametrów syntezy");
	gtk_widget_add_accelerator (m_ac_go_synth, "activate", accel,
                              GDK_k, GDK_CONTROL_MASK, GTK_ACCEL_VISIBLE);
	gtk_menu_shell_append(GTK_MENU_SHELL(accessmenu),m_ac_go_synth);

	GtkWidget *m_ac_go_conv=gtk_menu_item_new_with_label("Przejdź do parametrów konwersji");
	gtk_widget_add_accelerator (m_ac_go_conv, "activate", accel,
                              GDK_k, GDK_CONTROL_MASK | GDK_SHIFT_MASK, GTK_ACCEL_VISIBLE);
	gtk_menu_shell_append(GTK_MENU_SHELL(accessmenu),m_ac_go_conv);

	gtk_menu_shell_append(GTK_MENU_SHELL(accessmenu), gtk_separator_menu_item_new());
#ifdef USE_WEBKIT
	m_browser=gtk_check_menu_item_new_with_label("Użyj systemowej przeglądarki");
	gtk_menu_shell_append(GTK_MENU_SHELL(accessmenu),m_browser);
#endif
	m_ac_search=gtk_check_menu_item_new_with_label("Anonsuj wyniki wyszukiwania");
	gtk_menu_shell_append(GTK_MENU_SHELL(accessmenu),m_ac_search);
#ifndef HAVE_GTK3
	m_ac_atk=gtk_check_menu_item_new_with_label("Korekta błedów ATK");
	gtk_menu_shell_append(GTK_MENU_SHELL(accessmenu),m_ac_atk);
#endif
	m_ac_nop=gtk_check_menu_item_new_with_label("Nie zawijaj wierszy");
	gtk_menu_shell_append(GTK_MENU_SHELL(accessmenu),m_ac_nop);
	
	m_slowtimer=gtk_check_menu_item_new_with_label("Wolne liczniki");
	gtk_menu_shell_append(GTK_MENU_SHELL(accessmenu),m_slowtimer);

	gtk_menu_shell_append(GTK_MENU_SHELL(menubar),m_access);

	m_help=gtk_menu_item_new_with_mnemonic("Pomo_c");
	gtk_menu_item_set_submenu(GTK_MENU_ITEM(m_help), helpmenu);
	GtkWidget *m_hilfe=gtk_image_menu_item_new_from_stock(GTK_STOCK_HELP,NULL);
	gtk_menu_shell_append(GTK_MENU_SHELL(helpmenu), m_hilfe);
	GtkWidget *m_homepage=gtk_menu_item_new_with_label("Strona Mileny");
	gtk_menu_shell_append(GTK_MENU_SHELL(helpmenu), m_homepage);
	GtkWidget *m_about=gtk_image_menu_item_new_from_stock(GTK_STOCK_ABOUT,NULL);
	gtk_menu_shell_append(GTK_MENU_SHELL(helpmenu), m_about);
	gtk_menu_shell_append(GTK_MENU_SHELL(menubar), m_help);

	gtk_box_pack_start(GTK_BOX(frame), menubar, FALSE, FALSE, 3);

	g_signal_connect(G_OBJECT(m_open),"activate",G_CALLBACK(open_file),NULL);
	g_signal_connect(G_OBJECT(m_include),"activate",G_CALLBACK(open_file),(void *)1);
	g_signal_connect(G_OBJECT(m_new),"activate",G_CALLBACK(new_file),NULL);
	g_signal_connect(G_OBJECT(m_save),"activate",G_CALLBACK(save_file),NULL);
	g_signal_connect(G_OBJECT(m_saveas),"activate",G_CALLBACK(save_file),(void *)1);
	g_signal_connect(G_OBJECT(m_savehtml),"activate",G_CALLBACK(save_file_html),NULL);
	g_signal_connect(G_OBJECT(m_saveepub),"activate",G_CALLBACK(save_file_html),(void *)1);
	g_signal_connect(G_OBJECT(m_savefb2),"activate",G_CALLBACK(save_file_fb2),NULL);
	g_signal_connect(G_OBJECT(m_opendic),"activate",G_CALLBACK(open_dic),(void *)1);
	g_signal_connect(G_OBJECT(m_edswitch),"activate",G_CALLBACK(switch_editor),NULL);
	g_signal_connect(G_OBJECT(m_close),"activate",G_CALLBACK(close_current_editor),NULL);
	g_signal_connect(G_OBJECT(m_iso2),"activate",G_CALLBACK(convert_to_iso2),NULL);
	g_signal_connect(G_OBJECT(m_fake_iso2),"activate",G_CALLBACK(editor_fake_latin),(void *)"ISO-8859-2");
	g_signal_connect(G_OBJECT(m_fake_1250),"activate",G_CALLBACK(editor_fake_latin),(void *)"CP1250");
	g_signal_connect(G_OBJECT(m_normalize_blanks),"activate",G_CALLBACK(editorNormalizeText),NULL);
	g_signal_connect(G_OBJECT(m_dash),"activate",G_CALLBACK(make_dash),NULL);
	g_signal_connect(G_OBJECT(m_dict),"activate",G_CALLBACK(make_dict),NULL);
	g_signal_connect(G_OBJECT(m_dict2),"activate",G_CALLBACK(make_dict),(void *)1);
	g_signal_connect(G_OBJECT(m_dict3),"activate",G_CALLBACK(make_dict),(void *)2);
	g_signal_connect(G_OBJECT(m_seltodict),"activate",G_CALLBACK(dict_from_selection),NULL);
	g_signal_connect(G_OBJECT(m_dicsuggest),"activate",G_CALLBACK(dict_suggest_word),NULL);
	g_signal_connect(G_OBJECT(m_gluetodict),"activate",G_CALLBACK(glue_to_dict),NULL);
	g_signal_connect(G_OBJECT(m_ungluedict),"activate",G_CALLBACK(unglue_with_dict),NULL);
	g_signal_connect(G_OBJECT(m_adash),"activate",G_CALLBACK(apply_dash),NULL);
	g_signal_connect(G_OBJECT(m_unjaco),"activate",G_CALLBACK(correct_jacosub),NULL);
	g_signal_connect(G_OBJECT(m_autonumba),"activate",G_CALLBACK(edit_autonumber),NULL);
	g_signal_connect(G_OBJECT(m_autochapter),"activate",G_CALLBACK(edit_autochapter),NULL);
	g_signal_connect(G_OBJECT(m_unfor),"activate",G_CALLBACK(unformat_text),NULL);
	g_signal_connect(G_OBJECT(m_deline),"activate",G_CALLBACK(editor_delete_line),NULL);
	g_signal_connect(G_OBJECT(m_glueparts),"activate",G_CALLBACK(editor_glue_dashspace),NULL);
	g_signal_connect(G_OBJECT(m_edswap),"activate",G_CALLBACK(swap_editors),NULL);
	g_signal_connect(G_OBJECT(m_gotodash),"activate",G_CALLBACK(swap_editors),(void *)1);
	g_signal_connect(G_OBJECT(m_gotoforvo),"activate",G_CALLBACK(gotoforvo),(void *)"forvo");
	g_signal_connect(G_OBJECT(m_gotohowjs),"activate",G_CALLBACK(gotoforvo),(void *)"howjsay");
	g_signal_connect(G_OBJECT(m_font),"activate",G_CALLBACK(ChooseFont),NULL);
	g_signal_connect(G_OBJECT(m_educa),"activate",G_CALLBACK(editor_ulcase),(void *)1);
	g_signal_connect(G_OBJECT(m_edlca),"activate",G_CALLBACK(editor_ulcase),NULL);
	g_signal_connect(G_OBJECT(m_edmca),"activate",G_CALLBACK(editor_ulcase),(void *)2);
	g_signal_connect(G_OBJECT(m_edsca),"activate",G_CALLBACK(editor_ulcase),(void *)3);
	g_signal_connect(G_OBJECT(m_bold),"activate",G_CALLBACK(editor_ulcase),(void *)4);
	g_signal_connect(G_OBJECT(m_italic),"activate",G_CALLBACK(editor_ulcase),(void *)5);
	g_signal_connect(G_OBJECT(m_fpart),"activate",G_CALLBACK(insertPartChapter),NULL);
	g_signal_connect(G_OBJECT(m_upart),"activate",G_CALLBACK(insertPartChapter),(void *)1);
	g_signal_connect(G_OBJECT(m_fepi),"activate",G_CALLBACK(insertPartChapter),(void *)2);
	g_signal_connect(G_OBJECT(m_fepi1),"activate",G_CALLBACK(insertPartChapter),(void *)3);
	g_signal_connect(G_OBJECT(m_fcite),"activate",G_CALLBACK(insertPartChapter),(void *)4);
	g_signal_connect(G_OBJECT(m_fcite1),"activate",G_CALLBACK(insertPartChapter),(void *)5);
	g_signal_connect(G_OBJECT(m_fauthor),"activate",G_CALLBACK(insertPartChapter),(void *)6);
	g_signal_connect(G_OBJECT(m_fpoem),"activate",G_CALLBACK(insertPartChapter),(void *)7);

	g_signal_connect(G_OBJECT(m_find),"activate",G_CALLBACK(StartSearch),NULL);
	g_signal_connect(G_OBJECT(m_find_n),"activate",G_CALLBACK(StartSearch),(void *)1);
	g_signal_connect(G_OBJECT(m_find_p),"activate",G_CALLBACK(StartSearch),(void *)2);
	g_signal_connect(G_OBJECT(m_find_r),"activate",G_CALLBACK(StartReplace),(void *)2);
	g_signal_connect(G_OBJECT(m_findcur),"activate",G_CALLBACK(find_current_word),NULL);
	g_signal_connect(G_OBJECT(m_entity),"activate",G_CALLBACK(find_entity),NULL);
	g_signal_connect(G_OBJECT(m_scanner),"activate",G_CALLBACK(find_scanner_error),NULL);
	g_signal_connect(G_OBJECT(m_dialconn),"activate",G_CALLBACK(find_dialog_connection),NULL);
	g_signal_connect(G_OBJECT(m_dialcall),"activate",G_CALLBACK(autocorrect_dialog_connections),NULL);
	g_signal_connect(G_OBJECT(m_gotoline),"activate",G_CALLBACK(go_to_line),NULL);
	g_signal_connect(G_OBJECT(m_showtoc),"activate",G_CALLBACK(show_toc),NULL);
	g_signal_connect(G_OBJECT(m_scanread),"activate",G_CALLBACK(readScanner),NULL);
	g_signal_connect(G_OBJECT(m_searchlib),"activate",G_CALLBACK(openSearchLibWindow),NULL);
	g_signal_connect(G_OBJECT(m_findcover),"activate",G_CALLBACK(editorFindCover),NULL);
	g_signal_connect(G_OBJECT(m_findcover2),"activate",G_CALLBACK(editorFindCover),(void *)1);
	g_signal_connect(G_OBJECT(m_insimage),"activate",G_CALLBACK(editorInsertImage),NULL);

	g_signal_connect(G_OBJECT(m_play),"activate",G_CALLBACK(speech_play),NULL);
	g_signal_connect(G_OBJECT(m_stop),"activate",G_CALLBACK(speech_stop),NULL);
	g_signal_connect(G_OBJECT(m_mp3),"activate",G_CALLBACK(book_create),NULL);
	g_signal_connect(G_OBJECT(m_amr),"activate",G_CALLBACK(book_create),(void *)1);
	g_signal_connect(G_OBJECT(m_tiface),"toggled",G_CALLBACK(toggle_interface_menu),(void *)1);
	g_signal_connect(G_OBJECT(m_fullscreen),"toggled",G_CALLBACK(toggle_fullscreen),NULL);
	g_signal_connect(G_OBJECT(m_togtool),"toggled",G_CALLBACK(toggle_toolbar),(void *)1);
	g_signal_connect(G_OBJECT(m_use_pulse),"toggled",G_CALLBACK(toggle_audiodevice),NULL);
	g_signal_connect(G_OBJECT(m_pulse_margin),"activate",G_CALLBACK(set_pulse_margin),NULL);
	g_signal_connect(G_OBJECT(m_voice),"activate",G_CALLBACK(set_mbrola_voice),NULL);
	g_signal_connect(G_OBJECT(m_stereo),"activate",G_CALLBACK(stereo_dialog),NULL);
	g_signal_connect(G_OBJECT(m_equ1),"activate",G_CALLBACK(equalizer_dialog),(void *)0);
	g_signal_connect(G_OBJECT(m_equ2),"activate",G_CALLBACK(equalizer_dialog),(void *)1);
	g_signal_connect(G_OBJECT(m_sleep2),"activate",G_CALLBACK(AskSleep),(void *)1);
#ifdef USE_RESAMPLER
	g_signal_connect(G_OBJECT(m_resample),"activate",G_CALLBACK(resampler_dialog),NULL);
#endif
#ifdef USE_SUBMIXER
	g_signal_connect(G_OBJECT(m_video_open),"activate",G_CALLBACK(mplayer_read_movie),NULL);
	g_signal_connect(G_OBJECT(m_video_caud),"activate",G_CALLBACK(mplayer_make_audio),NULL);
	g_signal_connect(G_OBJECT(m_video_cmov),"activate",G_CALLBACK(mplayer_make_video),NULL);
	g_signal_connect(G_OBJECT(m_video_settings),"activate",G_CALLBACK(mplayer_settings),NULL);
	g_signal_connect(G_OBJECT(m_equ3),"activate",G_CALLBACK(equalizer_dialog),(void *)2);
	g_signal_connect(G_OBJECT(m_delmovies),"activate",G_CALLBACK(mplayer_delete_workdir),NULL);
#endif
	g_signal_connect(G_OBJECT(m_quit),"activate",G_CALLBACK(close_main_window),NULL);
	g_signal_connect(G_OBJECT(m_prefs),"activate",G_CALLBACK(save_prefs),NULL);

	g_signal_connect(G_OBJECT(m_ac_go_edi),"activate",G_CALLBACK(acc_go_editor),NULL);
	g_signal_connect(G_OBJECT(m_ac_go_synth),"activate",G_CALLBACK(acc_go_synth),NULL);
	g_signal_connect(G_OBJECT(m_ac_go_conv),"activate",G_CALLBACK(acc_go_conv),NULL);
	g_signal_connect(G_OBJECT(m_ac_nop),"toggled",G_CALLBACK(acc_make_wrap),NULL);
#ifndef HAVE_GTK3
	g_signal_connect(G_OBJECT(m_ac_atk),"toggled",G_CALLBACK(acc_make_wrap),NULL);
#endif
	g_signal_connect(G_OBJECT(m_about),"activate",G_CALLBACK(about_me),NULL);
	g_signal_connect(G_OBJECT(m_hilfe),"activate",G_CALLBACK(help_me),NULL);
	g_signal_connect(G_OBJECT(m_homepage),"activate",G_CALLBACK(show_milena_home),NULL);

	gtk_widget_set_sensitive(m_stop,FALSE);
#ifdef USE_SUBMIXER
	gtk_widget_set_sensitive(m_video_caud,FALSE);
	gtk_widget_set_sensitive(m_video_cmov,FALSE);
#endif
	void speak_and_next()
	{
		if (is_speaking) return;
		start_reading(1);
	}
    void find_current_word_ctl()
    {
        find_current_word(NULL,NULL);
    }
    void prev_editor_ctl()
    {
        switch_editor(NULL,(void *)-1);
    }
	GClosure *gcl=g_cclosure_new(speak_and_next,NULL,NULL);
	gtk_accel_group_connect(accel,GDK_p,GDK_CONTROL_MASK | GDK_SHIFT_MASK,0,gcl);
	gcl=g_cclosure_new(find_current_word_ctl,NULL,NULL);
	gtk_accel_group_connect(accel,GDK_b,GDK_CONTROL_MASK | GDK_SHIFT_MASK,0,gcl);
	gcl=g_cclosure_new(prev_editor_ctl,NULL,NULL);
	gtk_accel_group_connect(accel,GDK_j,GDK_CONTROL_MASK | GDK_SHIFT_MASK,0,gcl);

#ifdef HAVE_PYTHON
	if (!disable_python) initialize_python();
#endif

//toolbar
	toolbar = gtk_toolbar_new();
	gtk_toolbar_set_style(GTK_TOOLBAR(toolbar), GTK_TOOLBAR_BOTH);
	gtk_container_set_border_width(GTK_CONTAINER(toolbar), 1);

	t_new= (gpointer)gtk_tool_button_new_from_stock(GTK_STOCK_NEW);
	gtk_toolbar_insert(GTK_TOOLBAR(toolbar), (gpointer)t_new, -1);

	t_open = (gpointer)gtk_tool_button_new_from_stock(GTK_STOCK_OPEN);
	gtk_toolbar_insert(GTK_TOOLBAR(toolbar), (gpointer)t_open, -1);

	t_save = (gpointer)gtk_tool_button_new_from_stock(GTK_STOCK_SAVE);
	gtk_toolbar_insert(GTK_TOOLBAR(toolbar), (gpointer)t_save, -1);

	t_saveas = (gpointer)gtk_tool_button_new_from_stock(GTK_STOCK_SAVE_AS);
	gtk_toolbar_insert(GTK_TOOLBAR(toolbar), (gpointer)t_saveas, -1);

	t_close = (gpointer)gtk_tool_button_new_from_stock(GTK_STOCK_CLOSE);
	gtk_toolbar_insert(GTK_TOOLBAR(toolbar), (gpointer)t_close, -1);

	gtk_toolbar_insert(GTK_TOOLBAR(toolbar), gtk_separator_tool_item_new(), -1);

	t_play = (gpointer)gtk_tool_button_new_from_stock(GTK_STOCK_MEDIA_PLAY);
	gtk_toolbar_insert(GTK_TOOLBAR(toolbar), (gpointer)t_play, -1);
	t_stop = (gpointer)gtk_tool_button_new_from_stock(GTK_STOCK_MEDIA_STOP);
	gtk_toolbar_insert(GTK_TOOLBAR(toolbar), (gpointer)t_stop, -1);

	gtk_toolbar_insert(GTK_TOOLBAR(toolbar), gtk_separator_tool_item_new(), -1);
	t_prop = (gpointer)gtk_toggle_tool_button_new_from_stock(GTK_STOCK_PROPERTIES);
	gtk_toggle_tool_button_set_active((gpointer)t_prop,TRUE);
	gtk_toolbar_insert(GTK_TOOLBAR(toolbar), (gpointer)t_prop, -1);


	gtk_toolbar_insert(GTK_TOOLBAR(toolbar), gtk_separator_tool_item_new(), -1);

	GtkWidget *t_exit = (gpointer)gtk_tool_button_new_from_stock(GTK_STOCK_QUIT);
	gtk_toolbar_insert(GTK_TOOLBAR(toolbar), (gpointer)t_exit, -1);
	gtk_box_pack_start(GTK_BOX(frame), toolbar, FALSE, FALSE, 1);

	gtk_widget_set_sensitive(t_stop,FALSE);

	g_signal_connect(G_OBJECT(t_open),"clicked",G_CALLBACK(open_file),NULL);
	g_signal_connect(G_OBJECT(t_new),"clicked",G_CALLBACK(new_file),NULL);
	g_signal_connect(G_OBJECT(t_save),"clicked",G_CALLBACK(save_file),NULL);
	g_signal_connect(G_OBJECT(t_saveas),"clicked",G_CALLBACK(save_file),(void *)1);
	g_signal_connect(G_OBJECT(t_close),"clicked",G_CALLBACK(close_current_editor),NULL);
	g_signal_connect(G_OBJECT(t_exit),"clicked",G_CALLBACK(close_main_window),NULL);
	g_signal_connect(G_OBJECT(t_play),"clicked",G_CALLBACK(speech_play),NULL);
	g_signal_connect(G_OBJECT(t_stop),"clicked",G_CALLBACK(speech_stop),NULL);
	g_signal_connect(G_OBJECT(t_prop),"toggled",G_CALLBACK(toggle_iface),NULL);

//frame
	uframe=gtk_hbox_new(0,2);
	gtk_box_pack_start((gpointer)frame,uframe,FALSE,FALSE,0);
	leftframe=gtk_frame_new("Parametry syntezy");
	gtk_box_pack_start(GTK_BOX(uframe),leftframe,FALSE,FALSE,0);
	riteframe=gtk_frame_new("Konwerter MP3/AMR");
	gtk_box_pack_start(GTK_BOX(uframe),riteframe,FALSE,FALSE,0);

	lbox=gtk_vbox_new(0,2);
	gtk_container_add(GTK_CONTAINER(leftframe),lbox);

	//spins=gtk_table_new(2,2,0);
	spins=gtk_hbox_new(0,2);


#ifdef HAVE_IVONA
    if (ivona_enabled) {
        notek_ivona=gtk_notebook_new();
        gtk_notebook_set_scrollable((gpointer)notek_ivona,TRUE);
        gtk_box_pack_start(GTK_BOX(lbox),(gpointer)notek_ivona,TRUE,TRUE,0);
        gtk_notebook_append_page((gpointer)notek_ivona,(gpointer) spins,gtk_label_new("Mbrola"));
    } else
#endif
    {
        gtk_box_pack_start(GTK_BOX(lbox),spins,FALSE,FALSE,0);
    }
	label_tempo=gtk_label_new_with_mnemonic("_Tempo");
	gtk_box_pack_start(GTK_BOX(spins),label_tempo,FALSE,FALSE,0);
	//gtk_table_attach_defaults((gpointer)spins,label_tempo,0,1,0,1);
	spin_tempo=gtk_spin_button_new_with_range(0.35,1.5,0.01);
	gtk_spin_button_set_value((gpointer)spin_tempo,0.9);
	gtk_box_pack_start(GTK_BOX(spins),spin_tempo,FALSE,FALSE,0);
	//gtk_table_attach_defaults((gpointer)spins,spin_tempo,1,2,0,1);
	connect_label(label_tempo,spin_tempo);

	label_pitch=gtk_label_new("Wysokość");
	gtk_box_pack_start(GTK_BOX(spins),label_pitch,FALSE,FALSE,0);
	//gtk_table_attach_defaults((gpointer)spins,label_pitch,0,1,1,2);
	spin_pitch=gtk_spin_button_new_with_range(0.5,1.5,0.01);
	gtk_spin_button_set_value((gpointer)spin_pitch,0.9);
	gtk_box_pack_start(GTK_BOX(spins),spin_pitch,FALSE,FALSE,0);
	//gtk_table_attach_defaults((gpointer)spins,spin_pitch,1,2,1,2);
	connect_label(label_pitch,spin_pitch);

	cb_pro=gtk_check_button_new_with_label("Szybsze czytanie");
	gtk_box_pack_start(GTK_BOX(spins),cb_pro,FALSE,FALSE,0);


	cb_ellip=gtk_check_button_new_with_label("Wielokropek");
	gtk_widget_set_tooltip_text((gpointer)cb_ellip,"Wielokropek urywa zdanie");
	gtk_box_pack_start(GTK_BOX(spins),cb_ellip,FALSE,FALSE,0);

	cb_equ=gtk_check_button_new_with_label("EQS");
	gtk_widget_set_tooltip_text((gpointer)cb_equ,"Włączenie equalizera długości sylab");
	gtk_box_pack_start(GTK_BOX(spins),cb_equ,FALSE,FALSE,0);

#ifdef HAVE_IVONA
    static char *ivona_pause_names[]={
        "Normalny","Dialog","Pre-dial","Post-dial","Długi","Zdanie","Zdanie-d",NULL};

if (ivona_enabled) {
        GtkWidget *ispins=gtk_hbox_new(0,2);
        gtk_notebook_append_page((gpointer)notek_ivona,(gpointer) ispins,gtk_label_new("Ivona"));
        label=gtk_label_new("Prędkość");
        gtk_box_pack_start(GTK_BOX(ispins),label,FALSE,FALSE,0);
        spin_ivona_speed=gtk_spin_button_new_with_range(0.8,2.6,0.05);
        gtk_box_pack_start(GTK_BOX(ispins),spin_ivona_speed,FALSE,FALSE,0);
        connect_label(label,spin_ivona_speed);
        label=gtk_label_new("Pauzy");
        gtk_box_pack_start(GTK_BOX(ispins),label,FALSE,FALSE,0);
        spin_ivona_pauser=gtk_spin_button_new_with_range(0.1,1.0,0.05);
        gtk_box_pack_start(GTK_BOX(ispins),spin_ivona_pauser,FALSE,FALSE,0);
        connect_label(label,spin_ivona_pauser);
        gtk_widget_set_tooltip_text((gpointer)spin_ivona_pauser,"Pauzy po znakach interpunkcyjnych");

        label=gtk_label_new("Głos");
        gtk_box_pack_start(GTK_BOX(ispins),label,FALSE,FALSE,0);

        ivona_voice_combo=gtk_combo_box_new_text();
    //ivona_voicelist=IVOL_voices();
        for (i=n=0;ivona_voicelist[i];i++) {
            gtk_combo_box_append_text((gpointer)ivona_voice_combo,ivona_voicelist[i]);
        }
        gtk_combo_box_set_active((gpointer)ivona_voice_combo,0);
        ivona_voice=ivona_voicelist[0];
        gtk_box_pack_start(GTK_BOX(ispins),ivona_voice_combo,FALSE,FALSE,0);
        connect_label(label,ivona_voice_combo);
        for (i=0;i<=IV_PAU_SENDIAL;i++) ivona_std_pauses[i]=ivona_pause_lens[i];
        label=gtk_label_new("Oddech");
        ivona_breath_combo=gtk_combo_box_new_text();
        for (i=0;ivona_pause_names[i];i++) {
            gtk_combo_box_append_text((gpointer)ivona_breath_combo,ivona_pause_names[i]);
        }
        gtk_combo_box_set_active((gpointer)ivona_breath_combo,0);
        connect_label(label,ivona_breath_combo);
        ivona_breath_spin=gtk_spin_button_new_with_range(50.0,2500.0,10.0);
        gtk_box_pack_start(GTK_BOX(ispins),label,FALSE,FALSE,0);
        gtk_box_pack_start(GTK_BOX(ispins),ivona_breath_combo,FALSE,FALSE,0);
        gtk_box_pack_start(GTK_BOX(ispins),ivona_breath_spin,FALSE,FALSE,0);
        ivona_breath_button=gtk_button_new_with_label("Def");
        gtk_box_pack_start(GTK_BOX(ispins),ivona_breath_button,FALSE,FALSE,0);
        g_signal_connect(G_OBJECT(ivona_breath_button),"clicked",G_CALLBACK(ivona_breath_default),NULL);
        g_signal_connect(G_OBJECT(ivona_breath_combo),"changed",G_CALLBACK(ivona_breath_refresh),NULL);
    }

#endif
	langframe=gtk_frame_new("Języki");
	gtk_box_pack_start(GTK_BOX(lbox),langframe,FALSE,FALSE,0);
	langtb=gtk_table_new(4,2,0);
	gtk_container_add(GTK_CONTAINER(langframe),langtb);
	for (i=0;i<NUM_LANGS;i++) {
		lang_cb[i]=gtk_check_button_new_with_label(lang_names[i]);
		gtk_table_attach_defaults((gpointer)langtb,lang_cb[i],
			i%HALF_LANGS, i%HALF_LANGS+1, i/HALF_LANGS, i/HALF_LANGS+1);
	}

	tfr1=gtk_hbox_new(0,2);
	gtk_box_pack_start(GTK_BOX(lbox),tfr1,FALSE,FALSE,0);

	cb_hours=gtk_check_button_new_with_label("Odczytuj godziny");
	gtk_box_pack_start(GTK_BOX(tfr1),cb_hours,FALSE,FALSE,0);
	gtk_toggle_button_set_active((gpointer)cb_hours,TRUE);

	cb_lector=gtk_check_button_new_with_label("Lektor");
	gtk_box_pack_start(GTK_BOX(tfr1),cb_lector,FALSE,FALSE,0);


//	cb_pro=gtk_check_button_new_with_label("Szybsze czytanie");
//	gtk_box_pack_start(GTK_BOX(tfr1),cb_pro,FALSE,FALSE,0);

	cb_ign=gtk_check_button_new_with_label("Ignoruj akcenty");
	gtk_box_pack_start(GTK_BOX(tfr1),cb_ign,FALSE,FALSE,0);

	cb_spell=gtk_check_button_new_with_label("Czytaj interpunkcję");
	gtk_box_pack_start(GTK_BOX(tfr1),cb_spell,FALSE,FALSE,0);


	tfr2=gtk_hbox_new(0,2);
	gtk_box_pack_start(GTK_BOX(lbox),tfr2,FALSE,FALSE,0);

	cb_dic=gtk_check_button_new_with_label("Plik słownika");
	gtk_box_pack_start(GTK_BOX(tfr2),cb_dic,FALSE,FALSE,0);
	g_signal_connect(G_OBJECT(cb_dic),"toggled",G_CALLBACK(set_dicfile_active),NULL);
	dic_filechooser=gtk_file_chooser_button_new("Wybierz plik słownika",
		GTK_FILE_CHOOSER_ACTION_OPEN);
	gtk_file_chooser_set_local_only((gpointer)dic_filechooser,TRUE);
	gtk_file_chooser_button_set_width_chars((gpointer)dic_filechooser,50);
	gtk_box_pack_start(GTK_BOX(tfr2),dic_filechooser,FALSE,FALSE,0);
	gtk_widget_set_sensitive(dic_filechooser,FALSE);

	atk_object_set_name(gtk_widget_get_accessible(dic_filechooser),"Wybierz plik słownika");

	GtkWidget *themframe=gtk_frame_new("Tematy");
	gtk_box_pack_start(GTK_BOX(lbox),themframe,FALSE,FALSE,0);
	tfr3=gtk_hbox_new(0,2);
	gtk_container_add(GTK_CONTAINER(themframe),tfr3);

//	gtk_box_pack_start(GTK_BOX(lbox),tfr3,FALSE,FALSE,0);

	DIR *dy;
	if ((dy=opendir(milena_GetDataPath()))) {
		struct dirent *de;
		struct miltheme *mt,**mmt;
		while ((de=readdir(dy))) {
			char buf[256],bfn[256];FILE *f;
			int le=strlen(de->d_name);
			if (le<14) continue;
			if (strcmp("_theme.dat",de->d_name+le-10)) continue;
			if (strncmp("pl_",de->d_name,3)) continue;
			strncpy(buf,de->d_name+3,le-13);
			buf[le-13]=0;
			strcpy(bfn,milena_GetDataPath());
			strcat(bfn,"/");
			strcat(bfn,de->d_name);
			mt=g_malloc(sizeof(*mt));
			mt->fname=g_strdup(de->d_name);
			mt->tname=g_strdup(buf);
			mt->cb=gtk_check_button_new_with_label(buf);
			mt->title=NULL;
			f=fopen(bfn,"r");
			if (f) {
				if (fgets(bfn,256,f)) {
					char *c=bfn;
					while (*c && isspace(*c)) c++;
					if (*c && !strncmp(c,"//",2)) {
						c=trim(c+2);
						if (*c) mt->title=to_utf8(c,strlen(c),"ISO-8859-2",0);
					}
				}
				fclose(f);
			}
			if (mt->title) gtk_widget_set_tooltip_text((gpointer)mt->cb,mt->title);
			for (mmt=&themes;*mmt;mmt=&(*mmt)->next) {
				if (strcmp((*mmt)->fname,mt->fname)>0) break;
			}

			mt->next=*mmt;
			*mmt=mt;
		}
		closedir(dy);
		for (mt=themes;mt;mt=mt->next) {
			gtk_box_pack_start(GTK_BOX(tfr3),mt->cb,FALSE,FALSE,0);
		}
	}

//	cb_lector=gtk_check_button_new_with_label("Tryb lektorski");
//	gtk_box_pack_start(GTK_BOX(tfr3),cb_lector,FALSE,FALSE,0);
//	cb_spell=gtk_check_button_new_with_label("Czytaj większość znaków");
//	gtk_box_pack_start(GTK_BOX(tfr3),cb_spell,FALSE,FALSE,0);
	g_signal_connect(G_OBJECT(cb_lector),"toggled",G_CALLBACK(set_lector_active),NULL);
	g_signal_connect(G_OBJECT(cb_spell),"toggled",G_CALLBACK(set_lector_active),NULL);
	/* prawa strona */
	mp3tb=gtk_table_new(3,7,0);
	gtk_container_add(GTK_CONTAINER(riteframe),mp3tb);

	cb_kontrast=gtk_check_button_new_with_label("Kontrast");
	gtk_table_attach_defaults((gpointer)mp3tb,cb_kontrast,0,1,0,1);
	gtk_toggle_button_set_active((gpointer)cb_kontrast,TRUE);

	spin_kontrast=gtk_spin_button_new_with_range(0.3,1.0,0.05);
	atk_object_set_name(gtk_widget_get_accessible(spin_kontrast),"Kontrast");
	atk_object_set_description(gtk_widget_get_accessible(spin_kontrast),"Ustaw poziom efektu kontrast");
	gtk_spin_button_set_value((gpointer)spin_kontrast,0.9);
	gtk_table_attach_defaults((gpointer)mp3tb,spin_kontrast,1,2,0,1);
	g_signal_connect(G_OBJECT(cb_kontrast),"toggled",G_CALLBACK(set_kontrast_active),NULL);

	label=gtk_label_new(
#ifdef USE_FAAC
			    "Format MP3/AAC"
#else
			    "Format MP3"
#endif
			    );
	gtk_table_attach_defaults((gpointer)mp3tb,label,0,1,1,2);
	combo_mp3=combo(0,"MP3 32 kbit","MP3 48 kbit","MP3 64 kbit",
#ifdef USE_FAAC
			"AAC",
#endif
			NULL);
	gtk_table_attach_defaults((gpointer)mp3tb,combo_mp3,1,2,1,2);
	connect_label(label,combo_mp3);
	cb_stereo=gtk_check_button_new_with_label("Stereo");
	gtk_table_attach_defaults((gpointer)mp3tb,cb_stereo,2,3,1,2);

	label=gtk_label_new("Tryb AMR");
	gtk_table_attach_defaults((gpointer)mp3tb,label,0,1,2,3);
	combo_amr=combo(1,"2","3","4","5","6",NULL);
	gtk_table_attach_defaults((gpointer)mp3tb,combo_amr,1,2,2,3);
	connect_label(label,combo_amr);
	cb_dtx=gtk_check_button_new_with_label("DTX");
	gtk_table_attach_defaults((gpointer)mp3tb,cb_dtx,2,3,2,3);

	label=gtk_label_new("Podział na rozdziały");
	gtk_table_attach_defaults((gpointer)mp3tb,label,0,1,3,4);
	combo_split=combo(0,"Wyłączony","Według znaku",NULL);
	gtk_table_attach_defaults((gpointer)mp3tb,combo_split,1,2,3,4);
	connect_label(label,combo_split);
	char_split=gtk_entry_new();
	gtk_entry_set_max_length((gpointer)char_split,1);
	gtk_entry_set_text((gpointer)char_split,"#");
	gtk_widget_set_sensitive(char_split,FALSE);
	gtk_table_attach_defaults((gpointer)mp3tb,char_split,2,3,3,4);
	gtk_entry_set_width_chars((gpointer)char_split,2);
	g_signal_connect(G_OBJECT(combo_split),"changed",G_CALLBACK(set_autonum_active),NULL);
	atk_object_set_name(gtk_widget_get_accessible(char_split),"Znak");
	atk_object_set_description(gtk_widget_get_accessible(char_split),"Znak podziału na rozdziały");

	label=gtk_label_new("Autonumeracja");
	gtk_table_attach_defaults((gpointer)mp3tb,label,0,1,4,5);
	combo_autonum=combo(0,"Brak","Prosta","Z linią tytułową",NULL);
	gtk_table_attach_defaults((gpointer)mp3tb,combo_autonum,1,3,4,5);
	connect_label(label,combo_autonum);
	g_signal_connect(G_OBJECT(combo_autonum),"changed",G_CALLBACK(set_autonum_active),NULL);
	gtk_widget_set_sensitive(combo_autonum,FALSE);

	label=gtk_label_new("Prolog");
	gtk_table_attach_defaults((gpointer)mp3tb,label,0,1,5,6);
	combo_prolog=combo(0,"Brak","PROLOG","Z linią tytułową",NULL);
	gtk_table_attach_defaults((gpointer)mp3tb,combo_prolog,1,3,5,6);
	connect_label(label,combo_prolog);
	gtk_widget_set_sensitive(combo_prolog,FALSE);

	label=gtk_label_new("Epilog");
	gtk_table_attach_defaults((gpointer)mp3tb,label,0,1,6,7);
	combo_epilog=combo(0,"Brak","Ostatni rozdział","EPILOG","Z linią tytułową",NULL);
	gtk_table_attach_defaults((gpointer)mp3tb,combo_epilog,1,3,6,7);
	connect_label(label,combo_epilog);
	gtk_widget_set_sensitive(combo_epilog,FALSE);

	/* tresc */

	notek=gtk_notebook_new();
	gtk_notebook_set_scrollable((gpointer)notek,TRUE);
	gtk_box_pack_start(GTK_BOX(frame),(gpointer)notek,TRUE,TRUE,0);
	g_signal_connect(G_OBJECT(notek),"switch-page",
		G_CALLBACK(menu_active_notek),NULL);
	g_signal_connect(G_OBJECT(notek),"page-added",
		G_CALLBACK(menu_active_notek),NULL);
	g_signal_connect(G_OBJECT(notek),"page-removed",
		G_CALLBACK(menu_active_notek),NULL);
	g_signal_connect(G_OBJECT(notek),"change-current-page",
		G_CALLBACK(menu_active_notek),NULL);
	load_prefs();
	initialize_libre_list();
	CreateEditor(0,NULL,"nowy");
	/* statusbar */

	statusbar=(gpointer)gtk_statusbar_new();
	gtk_box_pack_start(GTK_BOX(frame),statusbar,FALSE,FALSE,0);

	statusbar_line=gtk_statusbar_new();
	gtk_widget_set_size_request(statusbar_line,120,-1);
	gtk_box_pack_end(GTK_BOX(statusbar),statusbar_line,FALSE,FALSE,0);

	statusbar_ove=gtk_statusbar_new();
	gtk_widget_set_size_request(statusbar_ove,80,-1);
	gtk_box_pack_end(GTK_BOX(statusbar),statusbar_ove,FALSE,FALSE,0);

#ifndef HAVE_GTK3
	gtk_statusbar_set_has_resize_grip((gpointer)statusbar,FALSE);
	gtk_statusbar_set_has_resize_grip((gpointer)statusbar_ove,FALSE);
	gtk_statusbar_set_has_resize_grip((gpointer)statusbar_line,FALSE);
#endif


}

int menu_active_notek_cb(void *data)
{
	struct MyGtkEditor *editor;
	int is_main=0,is_dash=0,is_dic=0,has_dash=0,has_dic=0;
	editor=gimma_current_editor();
	if (editor) {
		if (editor->editor_type == MILEDIT_MODE_NORMAL) {
			is_main=1;
			if (editor->dic_editor) has_dic=1;
			if (editor->dash_editor) has_dash=1;
		}
		else if (editor->editor_type == MILEDIT_MODE_DASH) is_dash=1;
		else if (editor->editor_type == MILEDIT_MODE_DIC) is_dic=1;
	}
	gtk_widget_set_sensitive(m_include,is_main);
	gtk_widget_set_sensitive(m_dash,is_main);
	gtk_widget_set_sensitive(m_dict,is_main);
	gtk_widget_set_sensitive(m_dict2,is_main);
	gtk_widget_set_sensitive(m_dict3,is_main);
	gtk_widget_set_sensitive(m_adash,is_main && has_dash);
	gtk_widget_set_sensitive(m_unfor,is_main);
	gtk_widget_set_sensitive(m_unjaco,is_main);
	gtk_widget_set_sensitive(m_autonumba,is_main);
	gtk_widget_set_sensitive(m_normalize_blanks,is_main);
	gtk_widget_set_sensitive(m_autochapter,is_main);
	gtk_widget_set_sensitive(m_case,is_main);
	gtk_widget_set_sensitive(m_partfb2,is_main);
	gtk_widget_set_sensitive(m_bold,is_main);
	gtk_widget_set_sensitive(m_italic,is_main);
	gtk_widget_set_sensitive(m_edswap,(is_main && (has_dic || has_dash)) || is_dic || is_dash);
	gtk_widget_set_sensitive(m_gotodash,(is_main && has_dash) || is_dash);
	gtk_widget_set_sensitive(m_findcur,is_dic || is_dash);
	gtk_widget_set_sensitive(m_entity,is_main);
	gtk_widget_set_sensitive(m_scanner,is_main);
	gtk_widget_set_sensitive(m_seltodict,is_main);
	gtk_widget_set_sensitive(m_gluetodict,is_main);
	gtk_widget_set_sensitive(m_ungluedict,is_main);
	gtk_widget_set_sensitive(m_dicsuggest,is_dic);
	gtk_widget_set_sensitive(m_amr,is_main);
	gtk_widget_set_sensitive(m_mp3,is_main);
	gtk_widget_set_sensitive(m_play,(is_main | is_dic) && !is_speaking);
	gtk_widget_set_sensitive(t_play,(is_main | is_dic) && !is_speaking);
	gtk_widget_set_sensitive(m_edit,is_main | is_dash | is_dic);
	gtk_widget_set_sensitive(m_search,is_main | is_dash | is_dic);
	gtk_widget_set_sensitive(m_close,is_main | is_dash | is_dic);
	gtk_widget_set_sensitive(t_close,is_main | is_dash | is_dic);
	gtk_widget_set_sensitive(m_wymowa,is_dic | is_main);
	gtk_widget_set_sensitive(m_showtoc,is_main && !is_speaking);
	show_position_on_sb(editor);
#ifdef USE_SUBMIXER
	enable_video_menues(is_main,editor);
#endif
    auto_window_title();
	return FALSE;
}
void menu_active_notek(GtkWidget *widget,void *dummy)
{
	g_timeout_add(200,menu_active_notek_cb,NULL);
}



// get_encoding dialog

char *ask_encoding(void)
{
	GtkWidget *dialog=gtk_dialog_new_with_buttons(
		"Wybierz kodowanie",
		(gpointer)main_window,
		GTK_DIALOG_MODAL,
		GTK_STOCK_OK,GTK_RESPONSE_ACCEPT,
		GTK_STOCK_CANCEL,GTK_RESPONSE_REJECT,
		NULL);
	GtkWidget *box=gtk_dialog_get_content_area((gpointer)dialog);
	GtkWidget *codings=combo(1,
		"ISO-8859-1","ISO-8859-2",
		"ISO-8859-13","ISO-8859-16",
		"CP1250","CP1252","CP1257","IBM852",NULL);
	gtk_box_pack_start(GTK_BOX(box),codings,FALSE,FALSE,0);
	gtk_widget_show_all(box);
	int n=gtk_dialog_run((gpointer)dialog);
	char *c=NULL;
	if (n==GTK_RESPONSE_ACCEPT) {
		c=gtk_combo_box_get_active_text((gpointer)codings);
	}
	gtk_widget_destroy(dialog);
	return c;
}

void show_main_window(void)
{
	gtk_window_present(GTK_WINDOW(main_window));
}

void start_busy_cursor(void)
{
	if (!watch_cursor) watch_cursor=gdk_cursor_new(GDK_WATCH);
	GdkDisplay *display=gtk_widget_get_display((gpointer)main_window);
//	gdk_window_set_cursor(GTK_WIDGET(main_window)->window,watch_cursor);
	gdk_display_sync(display);
	yield();
}
void end_busy_cursor(void)
{
	GdkDisplay *display=gtk_widget_get_display((gpointer)main_window);
//	gdk_window_set_cursor(GTK_WIDGET(main_window)->window,NULL);
	gdk_display_flush(display);
}


gchar ** initial_fnames=NULL;
gint auto_load_dic,no_load_dic;


void acc_make_wrap(void)
{
	struct MyGtkEditor *ed;
	for (ed=editors;ed;ed=ed->next) {
		if (!ed->editor_type) {
			gtk_text_view_set_wrap_mode(ed->view,word_wrap);
		}
	}
}

#include "milena_abc.xpm"
gint old_pdf_behav,tesseract_pdf,tesseract_pdfp,
        cuneiform_pdf,cuneiform_pdfp;

gint from_page,to_page;


static void correct_ifn(void)
{
	int i;
	char *cd=NULL,*c;
	for (i=0;initial_fnames[i];i++) {
		if (initial_fnames[i][0]=='/') continue;
		if (!cd) cd=g_get_current_dir();
		c=g_build_filename(cd,initial_fnames[i],NULL);
		g_free(initial_fnames[i]);
		initial_fnames[i]=c;
	}
}


int main(int argc,char *argv[])
{

	int fno;
	gint hide_converter=0;
	extern gint pdf_tollerance, pdf_newpara;
    gint disable_ivona=0;
    gint disable_enchant=0;
	gchar *rtf_mode=NULL,*the_subtitles=NULL;
	gint def_movie=0;
	GOptionContext *optcon=g_option_context_new("[PLIK...]");
	GOptionEntry optries[]={
		{"auto-load-dic",'a',0,G_OPTION_ARG_NONE,&auto_load_dic,"Automatycznie ładuj pliki DIC dla wszyskich typów",NULL},
		{"no-load-dic",'A',0,G_OPTION_ARG_NONE,&no_load_dic,"Nie próbuj ładować plików DIC nawet dla TXT",NULL},
		{"show-converter",'s',0,G_OPTION_ARG_NONE,&hide_converter,"Pokaż panel ustawień po załadowaniu plików",NULL},
		{"plain-pdf",'p',0,G_OPTION_ARG_NONE,&old_pdf_behav,"Użyj pdftotext zamiast pdftohtml",NULL},
		{"pdf-ignore-font",'q',0,G_OPTION_ARG_INT,&pdf_ignore_font_size,"Minimalna wysokość ignorowanej czcionki pdf(60)"},
		{"pdf-ignore-chunk",'Q',0,G_OPTION_ARG_INT,&pdf_ignore_chunk_height,"Minimalna wysokość ignorowanego klocka pdf(100)"},
		{"pdf-autonumber",'P',0,G_OPTION_ARG_NONE,&pdf_autonumber_pages,"Autonumeracja stron pdf"},
		{"pdf-show-heights",'S',0,G_OPTION_ARG_NONE,&pdf_show_heights,"Wypisz statystyki wysokości linii pdf"},
		{"pdf-max-line-height",'j',0,G_OPTION_ARG_INT,&pdf_max_line_height,"Maksymalna wysokość linii"},
		{"pdf-max-paragraph-height",'J',0,G_OPTION_ARG_INT,&pdf_max_paragraph_height,"Maksymalna wysokość kończącej linii akapitu"},
		{"pdf-keep-bold-italic",'K',0,G_OPTION_ARG_NONE,&pdf_keep_boldit,"Pozostaw italik i bold przy odczycie PDF",NULL},
		{"ignore-drm",'D',0,G_OPTION_ARG_NONE,&no_drm,"Ignoruj ustawienia DRM w pdftohtml",NULL},
		{"tesseract",'t',0,G_OPTION_ARG_NONE,&tesseract_pdf,"Użyj tesseracta do odczytu pdf",NULL},
		{"tesseract-pages",'T',0,G_OPTION_ARG_NONE,&tesseract_pdfp,"Użyj tesseracta z numeracją stron do odczytu pdf",NULL},
		{"cuneiform",'c',0,G_OPTION_ARG_NONE,&cuneiform_pdf,"Użyj cuneiform do odczytu pdf",NULL},
		{"cuneiform-pages",'C',0,G_OPTION_ARG_NONE,&cuneiform_pdfp,"Użyj cuneiform z numeracją stron do odczytu pdf",NULL},
		{"from-page",'F',0,G_OPTION_ARG_INT,&from_page,"Od strony (OCR)",NULL},
		{"to-page",'G',0,G_OPTION_ARG_INT,&to_page,"Do strony (OCR)",NULL},
		{"foot-rtf",'f',0,G_OPTION_ARG_STRING,&rtf_mode,"Tryb przypisów RTF (discard, normal, end, inline)",NULL},
		{"debug-level",'d',0,G_OPTION_ARG_INT,&debug_level,"Poziom debugowania",NULL},
#ifdef USE_SUBMIXER
		{"no-audiodump",'N',0,G_OPTION_ARG_NONE,&def_subonly,"Utwórz tylko napisy wczytując plik filmu",NULL},
		{"movie",'m',0,G_OPTION_ARG_NONE,&def_movie,"Podany plik jest filmem",NULL},
		{"subtitles",'n',0,G_OPTION_ARG_STRING,&the_subtitles,"Napisy do filmu",NULL},
#endif
#ifdef HAVE_IVONA
        {"disable-ivona",'i',0,G_OPTION_ARG_NONE,&disable_ivona,"Wyłącz Ivonę",NULL},
#endif
#ifdef HAVE_PYTHON
        {"disable-python",'X',0,G_OPTION_ARG_NONE,&disable_python,"Wyłącz wtyczki Pythona",NULL},
#endif
#ifdef HAVE_ENCHANT
        {"disable-enchant",'E',0,G_OPTION_ARG_NONE,&disable_enchant,"Wyłącz enchanta",NULL},
#endif
		{G_OPTION_REMAINING,'x',0,G_OPTION_ARG_FILENAME_ARRAY,&initial_fnames,"Pliki",NULL},
		{NULL}
	};
#ifdef HAVE_CURL
	initialize_curl();
#endif
	gtk_init(&argc,&argv);
	g_option_context_add_main_entries(optcon,optries,NULL);
	g_option_context_add_group (optcon, gtk_get_option_group (TRUE));
	g_option_context_set_summary(optcon,"Milena AudioBook Creator v"PACKAGE_VERSION);
	GError *error=NULL;
	if (!g_option_context_parse(optcon,&argc,&argv,&error)) {
		g_print("Options parser failed: %s\n",error->message);
		exit(1);
	}
	if (disable_enchant) {
		bad_enchant=3;
	}
#ifdef HAVE_IVONA
    ivona_enabled=0;
    if (!disable_ivona) {
        ivona_voicelist=IVOL_voices();
        if (ivona_voicelist && ivona_voicelist[0]) ivona_enabled=1;
    }
#endif
	if (rtf_mode) {
		setFootNote(rtf_mode);
	}
	if (debug_level <0) debug_level=0;
	main_window=gtk_window_new(GTK_WINDOW_TOPLEVEL);
	make_main_frame();
	GdkPixbuf* pix=gdk_pixbuf_new_from_xpm_data((void *)milena_icon);
	GtkStatusIcon *icon=gtk_status_icon_new_from_pixbuf(pix);
#if GTK_CHECK_VERSION(2,18,0)
	gtk_status_icon_set_title(icon,"Milena ABC");
#endif
	gtk_status_icon_set_tooltip_text(icon,"Milena - Kreator audioksiążek");
	gtk_window_set_icon(GTK_WINDOW(main_window),pix);
	gtk_widget_show_all(main_window);
	toggle_toolbar((gpointer)m_togtool);
	gtk_window_resize((gpointer)main_window,800,560);
	if (initial_fnames && !hide_converter) {
		gtk_toggle_tool_button_set_active((gpointer)t_prop,FALSE);
		gtk_widget_hide(uframe);

	}
	toggle_fullscreen((gpointer)m_fullscreen);
	gtk_check_menu_item_set_active((gpointer)m_tiface,gtk_toggle_tool_button_get_active((gpointer)t_prop));
	g_signal_connect_swapped(G_OBJECT(main_window), "delete-event",
	      G_CALLBACK(close_main_window), NULL);
	g_signal_connect(G_OBJECT(icon), "activate",
	      G_CALLBACK(show_main_window), NULL);
#ifdef HAVE_IVONA
    if (ivona_enabled) {
        gtk_notebook_set_current_page((gpointer)notek_ivona,use_ivona);
    }
#endif
	if (initial_fnames) {
		correct_ifn();
#ifdef USE_SUBMIXER
        if (initial_fnames[0]) {
            if (def_movie || def_subonly || the_subtitles || is_it_movie(initial_fnames[0])) {
                mplayer_read_movie_and_titles(NULL,(void *)initial_fnames[0],the_subtitles);
                goto  skipped1;
            }

        }
#endif
		for(fno=0;initial_fnames[fno];fno++) {
			open_file(NULL,initial_fnames[fno]);
		}
		gtk_notebook_set_current_page((gpointer)notek,0);
        g_timeout_add(1200,(gpointer)init_zakladki_cb,NULL);
	}
skipped1:
	gtk_main();
	return 0;
}

void save_prefs(GtkWidget *widget,void *dummy)
{
	char path[PATH_MAX+1];
	int num;
	sprintf(path,"%s/.milena_abcrc",getenv("HOME"));
	FILE *f=fopen(path,"w");
	if (!f) {
		g_perror(path);
		return;
	}
	if (font_name[0]) {
		fprintf(f,"font=%s\n",font_name);
	}
	fprintf(f,"tempo=%.3f\n",gtk_spin_button_get_value((gpointer)spin_tempo));
	fprintf(f,"pitch=%.3f\n",gtk_spin_button_get_value((gpointer)spin_pitch));
	fprintf(f,"hours=%d\n",gtk_toggle_button_get_active((gpointer)cb_hours)?1:0);
	fprintf(f,"pro=%d\n",gtk_toggle_button_get_active((gpointer)cb_pro)?1:0);
	fprintf(f,"lector=%d\n",gtk_toggle_button_get_active((gpointer)cb_lector)?1:0);
	fprintf(f,"contrast=%d\n",gtk_toggle_button_get_active((gpointer)cb_kontrast)?1:0);
	fprintf(f,"vcontrast=%.3f\n",gtk_spin_button_get_value((gpointer)spin_kontrast));
	fprintf(f,"mp3=%d\n",gtk_combo_box_get_active((gpointer)combo_mp3));
	fprintf(f,"amr=%d\n",gtk_combo_box_get_active((gpointer)combo_amr));
	fprintf(f,"dtx=%d\n",gtk_toggle_button_get_active((gpointer)cb_dtx));
	fprintf(f,"stereo=%d\n",gtk_toggle_button_get_active((gpointer)cb_stereo));
	fprintf(f,"ellipsis=%d\n",gtk_toggle_button_get_active((gpointer)cb_ellip));
	fprintf(f,"eql=%d\n",gtk_toggle_button_get_active((gpointer)cb_equ));
	fprintf(f,"a11y_search=%d\n",gtk_check_menu_item_get_active((gpointer)m_ac_search));
	fprintf(f,"a11y_slow=%d\n",gtk_check_menu_item_get_active((gpointer)m_slowtimer));
#ifndef HAVE_GTK3
	fprintf(f,"a11y_atk=%d\n",gtk_check_menu_item_get_active((gpointer)m_ac_atk));
#endif
	fprintf(f,"a11y_wrap=%d\n",gtk_check_menu_item_get_active((gpointer)m_ac_nop));
	fprintf(f,"pulse_audio=%d\n",gtk_check_menu_item_get_active((gpointer)m_use_pulse));
	fprintf(f,"pulse_margin=%d\n",pulse_margin);
	fprintf(f,"toolbar_on=%d\n",gtk_check_menu_item_get_active((gpointer)m_togtool));
	fprintf(f,"fullscreen_on=%d\n",gtk_check_menu_item_get_active((gpointer)m_fullscreen));
#ifdef USE_WEBKIT
	fprintf(f,"extbrowser=%d\n",gtk_check_menu_item_get_active((gpointer)m_browser));
#endif
	fprintf(f,"stereo_rev=%.3f\n",stereo_rev);
	fprintf(f,"stereo_hfd=%.3f\n",stereo_hfd);
	fprintf(f,"stereo_room=%.3f\n",stereo_room);
	fprintf(f,"stereo_depth=%.3f\n",stereo_depth);
	fprintf(f,"mpart_on=%d\n",multipartial_on);
	fprintf(f,"id3mp3=%d\n",id3_tag_mode);
	fprintf(f,"mpart_val=%.3f\n",multipartial_value);
	fprintf(f,"mpart_mrg=%.3f\n",multipartial_margin);
	fprintf(f,"sleep_on=%d\n",gtk_check_menu_item_get_active((gpointer)m_sleep));
	fprintf(f,"sleep_current=%d\n",sleep_current);
#ifdef USE_RESAMPLER
	fprintf(f,"resam_use=%d\n",use_resampler);
	fprintf(f,"resam_mpx=%.3f\n",computed_resample_factor);
	fprintf(f,"resam_vtl=%.3f\n",vocal_track_length);
#endif
#ifdef USE_SUBMIXER
	fprintf(f,"smix_tempo=%.3f\n",smix_speed);
	fprintf(f,"smix_maxtempo=%.3f\n",smix_maxspeed);
#ifdef HAVE_IVONA
	fprintf(f,"smix_ivo_tempo=%.3f\n",smix_ivona_speed);
	fprintf(f,"smix_ivo_maxtempo=%.3f\n",smix_ivona_maxspeed);
#endif
	fprintf(f,"smix_factor=%.3f\n",smix_volume_factor);
	fprintf(f,"smix_maxvol=%.3f\n",smix_max_origin_vol);
	fprintf(f,"smix_drop=%d\n",smix_droptime);
	fprintf(f,"smix_rise=%d\n",smix_risetime);
	fprintf(f,"smix_mindist=%d\n",smix_mindist);
	fprintf(f,"smix_margin=%d\n",smix_audio_margin);
	fprintf(f,"smix_delay=%d\n",smix_napi_delay);
	fprintf(f,"copy_matroska=%d\n",gtk_check_menu_item_get_active((gpointer)m_video_submkv));
#endif
#ifdef HAVE_MORFOLOGIK
	fprintf(f,"morf_shm=%d\n",morfo_get_value());
#endif
#ifdef HAVE_NAPIPRO
	fprintf(f,"napi_use=%d\n",gtk_check_menu_item_get_active((gpointer)m_napi_use));
	fprintf(f,"napi_autosave=%d\n",gtk_check_menu_item_get_active((gpointer)m_napi_autosave));
#endif
#ifdef HAVE_IVONA
    if (ivona_enabled) {
        check_ivona_enabled();
        fprintf(f,"ivona_speed=%.3f\n",ivona_speed);
        fprintf(f,"ivona_pauser=%.3f\n",ivona_pauser);
        fprintf(f,"ivona_voice=%s\n",ivona_voice);
        fprintf(f,"ivona_default=%d\n",use_ivona);
        for (num=1;num<=IV_PAU_SENDIAL;num++) {
            fprintf(f,"ivona_brt%d=%d\n",num,ivona_pause_lens[num]);
        }
    }
#endif
	for (num=0;num<3;num++) {
		fprintf(f,"equ_lfr%d=%d\n",num,audioparam_table[num].low_freq);
		fprintf(f,"equ_hfr%d=%d\n",num,audioparam_table[num].high_freq);
		fprintf(f,"equ_use%d=%d\n",num,audioparam_table[num].used);
		fprintf(f,"equ_lga%d=%.3f\n",num,audioparam_table[num].lgain);
		fprintf(f,"equ_mga%d=%.3f\n",num,audioparam_table[num].mgain);
		fprintf(f,"equ_hga%d=%.3f\n",num,audioparam_table[num].hgain);
		fprintf(f,"equ_mbr%d=%.3f\n",num,audioparam_table[num].mbrola_gain);
	}
	if (mbrola_voice[0]) fprintf(f,"voice=%s\n",mbrola_voice);
	if (scanner_path[0]) fprintf(f,"scanpath=%s\n",scanner_path);
    if (kindle_path[0]) fprintf(f,"kindlegen=%s\n",kindle_path);
	fprintf(f,"epub_nd=%d\n",gtk_check_menu_item_get_active((gpointer)m_epub_dash));
	fprintf(f,"epub_ju=%d\n",gtk_check_menu_item_get_active((gpointer)m_epub_just));
	fprintf(f,"epub_pr=%d\n",gtk_check_menu_item_get_active((gpointer)m_epub_procover));
	fprintf(f,"epub_fm=%d\n",gtk_check_menu_item_get_active((gpointer)m_epub_format));
	fprintf(f,"fb2_el=%d\n",gtk_check_menu_item_get_active((gpointer)m_fb2_el));
	fclose(f);
	Info("Informacja","Ustawienia zostały zapisane");
}


void load_prefs(void)
{
	char path[PATH_MAX+1];
	char line[1024];
	sprintf(path,"%s/.milena_abcrc",getenv("HOME"));
	FILE *f=fopen(path,"r");
	
	if (!f) {
		FILE *rcf;
		static char *fmtd[]={
			"%s/.local/share/milena.conf",
			"%s/.milena_bookrc",
			"/etc/milena/milena.conf",
			NULL};
		int nch;
		for (nch=0;fmtd[nch];nch++) {
			if (fmtd[nch][0] == '%') {
				sprintf(path,fmtd[nch],getenv("HOME"));
			}
			else {
				strcpy(path,fmtd[nch]);
			}
			rcf=fopen(path,"r");
			if (!rcf) continue;
			while(fgets(line,1024,rcf)) {
				char *val=strchr(line,'=');
				if (!val) continue;
				*val++=0;
				val=trim(val);
				char *cmd=trim(line);
				if (!strcmp(cmd,"tempo")) {
					gtk_spin_button_set_value((gpointer)spin_tempo,my_strtod(val,NULL));
				}
				else if (!strcmp(cmd,"pitch")) {
					gtk_spin_button_set_value((gpointer)spin_pitch,my_strtod(val,NULL));
				}
				else if (!strcmp(cmd,"voice")) {
					strcpy(mbrola_voice,val);
				}
			}
			fclose(rcf);
			if (!nch) nch += 1;
		}
		return;
	}
	while(fgets(line,1024,f)) {
		int num;
		char *val=strchr(line,'=');
		if (!val) continue;
		*val++=0;
		val=trim(val);
		char *cmd=trim(line);
		if (!strcmp(cmd,"font")) {
			strcpy(font_name,val);
			ApplyFont(font_name);
			continue;
		}
		else if (!strcmp(cmd,"tempo")) {
				gtk_spin_button_set_value((gpointer)spin_tempo,my_strtod(val,NULL));
		}
		else if (!strcmp(cmd,"pitch")) {
			gtk_spin_button_set_value((gpointer)spin_pitch,my_strtod(val,NULL));
		}
		else if (!strcmp(cmd,"voice")) {
			strcpy(mbrola_voice,val);
		}
		else if (!strcmp(cmd,"scanpath")) {
			strcpy(scanner_path,val);
		}
		else if (!strcmp(cmd,"kindlegen")) {
			strcpy(kindle_path,val);
		}
		else if (!strcmp(cmd,"hours")) {
			gtk_toggle_button_set_active((gpointer)cb_hours,strtol(val,NULL,10));
		}
		else if (!strcmp(cmd,"pro")) {
			gtk_toggle_button_set_active((gpointer)cb_pro,strtol(val,NULL,10));
		}
		else if (!strcmp(cmd,"lector")) {
			gtk_toggle_button_set_active((gpointer)cb_lector,strtol(val,NULL,10));
		}
		else if (!strcmp(cmd,"dtx")) {
			gtk_toggle_button_set_active((gpointer)cb_dtx,strtol(val,NULL,10));
		}
		else if (!strcmp(cmd,"stereo")) {
			gtk_toggle_button_set_active((gpointer)cb_stereo,strtol(val,NULL,10));
		}
		else if (!strcmp(cmd,"contrast")) {
			gtk_toggle_button_set_active((gpointer)cb_kontrast,strtol(val,NULL,10));
		}
		else if (!strcmp(cmd,"vcontrast")) {
			gtk_spin_button_set_value((gpointer)spin_kontrast,my_strtod(val,NULL));
		}
		else if (!strcmp(cmd,"mp3")) {
			gtk_combo_box_set_active((gpointer)combo_mp3,strtol(val,NULL,10));
		}
		else if (!strcmp(cmd,"amr")) {
			gtk_combo_box_set_active((gpointer)combo_amr,strtol(val,NULL,10));
		}
		else if (!strcmp(cmd,"ellipsis")) {
			gtk_toggle_button_set_active((gpointer)cb_ellip,strtol(val,NULL,10));
		}
		else if (!strcmp(cmd,"eql")) {
			gtk_toggle_button_set_active((gpointer)cb_equ,strtol(val,NULL,10));
		}
		else if (!strcmp(cmd,"toolbar_on")) {
			gtk_check_menu_item_set_active((gpointer)m_togtool,strtol(val,NULL,10));
		}
		else if (!strcmp(cmd,"fullscreen_on")) {
			gtk_check_menu_item_set_active((gpointer)m_fullscreen,strtol(val,NULL,10));
		}
#ifdef USE_WEBKIT
		else if (!strcmp(cmd,"extbrowser")) {
			gtk_check_menu_item_set_active((gpointer)m_browser,strtol(val,NULL,10));
		}
#endif
		else if (!strcmp(cmd,"a11y_search")) {
			gtk_check_menu_item_set_active((gpointer)m_ac_search,strtol(val,NULL,10));
		}
#ifndef HAVE_GTK3
		else if (!strcmp(cmd,"a11y_atk")) {
			gtk_check_menu_item_set_active((gpointer)m_ac_atk,strtol(val,NULL,10));
		}
#endif
		else if (!strcmp(cmd,"a11y_slow")) {
			gtk_check_menu_item_set_active((gpointer)m_slowtimer,strtol(val,NULL,10));
		}
		else if (!strcmp(cmd,"a11y_wrap")) {
			gtk_check_menu_item_set_active((gpointer)m_ac_nop,strtol(val,NULL,10));
		}
		else if (!strcmp(cmd,"pulse_audio")) {
			gtk_check_menu_item_set_active((gpointer)m_use_pulse,strtol(val,NULL,10));
			use_pulse=strtol(val,NULL,10);
		}
		else if (!strcmp(cmd,"pulse_margin")) {
			pulse_margin=strtol(val,NULL,10);
			if (pulse_margin < 0 || pulse_margin > 1000) pulse_margin=300;
		}
		else if (!strcmp(cmd,"stereo_rev")) {
			stereo_rev=my_strtod(val,NULL);
		}
		else if (!strcmp(cmd,"stereo_hfd")) {
			stereo_hfd=my_strtod(val,NULL);
		}
		else if (!strcmp(cmd,"stereo_depth")) {
			stereo_depth=my_strtod(val,NULL);
		}
		else if (!strcmp(cmd,"stereo_room")) {
			stereo_room=my_strtod(val,NULL);
		}
		else if (!strcmp(cmd,"mpart_val")) {
			multipartial_value=my_strtod(val,NULL);
		}
		else if (!strcmp(cmd,"mpart_mrg")) {
			multipartial_margin=my_strtod(val,NULL);
		}
		else if (!strcmp(cmd,"mpart_on")) {
			multipartial_on=strtol(val,NULL,10);
		}
		else if (!strcmp(cmd,"id3mp3")) {
			id3_tag_mode=strtol(val,NULL,10);
		}
#ifdef USE_RESAMPLER
		else if (!strcmp(cmd,"resam_use")) {
			use_resampler=strtol(val,NULL,10);
		}
		else if (!strcmp(cmd,"resam_mpx")) {
			computed_resample_factor=my_strtod(val,NULL);
		}
		else if (!strcmp(cmd,"resam_vtl")) {
			vocal_track_length=my_strtod(val,NULL);
		}
#endif
#ifdef USE_SUBMIXER
        else if (!strcmp(cmd,"smix_tempo")) {
            smix_speed=my_strtod(val,NULL);
        }
        else if (!strcmp(cmd,"smix_maxtempo")) {
            smix_maxspeed=my_strtod(val,NULL);
        }
#ifdef HAVE_IVONA
        else if (!strcmp(cmd,"smix_ivo_tempo")) {
            smix_ivona_speed=my_strtod(val,NULL);
        }
        else if (!strcmp(cmd,"smix_ivo_maxtempo")) {
            smix_ivona_maxspeed=my_strtod(val,NULL);
        }
#endif
        else if (!strcmp(cmd,"smix_drop")) {
            smix_droptime=strtol(val,NULL,10);
        }
        else if (!strcmp(cmd,"smix_rise")) {
            smix_risetime=strtol(val,NULL,10);
        }
        else if (!strcmp(cmd,"smix_mindist")) {
            smix_mindist=strtol(val,NULL,10);
        }
        else if (!strcmp(cmd,"smix_margin")) {
            smix_audio_margin=strtol(val,NULL,10);
        }
        else if (!strcmp(cmd,"smix_delay")) {
            smix_napi_delay=strtol(val,NULL,10);
        }
        else if (!strcmp(cmd,"smix_factor")) {
            smix_volume_factor=my_strtod(val,NULL);
        }
        else if (!strcmp(cmd,"smix_maxvol")) {
            smix_max_origin_vol=my_strtod(val,NULL);
        }
        else if (!strcmp(cmd,"copy_matroska")) {
            gtk_check_menu_item_set_active((gpointer)m_video_submkv,strtol(val,NULL,10));
        }
#endif
#ifdef HAVE_MORFOLOGIK
        else if (!strcmp(cmd,"morf_shm")) {
		morfo_set_value(strtol(val,NULL,10) & 3);
        }
#endif
		else if (!strncmp(cmd,"equ_mbr",7)) {
			num=strtol(cmd+7,NULL,10);
			if (num >= 0 && num <= 2) audioparam_table[num].mbrola_gain=my_strtod(val,NULL);
		}
		else if (!strncmp(cmd,"equ_lfr",7)) {
			num=strtol(cmd+7,NULL,10);
			if (num >= 0 && num <= 2) audioparam_table[num].low_freq=strtol(val,NULL,10);
		}
		else if (!strncmp(cmd,"equ_hfr",7)) {
			num=strtol(cmd+7,NULL,10);
			if (num >= 0 && num <= 2) audioparam_table[num].high_freq=strtol(val,NULL,10);
		}
		else if (!strncmp(cmd,"equ_lga",7)) {
			num=strtol(cmd+7,NULL,10);
			if (num >= 0 && num <= 2) audioparam_table[num].lgain=my_strtod(val,NULL);
		}
		else if (!strncmp(cmd,"equ_mga",7)) {
			num=strtol(cmd+7,NULL,10);
			if (num >= 0 && num <= 2) audioparam_table[num].mgain=my_strtod(val,NULL);
		}
		else if (!strncmp(cmd,"equ_hga",7)) {
			num=strtol(cmd+7,NULL,10);
			if (num >= 0 && num <= 2) audioparam_table[num].hgain=my_strtod(val,NULL);
		}
		else if (!strncmp(cmd,"equ_use",7)) {
			num=strtol(cmd+7,NULL,10);
			if (num >= 0 && num <= 2) audioparam_table[num].used=strtol(val,NULL,10);
		}
		else if (!strcmp(cmd,"sleep_on")) {
			gtk_check_menu_item_set_active((gpointer)m_sleep,strtol(val,NULL,10));
		}
		else if (!strcmp(cmd,"sleep_current")) {
			sleep_current=strtol(val,NULL,10);
		}
#ifdef HAVE_IVONA
        else if (!strcmp(cmd,"ivona_speed")) {
            ivona_speed=my_strtod(val,NULL);
        }
        else if (!strcmp(cmd,"ivona_pauser")) {
            ivona_pauser=my_strtod(val,NULL);
        }
        else if (!strncmp(cmd,"ivona_brt",9)) {
            int n=strtol(cmd+9,NULL,10);
            if (n>0 && n<=IV_PAU_SENDIAL) ivona_pause_lens[n]=strtol(val,NULL,10);
        }
        else if (!strcmp(cmd,"ivona_voice")) {
            int i;
            if (ivona_enabled) {
                for (i=0;ivona_voicelist[i];i++) {
                    if (!strcasecmp(ivona_voicelist[i],val)) {
                        ivona_voice=ivona_voicelist[i];
                        gtk_combo_box_set_active((gpointer)ivona_voice_combo,i);
                        break;
                    }
                }
            }
        }
        else if (!strcmp(cmd,"ivona_default")) {
            use_ivona=strtol(val,NULL,10)?1:0;
        }
#endif
#ifdef HAVE_NAPIPRO
		else if (!strcmp(cmd,"napi_use")) {
			gtk_check_menu_item_set_active((gpointer)m_napi_use,strtol(val,NULL,10));
		}
		else if (!strcmp(cmd,"napi_autosave")) {
			gtk_check_menu_item_set_active((gpointer)m_napi_autosave,strtol(val,NULL,10));
		}
#endif
		else if (!strcmp(cmd,"epub_nd")) {
			gtk_check_menu_item_set_active((gpointer)m_epub_dash,strtol(val,NULL,10));
		}
		else if (!strcmp(cmd,"epub_ju")) {
			gtk_check_menu_item_set_active((gpointer)m_epub_just,strtol(val,NULL,10));
		}
		else if (!strcmp(cmd,"epub_pr")) {
			gtk_check_menu_item_set_active((gpointer)m_epub_procover,strtol(val,NULL,10));
		}
		else if (!strcmp(cmd,"epub_fm")) {
			gtk_check_menu_item_set_active((gpointer)m_epub_format,strtol(val,NULL,10));
		}
		else if (!strcmp(cmd,"fb2_el")) {
			gtk_check_menu_item_set_active((gpointer)m_fb2_el,strtol(val,NULL,10));
		}
	}
	fclose(f);
#ifdef USE_RESAMPLER
	compute_resample_par();
#endif
#ifdef USE_SUBMIXER
	if (smix_speed < 0.1) {
		smix_speed = gtk_spin_button_get_value((gpointer)spin_tempo);
		smix_maxspeed = smix_speed * 0.9;
	}
#endif
	acc_make_wrap();
#ifdef HAVE_IVONA
    if (ivona_enabled) {
        gtk_spin_button_set_value((gpointer)spin_ivona_speed,ivona_speed);
        gtk_spin_button_set_value((gpointer)spin_ivona_pauser,ivona_pauser);
        ivona_breath_last=-1;
        ivona_breath_refresh();
    }
#endif

}

void set_pulse_margin(GtkWidget *widget,void *dummy)
{
	char bs[32];int n;
	sprintf(bs,"%d",pulse_margin);
	n=GetNumberD("Margines PA","msec",bs);
	printf("N=%d\n",n);
	if (n<0) return;
	if (n <= 1000) pulse_margin=n;
	else Error("Błąd","Wartość poza zakresem 0 .. 1000");
}

void set_mbrola_voice(GtkWidget *widget,void *dummy)
{
	GtkWidget *dialog=gtk_file_chooser_dialog_new("Wybierz plik",
		GTK_WINDOW(main_window),GTK_FILE_CHOOSER_ACTION_OPEN,
		GTK_STOCK_CANCEL, GTK_RESPONSE_CANCEL,
		GTK_STOCK_OPEN, GTK_RESPONSE_ACCEPT,
		NULL);
	GtkFileFilter *filter;
	gtk_file_chooser_set_local_only((gpointer)dialog,TRUE);
	gtk_file_chooser_add_filter((gpointer) dialog,
		filter=make_filter("Pliki Mbroli","pl1",NULL));
	gtk_file_chooser_add_filter((gpointer) dialog,
		make_filter("Wszystkie pliki","*",NULL));
	gtk_file_chooser_set_filter((gpointer) dialog,filter);
	if (gtk_dialog_run((gpointer)dialog)==GTK_RESPONSE_ACCEPT){
		strcpy(mbrola_voice,gtk_file_chooser_get_filename((gpointer)dialog));
	}
	gtk_widget_destroy(dialog);

}

int is_slowtimer(void)
{
	return gtk_check_menu_item_get_active((gpointer)m_slowtimer);
}

	
