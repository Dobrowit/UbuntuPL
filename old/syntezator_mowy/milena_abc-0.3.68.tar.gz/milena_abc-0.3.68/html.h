#ifndef MILENA_HTML_H
#define MILENA_HTML_H

extern int html2txt(char *instr,char *outbuf);

#endif