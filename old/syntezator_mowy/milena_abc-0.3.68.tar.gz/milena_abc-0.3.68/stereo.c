/*
 * stereo.c - Milena Audiobook Creator
 * Copyright (C) Bohdan R. Rau 2009 <ethanak@polip.com>
 *
 * Based on:
 * Addressable FIFO buffer Copyright (c) 2007 robs@users.sourceforge.net
 * freeverb by Jezar at Dreampoint.
 * 
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation; either version 2.1 of the License, or (at
 * your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser
 * General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this library; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 */

#include "config.h"
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "gmilena.h"



/* Addressable FIFO buffer */

#ifndef FIFO_SIZE_T
#define FIFO_SIZE_T size_t
#endif

typedef struct {
  char * data;
  size_t allocation;   /* Number of bytes allocated for data. */
  size_t item_size;    /* Size of each item in data */
  size_t begin;        /* Offset of the first byte to read. */
  size_t end;          /* 1 + Offset of the last byte byte to read. */
} fifo_t;

#define FIFO_MIN 0x4000

static void fifo_clear(fifo_t * f)
{
  f->end = f->begin = 0;
}

static void * fifo_reserve(fifo_t * f, FIFO_SIZE_T n)
{
  n *= f->item_size;

  if (f->begin == f->end)
    fifo_clear(f);

  while (1) {
    if (f->end + n <= f->allocation) {
      void *p = f->data + f->end;

      f->end += n;
      return p;
    }
    if (f->begin > FIFO_MIN) {
      memmove(f->data, f->data + f->begin, f->end - f->begin);
      f->end -= f->begin;
      f->begin = 0;
      continue;
    }
    f->allocation += n;
    f->data = realloc(f->data, f->allocation);
  }
}

static void * fifo_write(fifo_t * f, FIFO_SIZE_T n, void const * data)
{
  void * s = fifo_reserve(f, n);
  if (data)
    memcpy(s, data, n * f->item_size);
  return s;
}

#if 0
static void fifo_trim_to(fifo_t * f, FIFO_SIZE_T n)
{
  n *= f->item_size;
  f->end = f->begin + n;
}

static void fifo_trim_by(fifo_t * f, FIFO_SIZE_T n)
{
  n *= f->item_size;
  f->end -= n;
}

static FIFO_SIZE_T fifo_occupancy(fifo_t * f)
{
  return (f->end - f->begin) / f->item_size;
}
#endif
static void * fifo_read(fifo_t * f, FIFO_SIZE_T n, void * data)
{
  char * ret = f->data + f->begin;
  n *= f->item_size;
  if (n > (FIFO_SIZE_T)(f->end - f->begin))
    return NULL;
  if (data)
    memcpy(data, ret, (size_t)n);
  f->begin += n;
  return ret;
}

#define fifo_read_ptr(f) fifo_read(f, (FIFO_SIZE_T)0, NULL)

static void fifo_delete(fifo_t * f)
{
  free(f->data);
}

static void fifo_create(fifo_t * f, FIFO_SIZE_T item_size)
{
  f->item_size = item_size;
  f->allocation = FIFO_MIN;
  f->data = malloc(f->allocation);
  fifo_clear(f);
}

/* freeverb */

#define zalloc(var, n) var = calloc(n, sizeof(*var))
#define filter_create(p, n) (p)->ptr=zalloc((p)->buffer, (p)->size=(size_t)(n))
#define filter_advance(p) if (--(p)->ptr < (p)->buffer) (p)->ptr += (p)->size
#define filter_delete(p) free((p)->buffer)
#define dB_to_linear(x) exp((x) * M_LN10 * 0.05)

typedef struct {
  size_t  size;
  float   * buffer, * ptr;
  float   store;
} filter_t;

static float comb_process(filter_t * p,  /* gcc -O2 will inline this */
    float const * input, float const * feedback, float const * hf_damping)
{
  float output = *p->ptr;
  p->store = output + (p->store - output) * *hf_damping;
  *p->ptr = *input + p->store * *feedback;
  filter_advance(p);
  return output;
}

static float allpass_process(filter_t * p,  /* gcc -O2 will inline this */
    float const * input)
{
  float output = *p->ptr;
  *p->ptr = *input + output * .5;
  filter_advance(p);
  return output - *input;
}

static const size_t /* Filter delay lengths in samples (44100Hz sample-rate) */
  comb_lengths[] = {1116, 1188, 1277, 1356, 1422, 1491, 1557, 1617},
  allpass_lengths[] = {225, 341, 441, 556};
#define stereo_adjust 12

#define array_length(a) (sizeof(a)/sizeof(a[0]))

typedef struct {
  filter_t comb   [array_length(comb_lengths)];
  filter_t allpass[array_length(allpass_lengths)];
} filter_array_t;

static void filter_array_create(filter_array_t * p, double rate,
    double scale, double offset)
{
  size_t i;
  double r = rate * (1 / 44100.); /* Compensate for actual sample-rate */

  for (i = 0; i < array_length(comb_lengths); ++i, offset = -offset)
    filter_create(&p->comb[i], scale * r * (comb_lengths[i] + stereo_adjust * offset) + .5);
  for (i = 0; i < array_length(allpass_lengths); ++i, offset = -offset)
    filter_create(&p->allpass[i], r * (allpass_lengths[i] + stereo_adjust * offset) + .5);
}

static void filter_array_process(filter_array_t * p,
    size_t length, float const * input, float * output,
    float const * feedback, float const * hf_damping, float const * gain)
{
  while (length--) {
    float out = 0, in = *input++;

    size_t i = array_length(comb_lengths) - 1;
    do out += comb_process(p->comb + i, &in, feedback, hf_damping);
    while (i--);

    i = array_length(allpass_lengths) - 1;
    do out = allpass_process(p->allpass + i, &out);
    while (i--);

    *output++ = out * *gain;
  }
}

static void filter_array_delete(filter_array_t * p)
{
  size_t i;

  for (i = 0; i < array_length(allpass_lengths); ++i)
    filter_delete(&p->allpass[i]);
  for (i = 0; i < array_length(comb_lengths); ++i)
    filter_delete(&p->comb[i]);
}

typedef struct {
  float feedback;
  float hf_damping;
  float gain;
  fifo_t input_fifo;
  filter_array_t chan[2];
  float * out[2];
} reverb_t;

static void reverb_create(reverb_t * p, double sample_rate_Hz,
    double wet_gain_dB,
    double room_scale,     /* % */
    double reverberance,   /* % */
    double hf_damping,     /* % */
    double pre_delay_ms,
    double stereo_depth,
    size_t buffer_size,
    float * * out)
{
  size_t i, delay = pre_delay_ms / 1000 * sample_rate_Hz + .5;
  double scale = room_scale / 100 * .9 + .1;
  double depth = stereo_depth / 100;
  double a =  -1 /  log(1 - /**/.3 /**/);           /* Set minimum feedback */
  double b = 100 / (log(1 - /**/.98/**/) * a + 1);  /* Set maximum feedback */

  memset(p, 0, sizeof(*p));
  p->feedback = 1 - exp((reverberance - b) / (a * b));
  p->hf_damping = hf_damping / 100 * .3 + .2;
  p->gain = dB_to_linear(wet_gain_dB) * .015;
  fifo_create(&p->input_fifo, sizeof(float));
  memset(fifo_write(&p->input_fifo, delay, 0), 0, delay * sizeof(float));
  for (i = 0; i <= ceil(depth); ++i) {
    filter_array_create(p->chan + i, sample_rate_Hz, scale, i * depth);
    out[i] = zalloc(p->out[i], buffer_size);
  }
}

static void reverb_process(reverb_t * p, size_t length)
{
  size_t i;
  for (i = 0; i < 2 && p->out[i]; ++i)
    filter_array_process(p->chan + i, length, (float *) fifo_read_ptr(&p->input_fifo), p->out[i], &p->feedback, &p->hf_damping, &p->gain);
  fifo_read(&p->input_fifo, length, NULL);
}

static void reverb_delete(reverb_t * p)
{
  size_t i;
  for (i = 0; i < 2 && p->out[i]; ++i) {
    free(p->out[i]);
    filter_array_delete(p->chan + i);
  }
  fifo_delete(&p->input_fifo);
}

/* Milena wrapper - based on SoX 'reverb.c' by robs@users.sourceforge.net */

typedef struct {
  double reverberance, hf_damping, pre_delay_ms;
  double stereo_depth, wet_gain_dB, room_scale;
  int rate;
  int upsample;
  reverb_t reverb;
  int last_sample;
  float * dry, * wet[2];
} reveffect_t;

void *reverb_init(double rvb,double damp,double room,double depth,int upsample)
{
    reveffect_t *reff;
    reff=calloc(1,sizeof (*reff));
    /* reff fill */
    reff->upsample=upsample?1:0;
#ifdef HAVE_IVONA
    reff->rate=upsample?32000:use_ivona?ivona_getfreq():16000;
#else
    reff->rate=upsample?32000:16000;
#endif
    reff->reverberance=rvb;
    reff->hf_damping=damp;
    reff->room_scale=room;
    reff->stereo_depth=depth;
    reff->pre_delay_ms=0;
    reff->wet_gain_dB=0;

    reverb_create(
        &reff->reverb, reff->rate, reff->wet_gain_dB, reff->room_scale,
        reff->reverberance, reff->hf_damping, reff->pre_delay_ms, reff->stereo_depth,
        16384, reff->wet);
    return (void *)reff;
}

void reverb_flow(void *vreff, const short * ibuf,short * obuf, size_t len)
{
  
    size_t i, w;
    reveffect_t * reff=(reveffect_t *)vreff;
    reff->dry = fifo_write(&reff->reverb.input_fifo, len * (1+reff->upsample), 0);
    
    if (reff->upsample) {
        for (i=0;i<len;i++) {
            reff->dry[2*i]=(float)(*ibuf + reff->last_sample) * 0.25;
            reff->last_sample=*ibuf++;
            reff->dry[2*i+1]=(float)(reff->last_sample) * 0.5;
        }
        len*=2;
    }
    else {
      for (i = 0; i < len; ++i) {
           reff->dry[i] = (float)(*ibuf++) * 0.5;
      }
    }
    reverb_process(&reff->reverb, len);
    for (i = 0; i < len; ++i) for (w = 0; w < 2; ++w) {
        *obuf++ = reff->dry[i] + reff->wet[w][i];
    }
}

void reverb_free(void *vreff)
{
  reverb_delete(&((reveffect_t *)vreff)->reverb);
  free(vreff);
}

