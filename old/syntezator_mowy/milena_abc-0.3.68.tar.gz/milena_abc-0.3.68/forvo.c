/*
 * forvo.c - Milena Audiobook Creator
 * Copyright (C) Bohdan R. Rau 2009-2011 <ethanak@polip.com>
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write see:
 *               <http://www.gnu.org/licenses/>.
 */

#include "config.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "gmilena.h"
#include <ctype.h>

static void howjsay_speak(char *url);

static void append_lc_urlenc(GString *gs,char *str,int iplus)
{
	for (;*str;str++) {
		if (*str==' ' && iplus) {
			g_string_append_c(gs,'+');
		}
		else if (isalnum(*str) || strchr(".-_",*str)) {
			g_string_append_c(gs,*str);
		}
		else {
			g_string_append_printf(gs,"%%%02X",(*str) & 255);
		}
	}
}

void gotoforvo(void *widget, void *data)
{
	char *str=NULL,*str2,*instr;
	GString *forvo;
	GError *err=NULL;
	int ced=get_current_editor();
    if (ced == MILEDIT_MODE_DIC) {
        str=get_diction_line(0,1);
    }
    else if (ced == MILEDIT_MODE_NORMAL) {
        str=get_word_at_cursor(tresc,0);
    }
    if (!str) return;
    str2=g_utf8_strdown(str,-1);
    g_free(str);
    str=str2;
	if (!str) return;
	instr="http://www.forvo.com/search/";
	if (data && !strncmp((char *)data,"ho",2)) {
		instr="http://www.howjsay.com/index.php?wid=1280&flash=y&word=";
	}
	forvo=g_string_new(instr);
	append_lc_urlenc(forvo,str,1);
	g_free(str);
	str=g_string_free(forvo,0);
#ifdef USE_WEBPRON
	if (data && !strncmp(data,"ho",2)) {
		start_busy_cursor();
		howjsay_speak(str);
		end_busy_cursor();
		g_free(str);
		return;
	}

#endif
#ifdef USE_WEBKIT
    browser(str);
#else
	gtk_show_uri(NULL,str,GDK_CURRENT_TIME,&err);
#endif
	g_free(str);
	if (err) {
		Error("Błąd wywołania URL",err->message);
		g_error_free(err);
	}
}




#ifdef USE_WEBPRON


static struct webpron_cache {
	struct webpron_cache *next;
	char *url;
	int length;
	char *body;
} * webpron;

static void howjsay_speak(char *url)
{
	char *body;int len,rc;
	char *swrd,*c;
	GString *fvs;
	struct webpron_cache *wb;
	for (wb=webpron;wb;wb=wb->next) if (!strcmp(wb->url,url)) break;
	if (wb) {
		body=wb->body;
		if (!body) {
			Error("Błąd","Brak słowa w serwisie howjsay.com");
			return;
		}
		len=wb->length;
		goto ohayo;
	}
#ifdef HAVE_CURL
	rc=curl_fetch_file(url,(void **)&body,&len);
#else
	body=wget(url,&len);
	rc=body == NULL;
#endif
	if (rc) {
		Error("Błąd","Pobranie strony się nie udało");
		return;
	}
	if (!body) {
		Error("Błąd","Strona jest pusta");
		return;
	}
	wb=g_malloc(sizeof(*wb));
	wb->next=webpron;
	webpron=wb;
	wb->url=g_strdup(url);
	wb->body=NULL;
	wb->length=0;
	if (strstr(body,"nearest entry is")) swrd=NULL;
	else swrd=strstr(body," flashvars=\"word=");
	if (!swrd) {
		g_free(body);
		Error("Błąd","Brak słowa w serwisie howjsay.com");
		return;
	}
	swrd+=17;
	c=strchr(swrd,'&');if (c) *c=0;
	c=strchr(swrd,'=');if (c) *c=0;
	fvs=g_string_new("http://www.howjsay.com/mp3/");
	append_lc_urlenc(fvs,swrd,0);
	g_string_append(fvs,".mp3");
	g_free(body);
	body=NULL;
	c=g_string_free(fvs,0);
#ifdef HAVE_CURL
	rc=curl_fetch_file(c,(void **)&body,&len);
#else
	body=wget(c,&len);
	rc=body == NULL;
#endif

	g_free(c);
	if (rc) {
		Error("Błąd","Nie mogłem pobrać wymowy z howjsay.com");
		return;
	}
	wb->body=body;
	wb->length=len;
ohayo:
	mp3_play(body,len);
}
#endif

