UWAGA!

Przygotowana biblioteka przeznaczona jest do współpracy z programem milena_abc
i nie musi być przydatna w innych zastosowaniach.

Sposób użycia - patrz plik amrwb.c w źródłach milena_abc.

Przygotowanie bibilioteki:

1) uruchom skrypt get_amr.sh - po jego wykonaniu otrzymasz plik libamrwb_mil.so
2) Skopiuj (z poziomu roota) plik libamrwb_mil.so do katalogu gdzie trzymasz biblioteki
   Prawdopodobnie dobrym miejscem będzie /usr/local/lib lub /usr/local/lib64.
3) Również z poziomu roota wykonaj polecenie ldconfig

ethanak
