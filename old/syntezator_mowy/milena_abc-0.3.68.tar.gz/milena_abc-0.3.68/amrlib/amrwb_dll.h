/*
 *===================================================================
 *  3GPP AMR Wideband Floating-point Speech Codec
 *===================================================================
 */

// http://www.3gpp.org/ftp/Specs/2009-09/Rel-8/26_series/26204-800.zip

#ifndef AMRWB_ENCODER_DLL_H
#define AMRWB_ENCODER_DLL_H 1

typedef void (*AMRWBVF) (FILE *);
typedef int (*AMRWBIV) (void);
typedef void *(*AMRWBPV) (void);
typedef int (*AMRWBSX) (void *,short,short,unsigned char *,short);
typedef void (*AMRWBVP) (void *);

#endif
