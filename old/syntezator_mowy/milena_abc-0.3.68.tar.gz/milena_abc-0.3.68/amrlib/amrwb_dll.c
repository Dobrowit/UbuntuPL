/*
 *===================================================================
 *  3GPP AMR Wideband Floating-point Speech Codec
 *===================================================================
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "typedef.h"
#include "enc_if.h"

void amrwb_dll_magic(FILE *f_serial)
{
#ifndef IF2
#define AMRWB_MAGIC_NUMBER "#!AMR-WB\n"

	fwrite(AMRWB_MAGIC_NUMBER, sizeof(char), strlen(AMRWB_MAGIC_NUMBER), f_serial);
#endif
}

int amrwb_get_sample_count(void)
{
	return L_FRAME16k;
}

int amrwb_get_buffer_size(void)
{
	return NB_SERIAL_MAX;
}
