#!/bin/sh
if [ ! -d c-code ] ; then 
	if [ ! -f 26204-800_ANSI-C_source_code.zip ] ; then
		if [ ! -f 26204-800.zip ] ; then
			wget -O 26204-800.zip http://www.3gpp.org/ftp/Specs/2009-09/Rel-8/26_series/26204-800.zip || exit 1
		fi
		unzip 26204-800.zip
	fi
	unzip 26204-800_ANSI-C_source_code.zip
fi
cp amrwb_dll.c c-code
cp compile.sh c-code
cd c-code
sh ./compile.sh


