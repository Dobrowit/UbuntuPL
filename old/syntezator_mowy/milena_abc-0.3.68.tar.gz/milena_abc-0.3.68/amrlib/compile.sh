#!/bin/sh
CC=gcc
EXT=so
rm *.o 2>/dev/null
$CC -o amrwb_dll.o -O4 -c amrwb_dll.c
$CC -o enc_acelp.o -O4 -c enc_acelp.c
$CC -o enc_dtx.o -O4 -c enc_dtx.c
$CC -o enc_gain.o -O4 -c enc_gain.c
$CC -o enc_if.o -O4 -c enc_if.c
$CC -o enc_lpc.o -O4 -c enc_lpc.c
$CC -o enc_main.o -O4 -c enc_main.c
$CC -o enc_rom.o -O4 -c enc_rom.c
$CC -o enc_util.o -O4 -c enc_util.c
$CC -o if_rom.o -O4 -c if_rom.c
$CC -o ../libamrwb_mil.so -shared -fPIC amrwb_dll.o enc_acelp.o enc_dtx.o \
	enc_gain.o enc_if.o enc_lpc.o enc_main.o enc_rom.o \
	enc_util.o if_rom.o -lm
