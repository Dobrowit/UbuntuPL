#!/bin/sh
rm *.zip *.doc
rm -rf c-code
