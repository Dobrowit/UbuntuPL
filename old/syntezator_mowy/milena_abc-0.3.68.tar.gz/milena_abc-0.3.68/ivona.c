/*
 * ivona.c - Milena Audiobook Creator
 * Copyright (C) Bohdan R. Rau 2009-2011 <ethanak@polip.com>
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write see:
 *               <http://www.gnu.org/licenses/>.
 */

#include "config.h"
#include "gmilena.h"
#include <libivolektor.h>
#include <milena.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

#ifdef USE_SUBMIXER
#include <fcntl.h>
#include <unistd.h>
#include <sys/stat.h>
#endif

static char *ivona_outbuf;
static int ivona_outsize;
static int ivona_speaking;
int ivona_sync_mode;


int ivona_pause_lens[]={0,700,700,1050,1250,1800,350,250};
static int fins[]={1,0,1,1,0,0,0,0};


int milena_ivona_push(int mode,char *inbuf,char **outbuf,int *outsize)
{
    int len;
// korekta: kropka na końcu zdania zamieniana na wykrzyknik
#ifndef HAVE_NEW_IVONIZER
    if (!mode) mode = 3;
#endif
    if (debug_level) fprintf(stderr,"Fraza type: %d\n",mode);
#ifdef HAVE_NEW_IVONIZER
    len=milena_ivonizer_n(mode,inbuf,*outbuf,*outsize,milena);
#else
    len=milena_ivonizer(mode,inbuf,*outbuf,*outsize);
#endif
    if (len) {
        *outsize=len+256;
        if (*outbuf) *outbuf=realloc(*outbuf,*outsize);
        else {
            *outbuf=malloc(*outsize);
            **outbuf=0;
        }
#ifdef HAVE_NEW_IVONIZER
	milena_ivonizer_n(mode,inbuf,*outbuf,*outsize,milena);
#else
	milena_ivonizer(mode,inbuf,*outbuf,*outsize);
#endif
    }
    return 0;
}

static void ivona_phrase(char *phrase,char **outbuf,int *blen)
{
	static char *buf1;
	static int len1;
	int n;
	if (!len1) {
		buf1=malloc(len1=8192);
	}
	if (debug_level) fprintf(stderr,"Fraza in: %s\n",phrase);
	n=milena_Prestresser(milena,phrase,buf1,len1);
	if (n) {
		len1=n+1024;
		buf1=realloc(buf1,len1);
		milena_Prestresser(milena,phrase,buf1,len1);
	}
	if (debug_level) fprintf(stderr,"Prestress : %s\n",buf1);
	n=milena_TranslatePhrase(milena,(unsigned char *)buf1,*outbuf,*blen,0);
	if (n) {
		*blen=n+1024;
		*outbuf=realloc(*outbuf,*blen);
		milena_TranslatePhrase(milena,(unsigned char *)buf1,*outbuf,*blen,0);
	}
	if (debug_level) fprintf(stderr,"Translated : %s\n",buf1);
}


int ivona_prepare_paragraph(char *str)
{
	char *psf=str;
    int pau;
	int partyp=milena_GetParType(milena,&psf,spell_empty);
	static char *phrase_buf,*trans_buf;
	static int phrase_len,trans_len;

    if (!phrase_buf) phrase_buf=malloc(phrase_len=1024);
    if (!trans_buf) trans_buf=malloc(trans_len=1024);
	if (!partyp) {
		if (lastpar>0) lastpar=0;
		return -1;
	}
	if (lastpar<0) {
		pau=0;
	}
	else if (!bookmode) pau=IV_PAU_NORMAL;
	else {
		if (lastpar==0) pau=IV_PAU_LONG;
		else if (lastpar == partyp) {
            pau=(partyp == MILENA_PARTYPE_DIALOG)?IV_PAU_DIALOG:IV_PAU_NORMAL;
        }
		else if (partyp == MILENA_PARTYPE_DIALOG) pau=IV_PAU_PREDIAL;
		else pau=IV_PAU_POSTDIAL;
	}
	lastpar=partyp;
    if (ivona_outbuf) *ivona_outbuf=0;
    for (;;) {
   		int nlen,ptyp;
		nlen=milena_GetPhrase(milena,&psf,phrase_buf,phrase_len,&ptyp);
		if (nlen<0) break;
		if (nlen) {
			phrase_len=nlen+1024;
			phrase_buf=realloc(phrase_buf,phrase_len);
			milena_GetPhrase(milena,&psf,phrase_buf,phrase_len,&ptyp);
		}
        ivona_phrase(phrase_buf,&trans_buf,&trans_len);
        milena_ivona_push(ptyp & 7,trans_buf,&ivona_outbuf,&ivona_outsize);
    }
	//if (debug_level) fprintf(stderr,"Ivona text: %s\n",ivona_outbuf);
    return pau;
}


char *ivona_translate_string(char *iso2str)
{
	static char *phrase_buf,*trans_buf;
	static int phrase_len,trans_len;
    if (!phrase_buf) phrase_buf=malloc(phrase_len=1024);
    if (!trans_buf) trans_buf=malloc(trans_len=1024);
    if (ivona_outbuf) *ivona_outbuf=0;
    for (;;) {
   		int nlen,ptyp;
		nlen=milena_GetPhrase(milena,&iso2str,phrase_buf,phrase_len,&ptyp);
		if (nlen<0) break;
		if (nlen) {
			phrase_len=nlen+1024;
			phrase_buf=realloc(phrase_buf,phrase_len);
			milena_GetPhrase(milena,&iso2str,phrase_buf,phrase_len,&ptyp);
		}
        ivona_phrase(phrase_buf,&trans_buf,&trans_len);
        milena_ivona_push(ptyp & 7,trans_buf,&ivona_outbuf,&ivona_outsize);
    }
    return ivona_outbuf;
}

static struct IVOL_data *ivona;
static char last_ivona_voice[32];

int ivolektor_init(void)
{
    char *err;
    if (ivona) {
        if (!strcmp(last_ivona_voice,ivona_voice)) return 0;
        IVOL_close(ivona);
        ivona=NULL;
    }
    ivona=IVOL_open(ivona_voice,&err);
    if (!ivona) {
        Error("Błąd",err);
        return -1;
    }
    strcpy(last_ivona_voice,ivona_voice);
    return 0;
}

int last_beg,last_len,last_end;
short *last_wav;
int last_pause;
sonicStream sonic;


int ivona_push_wave(short *wave,int len)
{
    int rc=0,n;
    if (len <= 0) return 1;
    if (debug_level > 1) fprintf(stderr,"ivona_push_wave %p/%d\n",wave,len);
    audioparam(wave,len);

    if (!ivona_speaking) {
        if (debug_level > 1) fprintf(stderr,"ivona_push_wave initializing\n");

        if (ivona_speed <0.95 || ivona_speed > 1.05) {
            sonic=sonicCreateStream(ivona->freq,1);
            sonicSetSpeed(sonic,ivona_speed);
            ivona_speaking=2;
        }
        else {
            ivona_speaking=1;
        }
        if (debug_level > 1) fprintf(stderr,"ivona_push_wave started\n");

    }
    rc=0;
    int lmax=4096;
    if (ivona_sync_mode) lmax=32768;
    if (ivona_speaking == 2) {
        short buf[32768];
        int n,inlen;
        while (len > 0 && rc == 0) {
            inlen=16384;
            if (inlen > len) inlen=len;
            //printf("Partial %d\n",inlen);
            sonicWriteShortToStream(sonic,wave,inlen);
            wave+=inlen;
            len-=inlen;
            for (;;) {
                n=sonicReadShortFromStream(sonic,buf,lmax);
                if (n<=0) break;
                if (!rc) {
                    if (currently_making_book) {
                        if (!encode_audio(buf,n)) rc=-1;
                        yield();
                        if(!allow_run) rc=-1;
                    } else {
                        if(!audio_play_sfr(buf,n,ivona->freq)) rc=-1;
                        yield();
                        if(!is_speaking) rc=-1;
                    }
                }
            }
        }
        if (debug_level > 1) fprintf(stderr,"ivona_push_wave returning code %d\n",(rc<0)?0:1);
        if (rc<0) return 0;
        //if (!is_speaking) return 0;
        return 1;
    }
    while (len > 0) {
        n=len;
        if (n>lmax) n=lmax;
        if (currently_making_book) {
            if (!encode_audio(wave,n)) {
                rc=-1;
                break;
            }
            yield();
            if(!allow_run) {
                rc=-1;
                break;
            }
        } else {
            if(!audio_play_sfr(wave,n,ivona->freq)) {
                rc=-1;
                break;
            }
            yield();
            if(!is_speaking) {
                rc=-1;
                break;
            }
        }
        wave+=n;
        len-=n;
    }
    if (debug_level > 1) fprintf(stderr,"ivona_push_wave returning code %d\n",(rc<0)?0:1);
    if (rc<0) return 0;
    return 1;
    //wave_encode(wave,len);
}

int ivona_push_silence(int len)
{
    static short wave[4096],started=0;int rc=0;
    if (debug_level > 1) fprintf(stderr,"ivona_push_silence started\n");
    if (!started) {
        memset(wave,0,4096*sizeof(short));
        started=1;
    }
    while (len > 0) {
        int n=len;
        if (n>4096) n=4096;
        rc=ivona_push_wave(wave,n);
        if (!rc) break;
        len-=n;
    }
    if (debug_level > 1) fprintf(stderr,"ivona_push_silence finished\n");
    return rc;
}

int ivona_push_last_wav(int ofset)
{
    int rc=0,silence;
    if (!last_wav) return 0;
    int samp1=last_end;
    int samp2=ofset;
    if (last_pause < samp1+samp2) {
        samp1=(last_end *last_pause)/(ofset+last_end);
        samp2=(ofset *last_pause)/(ofset+last_end);
        silence=0;
    }
    else {
        silence=last_pause-(samp1+samp2);
    }
    if (!ivona_push_wave(last_wav+(last_len-last_end),samp1)) rc=-1;
    if (rc>=0 && silence>0) {
        if (!ivona_push_silence(silence)) rc=-1;
    }
    if (rc >= 0) rc=ofset-samp2;
    free(last_wav);
    last_wav=NULL;
    return rc;
}


void push_pause(int msec)
{
    if (ivona && ivona->freq) {
        last_pause=(msec * ivona->freq)/1000;
    }
}

int check_ivona_enabled(void)
{
    if (!ivona_enabled) {
        use_ivona=0;
        return 0;
    }
    use_ivona=gtk_notebook_get_current_page((gpointer)notek_ivona);
    ivona_speed=gtk_spin_button_get_value((gpointer)spin_ivona_speed);
	ivona_pauser=gtk_spin_button_get_value((gpointer)spin_ivona_pauser);
    ivona_breath_refresh();
    ivona_voice=ivona_voicelist[gtk_combo_box_get_active((gpointer)ivona_voice_combo)];
    return use_ivona;
}

void ivona_finish(void)
{
    ivona_speaking=0;
    if (sonic) {
        sonicDestroyStream(sonic);
        sonic=NULL;
    }
}

struct ivona_node {
    struct ivona_node *succ,*pred;
} ivona_head,ivona_tail;

struct ivona_thr_sentence {
    struct ivona_node node;
    char *ivotxt;
    GtkTextIter sr,ed;
    int pause;
    int ptype;
    int wave_got; /* przetworzone */
    char *error;
    int breath; /* przed falą */
    int length; /* fala */
    int rest;   /* za falą */
    short *wave;
};

static int ivona_ThreadStatus;
static GThread *ivona_Thread;
static GMutex *ivona_MainMutex;
int ivona_thread_play=0;
int ivona_thread_exit=0;

static int ivona_CountThreadQueue(int *isok)
{
    struct ivona_node *ithr;
    int n,i;
    g_mutex_lock(ivona_MainMutex);
    for (n=i=0,ithr=ivona_head.pred;ithr->pred;ithr=ithr->pred) {
        if (((struct ivona_thr_sentence *)ithr)->wave_got) i++;
        n++;
    }
    g_mutex_unlock(ivona_MainMutex);
    if (isok) *isok=i;
    return n;
}

static void ivona_PushThreadSent(char *ivotxt,GtkTextIter *sr,GtkTextIter *ed,int pause,int pmode)
{
    struct ivona_thr_sentence *ithr;
    ithr=malloc(sizeof(*ithr));
    memset(ithr,0,sizeof(*ithr));
    ithr->ivotxt=ivotxt;
    ithr->sr=*sr;
    ithr->ed=*ed;
    ithr->pause=pause;
    ithr->ptype=pmode;
    g_mutex_lock(ivona_MainMutex);
    ithr->node.succ=ivona_tail.succ;
    ithr->node.succ->pred=(gpointer) ithr;
    ithr->node.pred=&ivona_tail;
    ivona_tail.succ=(gpointer) ithr;
    g_mutex_unlock(ivona_MainMutex);
}

static struct ivona_thr_sentence *ivona_PullThreadSent(void)
{
    struct ivona_thr_sentence *ithr=NULL;
    g_mutex_lock(ivona_MainMutex);
    ithr=(gpointer) ivona_head.pred;
    if (!ithr->node.pred || !ithr->wave_got) {
        /* koniec listy albo nie przetworzone */
        g_mutex_unlock(ivona_MainMutex);
        return NULL;
    }

    ivona_head.pred=ithr->node.pred;
    ivona_head.pred->succ=&ivona_head;
    g_mutex_unlock(ivona_MainMutex);
    return ithr;
}

short *ivona_trim_wave(short *wave,int *len,int *offs,int *rest)
{
    *offs=*rest=0;
    if (ivona_pauser >= 0.96 && ivona_pauser < 1.04) {
        IVOL_trimWave(ivona,wave,*len,offs,rest);
    }
    else
    {
        short *wav2=IVOL_Repauser(ivona,wave,len,ivona_pauser,offs,rest);
        if (wav2) {
            free(wave);
            wave=wav2;
        }
    }
    return wave;
}

gpointer ivona_ThreadFunc(gpointer dummy)
{
    struct ivona_thr_sentence *it,*it1;
    for (;;) {
        g_mutex_lock(ivona_MainMutex);
        if (ivona_thread_exit) break;
        if (!ivona_thread_play) {
            ivona_ThreadStatus=0; /* thread nic nie robi */
            g_mutex_unlock(ivona_MainMutex);
            g_thread_yield();
            continue;
        }

        for (it=(gpointer)ivona_head.pred;it && it->node.pred;it=(gpointer)it->node.pred) {
            if (!it->wave_got) break;
        }
        if (it->node.pred) {
            ivona_ThreadStatus=1; /* thread szuka */
        }
        else {
            ivona_ThreadStatus=0;
        }

        g_mutex_unlock(ivona_MainMutex);
        if (!it->node.pred) {
            //g_thread_yield();
            usleep(100000);
            continue; /* nic nie robimy */
        }
        //printf("===== Coś trzeba zrobić...\n");
        int len,offs,rest;short *wave;char *err=NULL;
	if (debug_level) fprintf(stderr,"Ivona string: %s\n",it->ivotxt);
        wave=IVOL_getWave(ivona,it->ivotxt,&len,&err);
        if (wave) {
            wave=ivona_trim_wave(wave,&len,&offs,&rest);
        }
        g_mutex_lock(ivona_MainMutex);
        for (it1=(gpointer)ivona_head.pred;it1 && it1->node.pred;it1=(gpointer)it1->node.pred) {
            if (it1 == it) break;
        }

        if (it1 != it) {
            if (wave) free(wave);
            if (err) free(err);
        }
        else {
            it->wave=wave;
            it->length=len;
            it->breath=offs;
            it->rest=rest;
            it->error=err;
            it->wave_got=1;
        }
        //printf("===== Got from Ivona\n");
        g_mutex_unlock(ivona_MainMutex);
        g_thread_yield();
    }
    return NULL;
}

void ivona_StartThreads(void)
{
    if (ivona_Thread) return;
#if !GLIB_CHECK_VERSION(2,32,0)
    g_thread_init(NULL);
#endif
    ivona_MainMutex=g_mutex_new();
    ivona_head.pred = &ivona_tail;
    ivona_tail.succ = &ivona_head;
    g_mutex_lock(ivona_MainMutex);
    ivona_Thread=g_thread_create(ivona_ThreadFunc,NULL,TRUE,NULL);
}


static void ivona_clean_sentence_list(void)
{
    /* called from ivona thread */
    struct ivona_thr_sentence *ithr;
    ivona_thread_play=0;
    g_mutex_lock(ivona_MainMutex);
    for (;;) {
        ithr=(gpointer)ivona_head.pred;
        if (!ithr) {
            //fprintf(stderr,"ITHR is NULL\n");
            break;
        }
        //printf("%p %p %p->%p\n",&ivona_head,&ivona_tail,ithr,ithr->node.pred);
        ithr->node.succ=&ivona_head;
        if (!ithr->node.pred) break;
        ivona_head.pred=ithr->node.pred;
        if (ithr->wave) free(ithr->wave);
        if (ithr->ivotxt) free(ithr->ivotxt);
        if (ithr->error) free(ithr->error);
        free(ithr);
    }
    //fprintf(stderr,"IHTR OK\n");
    //fprintf(stderr,"%p %p %p\n",&ivona_head,ivona_head.pred,ivona_head.succ);
    //fprintf(stderr,"%p %p %p\n",&ivona_tail,ivona_tail.pred,ivona_tail.succ);

    g_mutex_unlock(ivona_MainMutex);
}


void poczytaj_mi_ivonko(int fast_start)
{
	GtkTextIter linebeg,sr,ed;
	char *curline;
	char *str,*c;
	int partype;
	int do_rewind=1,pau,ptyp;
	char *phr;
	static char *sentence_buf;
	static int sentence_len;
	int chaptermark;
	int prebuffer = fast_start?1:3;
    ivona_sync_mode=0;
	if (!sentence_buf) sentence_buf=malloc(sentence_len=1024);

    char *get_sentence(GtkTextIter *iter_start,GtkTextIter *iter_end)
    {
        char *outbuf=NULL;int outlen;
        char *spoken=str;
        while (*str) {
            phr=get_phrase_uni(&str,&ptyp);
            if (!phr) {
                break;
            }
            ivona_phrase(phr,&sentence_buf,&sentence_len);
            free(phr);
            milena_ivona_push(ptyp & 7,sentence_buf,&outbuf,&outlen);
            if (fins[ptyp & 7]) break;
        }
        if (outbuf) {
			*iter_start=linebeg;
			gtk_text_iter_forward_chars(iter_start,g_utf8_strlen(curline,spoken-curline));
			*iter_end=*iter_start;
			gtk_text_iter_forward_chars(iter_end,g_utf8_strlen(spoken,str-spoken));
        }
        return outbuf;
    }

    int fetch_sentence(void)
    {
        char *s=NULL;
        for (;;) {
            if (!curline) {
                curline=get_current_line(do_rewind,&linebeg);
                if (!curline) return 0;
                char *c=strchr(curline,'\n');
                if (c) *c=0;
                do_rewind=0;
                str=curline;
                str=curline;
                partype=uniParType(&str,chaptermark);
                if (!partype) {
                    if (lastpar>0) lastpar=0;
                    g_free(curline);
                    curline=NULL;
                    continue;
                }
                if (lastpar<0) {
                    pau=0;
                }
                else if (!bookmode) pau=IV_PAU_NORMAL;
                else {
                    if (lastpar==0) pau=IV_PAU_LONG;
                    else if (lastpar == partype) {
                        pau=(partype == MILENA_PARTYPE_DIALOG)?IV_PAU_DIALOG:IV_PAU_NORMAL;
                    }
                    else if (partype == MILENA_PARTYPE_DIALOG) pau=IV_PAU_PREDIAL;
                    else pau=IV_PAU_POSTDIAL;
                }
                if (partype==MILENA_PARTYPE_CHAPTER) partype=0;
                lastpar=partype;
            }
            s=get_sentence(&sr,&ed);
            if (!*str) {
                if (curline) g_free(curline);
                curline=NULL;
            }
            if (s) break;
        }
        ivona_PushThreadSent(s,&sr,&ed,pau,0);
        pau=IV_PAU_SENTENCE;
        if (ptyp & 8) pau=IV_PAU_SENDIAL;

        return 1;
    }


	chaptermark=0;
	if (gtk_combo_box_get_active((gpointer)combo_split)) {
		c=(char *)gtk_entry_get_text((gpointer)char_split);
		if (!*c || ((*c) & 0x80)) {
			Error("Błąd","Nielegalny znak podziału");
			return;
		}
		chaptermark=*c;
	}


    if (ivolektor_init()<0) return;
    //printf("Started ivol\n");
    ivona_StartThreads();
    //printf("Threads started\n");
    g_mutex_unlock(ivona_MainMutex);
    ivona_clean_sentence_list();
    //printf("Slist OK\n");
	curline=NULL;
	audioparam_init_f(0,ivona_getfreq());
	lastpar=-1;

    ivona_thread_play=1;
    int firstti=0;
    GtkTextIter sra,era;
    int sra_valid=0,can_break=0;

    for (;;) {
        int isal,isok,rc=0;
        for (;;) {
            isal=ivona_CountThreadQueue(&isok);
            if (isal < 10) {
                //printf("Fetch next\n");
                rc=fetch_sentence();
                //printf("Rc=%d\n",rc);
                if (rc) continue;
            }
            break;
        }
        if (!isal) break;
        if (!firstti) {
            isal=ivona_CountThreadQueue(&isok);
            //printf("GA %d %d\n",isal,isok);
            if (isok < ((isal>prebuffer)?prebuffer:isal)) {
                usleep(100000);
                yield();
                if (!is_speaking) break;
                //g_thread_yield();
                continue;
            }
            firstti=1;
        } else yield();
        if (!is_speaking) break;
        struct ivona_thr_sentence *ithr=ivona_PullThreadSent();
        if (!ithr) {
            g_thread_yield();
            continue;
        }
        //printf("Bede grać %s\n",ithr->ivotxt);
        free(ithr->ivotxt);
        if (!ithr->wave) {
            Error("Blad",ithr->error?ithr->error:"HGW");
            free(ithr->error);
            free(ithr);
            break;
        }
        sra=ithr->sr;
        era=ithr->ed;
        sra_valid=1;
        gtk_text_view_scroll_to_iter(tresc_v,&era,0.2,FALSE,0,0);
        gtk_text_buffer_apply_tag_by_name(tresc,"speaking",&sra,&era);

        push_pause(ivona_pause_lens[ithr->pause]);
        can_break=(ithr->pause < IV_PAU_SENTENCE);
        rc=1;
        int vbeg=ivona_push_last_wav(ithr->breath);
        last_wav=ithr->wave;
        last_beg=ithr->breath;
        last_end=ithr->rest;
        last_len=ithr->length;
        last_pause=0;
        free(ithr);
        if (can_break && sleep_mode && sleep_start + sleep_mode <= time(0)) {
            if (Ask("Sleep","Przerwać czytanie?")) {
                is_speaking=0;
            }
            sleep_start=time(0);
        }
        if (rc && !ivona_push_wave(last_wav+vbeg,last_len-(last_end+vbeg))) rc=0;
        gtk_text_buffer_remove_tag_by_name(tresc,"speaking",&sra,&era);

        if (!rc || !is_speaking) break;

    }
    ivona_finish();
    ivona_thread_play=0;
    while(ivona_ThreadStatus) {
        usleep(100000);
        g_thread_yield();
    }
    g_mutex_lock(ivona_MainMutex);
    if (sra_valid) {
        gtk_text_buffer_place_cursor(tresc,&sra);
    }
}



int ivona_getfreq(void)
{
    if (!ivona->freq) {
        int len;char *err,buf[2];
        strcpy(buf,"a");
        short *wave=IVOL_getWave(ivona,buf,&len,&err);
        if (wave) free(wave);
    }

    return ivona->freq;
}

short *ivona_get_wave_from_string(char *ivostr,int *leng,int *ofset,int *resty)
{
    short *wave;int len,offs,rest;char *err;
    if (ivolektor_init() < 0) {
        return NULL;
    }
    wave=IVOL_getWave(ivona,ivostr,&len,&err);
    if (!wave) return NULL;
    wave=ivona_trim_wave(wave,&len,&offs,&rest);
    if (leng) *leng=len;
    if (ofset) *ofset=offs;
    if (resty) *resty=rest;
    return wave;
}

int ivona_record_part(int npart)
{
	int pau,ptyp;
	int partyp;
    char *psf=NULL;
	static char *phrase_buf,*trans_buf;
	static int phrase_len,trans_len;
    if (!phrase_buf) phrase_buf=malloc(phrase_len=1024);
    if (!trans_buf) trans_buf=malloc(trans_len=1024);

    char *get_paragraph(void)
    {
        char *c,*d;
        for (;;) {
            if (!*this_pos) {
                return NULL;
            }
            c=strchr(this_pos,'\n');
            d=this_pos;
            if (!c) c=this_pos+strlen(this_pos);
            else *c++=0;
            this_pos=c;
            partyp=milena_GetParType(milena,&d,spell_empty);
            if (!partyp) {
                if (lastpar>0) lastpar=0;
                continue;
            }
            if (lastpar<0) {
                pau=0;
            }
            else if (!bookmode) pau=IV_PAU_NORMAL;
            else {
                if (lastpar==0) pau=IV_PAU_LONG;
                else if (lastpar == partyp) {
                    pau=(partyp == MILENA_PARTYPE_DIALOG)?IV_PAU_DIALOG:IV_PAU_NORMAL;
                }
                else if (partyp == MILENA_PARTYPE_DIALOG) pau=IV_PAU_PREDIAL;
                else pau=IV_PAU_POSTDIAL;
            }
            lastpar=partyp;
            SetProgress(npart,compute_percent());
            yield();
            if (!allow_run) return NULL;
            return d;
        }
    }

    int get_sentence(void)
    {
        loop:
	if (!psf || !*psf) {
            psf=get_paragraph();
            if (!psf || !*psf) return 0;
        }
        if (ivona_outbuf) *ivona_outbuf=0;
        for (;;) {
            int nlen;
	    if (debug_level) fprintf(stderr,"Ivona pre par[%s]\n",psf);
            nlen=milena_GetPhrase(milena,&psf,phrase_buf,phrase_len,&ptyp);
	    //printf("== %d [[%s]]\n",nlen,psf);
	    if (debug_level) fprintf(stderr,"Ivona nlen=%d, rest par[%s]\n",nlen,psf);
            if (nlen<0) {
		while (*psf) psf++; // ewentualne śmieci na końcu akapitu
		// jeśli mamy coś do powiedzenia, normalnie mówimy to
		if (ivona_outbuf && *ivona_outbuf) break;
		// a jeśli nie to przechodzimy bezpośrednio do nowego akapitu
		goto loop;
	    }
            if (nlen) {
                phrase_len=nlen+1024;
                phrase_buf=realloc(phrase_buf,phrase_len);
                milena_GetPhrase(milena,&psf,phrase_buf,phrase_len,&ptyp);
            }
	    if (debug_level) fprintf(stderr,"Ivona phrase buffer %s\n",phrase_buf);
            ivona_phrase(phrase_buf,&trans_buf,&trans_len);
	    if (debug_level) fprintf(stderr,"Ivona trans buffer %s\n",trans_buf);
            milena_ivona_push(ptyp & 7,trans_buf,&ivona_outbuf,&ivona_outsize);
	    if (debug_level) fprintf(stderr,"Ivona output buffer %s\n",ivona_outbuf);
            if (fins[ptyp & 7]) break;
        }
	if (debug_level > 0) fprintf(stderr,"Ivona output [%s]\n",ivona_outbuf);
        if (ivona_outbuf && *ivona_outbuf) return 1;
	// jeśli tutaj dojdzie to jakiś straszny babol jest!
        return 0;
    }

    for (;;) {
        short *wave;
        int breath,length,rest,n;
        int vbeg;
        int rc=1;
        if (!allow_run) break;
        n=get_sentence();
	if (debug_level) fprintf(stderr,"get_sentence returned %d\n",n);
        if (!n) break;
        yield();
        if (!allow_run) break;
        //printf("[%s]\n",ivona_outbuf);
	wave=ivona_get_wave_from_string(ivona_outbuf,&length,&breath,&rest);
        yield();
        if (!allow_run) {
            if (wave) free(wave);
            wave=NULL;
        }
        if (!wave) {
            if (last_wav) {
                free(last_wav);
                last_wav=NULL;
            }
            return 0;
        }
        push_pause(ivona_pause_lens[pau]);
        pau=(ptyp & 8) ? IV_PAU_SENDIAL:IV_PAU_SENTENCE;
        vbeg=ivona_push_last_wav(breath);
        yield();
        if (!rc || !allow_run) {
            free(wave);
            allow_run=0;
            break;
        }
        last_wav=wave;
        last_beg=breath;
        last_end=rest;
        last_len=length;
        last_pause=0;
        if (rc && !ivona_push_wave(last_wav+vbeg,last_len-(last_end+vbeg))) rc=0;
        yield();
        if (!rc || !allow_run) {
            allow_run=0;
            break;
        }
    }
    if (allow_run && last_wav) {
        ivona_push_wave(last_wav+(last_len-last_end),last_end);
    }
    ivona_speaking=0;
    if (sonic) {
        sonicDestroyStream(sonic);
        sonic=NULL;
    }
    return allow_run?1:0;
}

int ivona_record_paragraph(char *para)
{
	char *psf=para;
    int pau,ptyp;
	int partyp=milena_GetParType(milena,&psf,spell_empty);
	static char *phrase_buf,*trans_buf;
	static int phrase_len,trans_len;
    if (!phrase_buf) phrase_buf=malloc(phrase_len=1024);
    if (!trans_buf) trans_buf=malloc(trans_len=1024);

    int get_sentence(void)
    {
        if (ivona_outbuf) *ivona_outbuf=0;
        for (;;) {
            int nlen;
            nlen=milena_GetPhrase(milena,&psf,phrase_buf,phrase_len,&ptyp);
            if (nlen<0) break;
            if (nlen) {
                phrase_len=nlen+1024;
                phrase_buf=realloc(phrase_buf,phrase_len);
                milena_GetPhrase(milena,&psf,phrase_buf,phrase_len,&ptyp);
            }
            ivona_phrase(phrase_buf,&trans_buf,&trans_len);
            milena_ivona_push(ptyp & 7,trans_buf,&ivona_outbuf,&ivona_outsize);
            if (fins[ptyp & 7]) break;
        }
        if (ivona_outbuf && *ivona_outbuf) return 1;
        return 0;
    }


	if (!partyp) {
		if (lastpar>0) lastpar=0;
		return 1;
	}
	if (lastpar<0) {
		pau=0;
	}
	else if (!bookmode) pau=IV_PAU_NORMAL;
	else {
		if (lastpar==0) pau=IV_PAU_LONG;
		else if (lastpar == partyp) {
            pau=(partyp == MILENA_PARTYPE_DIALOG)?IV_PAU_DIALOG:IV_PAU_NORMAL;
        }
		else if (partyp == MILENA_PARTYPE_DIALOG) pau=IV_PAU_PREDIAL;
		else pau=IV_PAU_POSTDIAL;
	}
	lastpar=partyp;
    for (;;) {
        short *wave;
        int breath,length,rest,n;
        int samp1,samp2,silence,vbeg=0;
        int rc=1;
        if (!allow_run) break;
        n=get_sentence();
        if (!n) break;
        yield();
        if (!allow_run) break;
        wave=ivona_get_wave_from_string(ivona_outbuf,&length,&breath,&rest);
        yield();
        if (!allow_run) {
            if (wave) free(wave);
            wave=NULL;
        }
        if (!wave) {
            if (last_wav) {
                free(last_wav);
                last_wav=NULL;
            }
            return 0;
        }
        push_pause(ivona_pause_lens[pau]);
        pau=(ptyp & 8) ? IV_PAU_SENDIAL:IV_PAU_SENTENCE;
        if (last_wav) {
            samp1=last_end;
            samp2=breath;
            if (last_pause < samp1+samp2) {
                samp1=(last_end *last_pause)/(breath+last_end);
                samp2=(breath *last_pause)/(breath+last_end);
                silence=0;
            }
            else {
                silence=last_pause-(samp1+samp2);
            }
            if (!ivona_push_wave(last_wav+(last_len-last_end),samp1)) rc=0;
            //printf("Wave final OK\n");
            if (rc && silence>0) {
                if (!ivona_push_silence(silence)) rc=0;
            }
            vbeg=breath-samp2;
            free(last_wav);
            last_wav=NULL;
            yield();
            if (!rc || !allow_run) {
                free(wave);
                allow_run=0;
                break;
            }
        }
        last_wav=wave;
        last_beg=breath;
        last_end=rest;
        last_len=length;
        last_pause=0;
        if (rc && !ivona_push_wave(last_wav+vbeg,last_len-(last_end+vbeg))) rc=0;
        yield();
        if (!rc || !allow_run) {
            allow_run=0;
            break;
        }
    }
    if (allow_run && last_wav) {
        ivona_push_wave(last_wav+last_len-last_end,last_end);
    }
    ivona_finish();
    return allow_run?1:0;
}




#ifdef USE_SUBMIXER
short *ivona_get_subtitle_wave(char *ivostr,double speed,int *length,char *movie_path)
{
    short *wave;int len,offs,rest;int outlen,fd;
    char *err,*c;
    char ebuf[512];
    int have_dir=0;
    if (ivolektor_init() < 0) {
        return NULL;
    }
    strcpy(ebuf,movie_path);
	c=strrchr(ebuf,'/');
	if (c && c!=ebuf) *c=0;
    sprintf(ebuf+strlen(ebuf),"/_ivoice_%s",last_ivona_voice);
    if (!g_file_test(ebuf,G_FILE_TEST_IS_DIR)) {
        have_dir=!g_mkdir_with_parents(ebuf,0755);
    }
    else have_dir=1;
    wave=NULL;
    if (have_dir) {
        struct stat sb;
        GChecksum *gc;
        strcat(ebuf,"/");
        gc=g_checksum_new(G_CHECKSUM_SHA1);
        g_checksum_update(gc,(gpointer)ivostr,-1);
        strcat(ebuf,g_checksum_get_string(gc));
        g_checksum_free(gc);
        if (!stat(ebuf,&sb)) {
            fd=open(ebuf,O_RDONLY);
            if (fd >= 0) {
                wave=malloc(sb.st_size);
                ignore(read(fd,wave,sb.st_size));
                close(fd);
                len=sb.st_size/2;
            }
        }
    }
    if (!wave) {
        wave=IVOL_getWave(ivona,ivostr,&len,&err);
        if (!wave) return NULL;
        if (have_dir) {
            fd=open(ebuf,O_WRONLY | O_CREAT | O_TRUNC,0644);
            if (fd >= 0) {
                ignore(write(fd,wave,2*len));
                close(fd);
            }
            else perror(ebuf);
        }
    }
    wave=ivona_trim_wave(wave,&len,&offs,&rest);
    outlen=len-(offs+rest)/2;
    if (offs>2) memcpy(wave,wave+offs/2,2*outlen);

    if (speed >= 0.99 && speed <= 1.01) {
        *length=outlen;
        return wave;
    }
    if (speed < 1.0) {
        *length=outlen;
        return wave;
    }
    outlen=sonicChangeShortSpeed(wave,outlen,speed,1.0,1.0,ivona->freq,1);
    *length=outlen;
    return wave;
}

int ivona_compute_msec(char *ivostr,char *movie_path)
{
    short *wave;int len;
    wave=ivona_get_subtitle_wave(ivostr,1.0,&len,movie_path);
    if (!wave) return -1;
    free(wave);
    return (int)((len * 1000.0)/ivona_getfreq());
}

#endif
