/*
 * aac.c - Milena Audiobook Creator
 * Copyright (C) Bohdan R. Rau 2009 <ethanak@polip.com>
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write see:
 *               <http://www.gnu.org/licenses/>.
 */
#include "config.h"
#include "gmilena.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <faac.h>

static char *aac_buffer;
static short *aac_frame;
static unsigned long aac_buffer_size;
static unsigned long aac_frame_samples;
static FILE *aac_stream;
static faacEncHandle *encoder;
static int aac_readpos;

int init_aac_encoder(char *fname)
{
    faacEncConfigurationPtr ptr;
    printf("Faac started for %s\n",fname);
    aac_stream=fopen(fname,"wb");
    if (!aac_stream) {
        g_perror(fname);
        return 0;
    }
    encoder=faacEncOpen((stereo_mode && stereo_upsample)?32000:16000,stereo_mode?2:1,&aac_frame_samples,&aac_buffer_size);
    if (!encoder) {
        fclose(aac_stream);
        Error("Błąd","Nie mogę zainicjalizować enkodera AAC");
        return 0;
    }
    aac_buffer=malloc(aac_buffer_size);
    aac_frame=malloc(aac_frame_samples * sizeof(short));
    ptr=faacEncGetCurrentConfiguration(encoder);
    //ptr->bitRate=24000;
    //ptr->aacObjectType=LOW;
    //ptr->mpegVersion = MPEG2;
    //ptr->outputFormat=1;
    ptr->useTns=0;
    ptr->allowMidside=0;
    ptr->inputFormat=FAAC_INPUT_16BIT;
    if (!faacEncSetConfiguration(encoder,ptr)) {
        fclose(aac_stream);
        free(aac_frame);
        free(aac_buffer);
        Error("Błąd","Nie mogę ustawić parametrów AAC");
        return 0;
    }
    aac_readpos=0;
    return 1;
}

int aac_encode(short *buf,int nsamples)
{
	while (nsamples >0) {
		int nsm=nsamples;
		int serial_size;
		if (nsm > aac_frame_samples - aac_readpos) {
			nsm=aac_frame_samples - aac_readpos;
		}
		memcpy(aac_frame+aac_readpos,buf,2*nsm);
		aac_readpos+=nsm;
		buf+=nsm;
		nsamples-=nsm;
		if (aac_readpos == aac_frame_samples) {
			serial_size = faacEncEncode(encoder,(void *)aac_frame,aac_frame_samples,(void *)aac_buffer,aac_buffer_size);
			if (serial_size) fwrite(aac_buffer,1,serial_size,aac_stream);
			aac_readpos=0;
		}
	}
	return 1;
}

int finish_aac(void)
{
    faacEncClose(encoder);
    free(aac_frame);
    free(aac_buffer);
    fclose(aac_stream);
    printf("Faac finished\n");
    return 1;
}
