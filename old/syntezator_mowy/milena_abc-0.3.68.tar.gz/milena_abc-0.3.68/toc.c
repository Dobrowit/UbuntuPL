/*
 * toc.c - Milena Audiobook Creator
 * Copyright (C) Bohdan R. Rau 2012 <ethanak@polip.com>
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write see:
 *               <http://www.gnu.org/licenses/>.
 */
#include "config.h"
#include <gtk/gtk.h>
#include <string.h>
#include <stdlib.h>
#include "gmilena.h"
#include <ctype.h>



struct toc_item {
	struct toc_item *next;
	char *chapter_title;
	int offset;
	int level;
	char *chapter_start;
};

static int ShowTOCDialog(struct toc_item *toc)
{
	if (toc) toc->level=0;
	GtkWidget *dialog=gtk_dialog_new_with_buttons(
		"Spis treści",
		(void *)main_window,
		GTK_DIALOG_MODAL,
		GTK_STOCK_OK,GTK_RESPONSE_ACCEPT,
		GTK_STOCK_CANCEL,GTK_RESPONSE_REJECT,
		NULL);
    GtkTreeIter iter,parentiter;
	GtkWidget *box=gtk_dialog_get_content_area((gpointer)dialog);
	GtkWidget *vbox=gtk_vbox_new(0,2);
	gtk_box_pack_start(GTK_BOX(box),(gpointer)vbox,FALSE,FALSE,0);
	GtkTreeView *toc_treeview;
	GtkTreeStore *toc_treestore;

	toc_treeview=(gpointer)gtk_tree_view_new();
	GtkCellRenderer *renderer=gtk_cell_renderer_text_new();
	gtk_tree_view_insert_column_with_attributes (toc_treeview,-1,
                                               "Tytuł",
                                               renderer,
                                               "text", 0, NULL);
	renderer=gtk_cell_renderer_text_new();
	gtk_tree_view_insert_column_with_attributes (toc_treeview,-1,
                                               "Linia",
                                               renderer,
                                               "text", 1, NULL);
	gtk_tree_view_insert_column_with_attributes (toc_treeview,-1,
                                               "Treść",
                                               renderer,
                                               "text", 2, NULL);



	toc_treestore=gtk_tree_store_new(3,G_TYPE_STRING,G_TYPE_INT,G_TYPE_STRING);
	gtk_tree_view_set_model(toc_treeview,(gpointer)toc_treestore);
	g_object_unref(toc_treestore);

	GtkTreeViewColumn *cols[3];
	cols[0]=gtk_tree_view_get_column(toc_treeview,0);
	cols[1]=gtk_tree_view_get_column(toc_treeview,1);
	cols[2]=gtk_tree_view_get_column(toc_treeview,2);
	gtk_tree_view_column_set_sizing(cols[0],GTK_TREE_VIEW_COLUMN_FIXED);
	gtk_tree_view_column_set_fixed_width(cols[0],320);
	gtk_tree_view_column_set_sizing(cols[1],GTK_TREE_VIEW_COLUMN_FIXED);
	gtk_tree_view_column_set_fixed_width(cols[1],64);
	gtk_tree_view_column_set_sizing(cols[2],GTK_TREE_VIEW_COLUMN_FIXED);
	gtk_tree_view_column_set_fixed_width(cols[2],320);
	struct toc_item *t;
	for (t=toc;t;t=t->next) {
		gtk_tree_store_append (toc_treestore, &iter,
			t->level?&parentiter:NULL);
		if (t->level == 0) parentiter=iter;
		gtk_tree_store_set (toc_treestore, &iter,
			0,t->chapter_title,
			1,t->offset+1,
			2,t->chapter_start,
			-1);
	}
#ifndef HAVE_GTK3
	gtk_widget_set_size_request((gpointer)toc_treeview,790,500);
#endif
	GtkWidget *w=(gpointer)gtk_scrolled_window_new(NULL,NULL);
	gtk_box_pack_start(GTK_BOX(vbox),(gpointer)w,FALSE,FALSE,0);
	gtk_container_add((gpointer)w,(gpointer)toc_treeview);
#ifdef HAVE_GTK3
	gtk_widget_set_size_request((gpointer)w,790,500);
#endif
	gtk_widget_show_all(box);
	void retco(void)
	{
		gtk_dialog_response((gpointer)dialog,GTK_RESPONSE_ACCEPT);
	}
	g_signal_connect((gpointer)toc_treeview,"row-activated",(gpointer)retco,NULL);
	
	gtk_tree_view_expand_all((gpointer)toc_treeview);
	int n=gtk_dialog_run((gpointer)dialog);
	int rc=-1;
	if (n ==  GTK_RESPONSE_ACCEPT) {
		GtkTreeSelection *sel=gtk_tree_view_get_selection(toc_treeview);
		GtkTreeIter iter;
		GtkTreeModel *model;
		if (gtk_tree_selection_get_selected(sel,&model,&iter)) {
			gtk_tree_model_get(model,&iter,1,&rc,-1);
		}
	}
	gtk_widget_destroy(dialog);
	return rc;
}


static void free_toc(struct toc_item *toc)
{
	struct toc_item *t;
	while ((t=toc)) {
		toc=toc->next;
		g_free(t->chapter_title);
		g_free(t->chapter_start);
		g_free(t);
	}
}

static char *cpmax(char *src,int size,int marker)
{
	char *dst=g_malloc(6*size+1);
	char *c=dst;
	int n;
	if (!src) src="";
	while (size-- > 0 && *src) {
		n=*src;
		if (*src == marker || *src=='\n') break;
		*c++=*src++;
		if (n & 0x80) {
			for(;;) {
				if (((*src) & 0xc0) != 0x80) break;
				*c++ = *src++;
			}
		}
	}
	*c=0;
	return dst;
}


static struct toc_item *alloc_toc(char *chapter_name,char *chapter_start,int level,int offset,int marker)
{
	struct toc_item *toc;
	toc=g_malloc(sizeof(*toc));
	toc->next=NULL;
	toc->chapter_title=cpmax(chapter_name,40,'<');
	toc->chapter_start=cpmax(chapter_start,140,0);
	toc->level=level;
	toc->offset=offset;
	return toc;
}

static char *toc_find_marker(char *sptr,int marker)
{
	char *c;
	for (;;) {
		sptr=strchr(sptr,'\n');
		if (!sptr) return NULL;
		sptr++;
		c=sptr;
		while (*sptr == ' ' || *sptr == '\t') sptr++;
		if (*sptr==marker) return c;
	}
	return NULL;
}

void show_toc(void)
{
	char *body,*sptr,*dptr;int marker;
	char *c;
	struct toc_item *toc,**ttocc,*t;
	int level,offset;
	
	int chapter_count;
	
	if (get_current_editor()) return;
	c=(char *)gtk_entry_get_text((gpointer)char_split);
	if (!*c) return;
	marker=*c;
	body=get_actual_body();
	level=0;
	toc=NULL;
	ttocc=&toc;
	sptr=body;
	
	int compute_lineno(char *c)
	{
		char *d=body;
		int cnt=0;
		for (;*d && d<c;d++) if (*d=='\n') cnt++;
		return cnt;
	}
	
	for (;sptr;) {
		sptr=toc_find_marker(sptr,marker);
		//printf("%X\n",sptr);
		if (!sptr) break;
		offset=compute_lineno(sptr);
		sptr++;
		while (*sptr == ' ' || *sptr == '\t') sptr++;
		if (!strncmp(sptr,"<fb2:part>",10)) {
			sptr+=10;
			while (*sptr == ' ' || *sptr == '\t') sptr++;
			*ttocc=alloc_toc(sptr,NULL,0,offset,marker);
			ttocc=&(*ttocc)->next;
			level=1;
			while (*sptr && *sptr != '\n' && strncmp(sptr,"<fb2:chapter>",13)) sptr++;
			if (*sptr != '<') continue;
			sptr+=13;
			while (*sptr == ' ' || *sptr == '\t') sptr++;
		}
		else if (!strncmp(sptr,"<fb2:/part>",11)) {
			level=0;
			sptr+=11;
		}
		dptr=strchr(sptr,'\n');
		if (dptr) {
			dptr++;
			while (*dptr && isspace(*dptr)) dptr++;
		}
		*ttocc=alloc_toc(sptr,dptr,level,offset,0);
		ttocc=&(*ttocc)->next;
		sptr=dptr;
	}
	free(body);
	for (t=toc,chapter_count=0;t;t=t->next,chapter_count++);
	if (chapter_count < 2) {
		Error("Blad","Nie mam rozdziałów do wyświetlenia");
		free_toc(toc);
		return;
	}
	int n=ShowTOCDialog(toc);
	

	if (n>0) {
			GtkTextIter line;
			gtk_text_buffer_get_iter_at_line(tresc,&line,n-1);
			gtk_text_buffer_place_cursor(tresc,&line);
			gtk_text_view_scroll_to_iter((gpointer)tresc_v,&line,FALSE,TRUE,0.0,0.5);
	}
	
	free_toc(toc);
}
