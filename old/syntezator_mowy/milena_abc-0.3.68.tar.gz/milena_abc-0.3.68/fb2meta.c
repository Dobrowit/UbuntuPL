/*
 * fb2meta.c - Milena Audiobook Creator
 * Copyright (C) Bohdan R. Rau 2011 <ethanak@polip.com>
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write see:
 *               <http://www.gnu.org/licenses/>.
 */
#include "config.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "gmilena.h"
#include <ctype.h>



#define CCDUP(c,field) if ((c)->field) (c)->field=g_strdup((c)->field)

struct FB2Context *FB2_DuplicateContext(struct FB2Context *ctx)
{
    struct FB2Context *cty=g_malloc0(sizeof(*cty));
    *cty=*ctx;
    int n,i;
    if (ctx->authors) {
        n=sizeof(*(cty->authors)) * ctx->author_no;
        cty->authors=g_malloc(n);
        memcpy(cty->authors,ctx->authors,n);
        for (i=0;i<cty->author_no;i++) {
            CCDUP(cty->authors+i,first_name);
            CCDUP(cty->authors+i,middle_name);
            CCDUP(cty->authors+i,last_name);
            CCDUP(cty->authors+i,nick_name);
            CCDUP(cty->authors+i,home_page);
            CCDUP(cty->authors+i,email);
        }
    }
    if (ctx->translators) {
        n=sizeof(*(cty->translators)) * ctx->translator_no;
        cty->translators=g_malloc(n);
        memcpy(cty->translators,ctx->translators,n);
        for (i=0;i<cty->translator_no;i++) {
            CCDUP(cty->translators+i,first_name);
            CCDUP(cty->translators+i,middle_name);
            CCDUP(cty->translators+i,last_name);
            CCDUP(cty->translators+i,nick_name);
            CCDUP(cty->translators+i,home_page);
            CCDUP(cty->translators+i,email);
        }
    }
    if (ctx->genres) {
        n=sizeof(*(cty->genres)) * ctx->genre_no;
        cty->genres=g_malloc(n);
        memcpy(cty->genres,ctx->genres,n);
        for (i=0;i<ctx->genre_no;i++) {
            CCDUP(cty->genres+i,name);
        }
    }
    CCDUP(cty,title);
    CCDUP(cty,origin);
    CCDUP(cty,id);
    CCDUP(cty,cover);
    return cty;
}

void FB2FreeContext(struct FB2Context *ctx)
{
    if (!ctx) return;
    int i;
    void frep(struct FB2_person *pe)
    {
        g_free(pe->first_name);
        g_free(pe->middle_name);
        g_free(pe->last_name);
        g_free(pe->nick_name);
        g_free(pe->home_page);
        g_free(pe->email);
    }
    for (i=0;i<ctx->genre_no;i++) {
        g_free(ctx->genres[i].name);
    }
    g_free(ctx->genres);
    for (i=0;i<ctx->author_no;i++) {
        frep(ctx->authors+i);
    }
    g_free(ctx->authors);
    for (i=0;i<ctx->translator_no;i++) {
        frep(ctx->translators+i);
    }
    g_free(ctx->translators);
    g_free(ctx->title);
    g_free(ctx->id);
    g_free(ctx->cover);
    g_free(ctx->origin);
    g_free(ctx);
}


#define CFB_AUTHOR 1
#define CFB_TRANSLATOR 2
#define CFB_GENRES 3
#define CFB_TITLE 4
#define CFB_COVER 5
#define CFB_ID 6
#define CFB_ORIGIN 7


struct FB2Context *FB2ContextInit(void)
{
    struct FB2Context *fc=g_malloc0_n(1,sizeof(*fc));
    return fc;
}

static void add_genre(struct FB2Context *ctx,const gchar **aname,const gchar **avalue)
{
    int i;
    if (!ctx->genres) {
        ctx->genre_no=0;
        ctx->genre_si=16;
        ctx->genres=g_malloc(sizeof(*ctx->genres) * ctx->genre_si);
    }
    else if (ctx->genre_no >= ctx -> genre_si) {
        ctx->genre_si *= 2;
        ctx->genres=g_realloc(ctx->genres,sizeof(*ctx->genres) * ctx->genre_si);
    }
    struct FB2_Genre *ge=&ctx->genres[ctx->genre_no++];
    ge->name=NULL;
    ge->weight=100;
    for (i=0;aname[i];i++) {
        if (!strcmp(aname[i],"name")) ge->name=g_strdup(avalue[i]);
        else if (!strcmp(aname[i],"weight")) ge->weight=strtol(avalue[i],NULL,10);
    }
}

static void add_person(struct FB2Context *ctx,const gchar **aname,const gchar **avalue)
{
    struct FB2_person **perses,*pers;
    int i,*si,*no;
    char **ctl=NULL;
    if (ctx->context == CFB_AUTHOR) {
        si=&ctx->author_si;
        no=&ctx->author_no;
        perses=&ctx->authors;
    }
    else {
        si=&ctx->translator_si;
        no=&ctx->translator_no;
        perses=&ctx->translators;
    }
    if (!*perses) {
        *si=16;
        *no=0;
        *perses=g_malloc(sizeof(**perses) * 16);
    }
    else if (*no >= *si) {
        *si = 2 * *si;
        *perses=g_realloc(*perses, sizeof(**perses) * (*si));
    }
    pers = & (*perses)[(*no)++];
    memset(pers,0,sizeof(*pers));

    for (i=0;aname[i];i++) {
        ctl=NULL;
        if (!strcmp(aname[i],"first_name")) ctl=&(pers->first_name);
        else if (!strcmp(aname[i],"middle_name")) ctl=&(pers->middle_name);
        else if (!strcmp(aname[i],"last_name")) ctl=&(pers->last_name);
        else if (!strcmp(aname[i],"nickname")) ctl=&(pers->nick_name);
        else if (!strcmp(aname[i],"email")) ctl=&(pers->email);
        else if (!strcmp(aname[i],"home_page")) ctl=&(pers->home_page);
        else continue;
        if (!(*ctl)) *ctl=g_strdup(avalue[i]);
    }
}

#define CTX ((struct FB2Context *)udata)

static void fb2_start_element(GMarkupParseContext *context,
    const gchar *element,
    const gchar **anames,
    const gchar **avalues,
    gpointer udata,
    GError **error)
{

    if (!strcmp(element,"person")) {
        if (CTX->context != CFB_TRANSLATOR &&
            CTX->context != CFB_AUTHOR) return;
        add_person(CTX,anames,avalues);
        return;
    }
    if (!strcmp(element,"genre")) {
        if (CTX->context == CFB_GENRES) {
            add_genre(CTX,anames,avalues);

        }
        return;
    }
    if (!strcmp(element,"authors")) {
        if (!CTX->context) CTX->context=CFB_AUTHOR;
        return;
    }
    if (!strcmp(element,"translators")) {
        if (!CTX->context) CTX->context=CFB_TRANSLATOR;
        return;
    }
    if (!strcmp(element,"genres")) {
        if (!CTX->context) CTX->context=CFB_GENRES;
        return;
    }
    if (!strcmp(element,"title")) {
        if (!CTX->context) CTX->context=CFB_TITLE;
        return;
    }
    if (!strcmp(element,"cover")) {
        if (!CTX->context) CTX->context=CFB_COVER;
        return;
    }
    if (!strcmp(element,"id")) {
        if (!CTX->context) CTX->context=CFB_ID;
        return;
    }
    if (!strcmp(element,"origin")) {
        if (!CTX->context) CTX->context=CFB_ORIGIN;
        return;
    }
    if (!strcmp(element,"flags")) {
        int i;
        for (i=0;anames[i];i++) {
            if (!strcmp(anames[i],"first-anno")) {
                CTX->firstanno=strtol(avalues[i],NULL,10);
            }
            else if (!strcmp(anames[i],"nofootnotes")) {
                CTX->nofootnotes=strtol(avalues[i],NULL,10);
            }
        }
        return;
    }
    if (!strcmp(element,"seq")) {
        int i;
        if (CTX->seq_name) return;
        for (i=0;anames[i];i++) {
            if (!strcmp(anames[i],"number")) {
                CTX->seq_number=strtol(avalues[i],NULL,10);
            }
            else if (!strcmp(anames[i],"name") && !CTX->seq_name) {
                CTX->seq_name=g_strdup(avalues[i]);
            }
        }
    }
}

static void fb2_end_element(GMarkupParseContext *context,
    const gchar *element,
    gpointer udata,
    GError **error)
{
    if (!strcmp(element,"genre")) return;
    if (!strcmp(element,"person")) return;
    CTX->context=0;
}

static void fb2_text(GMarkupParseContext *context,
    const gchar *text,
    gsize text_length,
    gpointer udata,
    GError **error)
{
    char **txt=NULL;
    switch(CTX->context) {
        case CFB_ID: txt=&CTX->id;break;
        case CFB_TITLE: txt=&CTX->title;break;
        case CFB_COVER: txt=&CTX->cover;break;
        default: return;
    }
    if (!*txt) *txt=g_strdup(text);
}

static GMarkupParser FB2Parser={
    fb2_start_element,
    fb2_end_element,
    fb2_text};

struct FB2Context *FB2ReadContext(char *fname)
{
    FILE *f=fopen(fname,"r");
    if (!f) return NULL;
    char buf[1024];
    struct FB2Context *ctx=FB2ContextInit();
    int blen;
    GMarkupParseContext *context=g_markup_parse_context_new(
        &FB2Parser,0,(gpointer)ctx,NULL);
    for (;;) {
        blen=fread(buf,1,1024,f);
        if (blen <=0) break;
        g_markup_parse_context_parse(context,buf,blen,NULL);
    }
    g_markup_parse_context_end_parse(context,NULL);
    g_markup_parse_context_free(context);
    return ctx;
}

void FB2WriteContext(char *fname,struct FB2Context *ctx)
{
    FILE *f;
    int i;
    void vstr(char *c,char *tag,char *attr)
    {
        if (!c) return;
        char *d=g_markup_escape_text(c,-1);
        if (tag) fprintf(f,"<%s>",tag);
        if (attr) fprintf(f," %s=\"",attr);
        fwrite(d,strlen(d),1,f);
        if (tag) fprintf(f,"</%s>\n",tag);
        if (attr) fprintf(f,"\"");
        g_free(d);
    }
    void persona(struct FB2_person *p)
    {
        fprintf(f,"<person");
        vstr(p->first_name,NULL,"first_name");
        vstr(p->middle_name,NULL,"middle_name");
        vstr(p->last_name,NULL,"last_name");
        vstr(p->nick_name,NULL,"nickname");
        vstr(p->email,NULL,"email");
        vstr(p->home_page,NULL,"home_page");
        fprintf(f,"/>\n");
    }

    f=fopen(fname,"w");
    if (!f) return;
    fprintf(f,"<metadata>\n");
    vstr(ctx->title,"title",NULL);
    vstr(ctx->origin,"origin",NULL);
    vstr(ctx->cover,"cover",NULL);
    vstr(ctx->id,"id",NULL);
    fprintf(f,"<flags");
    vstr(ctx->firstanno?"1":"0",NULL,"first-anno");
    vstr(ctx->nofootnotes?"1":"0",NULL,"nofootnotes");
    fprintf(f," />\n");
    if (ctx->seq_name) {
        fprintf(f,"<seq number=\"%d\"",ctx->seq_number);
        vstr(ctx->seq_name,NULL,"name");
        fprintf(f," />\n");
    }
    if (ctx->genre_no) {
        fprintf(f,"<genres>\n");
        for (i=0;i<ctx->genre_no;i++) {
            fprintf(f,"<genre weight=\"%d\"",ctx->genres[i].weight);
            vstr(ctx->genres[i].name,NULL,"name");
            fprintf(f,"/>\n");
        }
        fprintf(f,"</genres>\n");
    }
    if (ctx->author_no) {
        fprintf(f,"<authors>\n");
        for (i=0;i<ctx->author_no;i++) persona(&ctx->authors[i]);
        fprintf(f,"</authors>\n");
    }
    if (ctx->translator_no) {
        fprintf(f,"<translators>\n");
        for (i=0;i<ctx->translator_no;i++) persona(&ctx->translators[i]);
        fprintf(f,"</translators>\n");
    }
    fprintf(f,"</metadata>\n");
    fclose(f);
}


struct FB2Context *FB2InitContextFromHeadline(char *str)
{
    struct FB2Context *ctx=FB2ContextInit();
    char *str2,*c,*d,*nstr;
    int spa;
    char *strcopy;
    static char *tluki[]={
		"tłum","tłum.","tłumaczył","tłumaczyła",
		"przeł","przeł.","przełożył","przełożyła",
		"tłumaczenie","przekład","przełożyli","tłumaczyli",NULL};
	int i,tlee;

    for (;*str && isspace(*str);str++);
    if (!*str)  return ctx;
    d=strpbrk(str,"\r\n");
    if (!d) return ctx;
    strcopy=g_malloc((d-str)+1);
    memcpy(strcopy,str,d-str);
    strcopy[d-str]=0;
    str=strcopy;
    nstr=d;
    while (*nstr && isspace(*nstr)) nstr++;
    for (c=d=str,spa=0;*c;c++) {
        if (isspace(*c)) {
            spa=1;
            continue;
        }
        if (spa) *d++=' ';
        spa=0;
        *d++=*c;
    }
    *d=0;


    d=strchr(str,',');
    if (!d) {
        ctx->title=g_strdup(str);
        g_free(strcopy);
        return ctx;
    }
    *d++=0;
    while (*d && isspace(*d)) d++;
    if (*d) {
        ctx->title=g_strdup(d);
    }
    for (c=d=str;*c;c++) if (!isspace(*c)) d=c+1;
    *d=0;
    c=strstr(str," i ");
    if (!c) c=strstr(str," & ");
    str2=NULL;
    if (c) {
        *c=0;
        c+=3;
        str2=c;
    }
    for (;str;str=str2,str2=NULL) {
        char *fna=NULL,*mna=NULL,*lna=NULL;
        c=strchr(str,' ');
        if (!c) {
            lna=g_strdup(str);
        }
        else {
            *c++=0;
            fna=g_strdup(str);
            str=c;
            c=strchr(c,' ');
            if (!c) {
                lna=g_strdup(str);
            }
            else {
                *c++=0;
                mna=g_strdup(str);
                lna=g_strdup(c);
            }
        }
        if (lna || mna || fna) {
            struct FB2_person *pe;
            if (!ctx->authors) {
                ctx->author_si=16;
                ctx->authors=g_malloc_n(ctx->author_si,sizeof(*ctx->authors));
            }
            pe=&ctx->authors[ctx->author_no++];
            memset(pe,0,sizeof(*pe));
            pe->first_name=fna;
            pe->middle_name=mna;
            pe->last_name=lna;
        }
    }
    g_free(strcopy);
    for (i=0;tluki[i];i++) {
		tlee=g_utf8_strlen(tluki[i],-1);
		if (g_utf8_strncasecmp(nstr,tluki[i],tlee)) continue;
		d=nstr+strlen(tluki[i]);
		if (isspace(*d)) {
			while (*d && isspace(*d)) d++;
			if (*d==':') d++;
			nstr=d;
			break;
		}
		if (*d==':') {
			d++;
		}
		else if (!isspace(*d)) continue;
		nstr=d;
		break;
	}
    if (tluki[i]) {
		while (*nstr && isspace(*nstr)) nstr++;
		d=strpbrk(nstr,"\r\n");
		if (!d) return ctx;
		strcopy=g_malloc((d-nstr)+1);
		memcpy(strcopy,nstr,d-nstr);
		strcopy[d-nstr]=0;
		str=strcopy;
		for (c=d=str,spa=0;*c;c++) {
			if (isspace(*c)) {
				spa=1;
            continue;
			}
			if (spa) *d++=' ';
			spa=0;
			*d++=*c;
		}
		*d=0;
		c=strstr(str," i ");
		if (!c) c=strstr(str," & ");
		str2=NULL;
		if (c) {
			*c=0;
			c+=3;
			str2=c;
		}
		for (;str;str=str2,str2=NULL) {
			char *fna=NULL,*mna=NULL,*lna=NULL;
			c=strchr(str,' ');
			if (!c) {
				lna=g_strdup(str);
			}
			else {
				*c++=0;
				fna=g_strdup(str);
				str=c;
				c=strchr(c,' ');
				if (!c) {
					lna=g_strdup(str);
				}
				else {
					*c++=0;
					mna=g_strdup(str);
					lna=g_strdup(c);
				}
			}
			if (lna || mna || fna) {
				struct FB2_person *pe;
				if (!ctx->translators) {
					ctx->translator_si=16;
					ctx->translators=g_malloc_n(ctx->translator_si,sizeof(*ctx->translators));
				}
				pe=&ctx->translators[ctx->translator_no++];
				memset(pe,0,sizeof(*pe));
				pe->first_name=fna;
				pe->middle_name=mna;
				pe->last_name=lna;
			}
		}
		g_free(strcopy);
	}
    return ctx;
}

static void _append_tag(GString *gs,char *value,char *tag)
{
    g_string_append_printf(gs,"<%s>",tag);
    g_string_append_htmlescape(gs,value);
    g_string_append_printf(gs,"</%s>",tag);
}

static void _add_person(GString *gs,struct FB2_person *pe,char *tag)
{
    g_string_append_printf(gs,"<%s>",tag);
    if (pe->first_name) _append_tag(gs,pe->first_name,"first-name");
    if (pe->middle_name) _append_tag(gs,pe->middle_name,"middle-name");
    if (pe->last_name) _append_tag(gs,pe->last_name,"last-name");
    if (pe->nick_name) _append_tag(gs,pe->nick_name,"nickname");
    if (pe->home_page) _append_tag(gs,pe->home_page,"homepage");
    if (pe->email) _append_tag(gs,pe->email,"email");
    g_string_append_printf(gs,"</%s>",tag);
}

GString *FB2MakeHeader(struct FB2Context *ctx,char *date,int do_anno,char *body,struct fb2_imagelist **images)
{
    int i;
    GString *gs=g_string_new(
"<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n\
<FictionBook xmlns=\"http://www.gribuser.ru/xml/fictionbook/2.0\" xmlns:l=\"http://www.w3.org/1999/xlink\" xmlns:xlink=\"http://www.w3.org/1999/xlink\">\
<description><title-info>");
    _append_tag(gs,ctx->title,"book-title");
    if (ctx->cover && *ctx->cover) {
        g_string_append(gs,"<coverpage><image xlink:href=\"#_cover\" /></coverpage>");
    }
    for (i=0;i<ctx->author_no;i++) {
        _add_person(gs,&ctx->authors[i],"author");
    }
    for (i=0;i<ctx->translator_no;i++) {
        _add_person(gs,&ctx->translators[i],"translator");
    }
    for (i=0;i<ctx->genre_no;i++) {
        if (ctx->genres[i].weight < 1) {
            _append_tag(gs,ctx->genres[i].name,"genre");
        }
        else {
            g_string_append_printf(gs,"<genre match=\"%d\">",ctx->genres[i].weight);
            g_string_append_htmlescape(gs,ctx->genres[i].name);
            g_string_append(gs,"</genre>");
        }
    }
    _append_tag(gs,"pl","lang");
    if (ctx->seq_name) {
        g_string_append_printf(gs,"<sequence");
        if (ctx->seq_number>0) g_string_append_printf(gs," number=\"%d\"",ctx->seq_number);
        g_string_append(gs," name=\"");
        g_string_append_htmlescape(gs,ctx->seq_name);
        g_string_append(gs,"\" />");
    }
    if (do_anno) {
        char c4[4],*cs;
        sprintf(c4,"\n%c",do_anno);
        cs=strstr(body,c4);
        if (cs) body=cs+2;
        cs=strstr(body,c4);
        if (!cs) {
            create_fb2_section(gs,body,1,0,1,images,NULL,NULL);
        }
        else {
            cs++;
            *cs=0;
            create_fb2_section(gs,body,1,0,1,images,NULL,NULL);
            *cs=do_anno;
        }
    }
    g_string_append(gs,"</title-info><document-info>");
    for (i=0;i<ctx->author_no;i++) {
        _add_person(gs,&ctx->authors[i],"author");
    }
    _append_tag(gs,date,"date");
    _append_tag(gs,ctx->id,"id");
    g_string_append(gs,"<program-used>Milena AudioBook Creator "PACKAGE_VERSION"</program-used>");
    g_string_append(gs,"<version>1.0</version></document-info></description><body>");
    return gs;
}

static char *genre_string="#General Fiction\n\
sf_history - Alternative history\n\
sf_action - Action\n\
sf_epic - Epic\n\
sf_heroic - Heroic\n\
sf_detective - Detective\n\
sf_cyberpunk - Cyberpunk\n\
sf_steampunk - Steampunk\n\
sf_space - Space\n\
sf_social - Social-philosophical\n\
sf_horror - Horror & mystic\n\
sf_humor - Humor\n\
sf_fantasy - Fantasy\n\
sf - Science Fiction\n\
#Detectives & Thrillers\n\
det_classic - Classical detectives\n\
det_police - Police Stories\n\
det_action - Action\n\
det_irony - Ironical detectives\n\
det_history - Historical detectives\n\
det_espionage - Espionage detectives\n\
det_crime - Crime detectives\n\
det_political - Political detectives\n\
det_maniac - Maniacs\n\
det_hard - Hard-boiled\n\
thriller - Thrillers\n\
detective - Detectives\n\
#Prose\n\
prose_classic - Classics prose\n\
prose_history - Historical prose\n\
prose_contemporary - Contemporary prose\n\
prose_counter - Counterculture\n\
prose_rus_classic - Russial classics prose\n\
prose_su_classics - Soviet classics prose\n\
#Romance\n\
love_contemporary - Contemporary Romance\n\
love_history - Historical Romance\n\
love_detective - Detective Romance\n\
love_short - Short Romance\n\
love_erotica - Erotica\n\
#Adventure\n\
adv_western - Western\n\
adv_history - History\n\
adv_indian - Indians\n\
adv_maritime - Maritime Fiction\n\
adv_geo - Travel & geography\n\
adv_animal - Nature & animals\n\
adventure - Other\n\
#Children's\n\
child_tale - Fairy Tales\n\
child_verse - Verses\n\
child_prose - Prose\n\
child_sf - Science Fiction\n\
child_det - Detectives & Thrillers\n\
child_adv - Adventures\n\
child_education - Educational\n\
children - Other\n\
#Poetry & Dramaturgy\n\
poetry - Poetry\n\
dramaturgy - Dramaturgy\n\
#Antique literature\n\
antique_ant - Antique\n\
antique_european - European\n\
antique_russian - Old russian\n\
antique_east - Old east\n\
antique_myths - Myths. Legends. Epos\n\
antique - Other\n\
#Scientific-educational\n\
sci_history - History\n\
sci_psychology - Psychology\n\
sci_culture - Cultural science\n\
sci_religion - Religious studies\n\
sci_philosophy - Philosophy\n\
sci_politics - Politics\n\
sci_business - Business literature\n\
sci_juris - Jurisprudence\n\
sci_linguistic - Linguistics\n\
sci_medicine - Medicine\n\
sci_phys - Physics\n\
sci_math - Mathematics\n\
sci_chem - Chemistry\n\
sci_biology - Biology\n\
sci_tech - Technical\n\
science - Other\n\
#Computers & Internet\n\
comp_www - Internet\n\
comp_programming - Programming\n\
comp_hard - Hardware\n\
comp_soft - Software\n\
comp_db - Databases\n\
comp_osnet - OS & Networking\n\
computers - Other\n\
#Reference\n\
ref_encyc - Encyclopedias\n\
ref_dict - Dictionaries\n\
ref_ref - Reference\n\
ref_guide - Guidebooks\n\
reference - Other\n\
#Nonfiction\n\
nonf_biography - Biography & Memoirs\n\
nonf_publicism - Publicism\n\
nonf_criticism - Criticism\n\
design - Art & design\n\
nonfiction - Other\n\
#Religion & Inspiration\n\
religion_rel - Religion\n\
religion_esoterics - Esoterics\n\
religion_self - Self-improvement\n\
religion - Other\n\
#Humor\n\
humor_anecdote - Anecdote (funny stories)\n\
humor_prose - Prose\n\
humor_verse - Verses\n\
humor - Other\n\
#Home & Family\n\
home_cooking - Cooking\n\
home_pets - Pets\n\
home_crafts - Hobbies & Crafts\n\
home_entertain - Entertaining\n\
home_health - Health\n\
home_garden - Garden\n\
home_diy - Do it yourself\n\
home_sport - Sports\n\
home_sex - Erotica & sex\n\
home - Other";

static char **genre_texts;
static char **genre_names;

static void init_genres(void)
{
    int n,gpos;
    char *c,*cns;
    if (genre_names) return;
    for (c=genre_string,n=0;*c;c++) if (*c=='\n') n++;
    genre_names=g_malloc(sizeof(char *) * n);
    genre_texts=g_malloc(sizeof(char *) * n);
    gpos=0;
    void vadd(char *c)
    {
        char *d,*str,*a,*b;
        char buf[256];
        d=strchr(c,' ');
        if (!d) return;
        str=g_malloc((d-c)+1);
        memcpy(str,c,d-c);
        str[d-c]=0;
        genre_names[gpos]=str;
        c=d;
        for (a=buf,b=cns;*b && *b!='\n';) *a++=*b++;
        for (;*c && *c!='\n';) *a++=*c++;
        *a=0;
        genre_texts[gpos]=g_strdup(buf);
        gpos++;
    }
    for (c=genre_string;*c;) {
        if (*c=='#') {
            c++;
            cns=c;
        }
        else {
            vadd(c);
        }
        c=strchr(c,'\n');
        if (!c) break;
        c++;
    }
    genre_names[gpos]=NULL;
    genre_texts[gpos]=NULL;
}

static char *PersonHeaders[]={"Imię","Drugie imię","Pseudonim","Nazwisko","E-mail","URL"};

static int tempty(char const *c)
{
	for (;*c && isspace(*c);c++);
	return !*c;
}

static char *trimdup(char const *c)
{
	for (;*c && isspace(*c);c++);
	char *d=g_strdup(c);
	return trim(d);
}

static int EditPerson(GtkWindow *win,char *title,char **names)
{
    GtkWidget *dialog=gtk_dialog_new_with_buttons(
		"Podaj dane o książce",
		(gpointer)win,
		GTK_DIALOG_MODAL,
		GTK_STOCK_OK,GTK_RESPONSE_ACCEPT,
		GTK_STOCK_CANCEL,GTK_RESPONSE_REJECT,
		NULL);
	GtkWidget *vbox=gtk_dialog_get_content_area((gpointer)dialog);
	GtkWidget *stable=gtk_table_new(2,4,0);
	gtk_box_pack_start(GTK_BOX(vbox),stable,FALSE,FALSE,0);
	GtkWidget *label,*fields[6];
	int i;
	for (i=0;i<6;i++) {
		label=gtk_label_new(PersonHeaders[i]);
		fields[i]=gtk_entry_new();
		gtk_entry_set_text((gpointer)fields[i],names[i]);
		gtk_table_attach_defaults((gpointer)stable,label,0,1,i,i+1);
		gtk_table_attach_defaults((gpointer)stable,fields[i],1,2,i,i+1);
		connect_label(label,fields[i]);
	}
    gtk_widget_show_all((gpointer)vbox);
    for (;;) {
		int n=gtk_dialog_run((gpointer)dialog);
		char *cps[6];
		if (n != GTK_RESPONSE_ACCEPT) {
			gtk_widget_destroy(dialog);
			return 0;
		}
		for (i=0;i<6;i++) cps[i]=(char *)gtk_entry_get_text((gpointer)fields[i]);
		if (tempty(cps[3])) {
			if (!tempty(cps[0]) || !tempty(cps[1])) {
				Error2("Błąd","Nazwisko nie może być puste jeśli podajesz imię",(gpointer)win);
				continue;
			}
			if (tempty(cps[2])) {
				Error2("Błąd","Musisz podać nazwisko lub pseudonim",(gpointer)win);
				continue;
			}
		}
		for (i=0;i<6;i++) {
			names[i]=trimdup(cps[i]);
		}
		break;
	}
	gtk_widget_destroy(dialog);
	return 1;
}

#define Pos P,P+1
struct FB2Context *FB2EditContext(struct FB2Context *ctx,int *do_foot,int *do_anno)
{
    init_genres();


    GtkTreeView *genre_treeview;
    GtkListStore *genre_liststore;
	GtkTreeViewColumn *genre_cols[2];
    GtkTreeView *auth_treeview;
    GtkListStore *auth_liststore;
	GtkTreeViewColumn *auth_cols[6];
    GtkTreeView *tran_treeview;
    GtkListStore *tran_liststore;
	GtkTreeViewColumn *tran_cols[6];
    GtkCellRenderer *renderer;
    GtkWidget *cb_cover=NULL;
    GtkWidget *imgchooser=NULL;
	GtkWidget *w;
    GtkWidget *vub;
    GtkTreeIter iter;
    int i;
    int P=0;


    GtkWidget *dialog=gtk_dialog_new_with_buttons(
		"Podaj dane o książce",
		(gpointer)main_window,
		GTK_DIALOG_MODAL,
		GTK_STOCK_OK,GTK_RESPONSE_ACCEPT,
		GTK_STOCK_CANCEL,GTK_RESPONSE_REJECT,
		NULL);
	GtkWidget *vbox=gtk_dialog_get_content_area((gpointer)dialog);

	GtkWidget *stable=gtk_table_new(3,4,0);
	gtk_box_pack_start(GTK_BOX(vbox),stable,FALSE,FALSE,0);
    GtkWidget *label=gtk_label_new("Tytuł");
    P++;
	gtk_table_attach_defaults((gpointer)stable,label,0,1,Pos);
    GtkWidget *title_entry=gtk_entry_new();
	gtk_table_attach_defaults((gpointer)stable,title_entry,1,3,Pos);
    if (ctx->title) gtk_entry_set_text((gpointer)title_entry,ctx->title);
    connect_label(label,title_entry);
    label=gtk_label_new("ID");
    P++;
	gtk_table_attach_defaults((gpointer)stable,label,0,1,Pos);
    GtkWidget *id_entry=gtk_entry_new();
	gtk_table_attach_defaults((gpointer)stable,id_entry,1,2,Pos);
    if (ctx->id) gtk_entry_set_text((gpointer)id_entry,ctx->id);
    connect_label(label,id_entry);
    void new_id(void)
    {
        unsigned char uuid[16];char uuname[256];
        create_uuid(uuid,uuname);
        gtk_entry_set_text((gpointer)id_entry,uuname);
    }
    GtkWidget *newid=gtk_button_new_with_label("Nowy ID");
    gtk_table_attach_defaults((gpointer)stable,newid,2,3,Pos);
    P++;
    g_signal_connect(G_OBJECT(newid),"clicked",G_CALLBACK(new_id),NULL);


	void set_coverfile_active(GtkWidget *w)
    {
        gtk_widget_set_sensitive(imgchooser,
            gtk_toggle_button_get_active((gpointer)w)
        );
    }

    cb_cover=gtk_check_button_new_with_label("Plik okładki");
    gtk_table_attach_defaults((gpointer)stable,cb_cover,0,1,Pos);
    imgchooser=gtk_file_chooser_button_new("Wybierz plik okładki",
        GTK_FILE_CHOOSER_ACTION_OPEN);
    ICPAddPreview((gpointer)imgchooser);
    gtk_file_chooser_set_local_only((gpointer)imgchooser,TRUE);
    gtk_file_chooser_button_set_width_chars((gpointer)imgchooser,50);
    atk_object_set_name(gtk_widget_get_accessible(imgchooser),"Plik okładki");
    GtkFileFilter *filter;
    gtk_file_chooser_add_filter((gpointer) imgchooser,
            filter=make_filter("Pliki JPG","*.jpg","*.JPG","*.jpeg","*.JPEG",NULL));
    gtk_file_chooser_add_filter((gpointer) imgchooser,
            make_filter("Wszystkie pliki","*",NULL));
    gtk_file_chooser_set_filter((gpointer) imgchooser,filter);
    atk_object_set_name(gtk_widget_get_accessible(imgchooser),"Wybierz plik okładki");

    gtk_table_attach_defaults((gpointer)stable,imgchooser,1,3,Pos);
    P++;

    if (ctx->cover) {
        gtk_file_chooser_set_filename((gpointer)imgchooser,ctx->cover);
        gtk_toggle_button_set_active((gpointer)cb_cover,TRUE);
        gtk_widget_set_sensitive(imgchooser,TRUE);
    }
    else {
		char *path=get_current_path();
        gtk_widget_set_sensitive(imgchooser,FALSE);
		if (path) {
			gtk_file_chooser_set_current_folder((gpointer)imgchooser,path);
			g_free(path);
		}
    }
    g_signal_connect(G_OBJECT(cb_cover),"toggled",G_CALLBACK(set_coverfile_active),NULL);


    GtkWidget *cb_foot=NULL,*cb_anno=NULL,*cb_seq=NULL,*en_seq,*spin_seq;
    if (do_foot && *do_foot) {
        cb_foot=gtk_check_button_new_with_label("Przypisy na końcu");
        gtk_table_attach_defaults((gpointer)stable,cb_foot,0,3,Pos);
        gtk_toggle_button_set_active((gpointer)cb_foot,!ctx->nofootnotes);
        P++;
    }
    if (do_anno && *do_anno) {
        cb_anno=gtk_check_button_new_with_label("Użyj pierwszego rozdziału jako adnotacji");
        gtk_table_attach_defaults((gpointer)stable,cb_anno,0,3,Pos);
        gtk_toggle_button_set_active((gpointer)cb_anno,ctx->firstanno);
        P++;
    }
    cb_seq=gtk_check_button_new_with_label("Seria");
    gtk_table_attach_defaults((gpointer)stable,cb_seq,0,1,Pos);
    en_seq=gtk_entry_new();
    atk_object_set_name(gtk_widget_get_accessible(en_seq),"Nazwa serii");
    gtk_table_attach_defaults((gpointer)stable,en_seq,1,2,Pos);
    spin_seq=gtk_spin_button_new_with_range(0.0,100.0,1.0);
    atk_object_set_name(gtk_widget_get_accessible(spin_seq),"Numer serii");
    gtk_table_attach_defaults((gpointer)stable,spin_seq,2,3,Pos);
    P++;
    if (ctx->seq_name) {
        gtk_toggle_button_set_active((gpointer)cb_seq,TRUE);
        gtk_entry_set_text((gpointer)en_seq,ctx->seq_name);
        gtk_spin_button_set_value((gpointer)spin_seq,ctx->seq_number);
    }
    else {
        gtk_toggle_button_set_active((gpointer)cb_seq,FALSE);
        gtk_widget_set_sensitive(en_seq,FALSE);
        gtk_widget_set_sensitive(spin_seq,FALSE);
    }

	void set_sequence_active(GtkWidget *w)
    {
        gtk_widget_set_sensitive(en_seq,
            gtk_toggle_button_get_active((gpointer)w)
        );
        gtk_widget_set_sensitive(spin_seq,
            gtk_toggle_button_get_active((gpointer)w)
        );
    }
    g_signal_connect(G_OBJECT(cb_seq),"toggled",G_CALLBACK(set_sequence_active),NULL);

    auth_treeview=(gpointer)gtk_tree_view_new();
    for (i=0;i<6;i++) {
        renderer=gtk_cell_renderer_text_new();
        gtk_tree_view_insert_column_with_attributes (auth_treeview,-1,
                                               PersonHeaders[i],
                                               renderer,
                                               "text", i, NULL);
    }
	auth_liststore=gtk_list_store_new(6,
        G_TYPE_STRING,G_TYPE_STRING,
        G_TYPE_STRING,G_TYPE_STRING,
        G_TYPE_STRING,G_TYPE_STRING);

	gtk_tree_view_set_model(auth_treeview,(gpointer)auth_liststore);
	g_object_unref(auth_liststore);
    for (i=0;i<6;i++) {
        auth_cols[i]=gtk_tree_view_get_column(auth_treeview,i);
        gtk_tree_view_column_set_sizing(auth_cols[i],GTK_TREE_VIEW_COLUMN_GROW_ONLY);
        gtk_tree_view_column_set_resizable(auth_cols[i],TRUE);
        gtk_tree_view_column_set_min_width(auth_cols[i],64);
    }
#ifndef HAVE_GTK3
	gtk_widget_set_size_request((gpointer)auth_treeview,600,80);
#endif

	void set_nameiter(GtkListStore *list,GtkTreeIter *iter,char **names)
	{
		int i;
		gtk_list_store_set (list, iter,
                      0, names[0],
                      1, names[1],
                      2, names[2],
                      3, names[3],
                      4, names[4],
                      5, names[5],
                      -1);
		for (i=0;i<6;i++) g_free(names[i]);
	}
	void edi_person(GtkTreeView *tv,GtkListStore *ls,char *title)
	{
			char *names[6],*fds[6];
			int i,n;
			GtkTreeSelection *sel=gtk_tree_view_get_selection(tv);
			GtkTreeModel *model;
			if (!gtk_tree_selection_get_selected(sel,&model,&iter)) return;
			for (i=0;i<6;i++) {
				gtk_tree_model_get(model,&iter,i,&names[i],-1);
			}
			for (i=0;i<6;i++) fds[i]=names[i];
			n=EditPerson((gpointer)dialog,title,names);
			for (i=0;i<6;i++) g_free(fds[i]);
			if (n) set_nameiter(ls,&iter,names);
	}

	void del_tv(GtkTreeView *tv)
	{
		GtkTreeSelection *sel=gtk_tree_view_get_selection(tv);
		GtkTreeModel *model;
		if (!gtk_tree_selection_get_selected(sel,&model,&iter)) return;
		gtk_list_store_remove((gpointer)model, &iter);
	}

	void del_author(void)
	{
		del_tv(auth_treeview);
	}
	void new_author(void)
	{
		char *names[6]={"","","","","",""};
		if (!EditPerson((gpointer)dialog,"Nowy autor",names)) return;
        gtk_list_store_append (auth_liststore, &iter);
        set_nameiter(auth_liststore,&iter,names);
	}


	void edi_author(void)
	{
		edi_person(auth_treeview,auth_liststore,"Popraw autora");
	}

    w=(gpointer)gtk_scrolled_window_new(NULL,NULL);
    gtk_scrolled_window_set_policy((gpointer)w,GTK_POLICY_NEVER,GTK_POLICY_ALWAYS);
	GtkWidget *frame=(gpointer)gtk_frame_new("Autorzy");
	GtkWidget *hboo=gtk_hbox_new(0,0);
	gtk_box_pack_start(GTK_BOX(hboo),(gpointer)w,FALSE,FALSE,0);

    GtkWidget *delbut=gtk_button_new_with_label("Usuń");
    vub=gtk_vbox_new(0,0);
    gtk_box_pack_start(GTK_BOX(vub),(gpointer)delbut,FALSE,FALSE,0);
    g_signal_connect(G_OBJECT(delbut),"clicked",G_CALLBACK(del_author),NULL);
    delbut=gtk_button_new_with_label("Dodaj");
    g_signal_connect(G_OBJECT(delbut),"clicked",G_CALLBACK(new_author),NULL);
    gtk_box_pack_start(GTK_BOX(vub),(gpointer)delbut,FALSE,FALSE,0);
    delbut=gtk_button_new_with_label("Edytuj");
    g_signal_connect(G_OBJECT(delbut),"clicked",G_CALLBACK(edi_author),NULL);
    gtk_box_pack_start(GTK_BOX(vub),(gpointer)delbut,FALSE,FALSE,0);

	gtk_box_pack_start(GTK_BOX(hboo),(gpointer)vub,FALSE,FALSE,0);
	gtk_container_add((gpointer)frame,hboo);
    gtk_table_attach_defaults((gpointer)stable,frame,0,3,Pos);P++;
	gtk_container_add((gpointer)w,(gpointer)auth_treeview);

#ifdef HAVE_GTK3
	gtk_widget_set_size_request((gpointer)w,600,80);
#endif




    char *_n(char *s)
    {
		return s?s:"";
	}

    void loc_add_person(GtkListStore *liststore,struct FB2_person *pe)
    {
        gtk_list_store_append (liststore, &iter);
		gtk_list_store_set (liststore, &iter,
                      0, _n(pe->first_name),
                      1, _n(pe->middle_name),
                      2, _n(pe->nick_name),
                      3, _n(pe->last_name),
                      4, _n(pe->email),
                      5, _n(pe->home_page),
                      -1);
	}

    for (i=0;i<ctx->author_no;i++) {
        loc_add_person(auth_liststore,&ctx->authors[i]);
    }


    tran_treeview=(gpointer)gtk_tree_view_new();
    for (i=0;i<6;i++) {
        renderer=gtk_cell_renderer_text_new();
        gtk_tree_view_insert_column_with_attributes (tran_treeview,-1,
                                               PersonHeaders[i],
                                               renderer,
                                               "text", i, NULL);
    }
	tran_liststore=gtk_list_store_new(6,
        G_TYPE_STRING,G_TYPE_STRING,
        G_TYPE_STRING,G_TYPE_STRING,
        G_TYPE_STRING,G_TYPE_STRING);

	gtk_tree_view_set_model(tran_treeview,(gpointer)tran_liststore);
	g_object_unref(tran_liststore);
    for (i=0;i<6;i++) {
        tran_cols[i]=gtk_tree_view_get_column(tran_treeview,i);
        gtk_tree_view_column_set_sizing(tran_cols[i],GTK_TREE_VIEW_COLUMN_GROW_ONLY);
        gtk_tree_view_column_set_resizable(tran_cols[i],TRUE);
        gtk_tree_view_column_set_min_width(tran_cols[i],64);
    }
#ifndef HAVE_GTK3
	gtk_widget_set_size_request((gpointer)tran_treeview,600,80);
#endif

	void del_tranor(void)
	{
		del_tv(tran_treeview);
	}

	void new_tranor(void)
	{
		char *names[6]={"","","","","",""};
		if (!EditPerson((gpointer)dialog,"Nowy tłumacz",names)) return;
        gtk_list_store_append (tran_liststore, &iter);
        set_nameiter(tran_liststore,&iter,names);
	}


	void edi_tranor(void)
	{
		edi_person(tran_treeview,tran_liststore,"Popraw tłumacza");
	}


    w=(gpointer)gtk_scrolled_window_new(NULL,NULL);
    gtk_scrolled_window_set_policy((gpointer)w,GTK_POLICY_NEVER,GTK_POLICY_ALWAYS);
	frame=(gpointer)gtk_frame_new("Tłumacze");
	hboo=gtk_hbox_new(0,0);
	gtk_box_pack_start(GTK_BOX(hboo),(gpointer)w,FALSE,FALSE,0);

    delbut=gtk_button_new_with_label("Usuń");
    vub=gtk_vbox_new(0,0);
    gtk_box_pack_start(GTK_BOX(vub),(gpointer)delbut,FALSE,FALSE,0);
    g_signal_connect(G_OBJECT(delbut),"clicked",G_CALLBACK(del_tranor),NULL);
    delbut=gtk_button_new_with_label("Dodaj");
    g_signal_connect(G_OBJECT(delbut),"clicked",G_CALLBACK(new_tranor),NULL);
    gtk_box_pack_start(GTK_BOX(vub),(gpointer)delbut,FALSE,FALSE,0);
    delbut=gtk_button_new_with_label("Edytuj");
    g_signal_connect(G_OBJECT(delbut),"clicked",G_CALLBACK(edi_tranor),NULL);
    gtk_box_pack_start(GTK_BOX(vub),(gpointer)delbut,FALSE,FALSE,0);

	gtk_box_pack_start(GTK_BOX(hboo),(gpointer)vub,FALSE,FALSE,0);
	gtk_container_add((gpointer)frame,hboo);
    gtk_table_attach_defaults((gpointer)stable,frame,0,3,Pos);P++;
	gtk_container_add((gpointer)w,(gpointer)tran_treeview);
#ifdef HAVE_GTK3
	gtk_widget_set_size_request((gpointer)w,600,80);
#endif
    for (i=0;i<ctx->translator_no;i++) {
        loc_add_person(tran_liststore,&ctx->translators[i]);
    }



    genre_treeview=(gpointer)gtk_tree_view_new();
	renderer=gtk_cell_renderer_text_new();
	gtk_tree_view_insert_column_with_attributes (genre_treeview,-1,
                                               "Gatunek",
                                               renderer,
                                               "text", 0, NULL);
	renderer=gtk_cell_renderer_text_new();
	gtk_tree_view_insert_column_with_attributes (genre_treeview,-1,
                                               "Waga",
                                               renderer,
                                               "text", 1, NULL);

	genre_liststore=gtk_list_store_new(2,G_TYPE_STRING,G_TYPE_STRING);
	gtk_tree_view_set_model(genre_treeview,(gpointer)genre_liststore);
	g_object_unref(genre_liststore);

	genre_cols[0]=gtk_tree_view_get_column(genre_treeview,0);
	genre_cols[1]=gtk_tree_view_get_column(genre_treeview,1);
	gtk_tree_view_column_set_sizing(genre_cols[0],GTK_TREE_VIEW_COLUMN_AUTOSIZE);
	gtk_tree_view_column_set_min_width(genre_cols[0],320);
	gtk_tree_view_column_set_sizing(genre_cols[1],GTK_TREE_VIEW_COLUMN_FIXED);
	gtk_tree_view_column_set_fixed_width(genre_cols[1],64);
#ifndef HAVE_GTK3
	gtk_widget_set_size_request((gpointer)genre_treeview,-1,80);
#endif
    w=(gpointer)gtk_scrolled_window_new(NULL,NULL);
    gtk_table_attach_defaults((gpointer)stable,w,0,2,Pos);
	gtk_container_add((gpointer)w,(gpointer)genre_treeview);
#ifdef HAVE_GTK3
	gtk_widget_set_size_request((gpointer)w,-1,80);
#endif

    char *genre_name(char *name)
    {
        int i;
        for (i=0;genre_texts[i];i++) {
            if (!strcmp(genre_names[i],name)) {
                return genre_texts[i];
            }
        }
        return "==UNKNOWN==";
    }

    void loc_add_genre(char *name,int weight)
    {
        char buf[32];
        if (weight) sprintf(buf,"%d",weight);
        else buf[0]=0;
        gtk_list_store_append (genre_liststore, &iter);
		gtk_list_store_set (genre_liststore, &iter,
                      0, genre_name(name),
                      1, buf,
                      -1);
	}

    for (i=0;i<ctx->genre_no;i++) {
        loc_add_genre(ctx->genres[i].name,ctx->genres[i].weight);
    }

    void del_genre(void)
    {
        del_tv(genre_treeview);
    }



    delbut=gtk_button_new_with_label("Usuń");
    vub=gtk_vbox_new(0,0);
    gtk_box_pack_start(GTK_BOX(vub),(gpointer)delbut,FALSE,FALSE,0);
    gtk_table_attach_defaults((gpointer)stable,vub,2,3,Pos);P++;
    g_signal_connect(G_OBJECT(delbut),"clicked",G_CALLBACK(del_genre),NULL);


    label=gtk_label_new("Gatunek");
	gtk_table_attach_defaults((gpointer)stable,label,0,1,Pos);
    vub=gtk_hbox_new(0,0);
    GtkWidget *g_genre=gtk_combo_box_new_text();
    for (i=0;genre_texts[i];i++) {
        gtk_combo_box_append_text((gpointer)g_genre,genre_texts[i]);
    }
    gtk_box_pack_start((gpointer)vub,g_genre,TRUE,FALSE,0);
    gtk_combo_box_set_active((gpointer)g_genre,0);
    connect_label(label,g_genre);

    GtkWidget *n_genre=gtk_spin_button_new_with_range(0.0,100.0,1.0);
    atk_object_set_name(gtk_widget_get_accessible(en_seq),"Waga gatunku");
    gtk_box_pack_start((gpointer)vub,n_genre,TRUE,FALSE,0);

    void new_genre(void)
    {
        char *tx=gtk_combo_box_get_active_text((gpointer)g_genre);
        int n=gtk_spin_button_get_value_as_int((gpointer)n_genre);
        char buf[32];
        if (n) sprintf(buf,"%d",n);
        else buf[0]=0;
        gtk_list_store_append (genre_liststore, &iter);
		gtk_list_store_set (genre_liststore, &iter,
                      0, tx,
                      1, buf,
                      -1);
    }

	gtk_table_attach_defaults((gpointer)stable,vub,1,2,Pos);
    GtkWidget *but=gtk_button_new_with_label("Dodaj");
    atk_object_set_name(gtk_widget_get_accessible(but),"Dodaj gatunek");
    gtk_table_attach_defaults((gpointer)stable,but,2,3,Pos);P++;
    g_signal_connect(G_OBJECT(but),"clicked",G_CALLBACK(new_genre),NULL);
    FB2FreeContext(ctx);
    gtk_widget_show_all((gpointer)vbox);
    for (;;) {
        int n=gtk_dialog_run((gpointer)dialog);
        char const *txt_tit;
        char const *txt_id;
        char const *txt_cvr;
        char const *txt_seq;

        if (n != GTK_RESPONSE_ACCEPT) {
            gtk_widget_destroy(dialog);
            return NULL;
        }
        if (tempty((char *)(txt_tit=gtk_entry_get_text((gpointer)title_entry)))) {
            Error2("Błąd","Podaj tytuł książki",(gpointer)dialog);
            continue;
        }
        if (tempty((char *)(txt_id=gtk_entry_get_text((gpointer)id_entry)))) {
            Error2("Błąd","Podaj ID książki",(gpointer)dialog);
            continue;
        }
        if (!gtk_toggle_button_get_active((gpointer)cb_cover)) {
            txt_cvr=NULL;
        }
        else {
            txt_cvr=gtk_file_chooser_get_filename((gpointer)imgchooser);
            if (!txt_cvr || tempty(txt_cvr)) {
                Error2("Błąd","Podaj ścieżkę do obrazka okładki",(gpointer)dialog);
                continue;
            }
        }
        if (!gtk_toggle_button_get_active((gpointer)cb_seq)) {
             txt_seq=NULL;
        }
        else {
            txt_seq=gtk_entry_get_text((gpointer)en_seq);
            if (!txt_seq || tempty(txt_seq)) {
                Error2("Błąd","Podaj nazwę serii",(gpointer)dialog);
                continue;
            }
        }
        int a_count=0;
        gboolean forea_a(GtkTreeModel *model,
                GtkTreePath  *path,
                GtkTreeIter  *iter,
                gpointer      user_data)
        {
            a_count++;
            return FALSE;
        }
        gtk_tree_model_foreach(GTK_TREE_MODEL(auth_liststore), forea_a, NULL);
        if (!a_count) {
            Error2("Błąd","Podaj co najmniej jednego autora",(gpointer)dialog);
            continue;
        }
        int auth_count=a_count;
        a_count=0;
        gtk_tree_model_foreach(GTK_TREE_MODEL(genre_liststore), forea_a, NULL);
        if (!a_count) {
            Error2("Błąd","Podaj co najmniej jeden gatunek",(gpointer)dialog);
            continue;
        }
        int genre_count=a_count;

        a_count=0;
        gtk_tree_model_foreach(GTK_TREE_MODEL(tran_liststore), forea_a, NULL);
        int tran_count=a_count;

        ctx=FB2ContextInit();
        ctx->title=trimdup(txt_tit);
        ctx->id=trimdup(txt_id);
        if (txt_cvr) ctx->cover=trimdup(txt_cvr);
        if (txt_seq) {
            ctx->seq_name=trimdup(txt_seq);
            ctx->seq_number=gtk_spin_button_get_value_as_int((gpointer)spin_seq);
        }
        int forea_genre(GtkTreeModel *model,
                GtkTreePath  *path,
                GtkTreeIter  *iter,
                gpointer      user_data)
        {
            char *pth,*nme,*wgt;int weight,i;
            gtk_tree_model_get(model,iter,0,&pth,-1);
            gtk_tree_model_get(model,iter,1,&wgt,-1);
            weight=strtol(wgt,NULL,10);
            g_free(wgt);
            nme=NULL;
            for (i=0;genre_texts[i];i++) if (!strcmp(genre_texts[i],pth)) {
               nme=genre_names[i];
               break;
            }
            g_free(pth);
            if (nme) {
                ctx->genres[ctx->genre_no].name=g_strdup(nme);
                ctx->genres[ctx->genre_no++].weight=weight;
            }

            return FALSE;
        }
        if (genre_count) {
            ctx->genre_si=genre_count;
            ctx->genre_no=0;
            ctx->genres=g_malloc_n(genre_count,sizeof(*ctx->genres));
            gtk_tree_model_foreach(GTK_TREE_MODEL(genre_liststore), forea_genre, NULL);
        }
        int *this_penr;
        struct FB2_person *this_pebd;
        int forea_person(GtkTreeModel *model,
                GtkTreePath  *path,
                GtkTreeIter  *iter,
                gpointer      user_data)
        {
            char *p;
            gtk_tree_model_get(model,iter,0,&p,-1);
            if (!tempty(p)) this_pebd->first_name=trimdup(p);g_free(p);
            gtk_tree_model_get(model,iter,1,&p,-1);
            if (!tempty(p)) this_pebd->middle_name=trimdup(p);g_free(p);
            gtk_tree_model_get(model,iter,2,&p,-1);
            if (!tempty(p)) this_pebd->nick_name=trimdup(p);g_free(p);
            gtk_tree_model_get(model,iter,3,&p,-1);
            if (!tempty(p)) this_pebd->last_name=trimdup(p);g_free(p);
            gtk_tree_model_get(model,iter,4,&p,-1);
            if (!tempty(p)) this_pebd->email=trimdup(p);g_free(p);
            gtk_tree_model_get(model,iter,5,&p,-1);
            if (!tempty(p)) this_pebd->home_page=trimdup(p);g_free(p);
            this_pebd++;
            (*this_penr)++;
            return FALSE;
        }
        ctx->author_si=auth_count;
        ctx->authors=g_malloc0_n(auth_count,sizeof(*ctx->authors));
        ctx->author_no=0;
        this_penr=&ctx->author_no;
        this_pebd=ctx->authors;
        gtk_tree_model_foreach(GTK_TREE_MODEL(auth_liststore), forea_person, NULL);
        ctx->translator_si=tran_count;
        ctx->translator_no=0;
        if (tran_count) {
            ctx->translators=g_malloc0_n(tran_count,sizeof(*ctx->translators));
            this_penr=&ctx->translator_no;
            this_pebd=ctx->translators;
            gtk_tree_model_foreach(GTK_TREE_MODEL(tran_liststore), forea_person, NULL);
        }
        break;
    }
    if (do_foot && cb_foot) {
        *do_foot=gtk_toggle_button_get_active((gpointer)cb_foot);
        ctx->nofootnotes=!*do_foot;
    }
    if (do_anno && cb_anno) {
        *do_anno=gtk_toggle_button_get_active((gpointer)cb_anno);
        ctx->firstanno=*do_anno;
    }
    gtk_widget_destroy(dialog);
    return ctx;
}
#undef Pos
