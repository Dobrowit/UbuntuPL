function goText()
{
	var el=document.getElementsByTagName('h2')[0];
	if (el) {
		el.setAttribute('tabIndex',0);
		el.focus()
        var evt = document.createEvent("MouseEvents");
        evt.initMouseEvent("mousedown", true, true, window,
                        0, 0, 0, 0, 0, false, false, false, false, 0, null);
                    el.dispatchEvent(evt);
	}
}
