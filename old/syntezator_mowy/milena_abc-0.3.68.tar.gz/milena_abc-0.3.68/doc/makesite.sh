#!/bin/sh
inname=$1
outname=`basename $1 .in`.html
title=`head -n 1 $inname | awk '{print substr($0,5,length($0)-9)}'`
sed -e s@%%TITLE%%@"${title}"@g -e '/^<!--TRESC/ r '$inname \
    < frame.pat >$outname


