/*
 * convert.c - Milena Audiobook Creator
 * Copyright (C) Bohdan R. Rau 2009 <ethanak@polip.com>
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write see:
 *               <http://www.gnu.org/licenses/>.
 */
#include "config.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <iconv.h>
#include <ctype.h>
#include <milena.h>
#include <glib.h>


int ignore_oor;
int count_bad_char;

int get_unichar(char **str)
{
	int znak,n,m;
	if (!*str) return 0;
	znak=(*(*str)++) & 255;
	if (!(znak & 0x80)) return znak;
	if ((znak & 0xe0)==0xc0) n=1;
	else if ((znak & 0xf0)==0xe0) n=2;
	else {
#ifdef __WIN32
		MessageBox(NULL,"Znaki powyzej \\uFFFF nie sa obslugiwane",NULL,MB_OK | MB_ICONERROR);
#else
		fprintf(stderr,"Znaki powyzej \\uFFFF nie sa obslugiwane\n");
#endif
		return 0;
	}
	znak &= 0x1f;
	while (n--) {
		m=*(*str)++ & 255;
		if ((m & 0xc0)!=0x80) {
#ifdef __WIN32
			MessageBox(NULL,"Bledna sekwencja UTF-8",NULL,MB_OK | MB_ICONERROR);
#else
			fprintf(stderr,"Bledna sekwencja UTF-8\n");
#endif
			return 0;
		}
		znak=(znak<<6) | (m & 0x3f);
	}
	return znak;
}

int to_iso2_mp(char *instr,char *outstr,char **instrpos,int maxpos)
{
    count_bad_char=0;
    return milena_utf2iso_mp(instr,outstr,ignore_oor,&count_bad_char,instrpos,maxpos);
}


int to_iso2(char *instr,char *outstr)
{
	return to_iso2_mp(instr,outstr,NULL,0);
}

char *to_utf8(char *fbuf,int flen,char *cset,int freeme)
{
	iconv_t ic;
	char pbuf[256];
	size_t inlen,outlen,desclen;
	char *ubody,*c,*d;
	ic=iconv_open("UTF-8",cset);
	if (ic == (iconv_t)-1) {
		perror(cset);
		exit(1);
	}
	desclen=0;
	inlen=flen;
	c=fbuf;
	while(inlen) {
		outlen=256;
		d=pbuf;
		iconv(ic,&c,&inlen,&d,&outlen);
		if (outlen == 256) {
			perror("iconv");
			exit(1);
		}
		desclen+=256-outlen;
	}
	ubody=g_malloc(desclen+1);
	iconv(ic,NULL,NULL,NULL,NULL);
	c=fbuf;
	d=ubody;
	inlen=flen;
	outlen=desclen;
	iconv(ic,&c,&inlen,&d,&outlen);
	if (inlen) {
		perror("iconv");
		exit(1);
	}
	iconv_close(ic);
	ubody[desclen]=0;
	if (freeme) g_free(fbuf);
	return ubody;
}

