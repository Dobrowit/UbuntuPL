/*
 * amrwb.c - Milena Audiobook Creator
 * Copyright (C) Bohdan R. Rau 2009 <ethanak@polip.com>
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write see:
 *               <http://www.gnu.org/licenses/>.
 */
#include "config.h"
#include "gmilena.h"
#include <dlfcn.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#ifdef HAVE_SAMPLERATE
#include <samplerate.h>
static SRC_STATE *resampler;
static SRC_DATA res_data;
int resampler_error;
static short resample_out[4*8192];
#endif

typedef void (*AMRWBVF) (FILE *);
typedef int (*AMRWBIV) (void);
typedef void *(*AMRWBPV) (void);
typedef int (*AMRWBSX) (void *,short,short*,unsigned char *,short);
typedef void (*AMRWBVP) (void *);


static AMRWBIV amrwb_get_sample_count=NULL;
static AMRWBIV amrwb_get_buffer_size=NULL;
static AMRWBPV E_IF_init=NULL;
static AMRWBVP E_IF_exit=NULL;
static AMRWBSX E_IF_encode=NULL;
static AMRWBVF amrwb_dll_magic=NULL;

static void * amrwb_dll=NULL;
#define L_FRAME16k   320   /* Frame size at 16kHz  */
#define NB_SERIAL_MAX 61   /* max serial size      */
static void _amrwb_dll_magic(FILE *f_serial)
{
#ifndef IF2
#define AMRWB_MAGIC_NUMBER "#!AMR-WB\n"

        fwrite(AMRWB_MAGIC_NUMBER, sizeof(char), strlen(AMRWB_MAGIC_NUMBER), f_serial);
#endif
}
static int _amrwb_get_sample_count(void)
{
        return L_FRAME16k;
}

static int _amrwb_get_buffer_size(void)
{
        return NB_SERIAL_MAX;
}

static int amr_initialized=0;

static short *amr_readbuf;
static int amrsamples;
static unsigned char *amr_stream;

static int amr_readpos;
static long int amr_samplenum;
static int amr_mode,amr_dtx;
static FILE *amr;
static void *coder;

int init_amrwb(void)
{
	if (amr_initialized) return 1;
	if (!amrwb_dll) {
		amrwb_dll=dlopen("libvo-amrwbenc.so.0",RTLD_LAZY);
		if (!amrwb_dll) {
			amrwb_dll=dlopen("libamrwb_mil.so",RTLD_LAZY);
			if (!amrwb_dll) {
				Error("Biblioteka amrwb","Nie znaleziono libvo-amrwbenc.so ani libamrwb_mil.so");
				return 0;
			}
		}
	}
	amrwb_get_sample_count=(AMRWBIV) dlsym(amrwb_dll,"amrwb_get_sample_count");
	amrwb_get_buffer_size=(AMRWBIV) dlsym(amrwb_dll,"amrwb_get_buffer_size");
	amrwb_dll_magic=(AMRWBVF) dlsym(amrwb_dll,"amrwb_dll_magic");
	E_IF_init=(AMRWBPV) dlsym(amrwb_dll,"E_IF_init");
	E_IF_exit=(AMRWBVP) dlsym(amrwb_dll,"E_IF_exit");
	E_IF_encode=(AMRWBSX) dlsym(amrwb_dll,"E_IF_encode");
	if (!amrwb_get_sample_count) amrwb_get_sample_count=_amrwb_get_sample_count;
	if (!amrwb_get_buffer_size) amrwb_get_buffer_size=_amrwb_get_buffer_size;
	if (!amrwb_dll_magic) amrwb_dll_magic=_amrwb_dll_magic;
	if (!E_IF_init ||
		!E_IF_exit ||
		!E_IF_encode) {
			Error("Biblioteka amrwb","Niemozliwa inicjalizacja amrwb");
			return 0;

	}
	amrsamples=amrwb_get_sample_count();
	amr_readbuf=malloc(2*amrsamples);
	amr_stream=malloc(amrwb_get_buffer_size());
	amr_initialized=1;
	return 1;
}

static int amr_resample;

int start_amrwb(char *fname,int mode,int dtx)
{
	if (!init_amrwb()) return 0;
	amr_mode=mode;
	amr_dtx=dtx;
	amr_readpos=0;
	amr_samplenum=0;
    amr_resample=0;
#ifdef HAVE_IVONA
    if (use_ivona) {
        int freq=ivona_getfreq();
        if (freq != 16000) {
#ifdef HAVE_SAMPLERATE
            amr_resample=1;
            resampler=src_new (SRC_SINC_MEDIUM_QUALITY, 1, &resampler_error) ;
            if (!res_data.data_in) res_data.data_in=malloc(8192*sizeof(float));
            if (!res_data.data_out)res_data.data_out=malloc(4*8192*sizeof(float));
            res_data.src_ratio=16000.0/(double)freq;
#else
            Error("Błąd","Nie potrafię nagrać AMR z częstotliwością inną niż 16 kHz");
            return 0;
#endif
        }
    }
#endif
	amr=fopen(fname,"wb");
	if (!amr) {
		g_perror(fname);
		return 0;
	}
	amrwb_dll_magic(amr);
	coder=E_IF_init();
	return 1;
}

static int encode_amrwb_internal(short *buf,int nsamples)
{
	while (nsamples >0) {
		int nsm=nsamples;
		int serial_size;
		if (nsm > amrsamples - amr_readpos) {
			nsm=amrsamples - amr_readpos;
		}
		memcpy(amr_readbuf+amr_readpos,buf,2*nsm);
		amr_readpos+=nsm;
		buf+=nsm;
		nsamples-=nsm;
		if (amr_readpos == amrsamples) {
			amr_samplenum+=amrsamples;
			serial_size = E_IF_encode(coder, amr_mode, amr_readbuf, amr_stream, amr_dtx);
			if (serial_size) fwrite(amr_stream,1,serial_size,amr);
			amr_readpos=0;
		}
	}
	return 1;
}

int encode_amrwb(short *buf,int nsamples)
{
#ifndef HAVE_SAMPLERATE
    return encode_amrwb_internal(buf,nsamples);
#else
    if (!amr_resample) {
        return encode_amrwb_internal(buf,nsamples);
    }
    while (nsamples > 0) {
        int n=1024,i;
        if (n > nsamples) n=nsamples;
        src_short_to_float_array(buf,res_data.data_in,n);
        res_data.input_frames=n;
        res_data.end_of_input=0;
        res_data.output_frames=8*4096;
        src_process(resampler,&res_data);
        n=res_data.input_frames_used;
        nsamples -= n;
        buf += n;
        i=res_data.output_frames_gen;
        if (i) {
            src_float_to_short_array(res_data.data_out,resample_out,i);
            encode_amrwb_internal(resample_out,i);
        }
    }
    return 1;
#endif
}

int finish_amrwb(void)
{
#ifdef HAVE_SAMPLERATE
    if (resampler) src_delete(resampler);
    resampler=NULL;
#endif
	if (amr) fclose(amr);amr=NULL;
	if (coder) E_IF_exit(coder);coder=NULL;
	return 1;
}

double amr_get_seconds(void)
{
	return amr_samplenum/16000.0;
}

