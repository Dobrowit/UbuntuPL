/*
 * ao.c - Milena Audiobook Creator
 * Copyright (C) Bohdan R. Rau 2009-2012 <ethanak@polip.com>
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write see:
 *               <http://www.gnu.org/licenses/>.
 */
#include "config.h"
#include "gmilena.h"
#include <ao/ao.h>
#include <string.h>
#include <dlfcn.h>
#include <stdlib.h>
//#ifdef HAVE_PULSE
//#include <pulse/simple.h>
//#include <pulse/error.h>
//#endif

int use_pulse=0;
static int internal_use_pulse;
int pulse_margin=300;

int audio_close_device(void);

static int playing;

static ao_device *device;
static int driver=-1;
static ao_sample_format format;
static int ao_initialized;
int dont_close_audiodevice;

static int init_ao(int rate)
{
	format.bits = 16;
	format.channels = 1;
	format.rate = rate;
	format.byte_format = AO_FMT_LITTLE;

	if (!ao_initialized) ao_initialize();
	if (driver == -1) {
		driver = ao_default_driver_id();
		if (driver == -1) {
			return 0;
		}
	}
	if (!device) device = ao_open_live(driver, &format, NULL);
	if (!device) {
		return 0;
	}
	return 1;
}


#ifdef HAVE_PULSE

typedef struct mypa_simple mypa_simple;
typedef enum {
	__pa_sample_16le=3,
	__pa_sample_d1=13,
	__pa_sample_d2=-1} mypa_format_t;

typedef struct mypa_sample_spec {
    mypa_format_t format;
    u_int32_t rate;
    u_int8_t channels;
} mypa_sample_spec;

typedef struct mypa_buffer_attr {
    u_int32_t maxlength;
    u_int32_t tlength;
    u_int32_t prebuf;
    u_int32_t minreq;
    u_int32_t fragsize;
} mypa_buffer_attr;


#define __pa_stream_playback 1

static mypa_simple * (*mypa_simple_new)(
    const char *,
    const char *,
    int,
    const char *,
    const char *,
    const mypa_sample_spec *,
    void *,
    const mypa_buffer_attr *,
    int *);

static void (*mypa_simple_free)(mypa_simple *);
static int (*mypa_simple_write)(mypa_simple *, const void*, size_t,int *);
static int (*mypa_simple_drain)(mypa_simple *, int *);
static int (*mypa_simple_flush)(mypa_simple *s, int *error);
static char *(*mypa_strerror)(int error);
static void *pulse_dll=NULL;




mypa_simple *p_simple;
int pulse_samples_sent;


static int mypa_init(int rate)
{
	mypa_buffer_attr buffAttr;
	mypa_sample_spec ss;
	int error;

	ss.rate = rate;
	ss.channels = 1;
	ss.format = __pa_sample_16le;
	
	format.rate = rate;

	buffAttr.maxlength = (u_int32_t)-1;
	buffAttr.tlength = 100;
	buffAttr.prebuf = (u_int32_t)-1;
	buffAttr.minreq = (u_int32_t)-1;
	buffAttr.fragsize = (u_int32_t)-1;
	p_simple = mypa_simple_new(
				NULL,
				"Milena",
				__pa_stream_playback,
				     NULL, "playback", &ss, NULL, &buffAttr, &error);
	if (!p_simple) {
		ErrorF(NULL,"PulseAudio","New: %s",mypa_strerror(error));
		return 0;
	}
	pulse_samples_sent=0;
	return 1;
}

static void mypa_close(void)
{
	if (!p_simple) return;
	if (internal_use_pulse) {
		short pbuffer[1024];
		int nc=pulse_margin * (format.rate/1000);
		int m;
		memset(pbuffer,0,sizeof(pbuffer));
		while (nc > 0) {
			m=1024;
			if (m > nc) m = nc;
			nc -= m;
			mypa_simple_write(p_simple,(char *)pbuffer,2*m,NULL);
		}
	}
	mypa_simple_free(p_simple);
	p_simple=0;
}

#endif

static int __is_pulse_enabled=0;
int enable_pulse(void)
{
	if (__is_pulse_enabled) {
		return __is_pulse_enabled > 0;
	}
#ifdef HAVE_PULSE
	if (!pulse_dll) {
		pulse_dll=dlopen("libpulse-simple.so.0",RTLD_LAZY);
		if (!pulse_dll) 
			pulse_dll=dlopen("libpulse-simple.so",RTLD_LAZY);
		if (!pulse_dll) {
			printf("pulse_simple not found\n");
			goto bad_fine;
		}
		if (!(mypa_simple_new=(void *)dlsym(pulse_dll,"pa_simple_new"))) {
			printf("pa_simple_new_not found\n");
			goto bad_fine;
		}
		if (!(mypa_simple_free=(void *)dlsym(pulse_dll,"pa_simple_free"))) {
			printf("pa_simple_free_not found\n");
			goto bad_fine;
		}
		if (!(mypa_simple_write=(void *)dlsym(pulse_dll,"pa_simple_write"))) {
			printf("pa_simple_write_not found\n");
			goto bad_fine;
		}
		if (!(mypa_simple_flush=(void *)dlsym(pulse_dll,"pa_simple_flush"))) {
			printf("pa_simple_flush_not found\n");
			goto bad_fine;
		}
		if (!(mypa_simple_drain=(void *)dlsym(pulse_dll,"pa_simple_drain"))) {
			printf("pa_simple_free_not found\n");
			goto bad_fine;
		}
		if (!(mypa_strerror=(void *)dlsym(pulse_dll,"pa_strerror"))) {
			printf("pa_strerror not found\n");
			goto bad_fine;
		}
	}
	__is_pulse_enabled=1;
	return 1;
bad_fine:
	pulse_dll=NULL;
#endif
	__is_pulse_enabled=-1;
	return 0;
}

static int init_audio(int rate)
{
#ifdef HAVE_PULSE
		internal_use_pulse=use_pulse && enable_pulse();
		if (use_pulse) {
			return mypa_init(rate);
		}
#endif
	return init_ao(rate);
}

int audio_play_sfr(short *samples,int nsamples,int rate)
{
	if (!samples) {
		if (playing) {
			audio_close_device();
		}
		return 1;
	}
    if (playing && rate != format.rate) {
		audio_close_device();
    }
	if (!playing) {
		if (!init_audio(rate)) return 0;
		playing=1;
	}
	int rc;
#ifdef HAVE_PULSE
	if (internal_use_pulse) {
		int error;
		rc = mypa_simple_write(p_simple, (char *)samples, 2*nsamples, &error) >= 0;
		if (!rc) {
			ErrorF(NULL,"PulseAudio","Write: %d",error);
		}
	}
	else
#endif
	rc=ao_play(device,(char *)samples,2*nsamples);

	if (!rc) {
		audio_close_device();
		return 0;
	}
	return 1;
}

int audio_play(short *samples,int nsamples)
{
	return audio_play_sfr(samples,nsamples,16000);
}

int audio_close_device(void)
{
	playing=0;
#ifdef HAVE_PULSE
	if (use_pulse) {
		mypa_close();
		return 1;
	}
#endif
	if (device) {
		ao_close(device);
		device=NULL;
	}
    return 1;
}
