/*
 * python.c - Milena Audiobook Creator
 * Copyright (C) Bohdan R. Rau 2012 <ethanak@polip.com>
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write see:
 *               <http://www.gnu.org/licenses/>.
 */
#include <Python.h>
#include <gtk/gtk.h>
#include "config.h"
#include <string.h>
#include <stdlib.h>
#include "gmilena.h"
#include <signal.h>


// Embedded module

static struct MyGtkEditor *_get_editor(char *which,int create)
{
	static char *modes[]={"text","dash","dict","current"};
	int n=get_current_editor();
	if (n < 0) return NULL;
	int i;
	for (i=0;i<4;i++) if (!strcasecmp(modes[i],which)) break;
	if (i >= 4) {
		PyErr_SetString(PyExc_ValueError,"parameter not in (\"text\",\"dash\",\"dict\",\"current\",None)");
		return (struct MyGtkEditor *)-1;
	}
	struct MyGtkEditor *edi=current_editor,*edzio=NULL;
	if (i < 3 && n != i) {
		if (n) edi=edi->owneditor;
		edzio=edi;
		if (!edi) return NULL;
		if (i==1) edi=edi->dash_editor;
		else if (i==2) edi=edi->dic_editor;
	}
	if (!create || edi) return edi;
	if (i != 1 && i != 2) return NULL;
	edi=get_subeditor(edzio,i);
	fflush(stdout);
	return edi;
}

static char *_emb_str(PyObject **arg,int enable_none)
{
	if (!*arg) {
		return NULL;
	}
	if (enable_none && (*arg == Py_None)) {
		*arg=NULL;
		return NULL;
	}
	if (PyString_Check(*arg)) {
		Py_INCREF(*arg);
		return PyString_AsString(*arg);
	}
	if (PyUnicode_Check(*arg)) {
		//printf ("CB %d\n",(*arg)->ob_refcnt);
		*arg=PyUnicode_AsUTF8String(*arg);
		//printf ("CC %d\n",(*arg)->ob_refcnt);
		return PyString_AsString(*arg);
	}
	if ((*arg)->ob_type->tp_str) {
		*arg=(*arg)->ob_type->tp_str(*arg);
		return PyString_AsString(*arg);
	}
	if ((*arg)->ob_type->tp_repr) {
		*arg=(*arg)->ob_type->tp_repr(*arg);
		return PyString_AsString(*arg);
	}
	
	*arg=NULL;
	return "";
}

static PyObject * emb_editorType(PyObject *self, PyObject *args)
{
	int n=get_current_editor();
	return Py_BuildValue("i", n);
}

static PyObject * emb_editorTypeS(PyObject *self, PyObject *args)
{
	static char *c[]={"Text","Dash","Dict"};
	int n=get_current_editor();
	if (n<0) Py_RETURN_NONE;
	return Py_BuildValue("s", c[n]);
}

static PyObject *emb_getfileid(PyObject *self, PyObject *args)
{
	int n = get_current_editor();
	if (n<0) Py_RETURN_NONE;
	return Py_BuildValue("i",current_editor->editor_number);
}

static PyObject *emb_yield(PyObject *self, PyObject *args)
{
	yield();
	Py_RETURN_NONE;
}

static PyObject *emb_alert(PyObject *self, PyObject *args)
{
	char *body=NULL;
	char *title=NULL;
	
	PyObject *oti=NULL,*obo=NULL;
	int rc=PyArg_ParseTuple(args,"O|O",&obo,&oti);
	if (!rc) return NULL;
	body=_emb_str(&obo,0);
	if (oti) title=_emb_str(&oti,1);
	if (!title) title="Informacja z wtyczki";
	Info(title,body);
	Py_XDECREF(obo);
	Py_XDECREF(oti);
	Py_RETURN_NONE;
}

static PyObject *emb_error(PyObject *self, PyObject *args)
{
	char *body=NULL;
	char *title=NULL;
	PyObject *oti=NULL,*obo=NULL;
	int rc=PyArg_ParseTuple(args,"O|O",&obo,&oti);
	if (!rc) return NULL;
	body=_emb_str(&obo,0);
	if (oti) title=_emb_str(&oti,1);
	if (!title) title="Błąd wtyczki";
	Error(title,body);
	Py_XDECREF(obo);
	Py_XDECREF(oti);
	Py_RETURN_NONE;
}

static PyObject *emb_ask(PyObject *self, PyObject *args)
{
	char *body=NULL;
	char *title=NULL;
	PyObject *oti=NULL,*obo=NULL;
	int rc=PyArg_ParseTuple(args,"O|O",&obo,&oti);
	if (!rc) return NULL;
	body=_emb_str(&obo,0);
	if (oti) title=_emb_str(&oti,1);
	if (!title) title="Pytanie od wtyczki";
	Py_XDECREF(obo);
	Py_XDECREF(oti);
	return Py_BuildValue("i",Ask(title,body));
}

static PyObject *emb_entry(PyObject *self, PyObject *args, PyObject *keywds)
{
	char *body=NULL;
	char *title=NULL;
	char *defval=NULL;
	char *rc;
	PyObject *ro,*obo=NULL,*oti=NULL,*ode=NULL;
	char *kwlist[]={"question","title","defval",NULL};
	if (!PyArg_ParseTupleAndKeywords(args,keywds,"O|OO",kwlist,&obo,&oti,&ode)) {
		return NULL;
	}
	body=_emb_str(&obo,0);
	title=_emb_str(&oti,0);
	defval=_emb_str(&ode,0);
	
	if (!title) title="Pytanie od wtyczki";
	if (!defval) defval="";
	rc=AskStringP(title,body,defval);
	if (!rc) Py_RETURN_NONE;
	ro=Py_BuildValue("s",rc);
	g_free(rc);
	Py_XDECREF(obo);
	Py_XDECREF(oti);
	Py_XDECREF(ode);
	return ro;
}

static PyObject *emb_getFilePath(PyObject *self, PyObject *args)
{
	char *dpath;
	int n;
	if ((n=get_current_editor()) < 0) {
		Py_RETURN_NONE;
	}
	struct MyGtkEditor *editor=current_editor;
	if (n) editor=current_editor->owneditor;
	if (editor->save_name[0]) dpath=editor->save_name;
	else if (editor->load_name[0]) dpath=editor->load_name;
	else Py_RETURN_NONE;
	return Py_BuildValue("s", dpath);
}

static PyObject *emb_getText(PyObject *self, PyObject *args)
{
	PyObject *rc,*owh=NULL;
	char *which="current";
	
	if (!PyArg_ParseTuple(args,"|O",&owh)) return NULL;
	if (owh) which=_emb_str(&owh,0);
	struct MyGtkEditor *edi=_get_editor(which,0);
	Py_XDECREF(owh);
	if (edi == (struct MyGtkEditor *)-1) return NULL;
	if (!edi) Py_RETURN_NONE;
	char *body=get_editor_body(edi);
	rc=Py_BuildValue("s", body);
	g_free(body);
	return rc;
}

static PyObject *emb_getTextPart(PyObject *self, PyObject *args)
{
	PyObject *rc,*owh=NULL;
	char *which="current";
	int begi,endi;
	if (!PyArg_ParseTuple(args,"ii|O",&begi,&endi,&owh)) return NULL;
	if (owh) which=_emb_str(&owh,1);
	struct MyGtkEditor *edi=_get_editor(which,0);
	Py_XDECREF(owh);
	if (edi == (struct MyGtkEditor *)-1) return NULL;
	if (!edi) Py_RETURN_NONE;
	GtkTextIter start,end;
	gtk_text_buffer_get_iter_at_offset(edi->buf,&start,begi);
	gtk_text_buffer_get_iter_at_offset(edi->buf,&end,endi);
	char *body=gtk_text_buffer_get_text(edi->buf,&start,&end,FALSE);
	rc=Py_BuildValue("s", body);
	g_free(body);
	return rc;
}

static PyObject *emb_setText(PyObject *self,PyObject *args)
{
	char *which="current";
	char *body;
	PyObject *obo,*owh=NULL;
	if (!PyArg_ParseTuple(args,"O|O",&obo,&owh)) return NULL;
	if (owh) which=_emb_str(&owh,1);
	body=_emb_str(&obo,0);
	struct MyGtkEditor *edi=_get_editor(which,1);
	Py_XDECREF(owh);
	if (edi && edi != (struct MyGtkEditor *)-1) {
		set_buffer_text(edi->buf,body,-1,1);
	}
	Py_XDECREF(obo);
	if (edi == (struct MyGtkEditor *)-1) {
		return NULL;
	}
	Py_RETURN_NONE;
}

static PyObject *emb_newFile(PyObject *self, PyObject *args)
{
	char *body=NULL;
	char *path=NULL;
	PyObject *obo=NULL,*opa=NULL;
	char *flabel;
	int rc=PyArg_ParseTuple(args,"O|O",&obo,&opa);
	if (!rc) return NULL;
	body=_emb_str(&obo,0);
	path=_emb_str(&opa,1);
	if (path) {
		flabel=strrchr(path,'/');
		if (!flabel) flabel=path;
		else flabel++;
	}
	else {
		flabel="TEXT";
	}
	int is_hash=fbody_is_hash(body,'#');
	get_current_editor();
	if (!current_editor || current_editor->editor_type != 0 || !textbuf_is_empty(tresc)) {
		CreateEditor(0,NULL,flabel);
		atk_object_set_name(gtk_widget_get_accessible((gpointer)tresc_v),flabel);
	}
	else {
		notek_set_tab_label(flabel);
	}
	set_buffer_text(tresc,body,-1,0);
	Py_XDECREF(obo);
	gtk_widget_grab_focus((gpointer)tresc_v);
    current_editor->saveas_iso2 = 0;
	if (is_hash) {
		char const *xc=gtk_entry_get_text((gpointer)char_split);
		if (*xc == '#') gtk_combo_box_set_active((gpointer)combo_split,1);
	}
	if (!path) {
		Py_XDECREF(opa);
		Py_RETURN_NONE;
	}
	if (g_path_is_absolute(path)) {
		strcpy(last_file_path,path);
	}
	else {
		char *cd=g_get_current_dir();
		char *p=g_build_filename(cd,path,NULL);
		strcpy(last_file_path,p);
		g_free(p);
		g_free(cd);
	}
	simplify_path(last_file_path);
	strcpy(current_editor->load_name,last_file_path);
	Py_XDECREF(opa);
    Py_RETURN_NONE;
}

static PyObject *emb_getFB2Context(PyObject *self, PyObject *args)
{
	char buffer[PATH_MAX];
	if (!save_file_fb2_meta(buffer)) {
		Py_RETURN_NONE;
	}
	return Py_BuildValue("s",buffer);
}

static int _add_filters(GtkWidget *dialog,PyObject *pFilter)
{
	int fmode=0;
	int nfilter=0;
	int i,adi;
	GtkFileFilter *filter,*defilter=NULL;
	if (pFilter == Py_None) return 1;
	if (PyTuple_Check(pFilter)) {
		fmode=1;
		nfilter=PyTuple_Size(pFilter);
	}
	else if (PyList_Check(pFilter)) {
		fmode=2;
		nfilter=PyList_Size(pFilter);
	}
	else {
		PyErr_SetString(PyExc_TypeError,"Parametr 'filter' musi byc listą lub krotką");
		return 0;
	}
	
	int __afilter(char *cf)
	{
		char *c=strchr(cf,':');
		if (!c) return 0;
		*c++=0;
		while (*c && isspace(*c)) c++;
		if (!*c) return 0;
		filter=gtk_file_filter_new();
		gtk_file_filter_set_name(filter,cf);
		cf=c;
		while (c && *c) {
			c=strchr(cf,'|');
			if (c) *c++=0;
			else c=cf+strlen(cf);
			cf=trim(cf);
			if (*cf) gtk_file_filter_add_pattern(filter,cf);
			cf=c;
		}
		gtk_file_chooser_add_filter((gpointer) dialog,filter);
		if (!defilter) defilter=filter;
		return 1;
	}
	
	for (i=adi=0;i<nfilter;i++) {
		PyObject *pItem;
		if (fmode == 1) pItem=PyTuple_GetItem(pFilter,i);
		else pItem=PyList_GetItem(pFilter,i);
		if (!PyString_Check(pItem)) continue;
		char *cf=g_strdup(PyString_AsString(pItem));
		if (__afilter(cf)) adi++;
		g_free(cf);
	}
	if (defilter) gtk_file_chooser_set_filter((gpointer) dialog,defilter);
	return 1;
}

static PyObject *emb_choiceLoadFile(PyObject *self, PyObject *args, PyObject *keywds)
{
	char *folder=NULL,*file=NULL,*title="Wybierz plik";
	PyObject *filters=NULL,*rc,*otitle,*ofolder;
	char *fname=NULL;
        static char *kwlist[]={"title","filename","filters",NULL};
	if (!PyArg_ParseTupleAndKeywords(args,keywds,"|OOO",kwlist,&otitle,&ofolder,&filters)) {
		return NULL;
	}
	if (otitle) title=_emb_str(&otitle,1);
	if (ofolder) folder=_emb_str(&ofolder,1);
	GtkWidget *dialog=gtk_file_chooser_dialog_new(
			title,
			GTK_WINDOW(main_window),GTK_FILE_CHOOSER_ACTION_OPEN,
			GTK_STOCK_CANCEL, GTK_RESPONSE_CANCEL,
			GTK_STOCK_OPEN, GTK_RESPONSE_ACCEPT,
			NULL);
	gtk_file_chooser_set_local_only((gpointer)dialog,TRUE);
	if (filters && !_add_filters(dialog,filters)) {
		gtk_widget_destroy(dialog);
		Py_XDECREF(otitle);
		Py_XDECREF(ofolder);
		return NULL;
	}

	if (!folder) {
		folder=get_current_path();
		if (!folder) {
			folder=g_get_current_dir();
		}
	}
	else {
		if (g_file_test(folder, G_FILE_TEST_IS_REGULAR)) {
                        file=folder=strdup(folder);
                }
                else {
                        folder=g_path_get_dirname(folder);
                }
	}
	if (file) {
                gtk_file_chooser_select_filename((gpointer)dialog,file);
	}
        else {
                gtk_file_chooser_set_current_folder((gpointer)dialog,folder);
        }
	if (folder) g_free(folder);
	if (gtk_dialog_run((gpointer)dialog)==GTK_RESPONSE_ACCEPT){
		fname=gtk_file_chooser_get_filename((gpointer)dialog);
	}
	gtk_widget_destroy(dialog);
	if (!fname) Py_RETURN_NONE;
	rc=Py_BuildValue("s",fname);
	g_free(fname);
	Py_XDECREF(otitle);
	Py_XDECREF(ofolder);
	return rc;
}

static PyObject *emb_choiceSaveFile(PyObject *self, PyObject *args, PyObject *keywds)
{
	char *folder=NULL,*file=NULL,*title="Zapisz plik";
	PyObject *filters=NULL,*rc,*otitle,*ofolder;
	char *fname=NULL;
	static char *kwlist[]={"title","filename","filters",NULL};
	if (!PyArg_ParseTupleAndKeywords(args,keywds,"|OOO",kwlist,&otitle,&ofolder,&filters)) {
		return NULL;
	}
	if (otitle) title=_emb_str(&otitle,1);
	if (ofolder) folder=_emb_str(&ofolder,1);
	GtkWidget *dialog=gtk_file_chooser_dialog_new(
			title,
			GTK_WINDOW(main_window),GTK_FILE_CHOOSER_ACTION_SAVE,
			GTK_STOCK_CANCEL, GTK_RESPONSE_CANCEL,
			GTK_STOCK_SAVE, GTK_RESPONSE_ACCEPT,
			NULL);
	gtk_file_chooser_set_local_only((gpointer)dialog,TRUE);
	if (filters && !_add_filters(dialog,filters)) {
		gtk_widget_destroy(dialog);
		Py_XDECREF(otitle);
		Py_XDECREF(ofolder);
		return NULL;
	}

	if (!folder) {
		folder=get_current_path();
		if (!folder) {
			folder=g_get_current_dir();
		}
	}
	else {
		file=g_path_get_basename(folder);
		folder=g_path_get_dirname(folder);
	}
	gtk_file_chooser_set_current_folder((gpointer)dialog,folder);
	if (file) {
		if (*file) gtk_file_chooser_set_current_name((gpointer)dialog,file);
		g_free(file);
	}
	g_free(folder);
	gtk_file_chooser_set_do_overwrite_confirmation((gpointer)dialog,TRUE);
#if GTK_CHECK_VERSION(2,18,0)
	gtk_file_chooser_set_create_folders((gpointer)dialog,TRUE);
#endif
	if (gtk_dialog_run((gpointer)dialog)==GTK_RESPONSE_ACCEPT){
		fname=gtk_file_chooser_get_filename((gpointer)dialog);
	}
	gtk_widget_destroy(dialog);
	if (!fname) Py_RETURN_NONE;
	rc=Py_BuildValue("s",fname);
	g_free(fname);
	Py_XDECREF(otitle);
	Py_XDECREF(ofolder);
	return rc;
}


static PyObject *emb_getTextInfo(PyObject *self, PyObject *args, PyObject *keywds)
{
	char *which="current";
	char *what=NULL;
	char *kwlist[]={"what","editor",NULL};
	char *str;
	PyObject *owha,*owhi=NULL;
	char lc[32];
	PyObject *rcs(char *str,int fm)
	{
		if (!str) Py_RETURN_NONE;
		PyObject *py=Py_BuildValue("s",str);
		if (fm) g_free(str);
		return py;
	}
		
	if (!PyArg_ParseTupleAndKeywords(args,keywds,"O|O",kwlist,&owha,&owhi)) {
		return NULL;
	}
	what=_emb_str(&owha,0);
	if (strlen(what)>31) {
		Py_XDECREF(owha);
		PyErr_SetString(PyExc_ValueError,"Błędna wartość parametru \"what\"");
		return NULL;
	}
	strcpy(lc,what);
	what=lc;
	Py_XDECREF(owha);
	if (owhi) which=_emb_str(&owhi,1);
	struct MyGtkEditor *edi=_get_editor(which,0);
	Py_XDECREF(owhi);
	if (edi == (struct MyGtkEditor *)-1) return NULL;
	if (!edi) Py_RETURN_NONE;
	if (!strcmp(what,"word")) {
		return rcs(get_word_at_cursor(edi->buf,0),1);
	}

	if (!strcmp(what,"length")) {
		return Py_BuildValue("i",gtk_text_buffer_get_char_count(edi->buf));
	}

	if (!strcmp(what,"lines")) {
		return Py_BuildValue("i",gtk_text_buffer_get_line_count(edi->buf));
	}

	GtkTextIter start,end;

	void cursor(void)
	{
		GtkTextMark *sel=gtk_text_buffer_get_selection_bound(edi->buf);
		gtk_text_buffer_get_iter_at_mark(edi->buf,&start,sel);
	}
	
	if (!strcmp(what,"bounds")) {
	    gtk_text_buffer_get_selection_bounds(edi->buf,&start,&end);
	    int n1=gtk_text_iter_get_offset(&start);
	    int n2=gtk_text_iter_get_offset(&end);
	    if (n1 > n2) {
		int x=n1;
		n1=n2;
		n2=x;
	    }
	    return Py_BuildValue("(i,i)",n1,n2);
	}

	if (!strcmp(what,"selection")) {
		gtk_text_buffer_get_selection_bounds(edi->buf,&start,&end);
		str=gtk_text_buffer_get_text(edi->buf,&start,&end,FALSE);
		return rcs(str,1);
	}
	
	if (!strcmp(what,"offset")) {
		cursor();
		return Py_BuildValue("i",gtk_text_iter_get_offset(&start));
	}

	if (!strcmp(what,"line")) {
		cursor();
		return Py_BuildValue("i",gtk_text_iter_get_line(&start));
	}
	if (!strcmp(what,"lineoffset")) {
		cursor();
		return Py_BuildValue("i",gtk_text_iter_get_line_offset(&start));
	}
	if (!strcmp(what,"linecontent")) {
		cursor();
		end=start;
		while (!gtk_text_iter_starts_line(&start)) {
			if (!gtk_text_iter_backward_char(&start)) break;
		}
		while (!gtk_text_iter_ends_line(&end)) {
			if (!gtk_text_iter_forward_char(&end));
		}
		str=gtk_text_buffer_get_text(edi->buf,&start,&end,FALSE);
		return rcs(str,1);
	}
	PyErr_SetString(PyExc_ValueError,"Błędna wartość parametru \"what\"");
	return NULL;
	
}

#define NOT_NUMBER ((int)0xDEADF00D)
#define IS_NUMBER(a) ((a) != NOT_NUMBER)

static PyObject *emb_goTo(PyObject *self, PyObject *args, PyObject *keywds)
{
	char *which="current";
	int line=NOT_NUMBER;
	int col=NOT_NUMBER;
	int offset=NOT_NUMBER;
	char *kwlist[]={"line","lineoffset","offset","editor",NULL};
	if (!PyArg_ParseTupleAndKeywords(args,keywds,"|iiis",kwlist,&line,&col,&offset,&which)) {
		return NULL;
	}
	struct MyGtkEditor *edi=_get_editor(which,0);
	if (edi == (struct MyGtkEditor *)-1) return NULL;
	if (!edi) Py_RETURN_NONE;
	if (IS_NUMBER(offset) && (IS_NUMBER(col) || IS_NUMBER(line))) {
		PyErr_SetString(PyExc_ValueError,"Offset nie może byc podany razem z line lub lineoffset");
		return NULL;
	}
	show_editor(edi);
	int nmax;
	int do_scroll=0;
	GtkTextIter iter,eol;
	if (IS_NUMBER(offset)) {
		do_scroll=1;
		nmax=gtk_text_buffer_get_char_count(edi->buf);
		if (offset < 0) {
			offset=nmax+offset;
		}
		if (offset < 0) gtk_text_buffer_get_start_iter(edi->buf,&iter);
		else if (offset >= nmax) gtk_text_buffer_get_end_iter(edi->buf,&iter);
		else gtk_text_buffer_get_iter_at_offset(edi->buf,&iter,offset);
	}
	else {
		if (IS_NUMBER(line)) {
			nmax=gtk_text_buffer_get_line_count(edi->buf);
			if (line < 0) line=nmax+line;
			if (line < 0) line=0; else if (line >=nmax) line=nmax;
			if (!IS_NUMBER(col) || col==0) {
				col=NOT_NUMBER;
			}
			gtk_text_buffer_get_iter_at_line(edi->buf,&iter,line);
			do_scroll=1;
		}
		else if (IS_NUMBER(col)) {
			GtkTextMark *sel=gtk_text_buffer_get_selection_bound(edi->buf);
			gtk_text_buffer_get_iter_at_mark(edi->buf,&iter,sel);
			while (!gtk_text_iter_starts_line(&iter)) {
				if (!gtk_text_iter_backward_char(&iter)) break;
			}
			do_scroll=1;
		}
		if (IS_NUMBER(col)) {
			do_scroll=1;
			// iter jest zawsze na początku linii
			eol=iter;
			while (!gtk_text_iter_ends_line(&eol)) {
				if (!gtk_text_iter_forward_char(&eol)) break;
			}
			nmax=gtk_text_iter_get_line_offset(&eol);
			if (col < 0) col=nmax + col;
			if (col >= nmax) iter=eol;
			else if (col > 0) gtk_text_iter_forward_chars(&iter,col);
		}
	}
	if (do_scroll) {
		gtk_text_buffer_place_cursor(edi->buf,&iter);
		gtk_text_view_scroll_to_iter((gpointer)edi->view,&iter,0.2,TRUE,0.0,0.5);
	}
	Py_RETURN_NONE;
}	

static PyObject *emb_replaceText(PyObject *self, PyObject *args, PyObject *keywds)
{
	char *which="current";
	int highlight=0;
	int fra,til,mxv;
	
	char *body;
	PyObject *obody;
	char *kwlist[]={"text","start","end","highlight","editor",NULL};
	if (!PyArg_ParseTupleAndKeywords(args,keywds,"Oii|is",kwlist,&obody,&fra,&til,&highlight,&which)) {
		return NULL;
	}
	struct MyGtkEditor *edi=_get_editor(which,1);
	if (edi == (struct MyGtkEditor *)-1) return NULL;
	if (!edi) Py_RETURN_NONE;
	gtk_text_buffer_begin_user_action(edi->buf);
	mxv=gtk_text_buffer_get_char_count(edi->buf);
	if (fra<0) fra+=mxv;
	if (til<0) til+=mxv;
	if (til < 0 || fra < 0 || fra > mxv || til > mxv || fra > til) {
		PyErr_SetString(PyExc_ValueError,"Start lub end poza dopuszczalnymi granicami");
		return NULL;
	}
	
	GtkTextIter start,end;
	gtk_text_buffer_begin_user_action(edi->buf);
	gtk_text_buffer_get_iter_at_offset(edi->buf,&start,fra);
	if (fra != til) {
		gtk_text_buffer_get_iter_at_offset(edi->buf,&start,fra);
		gtk_text_buffer_get_iter_at_offset(edi->buf,&end,til);
		gtk_text_buffer_delete(edi->buf,&start,&end);
	}
	body=_emb_str(&obody,0);
	gtk_text_buffer_insert(edi->buf,&start,body,-1);
	Py_XDECREF(obody);
	if (highlight) {
		gtk_text_buffer_get_iter_at_offset(edi->buf,&start,fra);
		gtk_text_buffer_get_iter_at_offset(edi->buf,&end,fra+strlen(body));
		gtk_text_buffer_select_range(edi->buf,&start,&end);
	}
	gtk_text_buffer_end_user_action(edi->buf);
	Py_RETURN_NONE;
}

static PyObject *emb_insertText(PyObject *self, PyObject *args, PyObject *keywds)
{
	char *which="current";
	int highlight=0;
	char *body;
	PyObject *obody;
	char *kwlist[]={"text","highlight","editor",NULL};
	if (!PyArg_ParseTupleAndKeywords(args,keywds,"O|is",kwlist,&obody,&highlight,&which)) {
		return NULL;
	}
	struct MyGtkEditor *edi=_get_editor(which,1);
	if (edi == (struct MyGtkEditor *)-1) return NULL;
	if (!edi) Py_RETURN_NONE;
	body=_emb_str(&obody,0);
	gtk_text_buffer_begin_user_action(edi->buf);
	if (!highlight) {
		gtk_text_buffer_insert_at_cursor(edi->buf,body,-1);
	}
	else {
		GtkTextIter iter,end;
		int coff;
		GtkTextMark *sel=gtk_text_buffer_get_selection_bound(edi->buf);
		gtk_text_buffer_get_iter_at_mark(edi->buf,&iter,sel);
		coff=gtk_text_iter_get_offset(&iter);
		gtk_text_buffer_insert(edi->buf,&iter,body,-1);
		end=iter;
		gtk_text_buffer_get_iter_at_offset(edi->buf,&iter,coff);
		gtk_text_buffer_select_range(edi->buf,&iter,&end);
	}
	gtk_text_buffer_end_user_action(edi->buf);
	Py_XDECREF(obody);
	Py_RETURN_NONE;
}

static PyObject *emb_appendText(PyObject *self, PyObject *args, PyObject *keywds)
{
	char *which="current";
	int newline=0;
	int moveto=0;
	char *body;
	PyObject *obody;
	char *kwlist[]={"text","newline","moveto","editor",NULL};
	if (!PyArg_ParseTupleAndKeywords(args,keywds,"O|iis",kwlist,&obody,&newline,&moveto,&which)) {
		return NULL;
	}
	struct MyGtkEditor *edi=_get_editor(which,1);
	if (edi == (struct MyGtkEditor *)-1) return NULL;
	if (!edi) Py_RETURN_NONE;
	GtkTextIter iter,iterb;
	gtk_text_buffer_get_end_iter(edi->buf,&iter);
	gtk_text_buffer_begin_user_action(edi->buf);
	if (newline && gtk_text_buffer_get_char_count(edi->buf)>0) {
		iterb=iter;
		gtk_text_iter_backward_char(&iterb);
		char *s=gtk_text_buffer_get_text(edi->buf,&iterb,&iter,FALSE);
		if (*s!='\n') {
			iterb=iter;
			gtk_text_buffer_insert(edi->buf,&iterb,"\n",-1);
			gtk_text_buffer_get_end_iter(edi->buf,&iter);
		}
		g_free(s);
	}
	body=_emb_str(&obody,0);
	gtk_text_buffer_insert(edi->buf,&iter,body,-1);
	Py_XDECREF(obody);
	gtk_text_buffer_end_user_action(edi->buf);
	if (moveto) {
		gtk_text_buffer_get_end_iter(edi->buf,&iter);
		while(body && *body) {
			body=g_utf8_next_char(body);
			if (!gtk_text_iter_backward_char(&iter)) break;
		}
		gtk_text_buffer_place_cursor(edi->buf,&iter);
		yield();
		gtk_text_view_scroll_to_iter((gpointer)edi->view,&iter,FALSE,TRUE,0.0,0.5);
	}
	Py_RETURN_NONE;
}

static PyObject *emb_cutLine(PyObject *self, PyObject *args)
{
	char *which="current";
	char *body;
	PyObject *rc;
	if (!PyArg_ParseTuple(args,"|z",&which)) return NULL;
	struct MyGtkEditor *edi=_get_editor(which,1);
	if (edi == (struct MyGtkEditor *)-1) return NULL;
	if (!edi) Py_RETURN_NONE;
	
	GtkTextMark *m;
	GtkTextIter start,finisz;
	int cnt;
	m=gtk_text_buffer_get_insert(edi->buf);
	gtk_text_buffer_get_iter_at_mark(edi->buf,&start,m);
	cnt=gtk_text_iter_get_line_offset(&start);
	if (cnt) gtk_text_iter_backward_chars(&start,cnt);
	finisz=start;
	gtk_text_iter_forward_line(&finisz);
	body=gtk_text_buffer_get_text(edi->buf,&start,&finisz,0);
	gtk_text_buffer_begin_user_action(edi->buf);
	gtk_text_buffer_delete(tresc,&start,&finisz);
	gtk_text_buffer_end_user_action(edi->buf);
	rc=Py_BuildValue("s",body);
	g_free(body);
	return rc;
}

static PyObject *emb_showEditor(PyObject *self, PyObject *args)
{
	char *which="current";
	if (!PyArg_ParseTuple(args,"|z",&which)) return NULL;
	struct MyGtkEditor *edi=_get_editor(which,1);
	if (edi == (struct MyGtkEditor *)-1) return NULL;
	if (edi) show_editor(edi);
	Py_RETURN_NONE;
}

static PyObject *emb_close(PyObject *self, PyObject *args)
{
	char *which=NULL;
	int ned;
	struct MyGtkEditor *edi;
	if (!PyArg_ParseTuple(args,"s",&which)) return NULL;
	if (!strcasecmp(which,"dash")) ned=1;
	else if (!strcasecmp(which,"dict")) ned=2;
	else {
		PyErr_SetString(PyExc_ValueError,"Zamknąć możesz wyłącznie DASH i DICT");
		return NULL;
	}
	int n=get_current_editor();
	if (n<0) Py_RETURN_NONE;
	edi=current_editor;
	if (n) edi=edi->owneditor;
	if (ned == 1) {edi=edi->dash_editor;edi->dash_editor=NULL;}
	else {edi=edi->dic_editor;edi->dic_editor=NULL;}
	if (edi) remove_subeditor(edi);
	Py_RETURN_NONE;
}

	
static GtkWidget *PGM_dialog, *PGM_label, *PGM_meter;
static int PGM_stop,PGM_resume;


static void progressShowFinish(void)
{
	if (!PGM_dialog) return;
	gtk_widget_hide(PGM_dialog);
	gtk_widget_destroy(PGM_dialog);
	PGM_dialog=NULL;
}

static int rt(void)
{
	return TRUE;
}

static PyObject *emb_progressQuery(PyObject *self, PyObject *args)
{
	yield();
	return Py_BuildValue("i",!PGM_stop);
}

static PyObject *emb_progressFinish(PyObject *self, PyObject *args)
{
	progressShowFinish();
	Py_RETURN_NONE;
}

static void pgm_break(GtkWidget *w,gint id,gpointer udata)
{
	if (id != 100) return;
	if (PGM_stop) return;
	if (!PGM_resume || Ask("Pytanie","Przerywasz proces?")) PGM_stop=1;
}

static PyObject *emb_progressSet(PyObject *self, PyObject *args, PyObject *keywds)
{
	char *label=NULL;
	double df=-1.0;
	char *kwlist[]={"label","value",NULL};
	PyObject *olabel;
	if (!PyArg_ParseTupleAndKeywords(args,keywds,"|Of",kwlist,&olabel,&df)) {
		return NULL;
	}
	if (!PGM_dialog) {
		PyErr_SetString(PyExc_SystemError,"Brak wskaźnika postępu");
		return NULL;
	}
	label=_emb_str(&olabel,1);
	if (label) 	gtk_label_set_text((gpointer)PGM_label,label);
	Py_XDECREF(olabel);
	if (df >= 0.0) {
		if (df > 1.0) df=1.0;
		gtk_progress_bar_set_fraction((gpointer)PGM_meter,df);
	}
	yield();
	return Py_BuildValue("i",!PGM_stop);
}

static PyObject *emb_progressInit(PyObject *self, PyObject *args)
{
	char *title;
	char *label;
	int resume=1;
	PyObject *olabel,*otitle;
	if (!PyArg_ParseTuple(args,"ss|i",&olabel,&otitle,&resume)) {
		return NULL;
	}
	label=_emb_str(&olabel,0);
	title=_emb_str(&otitle,0);
	PGM_dialog=gtk_dialog_new_with_buttons(
		title,
		(gpointer)main_window,
		GTK_DIALOG_MODAL,
		"Przerwij",100,
		NULL);
	g_signal_connect_swapped(G_OBJECT(PGM_dialog), "delete-event",
	      G_CALLBACK(rt), NULL);
	g_signal_connect_swapped(G_OBJECT(PGM_dialog), "response",
	      G_CALLBACK(pgm_break), NULL);
	GtkWidget *box=gtk_dialog_get_content_area((gpointer)PGM_dialog);
	GtkWidget *vbox=gtk_vbox_new(0,2);
	gtk_box_pack_start(GTK_BOX(box),(gpointer)vbox,FALSE,FALSE,0);
	PGM_label=gtk_label_new("");
	gtk_label_set_selectable((gpointer)PGM_label,TRUE);
	gtk_box_pack_start(GTK_BOX(vbox),(gpointer)PGM_label,FALSE,FALSE,0);
	PGM_meter=gtk_progress_bar_new();
	init_progressbar((gpointer)PGM_meter);
    gtk_progress_bar_set_pulse_step((gpointer)PGM_meter,0.05);
	gtk_box_pack_start(GTK_BOX(vbox),(gpointer)PGM_meter,FALSE,FALSE,0);
	gtk_label_set_text((gpointer)PGM_label,label);
	gtk_progress_bar_set_fraction((gpointer)PGM_meter,0.0);
    gtk_widget_set_size_request((gpointer)PGM_meter, 320,-1);
    gtk_widget_show_all(box);
    PGM_stop=0;
    PGM_resume=resume;
    gtk_widget_show_all(PGM_dialog);
    Py_XDECREF(olabel);
    Py_XDECREF(otitle);
    yield();
    Py_RETURN_NONE;
}

static PyObject *emb_toiso2(PyObject *self, PyObject *args)
{
	char *body;
	char *rstr;
	PyObject *rc,*obody;
	if (!PyArg_ParseTuple(args,"O",&obody)) {
		return NULL;
	}
	body=_emb_str(&obody,0);
	int n=to_iso2(body,NULL);
	if (n<0) {
		Py_XDECREF(obody);
		PyErr_SetString(PyExc_SystemError,"Błąd dekodera UNICODE");
		return NULL;
	}
	rstr=g_malloc(n);
	to_iso2(body,rstr);
	Py_XDECREF(obody);
	rstr=to_utf8(rstr,strlen(rstr),"ISO-8859-2",1);
	rc=Py_BuildValue("s",rstr);
	g_free(rstr);
	return rc;
}

static PyObject *emb_getLangs(PyObject *self, PyObject *args)
{
	int isavail=0;
	int i;
	PyObject *rc;
	if (!PyArg_ParseTuple(args,"|i",&isavail)) {
		return NULL;
	}
	rc=PyList_New(0);
	for (i=0;i<NUM_LANGS;i++) {
		if (isavail || gtk_toggle_button_get_active((gpointer)lang_cb[i])) {
			PyObject *str=Py_BuildValue("s",lang_codes[i]);
			PyList_Append(rc,str);
		}
	}
	return rc;
}

static PyObject *emb_getThemes(PyObject *self, PyObject *args)
{
	int isavail=0;
	struct miltheme *mt;
	PyObject *rc;
	
	if (!PyArg_ParseTuple(args,"|i",&isavail)) {
		return NULL;
	}
	rc=PyList_New(0);
	for (mt=themes;mt;mt=mt->next) {
		if (isavail || gtk_toggle_button_get_active((gpointer)mt->cb)) {
			PyObject *str=Py_BuildValue("s",mt->tname);
			PyList_Append(rc,str);
		}
	}
	return rc;
}

static PyObject *emb_setTheme(PyObject *self, PyObject *args)
{
	int isset=0;
	struct miltheme *mt;
	char *what;
	if (!PyArg_ParseTuple(args,"si",&what,&isset)) {
		return NULL;
	}
	for (mt=themes;mt;mt=mt->next) {
		if (!strcmp(mt->tname,what)) {
			gtk_toggle_button_set_active((gpointer)mt->cb,isset);
			break;
		}
	}
	Py_RETURN_NONE;
}

static PyObject *emb_setLang(PyObject *self, PyObject *args)
{
	int i;
	int isset=0;
	char *what;
	if (!PyArg_ParseTuple(args,"si",&what,&isset)) {
		return NULL;
	}
	for (i=0;i<NUM_LANGS;i++) {
		if (!strcmp(lang_codes[i],what)) {
			gtk_toggle_button_set_active((gpointer)lang_cb[i],isset);
			break;
		}
	}
	Py_RETURN_NONE;
}

static PyObject *emb_getchapmark(PyObject *self, PyObject *args)
{
    if (!gtk_combo_box_get_active((gpointer)combo_split)) {
		Py_RETURN_NONE;
	}
	char const *c=gtk_entry_get_text((gpointer)char_split);
	PyObject *rc;
	if (strlen(c)!=1) {
		rc=Py_None;
		Py_INCREF(rc);
	}
	else {
		rc=Py_BuildValue("s",c);
	}
	g_free((gpointer)c);
	return rc;
}



static PyObject *emb_setchapmark(PyObject *self, PyObject *args)
{
	char *cmark=NULL;
	PyObject *ocm;
	if (!PyArg_ParseTuple(args,"|O",&ocm)) {
		return NULL;
	}
	if (ocm) cmark=_emb_str(&ocm,1);
	if (!cmark) {
		gtk_combo_box_set_active((gpointer)combo_split,0);
		Py_XDECREF(ocm);
		Py_RETURN_NONE;
	}
	if (strlen(cmark)!=1) {
		PyErr_SetString(PyExc_ValueError,"parametr musi byc jednoznakowy");
		Py_XDECREF(ocm);
		return NULL;
	}
	gtk_combo_box_set_active((gpointer)combo_split,1);
	gtk_entry_set_text((gpointer)char_split,cmark);
	Py_XDECREF(ocm);
	Py_RETURN_NONE;
}

static PyObject *emb_sayText(PyObject *self, PyObject *args)
{
	char *str=NULL;
	PyObject *ostr;
	if (!PyArg_ParseTuple(args,"O",&ostr)) {
		return NULL;
	}
	str=_emb_str(&ostr,0);
	speak_text(str);
	Py_XDECREF(ostr);
	Py_RETURN_NONE;
}

static PyObject *emb_openBrowser(PyObject *self, PyObject *args)
{
	char *str=NULL;
	PyObject *ostr;
	if (!PyArg_ParseTuple(args,"O",&ostr)) {
		return NULL;
	}
	str=_emb_str(&ostr,0);
	show_url(str);
	Py_XDECREF(ostr);
	Py_RETURN_NONE;
}

static PyObject *emb_getClipboard(PyObject *self, PyObject *args)
{
    static GdkAtom atom=NULL;
    GtkClipboard *clip;
    char *txt;
    if (!atom) {
	atom=gdk_atom_intern_static_string("CLIPBOARD");
    }
    clip=gtk_clipboard_get(atom);
    if (!clip) {
	PyErr_SetString(PyExc_SystemError,"Nie mogę znaleźć schowka");
	return NULL;
    }
    txt=gtk_clipboard_wait_for_text(clip);
    if (!txt) {
	Py_RETURN_NONE;
    }
    PyObject *rc=Py_BuildValue("s",txt);
    g_free(txt);
    return rc;
}

    

/*
 * 
 * Potrzebne metody:
 * getChapterMarker()
 * setChapterMarker(marker)
 * setLang(lang,isset)
 * setTheme(theme,isset)
 * 
 */
static PyMethodDef EmbMethods[] = {
    {"getEditorTypeI", emb_editorType, METH_NOARGS,
     "Zwraca 0 dla text, 1 dla dash, 2 dla Dict, -1 jeśli nie ma edytora"},
    {"getEditorType", emb_editorTypeS, METH_NOARGS,
     "Zwraca 'Text','Dash' lub 'Dict' albo None jeśli nie ma edytora"},
    {"getFileId",emb_getfileid,METH_NOARGS,
     "Zwraca ID pliku albo None jeśli nie ma edytora"},
    {"getFB2Context",emb_getFB2Context,METH_NOARGS,
     "Zwraca ścieżkę do kontekstu fbmeta"},
    {"flushGtkEvents",emb_yield,METH_NOARGS,
     "Czyści pętlę gtk ze zdarzeń, zwraca None"},
    {"Alert",emb_alert,METH_VARARGS,
     "Alert(treść,tytuł=None)\nWyświetla informację"},
    {"Error",emb_error,METH_VARARGS,
     "Error(treść,tytuł=None)\nWyświetla informację o błędzie"},
    {"Confirm",emb_ask,METH_VARARGS,
     "Confirm(treść,tytuł=None)\nWyświetla okno z mozliwościa potwierdzenia"},
    {"Prompt",(void *)emb_entry,METH_VARARGS | METH_KEYWORDS,
     "Confirm(label,title=None,defval=None)\nWyświetla okno wprowadzenia tekstu"},
    {"getFilePath",emb_getFilePath,METH_VARARGS,
     "Zwraca aktualną ścieżkę do pliku tekstowego lub None"},
    {"newFile",emb_newFile,METH_VARARGS,
     "newFile(tresc,path=None)\nTworzy nowy notatnik z plikiem."},
    {"getText",emb_getText,METH_VARARGS,
     "getText(editor=None)\nZwraca zawartość edytora."},
    {"getTextPart",emb_getTextPart,METH_VARARGS,
     "getText(startpos,endpos,editor=None)\nZwraca zawartość edytora."},
    {"getTextInfo",(void *)emb_getTextInfo,METH_VARARGS | METH_KEYWORDS,
     "getTextInfo(what,editor=None)\nZwraca informację o stanie edytora."},
    {"setText",emb_setText,METH_VARARGS,
     "setText(text,editor=None)\nUstawia zawartość edytora."},
    {"insertText",(void *)emb_insertText,METH_VARARGS | METH_KEYWORDS,
     "insertText(text,highlight=False,editor=None)\nwstawia tekst na pozycji kursora."},
    {"replaceText",(void *)emb_replaceText,METH_VARARGS | METH_KEYWORDS,
     "replaceText(text,start,end,highlight=False,editor=None)\nwstawia tekst na podanej pozycji."},
    {"cutLine",emb_cutLine,METH_VARARGS,
     "cutLine(editor=None)\nUsuwa bieżącą linię i zwraca jej treść wraz ze znakiem końca"},
    {"showEditor",emb_showEditor,METH_VARARGS,
     "showEditor(editor=None)\nPrzełącza na podany edytor i ogniskuje kursor na treści."},
    {"close",emb_close,METH_VARARGS,
     "close(editor)\nZamyka dash lub dict."},
    {"appendText",(void *)emb_appendText,METH_VARARGS | METH_KEYWORDS,
     "appendText(text,newline=False,moveto=False,editor=None)\nwstawia tekst na koniec"},
    {"goTo",(void *)emb_goTo,METH_VARARGS | METH_KEYWORDS,
     "goTo(line=None,lineoffset=None,offet=None,editor=None)\nPrzeskok do wskazanej pozycji"},
    {"choiceLoadFile",(void *)emb_choiceLoadFile,METH_VARARGS | METH_KEYWORDS,
     "choiceLoadFile(title,filename=None,filters=None)\nWyświetla dialog Open."},
    {"choiceSaveFile",(void *)emb_choiceSaveFile,METH_VARARGS | METH_KEYWORDS,
     "choiceSaveFile(title,filename=None,filters=None)\nWyświetla dialog Save."},
    {"progressInit",(void *)emb_progressInit, METH_VARARGS,
     "progressInit(title,label[,resume])\nInicjalizuje wskaźnik postępu."},
    {"progressSet",(void *)emb_progressSet, METH_VARARGS | METH_KEYWORDS,
     "progressSet(label=None,value=None)\nZmienia stan wskaźnika postępu. Zwraca False jeśli wciśnięto przerwanie"},
    {"progressQuery",(void *)emb_progressQuery, METH_VARARGS,
     "progressQuery()\nZwraca False jeśli wciśnięto przerwanie"},
    {"progressFinish",(void *)emb_progressFinish, METH_VARARGS,
     "progressFinish()\nZamyka wskaźnik postępu"},
    {"Latin2",(void *)emb_toiso2, METH_VARARGS,
     "Zwraca string posiadający wyłącznie znaki występujące w iso-8859-2"},
    {"getLangs",(void *)emb_getLangs, METH_VARARGS,
     "getLangs([avail])\nZwraca języki"},
    {"getThemes",(void *)emb_getThemes, METH_VARARGS,
     "getThemes([avail])\nZwraca tematy"},
    {"setTheme",(void *)emb_setTheme, METH_VARARGS,
     "setTheme(theme,isset)\nWłącza lub wyłącza temat"},
    {"setLang",(void *)emb_setLang, METH_VARARGS,
     "setLang(lang,isset)\nWłącza lub wyłącza język"},
    {"getChapterMark",(void *)emb_getchapmark, METH_VARARGS,
     "Pobiera znak markera rozdziałów lub None"},
    {"setChapterMark",(void *)emb_setchapmark, METH_VARARGS,
     "Ustawia znak markera rozdziałów lub wyłącza podział"},
    {"sayText",(void *)emb_sayText, METH_VARARGS,
     "Mówi to co jest w argumencie"},
    {"openBrowser",(void *)emb_openBrowser, METH_VARARGS,
     "Otwiera przeglądarkę z podanym url-em"},
    {"getClipboard",(void *)emb_getClipboard, METH_VARARGS,
     "Zwraca zawartość schowka lub None"},
     
    {NULL, NULL, 0, NULL}
};

//

#define PYDIR DATADIR "/python"

extern GtkWidget *menubar;
struct __modcaller {
	PyObject *pModule;
	PyObject *pMname;
};

//static sighandler_t __pygnal;
static void *pygnal;

static void showPyError(void)
{
    PyObject *type, *value, *traceback;
    PyObject *tracebackModule;

    PyErr_Fetch(&type, &value, &traceback);

    tracebackModule = PyImport_ImportModule("traceback");
    if (tracebackModule != NULL)
    {
        PyObject *tbList, *enString, *strRetval;

        tbList = PyObject_CallMethod(
            tracebackModule,
            "format_exception",
            "OOO",
            type,
            value == NULL ? Py_None : value,
            traceback == NULL ? Py_None : traceback);

        enString = PyString_FromString("\n");
        strRetval = PyObject_CallMethod(enString, "join",
            "O", tbList);

        Error("Błąd wtyczki",PyString_AsString(strRetval));
        Py_DECREF(tbList);
        Py_DECREF(enString);
        Py_DECREF(strRetval);
        Py_DECREF(tracebackModule);
    }
    else
    {
        Error("Błąd Pythona","Nie mogę zaimportować modułu traceback");
    }

    Py_DECREF(type);
    Py_XDECREF(value);
    Py_XDECREF(traceback);
}

static void run_python(GtkWidget *menu,struct __modcaller *mc)
{
	PyObject *pFunc = PyObject_GetAttrString(mc->pModule, "run");
	if (pFunc && PyCallable_Check(pFunc)) {
        PyObject *pArgs = Py_BuildValue("(O)",mc->pMname); //PyTuple_New(0);
        signal(SIGINT,pygnal);
        PyObject *pValue = PyObject_CallObject(pFunc, pArgs);
        signal(SIGINT,SIG_DFL);
        Py_DECREF(pArgs);
        progressShowFinish();
	if (!pValue || PyErr_Occurred()) {
	    showPyError();
	    if (pValue) Py_DECREF(pValue);
	    return;
	}
        if (PyString_Check(pValue)) {
			Info("Informacja z wtyczki",PyString_AsString(pValue));
		}
        Py_DECREF(pValue);
	}
	else {
		Error("Błąd wtyczki","Brak atrybutu 'run' lub nie jest metodą");
	}
}

static void _connectPyMenu(void *menu,PyObject *pModule,PyObject *pMname)
{
	struct __modcaller *mc=g_malloc(sizeof(*mc));
	mc->pModule=pModule;
	if (pMname) {
		mc->pMname=pMname;
	}
	else {
		mc->pMname=Py_None;
	}
	Py_INCREF(mc->pMname);
	g_signal_connect(G_OBJECT(menu),"activate",G_CALLBACK(run_python),mc);
}

static void pynitialize_plugin(char const *name)
{
	PyObject *pName, *pModule, *pMenu,*pSubmenu;
	int submode=0;
	int subsize=0;
	pName=PyString_FromString(name);
	pModule=PyImport_Import(pName);
	Py_DECREF(pName);
	if (!pModule) return;
	pMenu=PyObject_GetAttrString(pModule, "menuname");
	if (!pMenu) {
		Py_DECREF(pModule);
		return;
	}
	if (!PyString_Check(pMenu)) {
		Py_DECREF(pMenu);
		Py_DECREF(pModule);
		return;
	}
	if (PyObject_HasAttrString(pModule,"submenu")) {
		pSubmenu=PyObject_GetAttrString(pModule,"submenu");
		if (pSubmenu) {
			if (PyTuple_Check(pSubmenu)) {
				submode=1;
				subsize=PyTuple_Size(pSubmenu);
			}
			else if (PyList_Check(pSubmenu)) {
				submode=2;
				subsize=PyList_Size(pSubmenu);
			}
			if (!submode) {
				Py_DECREF(pSubmenu);
				Py_DECREF(pMenu);
				Py_DECREF(pModule);
			}
			if (!subsize) {
				submode=0;
				Py_DECREF(pSubmenu);
			}
		}
	}
	if (!m_python) {
		python_menu = gtk_menu_new();
		m_python=gtk_menu_item_new_with_mnemonic("P_ython");
		gtk_menu_item_set_submenu(GTK_MENU_ITEM(m_python), python_menu);
		gtk_menu_shell_append(GTK_MENU_SHELL(menubar), m_python);
	}
	
	char *menuname=PyString_AsString(pMenu);
	GtkWidget *menu=gtk_menu_item_new_with_label(menuname);
	Py_DECREF(pMenu);
	gtk_menu_shell_append(GTK_MENU_SHELL(python_menu), menu);
	if (!submode) {
		_connectPyMenu((void *)menu,pModule,NULL);
		return;
	}
	GtkWidget *smenu=gtk_menu_new();
	gtk_menu_item_set_submenu(GTK_MENU_ITEM(menu), smenu);
	int i;
	PyObject *pItem;
	char *subname;
	for (i=0;i<subsize;i++) {
		if (submode == 1) pItem=PyTuple_GetItem(pSubmenu,i);
		else pItem=PyList_GetItem(pSubmenu,i);
		if (!PyString_Check(pItem)) continue;
		subname=PyString_AsString(pItem);
		GtkWidget *sub_menu = gtk_menu_item_new_with_label(subname);
		gtk_menu_shell_append(GTK_MENU_SHELL(smenu), sub_menu);
		_connectPyMenu((void *)sub_menu,pModule,pItem);
	}
	Py_DECREF(pSubmenu);
}

static int python_initialized=0;

static void pynalize()
{
	if (python_initialized) {
		Py_Finalize();
		python_initialized=0;
	}
}

void initialize_python(void)
{
	char *fname,*dname;
	const char *fn;
	char *ppath=getenv("PYTHONPATH");
	static char read_buf[1024];
	int is_py(char const *c,char const *d)
	{
		if (c[0] == '_') return 0;
		int n=strlen(c);
		if (n < 4) return 0;
		if (strcmp(c+n-3,".py")) return 0;
		char *dn=g_build_filename(d,c,NULL);
		FILE *f=fopen(dn,"r");
		g_free(dn);
		if (!f) {
			return 0;
		}
		n=fread(read_buf,1,1023,f);
		fclose(f);
		read_buf[n]=0;
		char *cs;
		for (cs=read_buf;cs && *cs;cs=strchr(cs,'\n')) {
			while (*cs && isspace(*cs)) cs++;
			if (*cs != '#') return 0;
			cs++;
			if (!strncmp(cs,"==plugin==",10)) return 1;
		}
		return 0;
	}
			
	dname=g_build_filename(getenv("HOME"),".milena_abc_plugins",NULL);
	if (!ppath) {
		ppath=g_strdup_printf("%s:%s",PYDIR,dname);
	}
	else {
		ppath=g_strdup_printf("%s:%s:%s",ppath,PYDIR,dname);
	}
	setenv("PYTHONPATH",ppath,1);
	python_initialized=1;
	Py_Initialize();
	Py_InitModule("ABC", EmbMethods);	
	GDir *dy=g_dir_open(PYDIR,0,NULL);
	if (dy) {
		while((fn=g_dir_read_name(dy))) {
			if (!is_py(fn,dname)) continue;
			pynitialize_plugin(fn);
		}
		g_dir_close(dy);
	}
	dname=g_build_filename(getenv("HOME"),".milena_abc_plugins",NULL);
	dy=g_dir_open(dname,0,NULL);
	if (dy) {
		while((fn=g_dir_read_name(dy))) {
			if (!is_py(fn,dname)) continue;
			fname=g_strdup(fn);
			fname[strlen(fname)-3]=0;
			pynitialize_plugin(fname);
			g_free(fname);
		}
		g_dir_close(dy);
	}
	if (!m_python) pynalize();
	else {
		pygnal=signal(SIGINT,SIG_DFL);
		atexit(pynalize);
	}
}

