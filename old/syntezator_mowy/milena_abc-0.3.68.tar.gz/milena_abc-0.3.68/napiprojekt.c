/*
 * naiprojekt.c - Milena Audiobook Creator
 * Based on "pynapi" by Arkadiusz Miśkiewicz
 * Copyright (C) Bohdan R. Rau 2012 <ethanak@polip.com>
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write see:
 *               <http://www.gnu.org/licenses/>.
 */

#define _FILE_OFFSET_BITS 64
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <glib.h>
#include <fcntl.h>
#include <unistd.h>
#include "gmilena.h"
#include <ctype.h>

#define NAPIBUF_LEN (1024*1024)
#define NAPIHSIZE (1024*1024*10)




int movie_napilink(char *fname,char *inbuf)
{
	unsigned char *buf;char *rc;
	GChecksum *ch;
	int fd;
	int blen,nlen;
	int rd,i;
    int idx[] = { 0xe, 0x3,  0x6, 0x8, 0x2 };
    int mul[] = {   2,   2,    5,   4,   3 };
    int add[] = {   0, 0xd, 0x10, 0xb, 0x5 };
    

	int g16(char *str,int n)
	{
		int rc=0,p;
		for (;n>0;n--,str++) {
			if (isdigit(*str)) p=(*str) - '0';
			else p=tolower((*str))+10-'a';
			rc=rc*16+p;
		}
		return rc;
	}
	int t16(int n)
	{
		if (n<10) return '0'+n;
		else return 'a'+n-10;
	}
	fd=open(fname,O_RDONLY);
	if (fd<0) {
	    perror(fname);
	    return -1;
	}
	buf=g_malloc(NAPIBUF_LEN);
	ch=g_checksum_new(G_CHECKSUM_MD5);
	blen=0;
	while (blen < NAPIHSIZE) {
		nlen=NAPIHSIZE-blen;
		if (nlen > NAPIBUF_LEN) nlen=NAPIBUF_LEN;
		rd=read(fd,buf,nlen);
		if (rd <= 0) break;
		g_checksum_update(ch,buf,rd);
		blen+=rd;
	}
	g_free(buf);
	close(fd);
	rc=(char *)g_checksum_get_string(ch);
	sprintf(inbuf,
		"http://napiprojekt.pl/unit_napisy/dl.php?l=PL&f=%s&t=",
		rc);
	inbuf+=strlen(inbuf);
	
	for (i=0;i<5;i++) {
        int a = add[i];
        int m = mul[i];
        int n = idx[i];

        int t = a + g16(rc+n,1);
        int v = g16(rc+t,2);
		*inbuf++=t16((v*m) & 15);
	}
	g_checksum_free(ch);
	sprintf(inbuf,"&v=pynapi&kolejka=false&nick=&pass=&napios=posix");
	return 0;
}

char *get_napi(char *fname)
{
	char url[256];
	char *body;int len,rc;
	if (movie_napilink(fname,url)) return NULL;
#ifdef HAVE_CURL
	rc=curl_fetch_file(url,(void **)&body,&len);
#else
	body=wget(url,&len);
	rc=body == NULL;
#endif
	if (rc) return NULL;
	if (len<3 || !strncmp(body,"NPc",3)) {
		g_free(body);
		return NULL;
	}
	return body;
}
	

/*
main(int argc,char *argv[])
{
	char bsx[256];
	if (argc != 2) exit(1);
	movie_napilink(argv[1],bsx);
	printf("%s\n",bsx);
}
*/

