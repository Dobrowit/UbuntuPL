/*
 * tesseract.c - Milena Audiobook Creator
 * Copyright (C) Bohdan R. Rau 2009-2011 <ethanak@polip.com>
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write see:
 *               <http://www.gnu.org/licenses/>.
 */

#include "config.h"
#include <gtk/gtk.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "gmilena.h"
#include <sys/wait.h>
#include <errno.h>
#include <sys/stat.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/resource.h>
#include <ctype.h>

static int filesorter(gconstpointer a,
                    gconstpointer b )
{
    return( strcmp( (const gchar *)a, (const gchar *)b ) );
}

static GList *getFileList(char *dirname)
{
    GDir *dir;
    GList *list=NULL;
    char const *fname;char *fulfname;
    dir=g_dir_open(dirname,0,NULL);
    if (!dir) {
        return NULL;
    }
    while ((fname=g_dir_read_name(dir))) {
        fulfname=g_build_filename(dirname,fname,NULL);
        list=g_list_prepend(list,fulfname);
    }
    g_dir_close(dir);
    list=g_list_sort(list,filesorter);
    return list;
}

static void rem_dir(char *dirname,GList *lista)
{
    char buf[256];
    void rmfun(gpointer data,gpointer dummy) {
        unlink(data);
    }
    g_list_foreach(lista,rmfun,NULL);
    g_list_free(lista);
    sprintf(buf,"%s/page.txt",dirname);
    unlink(buf);
    rmdir(dirname);
}

static void renice(int id)
{
    setpriority(PRIO_PROCESS,id,10);
}

static int rt(void)
{
	return TRUE;
}

int pgr_stop;
static void pgress_break(GtkWidget *w,gint id,gpointer udata)
{
	if (id != 100) return;
	if (Ask("Pytanie","Przerywasz konwersję?")) pgr_stop=1;
}


static GtkWidget *pgr_meter, *pgr_label,*pgr_bar;

static GtkWidget *makemeter()
{
	GtkWidget *progressmeter=gtk_dialog_new_with_buttons(
		"Proces",
		(gpointer)main_window,
		GTK_DIALOG_MODAL,
		"Przerwij",100,
		NULL);
	g_signal_connect_swapped(G_OBJECT(progressmeter), "delete-event",
	      G_CALLBACK(rt), NULL);
	g_signal_connect_swapped(G_OBJECT(progressmeter), "response",
	      G_CALLBACK(pgress_break), NULL);
	GtkWidget *box=gtk_dialog_get_content_area((gpointer)progressmeter);
	GtkWidget *vbox=gtk_vbox_new(0,2);
	gtk_box_pack_start(GTK_BOX(box),(gpointer)vbox,FALSE,FALSE,0);
	pgr_label=gtk_label_new("");
	gtk_label_set_selectable((gpointer)pgr_label,TRUE);
	gtk_box_pack_start(GTK_BOX(vbox),(gpointer)pgr_label,FALSE,FALSE,0);
	pgr_bar=gtk_progress_bar_new();
	init_progressbar((gpointer)pgr_bar);
    gtk_progress_bar_set_pulse_step((gpointer)pgr_bar,0.05);
	gtk_box_pack_start(GTK_BOX(vbox),(gpointer)pgr_bar,FALSE,FALSE,0);

    gtk_widget_set_size_request((gpointer)pgr_bar, 320,-1);
    gtk_widget_show_all(box);

    return progressmeter;

}


void pgr_set(int page,int npages,char *txt)
{
    double pc;
    char buf[256];
    if (page <=0 || npages <=0) pc=0;
    else {
        pc=(double)page/(double)npages;
        if (pc>1) pc=1;
    }
    if (npages>0 && page >=0) {
        sprintf(buf,"OCR - strona %d z %d",page+1,npages);
        txt=buf;
    }
    gtk_label_set_text((gpointer)pgr_label,txt);
	gtk_progress_bar_set_fraction((gpointer)pgr_bar,pc);
}

extern gint from_page,to_page;

void uncune(char *c)
{
    char *esc="â€”";
    char *esd="—";
    int le=strlen(esc);
    char *d;
    for (d=c;*c;) {
        if (strncmp(c,esc,le)) {
            *d++=*c++;
            continue;
        }
        strcpy(d,esd);
        while (*d) d++;
        c+=le;
    }
    *d=0;
}

char *tesseract(char *fname,int nump,int cuneiform)
{
    int pid,stus;struct stat sb;
    char dirname[256],*dn,command[8192];
    int page_od;


    sprintf(dirname,"%s/tmp/milena_XXXXXX",getenv("HOME"));
    dn=mkdtemp(dirname);
    if (!dn) {
        strcpy(dirname,"/tmp/milena_XXXXXX");
        dn=mkdtemp(dirname);
    }
    if (!dn) {
        Error("Błąd",strerror(errno));
        return NULL;
    }
    pid=fork();
    if (pid < 0) {
        Error("Błąd",strerror(errno));
        rmdir(dirname);
        return NULL;
    }
    if (pid == 0) {
        char *args[16],compo[256];
        int n=0;
        args[n++]="gs";
        args[n++]="-q";
        args[n++]="-dNOPAUSE";
        args[n++]="-dBATCH";
        args[n++]="-dSAFER";
        args[n++]="-r300x300";
        args[n++]="-sDEVICE=tiffg3";
        sprintf(compo,"-sOutputFile=%s/page_%%03d.tif",dirname);
        args[n++]=compo;
        args[n++]="-f";
        args[n++]=fname;
        args[n++]=NULL;
        execvp("gs",args);
        exit(1);
    }
    if (!pgr_meter) pgr_meter=makemeter();
    gtk_widget_show_all(pgr_meter);
    pgr_set(-1,-1,"Tworzę pliki TIFF");
    pgr_stop=0;
    renice(pid);
    for (;;) {
        usleep(50000);
        int rc=waitpid(pid,&stus,WNOHANG);
        if (!rc) {
            gtk_progress_bar_pulse((gpointer)pgr_bar);
            yield();
            if (pgr_stop) break;
            continue;
        }
        if (rc == -1) {
            if (errno != EINTR) {
                perror("Wait");
                exit(1);
            }
        }
        if (rc == pid) break;
    }
    if (pgr_stop) {
        kill(pid,KILL_SIGNAL);
        waitpid(pid,&stus,0);
    }

    GList *flista=getFileList(dirname);
    if (pgr_stop || !WIFEXITED(stus) || WEXITSTATUS(stus)) {
        gtk_widget_hide_all(pgr_meter);
        if (!pgr_stop) Error("Błąd","Ghostscript się zbiesił");
        rem_dir(dirname,flista);
        return NULL;
    }
    if (!flista) {
        gtk_widget_hide_all(pgr_meter);
        Error("Błąd","Ghostscript nie zrobił plików");
        rem_dir(dirname,flista);
        return NULL;
    }
    int page_count=0;
    void mxp(gpointer ffd,gpointer ds)
    {
        int nr;
        char *fd;
        fd=strrchr(ffd,'_');
        if (!fd) return;
        fd++;
        if (!isdigit(*fd)) return;
        nr=strtol(fd,&fd,10);
        if (strcmp(fd,".tif")) return;
        if (nr > page_count) page_count=nr;
    }
    g_list_foreach(flista,mxp,NULL);
    if (!page_count) {
        gtk_widget_hide_all(pgr_meter);
        Error("Błąd","Ilość stron wynosi 0");
        rem_dir(dirname,flista);
        return NULL;
    }
    if (to_page>0) {
        if (page_count > to_page) page_count=to_page;
    }
    page_od=0;
    if (from_page > 1) page_od=from_page-1;
    if (page_od >=page_count) page_od=page_count-1;
    int this_page;
    GString *fbody=g_string_sized_new(1600*(page_count-page_od));

    for (this_page=page_od;this_page < page_count;this_page++) {
        pid=fork();
        if (pid < 0) {
            gtk_widget_hide_all(pgr_meter);
            Error("Fork",strerror(errno));
            g_string_free(fbody,TRUE);
            rem_dir(dirname,flista);
            return NULL;
        }
        if (pid == 0) {
            char *args[16],compo[256],dcompo[256];
            int n;
            close(0);
            close(1);
            close(2);
            n=0;

            if (cuneiform) {
                args[n++]="sh";
                args[n++]="-c";
                sprintf(compo,"%s/page_%03d.tif",dirname,this_page+1);
                sprintf(dcompo,"%s/page.txt",dirname);
                args[n++]=g_strdup_printf(
                    "convert %s +matte +compress bmp:- | cuneiform -f text -l pol -o %s /dev/stdin",
                    g_shell_quote(compo),
                    g_shell_quote(dcompo));
                args[n++]=NULL;
                execvp("/bin/sh",args);
                exit(1);
            }
            args[n++]="tesseract";
            sprintf(compo,"%s/page_%03d.tif",dirname,this_page+1);
            args[n++]=compo;
            sprintf(dcompo,"%s/page",dirname);
            args[n++]=dcompo;
            args[n++]="-l";
            args[n++]="pol";
            args[n++]=NULL;
            execvp("tesseract",args);
            exit(1);
        }
        renice(pid);
        pgr_set(this_page,page_count,"");
        for (;;) {
            usleep(50000);
            int rc=waitpid(pid,&stus,WNOHANG);
            if (!rc) {
                yield();
                if (pgr_stop) break;
                continue;
            }
            if (rc == -1) {
                if (errno != EINTR) {
                    perror("Wait");
                    exit(1);
                }
            }
            if (rc == pid) break;
        }
        if (pgr_stop) {
            gtk_widget_hide_all(pgr_meter);
            kill(pid,KILL_SIGNAL);
            waitpid(pid,&stus,0);
            g_string_free(fbody,TRUE);
            rem_dir(dirname,flista);
            return NULL;
        }
        if (nump) g_string_append_printf(fbody,"\n\n--<<%03d>>--\n\n",this_page+1);
        sprintf(command,"%s/page.txt",dirname);
        if (stat(command,&sb)) {
			continue;
            gtk_widget_hide_all(pgr_meter);
            Error("Stat",strerror(errno));
            g_string_free(fbody,TRUE);
            rem_dir(dirname,flista);
            return NULL;
        }
        int tlen=sb.st_size;
        int fd=open(command,O_RDONLY);
        if (fd < 0) {
            gtk_widget_hide_all(pgr_meter);
            Error("Open",strerror(errno));
            g_string_free(fbody,TRUE);
            rem_dir(dirname,flista);
            return NULL;
        }
        char *cb=g_malloc(tlen+1);
        ignore(read(fd,cb,tlen));
        close(fd);
        cb[tlen]=0;
        //printf("%s\n",cb);
        if (nump) {
            g_string_append(fbody,trim(cb));
        } else {
            g_string_append(fbody,cb);
        }
        g_free(cb);
    }
    if (cuneiform) {
		uncune(fbody->str);
	}
    gtk_widget_hide_all(pgr_meter);
    rem_dir(dirname,flista);
    return g_string_free(fbody,0);
}
