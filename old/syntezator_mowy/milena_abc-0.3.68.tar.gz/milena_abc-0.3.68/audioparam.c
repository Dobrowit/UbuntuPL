/*
 * audioparam.c - Milena Audiobook Creator
 * Copyright (C) Bohdan R. Rau 2009 <ethanak@polip.com>
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write see:
 *               <http://www.gnu.org/licenses/>.
 */

#include "config.h"
#include <gtk/gtk.h>
#include "gmilena.h"
#include "equalizer.h"
static struct EQSTATE equiz;
static double equa_dv;
struct audioparam audioparam_table[3]={
	{880,4000,0.3,1.0,1.0,1.0,0},
	{880,4000,0.3,1.0,1.0,1.0,0},
	{880,4000,0.3,1.0,1.0,1.0,0}};
static int use_equalizer;
static double mbrola_gain=2.5;
static int use_gain=0;
void audioparam_init_f(int which,int freq)
{
	init_equaliser(&equiz,
		audioparam_table[which].low_freq,
		audioparam_table[which].high_freq,
		freq);
	equiz.lg=audioparam_table[which].lgain;
	equiz.mg=audioparam_table[which].mgain;
	equiz.hg=audioparam_table[which].hgain;
	equa_dv=1.0;
	if (equiz.lg > equa_dv) equa_dv=equiz.lg;
	if (equiz.mg > equa_dv) equa_dv=equiz.mg;
	if (equiz.hg > equa_dv) equa_dv=equiz.hg;
	mbrola_gain=audioparam_table[which].mbrola_gain;
	use_equalizer=audioparam_table[which].used;
#ifdef HAVE_IVONA
    if (use_ivona) use_gain=0;
    else
#endif
    use_gain=(mbrola_gain<0.9 ||  mbrola_gain>1.1)?1:0;
}

void audioparam_init(int which)
{
    audioparam_init_f(which,16000);
}

static int clip(double t)
{
	t/=equa_dv;
	if (t>32767) return 32767;
	if (t<-32767) return -32767;
	return t;
}
	
void audioparam(short *buf,int count)
{
	int i;
	if (!use_equalizer) {
        if (!use_gain) return;
        for (i=0;i<count;i++) buf[i]=clip(mbrola_gain *(double)buf[i]);
        return;
    }
    if (use_gain) {
        for (i=0;i<count;i++) buf[i]=clip(equalise(&equiz,mbrola_gain * (double)buf[i]));
    }
    else {
        for (i=0;i<count;i++) buf[i]=clip(equalise(&equiz,(double)buf[i]));
    }
}

static GtkWidget *create_slider(double emin,double emax,double estep,double value)
{
	GtkWidget *gx = 
#ifdef HAVE_GTK3
		gtk_scale_new_with_range(GTK_ORIENTATION_HORIZONTAL,emin,emax,estep);
#else
		gtk_hscale_new_with_range(emin,emax,estep);
#endif
	gtk_scale_set_draw_value((gpointer)gx,TRUE);
	gtk_scale_set_value_pos((gpointer)gx,GTK_POS_RIGHT);
	gtk_widget_set_size_request((gpointer)gx,150,-1);
	gtk_range_set_value((gpointer)gx,value);
	return gx;
}

void audioparam_ask(int which)
{
	static char *whaty[]={
		"Włącz equalizer dla mowy",
		"Włącz equalizer dla nagrań",
		"Włącz equalizer dla lektora w filmie"};
	GtkWidget *dialog=gtk_dialog_new_with_buttons("Equalizer",
			(gpointer)main_window,
			GTK_DIALOG_DESTROY_WITH_PARENT | GTK_DIALOG_MODAL,
			GTK_STOCK_OK,GTK_RESPONSE_ACCEPT,
			GTK_STOCK_CANCEL,GTK_RESPONSE_REJECT,
			NULL);
	
	GtkWidget *box=gtk_dialog_get_content_area((gpointer)dialog);
	GtkWidget *stable=gtk_table_new(4,3,0);
	GtkWidget *label=gtk_label_new("Niskie");
	gtk_table_attach_defaults((gpointer)stable,label,0,1,0,1);
	//GtkWidget *lo_gain=gtk_spin_button_new_with_range(0.0,1.5,0.01);
	//gtk_spin_button_set_value((gpointer)lo_gain,(double)audioparam_table[which].lgain);
	GtkWidget *lo_gain=create_slider(0.0,1.5,0.01,(double)audioparam_table[which].lgain);
	gtk_table_attach_defaults((gpointer)stable,lo_gain,1,2,0,1);
	connect_label(label,lo_gain);
	//GtkWidget *lo_freq=gtk_spin_button_new_with_range(50.0,1200.0,1.0);
	//gtk_spin_button_set_value((gpointer)lo_freq,(double)audioparam_table[which].low_freq);
	GtkWidget *lo_freq=create_slider(50.0,1200.0,1.0,(double)audioparam_table[which].low_freq);
	gtk_table_attach_defaults((gpointer)stable,lo_freq,2,3,0,1);
	atk_object_set_name(gtk_widget_get_accessible(lo_freq),"Częstotliwość odcięcia niskich");
	label=gtk_label_new("Hz");
	gtk_table_attach_defaults((gpointer)stable,label,3,4,0,1);
	label=gtk_label_new("Średnie");
	gtk_table_attach_defaults((gpointer)stable,label,0,1,1,2);
	//GtkWidget *mi_gain=gtk_spin_button_new_with_range(0.0,1.5,0.01);
	//gtk_spin_button_set_value((gpointer)mi_gain,(double)audioparam_table[which].mgain);
	GtkWidget *mi_gain=create_slider(0.0,1.5,0.01,(double)audioparam_table[which].mgain);

	gtk_table_attach_defaults((gpointer)stable,mi_gain,1,2,1,2);
	connect_label(label,mi_gain);
	label=gtk_label_new("Wysokie");
	gtk_table_attach_defaults((gpointer)stable,label,0,1,2,3);
	//GtkWidget *hi_gain=gtk_spin_button_new_with_range(0.0,1.5,0.01);
	//gtk_spin_button_set_value((gpointer)hi_gain,(double)audioparam_table[which].hgain);
	GtkWidget *hi_gain=create_slider(0.0,1.5,0.01,(double)audioparam_table[which].hgain);

	gtk_table_attach_defaults((gpointer)stable,hi_gain,1,2,2,3);
	connect_label(label,hi_gain);
	GtkWidget *hi_freq=create_slider(2400.0,5000.0,10.0,(double)audioparam_table[which].high_freq);

	//GtkWidget *hi_freq=gtk_spin_button_new_with_range(2400,5000.0,10.0);
	//gtk_spin_button_set_value((gpointer)hi_freq,(double)audioparam_table[which].high_freq);
	gtk_table_attach_defaults((gpointer)stable,hi_freq,2,3,2,3);
	atk_object_set_name(gtk_widget_get_accessible(hi_freq),"Częstotliwość odcięcia wysokich");
	label=gtk_label_new("Hz");
	gtk_table_attach_defaults((gpointer)stable,label,3,4,2,3);
	GtkWidget *use_eq=gtk_check_button_new_with_label(whaty[which]);
	gtk_toggle_button_set_active((gpointer)use_eq,audioparam_table[which].used);
	gtk_table_attach_defaults((gpointer)stable,use_eq,0,4,3,4);

	label=gtk_label_new("Mnożnik (mbrola)");
	gtk_table_attach_defaults((gpointer)stable,label,0,1,4,5);
	GtkWidget *mbr_gain=create_slider(0.5,3.0,0.05,(double)audioparam_table[which].mbrola_gain);

	gtk_table_attach_defaults((gpointer)stable,mbr_gain,1,2,4,5);
	connect_label(label,mbr_gain);

    gtk_box_pack_start(GTK_BOX(box),stable,FALSE,FALSE,0);
	gtk_widget_show_all(box);
	if (gtk_dialog_run((gpointer)dialog) == GTK_RESPONSE_ACCEPT) {
		audioparam_table[which].used=gtk_toggle_button_get_active((gpointer)use_eq);
		audioparam_table[which].low_freq=gtk_range_get_value((gpointer)lo_freq);
		audioparam_table[which].high_freq=gtk_range_get_value((gpointer)hi_freq);
		audioparam_table[which].lgain=gtk_range_get_value((gpointer)lo_gain);
		audioparam_table[which].mgain=gtk_range_get_value((gpointer)mi_gain);
		audioparam_table[which].hgain=gtk_range_get_value((gpointer)hi_gain);
		audioparam_table[which].mbrola_gain=gtk_range_get_value((gpointer)mbr_gain);
	}
	gtk_widget_destroy(dialog);
}
