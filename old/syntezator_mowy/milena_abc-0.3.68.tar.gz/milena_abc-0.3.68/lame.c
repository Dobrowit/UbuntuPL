/*
 * lame.c - Milena Audiobook Creator
 * Copyright (C) Bohdan R. Rau 2009 <ethanak@polip.com>
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write see:
 *               <http://www.gnu.org/licenses/>.
 */
#include "config.h"
#include "gmilena.h"
#include <lame/lame.h>

static FILE *mp3_file;
static lame_t lame_encoder;

#define LAME_BUFSIZE (8192 + 1024 + 7200)

static int rates[3]={32,48,64};
static int lame_samplefreq;
static long int lame_samplenum;

int init_lame_encoder(char *fname,int rate,char *artist,char *album,char *title,int track,int samplefreq)
{
	mp3_file=fopen(fname,"w+");
	if (!mp3_file) {
		g_perror(fname);
		return 0;
	}
	lame_encoder=lame_init();
	lame_set_num_channels(lame_encoder,stereo_mode?2:1);
	lame_samplefreq=stereo_upsample?(2*samplefreq):samplefreq;
    lame_set_in_samplerate(lame_encoder,stereo_upsample?(2*samplefreq):samplefreq);
	lame_set_mode(lame_encoder,stereo_mode?JOINT_STEREO:MONO);
	lame_set_brate(lame_encoder,rates[rate]);
	if ((id3_tag_mode & 3) && (artist || album ||title)) {
		char trk[8];
		sprintf(trk,"%d",track);
		id3tag_init(lame_encoder);
		switch (id3_tag_mode & 3) {
			case 1:
				id3tag_v1_only(lame_encoder);
				break;
			case 2:
				id3tag_v2_only(lame_encoder);
				id3tag_pad_v2(lame_encoder);
				break;
			default:
				id3tag_add_v2(lame_encoder);
				id3tag_pad_v2(lame_encoder);
				break;
		}
		if (artist) id3tag_set_artist(lame_encoder,artist);
		if (album) id3tag_set_album(lame_encoder,album);
		if (title) id3tag_set_title(lame_encoder,title);
		id3tag_set_track(lame_encoder,trk);
		id3tag_set_genre(lame_encoder,"101");
	}
	int ret=lame_init_params(lame_encoder);
	if (ret<0) {
		fclose(mp3_file);
		Error("Lame","Nie mogę zainicjalizować enkodera");
		return 0;
	}
    lame_samplenum=0;
	return 1;
}

int lame_encode(short *buf,int nsamples)
{
	unsigned char outbuf[LAME_BUFSIZE];
	int n;
    lame_samplenum += nsamples;
	if (stereo_mode) {
		n=lame_encode_buffer_interleaved(lame_encoder,buf,nsamples/2,outbuf,LAME_BUFSIZE);
	}
	else {
		n=lame_encode_buffer(lame_encoder,buf,buf,nsamples,outbuf,LAME_BUFSIZE);
	}
	if (n<0) return 0;
	if (n) fwrite(outbuf,1,n,mp3_file);
	return 1;
}

int lame_finish(void)
{
	unsigned char outbuf[LAME_BUFSIZE];
	int n;
	n=lame_encode_flush(lame_encoder,outbuf,LAME_BUFSIZE);
	if (n<0) {
		fclose(mp3_file);
		return 0;
	}
	if (n) fwrite(outbuf,1,n,mp3_file);
	fflush(mp3_file);
	lame_mp3_tags_fid(lame_encoder,mp3_file);
	lame_close(lame_encoder);
	fclose(mp3_file);
	return 1;
}

double lame_get_seconds(void)
{
	return lame_samplenum/(double)lame_samplefreq;
}
