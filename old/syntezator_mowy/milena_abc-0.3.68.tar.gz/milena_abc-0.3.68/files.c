/*
 * files.c - Milena Audiobook Creator
 * Copyright (C) Bohdan R. Rau 2009 <ethanak@polip.com>
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write see:
 *               <http://www.gnu.org/licenses/>.
 */

#include "config.h"
#include "gmilena.h"
#include "html.h"
#include <stdarg.h>
#include <string.h>
#include <math.h>
#include <enca.h>
#include <unistd.h>
#include <fcntl.h>
#include <stdio.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <ctype.h>
#include <errno.h>
#include <glib/gstdio.h>
#include <glib.h>

extern int ignore_oor;

int my_compare(char *s1,char *s2)
{
	while (*s1) {
		while (*s1 && !isalnum(*s1)) s1++;
		if (!*s1) break;
		if (*s2++ != tolower(*s1++)) return 0;
	}
	if (*s2) return 0;
	return 1;
}

void auto_window_title(void)
{
    int m=get_current_editor();
    struct MyGtkEditor *edi;
    char *ext,*c,*d;
    static char titlebuf[256];
    edi=current_editor;
    if (m<0 || !edi) {
        gtk_window_set_title((gpointer)main_window,"Milena - Kreator audioksiążek");
        return;
    }
    ext="tekst";
    if (m==MILEDIT_MODE_DASH) ext="dash";
    else if (m==MILEDIT_MODE_DIC) ext="dic";
    if (m) edi=edi->owneditor;
    if (!edi) {
        gtk_window_set_title((gpointer)main_window,"Milena - Kreator audioksiążek");
    }
    d=edi->movie_name;
    if (!*d) d=edi->save_name;
    if (!*d) d=edi->load_name;
    strcpy(titlebuf,"Milena - ");
    if (*d) {
        c=strrchr(d,'/');
        if (c) c++;
        else c=d;
        strcat(titlebuf,c);
        c=strrchr(titlebuf,'.');
        if (c) *c=0;
    }
    else strcat(titlebuf,"FILE");
    sprintf(titlebuf+strlen(titlebuf)," - %s",ext);
    gtk_window_set_title((gpointer)main_window,titlebuf);
}






extern char *read_rtf(char *str,int len);
extern char *to_utf8(char *fbuf,int flen,char *cset,int freeme);
#define TESTBUF_SIZE 100

const char *get_encoding(char *buf,size_t len)
{
	EncaAnalyser an;
	const double mu = 0.005;
	const double m = 15.0;
	size_t sgnf;
	const char *c;
	EncaEncoding result;
	for (c=buf;*c && (c-buf)<len;c++) if ((*c) & 0x80) break;
	if (!*c || c>=buf+len) return "UTF-8";
	an=enca_analyser_alloc("pl");
	if (!an) {
		return NULL;
	}
	enca_set_threshold(an, 1.38);
	enca_set_multibyte(an, 1);
	enca_set_ambiguity(an, 1);
	enca_set_garbage_test(an, 1);
	sgnf = ceil((double)len/(len/m + 1.0/mu));
	enca_set_significant(an, sgnf);
	enca_set_termination_strictness(an, 1);
	enca_set_filtering(an, sgnf > 2);

	result = enca_analyse_const(an, (unsigned char *)buf, len);
	if (!enca_charset_is_known(result.charset)) {
		enca_analyser_free(an);
		return NULL;
	}
	c=enca_charset_name(result.charset,ENCA_NAME_STYLE_ICONV);
	enca_analyser_free(an);
	return c;
}

int check_program(char *program,char *pakiet)
{
	char *c=getenv("PATH");
	if (!c) {
		Error("Błąd","Brak ustawionej ścieżki PATH");
		return 0;
	}
	char **path=g_strsplit(c,":",0);
	int i,fnd;
	for (i=fnd=0;path[i];i++) {
		char buf[PATH_MAX];
		sprintf(buf,"%s/%s",path[i],program);
		if (!g_access(buf,X_OK|R_OK)) {
			fnd=1;
			break;
		}

	}
	g_strfreev(path);
	if (!fnd) {
		char buf[512];
		sprintf(buf,"Brak programu %s",program);
		if (pakiet) sprintf(buf+strlen(buf),".\nZainstaluj pakiet %s",pakiet);
		Error("Błąd",buf);
	}
	return fnd;

}

void autocompose_psp(char *buf)
{
	char *obuf,*s,*bs;
	obuf=bs=buf;
	int gtch()
	{
		int z,n;
		if (!*buf) return 0;
		z=(*buf++) & 255;
		if (!(z & 0x80)) return z;
		if ((z & 0xe0) == 0xc0) {n=1;z&=0x1f;}
		else if ((z & 0xf0) == 0xe0) {n=2;z&=0x0f;}
		else if ((z & 0xf8) == 0xf0) {n=3;z&=0x07;}
		else if ((z & 0xfc) == 0xf8) {n=4;z&=0x03;}
		else if ((z & 0xfe) == 0xfc) {n=5;z&=0x01;}
		else return 0;

		while(n && *buf) {
			z=(z<<6) | ((*buf++) & 0x3f);
			n--;
		}
		return z;
	}
	for (;;) {
		int z1,z2,z3;
		s=buf;
		z1=gtch();
		if (!z1) break;
		//printf("%d %d\n",z1,L'´');
		if (z1 != L'´' && z1 != L'˙' && z1 !=L'˛') {
loop:			while (s<buf) *obuf++=*s++;
			continue;
		}
		z2=gtch();
		if (!z2) break;
		if (z2 >= 0x80) goto loop;
		if (z1==L'´') {
			if (z2=='S') z3=L'Ś';
			else if (z2=='s') z3=L'ś';
			else if (z2=='C') z3=L'Ć';
			else if (z2=='c') z3=L'ć';
			else if (z2=='N') z3=L'Ń';
			else if (z2=='n') z3=L'ń';
			else if (z2=='Z') z3=L'Ź';
			else if (z2=='z') z3=L'ź';
			else goto loop;
		}
		else if (z1 == L'˙') {
			if (z2=='Z') z3=L'Ż';
			else if (z2=='z') z3=L'ż';
			else goto loop;
		}
		else if (z1 == L'˛') {
			if (z2=='A') z3=L'Ą';
			else if (z2=='a') z3=L'ą';
			else if (z2=='E') z3=L'Ę';
			else if (z2=='e') z3=L'ę';
			else goto loop;
			if (obuf != bs && obuf[-1] == ' ') obuf--;
		}
		else goto loop;
		*obuf++=(z3>>6) | 0xc0;
		*obuf++=(z3 & 0x3f) | 0x80;
	}
	*obuf=0;
}

static char *read_file(char *name,int *is_g,int new_pdf,int *is_iso2)
{
	int fd;
	struct stat sb;
	int flen,inb,fmode;
	char *fbuf,*exten;
	char tempo[64];
	static unsigned char *isword[3]={
		(unsigned char *)"\004\376\067\0\043",
		(unsigned char *)"\x8\320\317\021\340\241\261\032\341",
		(unsigned char *)"\x6\333\245-\0\0\0"};
	char testbuf[TESTBUF_SIZE];
	int i;
	char *encoding=NULL;

	if (is_g) *is_g=0;
	if (stat(name,&sb)) {
		g_perror(name);
		return NULL;
	}
	exten=strrchr(name,'.');
	if (exten && !strcasecmp(exten,".mobi")) {
		char *erc=NULL;
		if (!check_program("ebook-convert","calibre")) return NULL;
		fbuf=read_mobi(name,&erc);
		if (!fbuf) {
			if (!erc) erc="Nieznany błąd";
			Error("MOBI",erc);
			return NULL;
		}
		return fbuf;
	}
#ifdef HAVE_EPUB
	if (exten && !strcasecmp(exten,".epub")) {
		char *erc=NULL;
		fbuf=read_epub(name,&erc);
		if (!fbuf) {
			if (!erc) erc="Nieznany błąd";
			Error("EPub",erc);
			return NULL;
		}
		return fbuf;
	}
#endif
	if ((fd=open(name,O_RDONLY))<0) {
		g_perror(name);
		return NULL;
	}
	flen=sb.st_size;
	inb=0;fmode=0;
	if (flen > TESTBUF_SIZE) {
		if (read(fd,testbuf,TESTBUF_SIZE)!=TESTBUF_SIZE) {
			g_perror(name);
			return NULL;
		}
		inb=TESTBUF_SIZE;
		fmode=0;
		if (!strncmp(testbuf,"{\\rtf",5)) fmode=1;
		else if (!strncmp(testbuf,"%!PS-Adobe",10)) fmode=5;
		else if (!strncmp(testbuf,"%PDF-1",6)) fmode=4;
		else {
			for (i=0;i<3;i++) if (!memcmp(testbuf,isword[i]+1,isword[i][0])) {
				fmode=2;
				break;
			}

		}
		if (!fmode) {
			if (!memcmp(testbuf,"PK\003\004",4)) {
				for (i=0;i<TESTBUF_SIZE-27;i++) {
					if (!memcmp(testbuf+i,"vnd.oasis.opendocument.text",27)) {
						fmode=3;
						break;
					}
				}
			}
		}
	}
    if (fmode == 4 && (new_pdf == 2 || new_pdf == 3 || new_pdf == 4 || new_pdf ==5)) {
        close(fd);
        if (!check_program("gs","ghostscript")) return NULL;
        if (new_pdf < 4 && !check_program("tesseract","tesseract")) return NULL;
        if (new_pdf > 4 && (!check_program("cuneiform","cuneiform") || !check_program("convert","ImageMagick"))) return NULL;
        if(is_g) *is_g=1;
        return tesseract(name,(new_pdf == 3) || (new_pdf == 5),new_pdf>3);
    }
	if (fmode == 5) {
		char sbuf[1024],*c,*d;
		close(fd);
		if (!check_program(new_pdf?"pdftohtml":"pdftotext","poppler-utils lub xpdf-utils")) return NULL;
		if (!check_program("ps2pdf","ghostscript")) return NULL;
		strcpy(sbuf,"ps2pdf ");
		c=name;
		d=sbuf+strlen(sbuf);
		for (;*c;c++) {
		if (!isalnum(*c) && !strchr("./",*c)) *d++='\\';
			*d++=*c;
		}
		*d++=' ';
		strcpy(tempo,"/tmp/milenizer_XXXXXX");
		fd=mkstemp(tempo);
		if (fd<0) {
			g_perror("mkstemp");
			return NULL;
		}
		close(fd);
		strcpy(d,tempo);
		strcat(sbuf,".pdf");
		ignore(system(sbuf));
		if (stat(d,&sb)) {
			g_perror(d);
			remove(tempo);
			remove(d);
			return NULL;
		}
		if (new_pdf) strcpy(sbuf,"pdftohtml -i -noframes -xml -stdout -enc UTF-8 ");
		else strcpy(sbuf,"pdftotext -raw -enc UTF-8 ");
		strcat(sbuf,tempo);
		strcat(sbuf,".pdf ");
		if (new_pdf) strcat(sbuf,">");
		strcat(sbuf,tempo);
		ignore(system(sbuf));
		strcpy(sbuf,tempo);
		strcat(sbuf,".pdf");
		remove(sbuf);
		if (stat(tempo,&sb)) {
			g_perror(d);
			remove(tempo);
			return NULL;
		}
		flen=sb.st_size;
		if (!flen) {
			remove(tempo);
			Error("Błąd","Wynikowy plik jest pusty");
			return NULL;
		}
		fd=open(tempo,O_RDONLY);
		if (fd<0) {
			g_perror(tempo);
			remove(tempo);
			return NULL;
		}
		inb=0;
		remove(tempo);
		encoding="UTF-8";
	}
	else if (fmode==2 || fmode==3 || fmode==4) {
		char sbuf[1024],*c,*d;
		close(fd);
		if (fmode==2) {
			if (!check_program("antiword",NULL)) return NULL;
			strcpy(sbuf,"antiword -w 0 -m UTF-8.txt ");
		}
		else if (fmode == 3) {
			if (!check_program("odt2txt",NULL)) return NULL;
			strcpy(sbuf,"odt2txt --width=-1 --encoding=UTF-8 ");
		}
		else {
			if (!check_program(new_pdf?"pdftohtml":"pdftotext","poppler-utils lub xpdf-tools")) return NULL;
			if (new_pdf) sprintf(sbuf,"pdftohtml -i -noframes %s -xml -stdout -enc UTF-8 ",no_drm?"-nodrm":"");
			else strcpy(sbuf,"pdftotext -raw -enc UTF-8 ");
		}
		c=name;
		d=sbuf+strlen(sbuf);
		for (;*c;c++) {
		if (!isalnum(*c) && !strchr("./",*c)) *d++='\\';
			*d++=*c;
		}
		if (fmode !=4 || new_pdf) strcpy(d," > ");
		else strcpy(d," ");
		strcpy(tempo,"/tmp/milenizer_XXXXXX");
		fd=mkstemp(tempo);
		if (fd<0) {
			g_perror("mkstemp");
			return NULL;
		}
		close(fd);
		strcat(sbuf,tempo);
		ignore(system(sbuf));
		if (stat(tempo,&sb)) {
			g_perror(tempo);
			remove(tempo);
			return NULL;
		}
		flen=sb.st_size;
		if (!flen && fmode == 4) {
			remove(tempo);
			if ((new_pdf == 1) && !no_drm && Ask("Pytanie","Czy mam włączyć ignorowanie DRM?")) {
			    no_drm=1;
			    return read_file(name,is_g,new_pdf,is_iso2);
			}
			
			if (!Ask("Pytanie","Plik PDF wygląda na zabezpieczony.\nCzy mam próbować wczytać go poprzez PostScript?\nNie zawsze się to udaje...")) return NULL;
			yield();
			if (!check_program("pdftops","poppler-utils lub xpdf-tools")) return NULL;
			if (!check_program("ps2pdf","ghostscript")) return NULL;

			strcpy(sbuf,"pdftops ");
			c=name;
			d=sbuf+strlen(sbuf);
			for (;*c;c++) {
			if (!isalnum(*c) && !strchr("./",*c)) *d++='\\';
				*d++=*c;
			}
			*d++=' ';
			strcpy(d,tempo);
			strcat(d,".ps");
			//printf("\nWykonuję %s\n",sbuf);
			ignore(system(sbuf));
			strcpy(sbuf,"ps2pdf ");
			strcat(sbuf,tempo);
			strcat(sbuf,".ps ");
			strcat(sbuf,tempo);
			strcat(sbuf,".pdf");
			//printf("Wykonuję %s\n",sbuf);
			ignore(system(sbuf));
			strcpy(sbuf,tempo);
			strcat(sbuf,".ps");
			remove(sbuf);
			if (new_pdf) strcpy(sbuf,"pdftohtml -i -noframes -xml -stdout -enc UTF-8 ");
			else strcpy(sbuf,"pdftotext -raw -enc UTF-8 ");
			strcat(sbuf,tempo);
			strcat(sbuf,".pdf ");
			if (new_pdf) strcat(sbuf,">");
			strcat(sbuf,tempo);
			//printf("Wykonuję %s\n",sbuf);
			ignore(system(sbuf));
			strcpy(sbuf,tempo);
			strcat(sbuf,".pdf");
			remove(sbuf);
			if (stat(tempo,&sb)) {
				g_perror(tempo);
				remove(tempo);
				return NULL;
			}
			flen=sb.st_size;
		}
		fd=open(tempo,O_RDONLY);
		if (fd<0) {
			g_perror(tempo);
			remove(tempo);
			return NULL;
		}
		inb=0;
		remove(tempo);
		encoding="UTF-8";
		//fmode=0;
	}
	fbuf=g_malloc(flen+1);
	if (inb) memcpy(fbuf,testbuf,inb);
	if (read(fd,fbuf+inb,flen-inb)!=flen-inb) {
		g_perror(name);
		return NULL;
	}
	close(fd);
	fbuf[flen]=0;
	if (!fmode && exten && (!strcasecmp(exten,".html") || !strcasecmp(exten,".xhtml") || !strcasecmp(exten,".htm"))) {
		int n=html2txt(fbuf,NULL);
		if (n>0) {
			char *c=g_malloc(n);
			html2txt(fbuf,c);
			g_free(fbuf);
			return c;
		}
	}
	if (!fmode) {
		char *c=strstr(fbuf,"<!DOCTYPE pdf2xml");
		if (c && c < fbuf+100) {
			c=pdxml2txt(fbuf);
			g_free(fbuf);
			fbuf=c;
		}
	}
	if (fmode==1) {
		char *c=read_rtf(fbuf,flen);
		g_free(fbuf);
		return c;
	}
	if (!encoding) encoding=(char *)get_encoding(fbuf,flen);
	if (!encoding) {
		encoding=ask_encoding();
		if (!encoding) {
			g_free(fbuf);
			return NULL;
		}
	}
    if (is_iso2) {
        *is_iso2 = fmode?0:my_compare(encoding,"iso88592");
    }
	if (!my_compare(encoding,"utf8")) {
		fbuf=to_utf8(fbuf,flen,encoding,1);
	}
	if (fmode == 4 || fmode == 5) {
		if (new_pdf) {
			char *cs=pdxml2txt(fbuf);
			g_free(fbuf);
			fbuf=cs;
		}
		autocompose_psp(fbuf);
	}
	return fbuf;
}



char last_file_path[PATH_MAX+1];

GtkFileFilter *make_filter(char *name,...)
{
	va_list ap;
	va_start(ap,name);
	char *c;
	GtkFileFilter *filter=gtk_file_filter_new();
	gtk_file_filter_set_name(filter,name);
	for (;;) {
		c=va_arg(ap,char *);
		if (!c) break;
		gtk_file_filter_add_pattern(filter,c);
	}
	va_end(ap);
	return filter;
}
int textbuf_is_empty(gpointer buf)
{
	int n=gtk_text_buffer_get_char_count(buf);
	return !n;

}

void new_file(GtkWidget *dummy,void *data)
{
	CreateEditor(0,NULL,"nowy");
}

static int get_save_path(char *path,int is_dic,int *save_as_iso2)
{
	int n;
	GtkWidget *dialog=gtk_file_chooser_dialog_new(
		is_dic?"Wybierz plik do zapisu słownika":"Wybierz plik do zapisu",
		GTK_WINDOW(main_window),GTK_FILE_CHOOSER_ACTION_SAVE,
		GTK_STOCK_CANCEL, GTK_RESPONSE_CANCEL,
		GTK_STOCK_SAVE, GTK_RESPONSE_ACCEPT,
		NULL);
	GtkFileFilter *filter;
    GtkWidget *iso2;
	gtk_file_chooser_set_local_only((gpointer)dialog,TRUE);
	if (!is_dic) gtk_file_chooser_add_filter((gpointer) dialog,
		filter=make_filter("Pliki tekstowe","*.txt","*.TXT",NULL));
	if (is_dic) gtk_file_chooser_add_filter((gpointer) dialog,
		filter=make_filter("Pliki DIC","*.dic","*.DIC",NULL));
	gtk_file_chooser_add_filter((gpointer) dialog,
		make_filter("Wszystkie pliki","*",NULL));
	gtk_file_chooser_set_filter((gpointer) dialog,filter);
    if (!is_dic && save_as_iso2) {
        iso2=gtk_check_button_new_with_label("Zapisz jako ISO-8859-2");
        gtk_file_chooser_set_extra_widget((gpointer) dialog,iso2);
        gtk_toggle_button_set_active((gpointer)iso2, *save_as_iso2);
		gtk_widget_show_all(iso2);
    }
    else {
        iso2=NULL;
    }
	if (*path) {
		char *c=strrchr(path,'/');
		if (c) {
			*c++=0;
			gtk_file_chooser_set_current_folder((gpointer)dialog,path);
			gtk_file_chooser_set_current_name((gpointer)dialog,c);
		}
	}
	gtk_file_chooser_set_do_overwrite_confirmation((gpointer)dialog,TRUE);
#if GTK_CHECK_VERSION(2,18,0)
	gtk_file_chooser_set_create_folders((gpointer)dialog,TRUE);
#endif
	if ((n=gtk_dialog_run((gpointer)dialog))==GTK_RESPONSE_ACCEPT){
		strcpy(path,gtk_file_chooser_get_filename((gpointer)dialog));
	}
    if (iso2 && save_as_iso2) {
        *save_as_iso2=gtk_toggle_button_get_active((gpointer)iso2);
    }
	gtk_widget_destroy(dialog);
	return n==GTK_RESPONSE_ACCEPT;
}

extern int ignore_oor;
static void save_dic_file(int do_ask)
{
	struct MyGtkEditor *main_editor,*dic_editor;
	char path[PATH_MAX+1],*fname;
	int cp=0;char *c;
	if (current_editor->editor_type == MILEDIT_MODE_NORMAL) {
		main_editor=current_editor;
		dic_editor=current_editor->dic_editor;
	}
	if (current_editor->editor_type == MILEDIT_MODE_DIC) {
		main_editor=current_editor->owneditor;
		dic_editor=current_editor;
	}
	else return;
	if (!gtk_text_buffer_get_char_count(dic_editor->buf)) return;
	if (!main_editor || !dic_editor) return;
	path[0]=0;
	if (do_ask || !dic_editor->save_name[0]) {
		if (dic_editor->save_name[0]) strcpy(path,dic_editor->save_name);
		else if (dic_editor->load_name[0]) strcpy(path,dic_editor->load_name);
		else if (main_editor->save_name[0]) {
			strcpy(path,main_editor->save_name);
			cp=1;
		}
		else if (main_editor->load_name[0]) {
			strcpy(path,main_editor->load_name);
			cp=1;
		}
		if (path[0]) {
			fname=strrchr(path,'/');
			if (!fname) path[0]=0;
			else {
				fname++;
			}
			if (cp) {
				c=strrchr(fname,'.');
				if (!c) c=fname+strlen(fname);
				strcpy(c,".dic");
			}
		}
		if (!get_save_path(path,1,NULL)) return;
	}
	else strcpy(path,dic_editor->save_name);

	GtkTextIter start,end;
	gtk_text_buffer_get_start_iter((gpointer)dic_editor->buf,&start);
	gtk_text_buffer_get_end_iter((gpointer)dic_editor->buf,&end);
	char *str=gtk_text_buffer_get_text((gpointer)dic_editor->buf,&start,&end,FALSE);
	//str=get_actual_body();
	ignore_oor=1;
	int n=to_iso2(str,NULL);
	if (!n) {
		g_free(str);
		return;
	}
	char *istr=g_malloc(n);
	to_iso2(str,istr);
	g_free(str);
	FILE *f=fopen(path,"w");
	if (!f) {
		g_perror(path);
		g_free(istr);
		return;
	}
	fwrite(istr,1,strlen(istr),f);
	fclose(f);
	g_free(istr);
	strcpy(dic_editor->save_name,path);
	gtk_text_buffer_set_modified((gpointer)dic_editor->buf,FALSE);
	Info("Potwierdzenie","Plik słownika został zapisany");

}


void notek_set_tab_label(char *text)
{
	get_current_editor();
	GtkWidget *label=gtk_label_new(text);
	gtk_notebook_set_tab_label((gpointer)notek,(gpointer)current_editor->window,label);
	atk_object_set_name(gtk_widget_get_accessible((gpointer)label),text);
	atk_object_set_name(gtk_widget_get_accessible((gpointer)tresc_v),text);
	//printf("New label %s\n",text);
}

void create_uuid(unsigned char *c,char *name)
{
    int i;
    int fd;
    fd=open("/dev/urandom",O_RDONLY);
    if (fd<0) {
        srand(time(0));
        for (i=0;i<16;i++) c[i]=rand() & 255;
    }
    else {
        ignore(read(fd,c,16));
        close(fd);
    }
    c[6]=0x40 | (c[6] & 0x0f);
    c[8]=0x80 | (c[8] & 0x3f);
    for (i=0;i<16;i++) {
        if (i==4 || i==6 || i==8 || i==10) *name++='-';
        sprintf(name,"%02x",c[i]);
        name+=2;
    }
    *name=0;
}

static char *epub_content_xml="<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n\
<package xmlns=\"http://www.idpf.org/2007/opf\" unique-identifier=\"BookId\" version=\"2.0\">\n\
    <metadata xmlns:dc=\"http://purl.org/dc/elements/1.1/\" xmlns:dcterms=\"http://purl.org/dc/terms/\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:opf=\"http://www.idpf.org/2007/opf\">\n\
      <dc:title>%T</dc:title>\n\
      <dc:creator>%A</dc:creator>\n\
      <dc:language>pl</dc:language>\n\
      <dc:identifier id=\"BookId\">%U</dc:identifier>\n\
      <dc:subject>General Fiction</dc:subject>\n\
      <dc:date>%D</dc:date>\n%X\
    </metadata>\n\
    <manifest>\n\
        <item id=\"toc\" href=\"toc.ncx\"\n\
          media-type=\"application/x-dtbncx+xml\" />\n\
        <item id=\"CoverPage\" href=\"CoverPage.html\"\n\
          media-type=\"application/xhtml+xml\" />\n%Y\
        <item id=\"TableOfContents\" href=\"TableOfContents.html\"\n\
          media-type=\"application/xhtml+xml\" />\n\
        <item id=\"style\" href=\"style.css\"\n\
          media-type=\"text/css\" />\n\
%C    </manifest>\n\
    <spine toc=\"toc\">\n\
        <itemref idref=\"CoverPage\" />\n\
        <itemref idref=\"TableOfContents\" />\n\
%I    </spine>\n\
    <guide>\n\
        <reference type=\"cover\" title=\"Okładka\"\n\
            href=\"CoverPage.html\" />\n\
        <reference type=\"toc\" title=\"Spis treści\"\n\
            href=\"TableOfContents.html\" />\n\
    </guide>\n\
</package>\n";


static char *epub_toc_xml="<?xml version=\"1.0\" encoding=\"utf-8\" ?>\n\
<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.1//EN\" \"http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd\">\n\
<html xmlns=\"http://www.w3.org/1999/xhtml\">\n\
<head>\n\
<meta http-equiv=\"Content-Type\" content=\"application/xhtml+xml; charset=utf-8\" />\n\
<link rel=\"stylesheet\" type=\"text/css\" href=\"style.css\" />\n\
<title>Spis treści</title>\n\
</head>\n\
<body>\n\
<h3 class=\"toc_heading\">Spis treści</h3>\n";

static char *epub_ncx_xml="<?xml version=\"1.0\" encoding=\"utf-8\" ?>\n\
<!DOCTYPE ncx PUBLIC \"-//NISO//DTD ncx 2005-1//EN\" \"http://www.daisy.org/z3986/2005/ncx-2005-1.dtd\">\n\
<ncx xmlns=\"http://www.daisy.org/z3986/2005/ncx/\" xml:lang=\"pl\" version=\"2005-1\">\n\
    <head>\n\
        <meta name=\"dtb:uid\" content=\"%U\" />\n\
        <meta name=\"dtb:depth\" content=\"1\" />\n\
        <meta name=\"dtb:totalPageCount\" content=\"0\" />\n\
        <meta name=\"dtb:maxPageNumber\" content=\"0\" />\n\
    </head>\n\
\n\
    <docTitle>\n\
        <text>%T</text>\n\
    </docTitle>\n\
\n\
    <navMap>\n\
        <navPoint id=\"navPoint-1\" playOrder=\"1\">\n\
            <navLabel>\n\
                <text>Okładka</text>\n\
            </navLabel>\n\
            <content src=\"CoverPage.html\" />\n\
        </navPoint>\n\
        <navPoint id=\"navPoint-2\" playOrder=\"2\">\n\
            <navLabel>\n\
                <text>Spis treści</text>\n\
            </navLabel>\n\
            <content src=\"TableOfContents.html\" />\n\
        </navPoint>\n\
%I    </navMap>\n\
</ncx>\n";

static char *epub_cover_xml="<?xml version=\"1.0\" encoding=\"utf-8\" ?>\n\
<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.1//EN\" \"http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd\">\n\
<html xmlns=\"http://www.w3.org/1999/xhtml\">\n\
<head>\n\
<meta http-equiv=\"Content-Type\" content=\"application/xhtml+xml; charset=utf-8\" />\n\
<link rel=\"stylesheet\" type=\"text/css\" href=\"style.css\" />\n\
<title>Okładka</title>\n\
</head>\n\
<body style=\"margin-top: 10; padding: 0; oeb-column-number: 1;\">\n\
<h1>%T</h1>\n\
<h2>%A</h2>\n\
</body>\n</html>\n";

static char *epub_cover_img_xml="<?xml version=\"1.0\" encoding=\"utf-8\" ?>\n\
<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.1//EN\" \"http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd\">\n\
<html xmlns=\"http://www.w3.org/1999/xhtml\">\n\
<head>\n\
<meta http-equiv=\"Content-Type\" content=\"application/xhtml+xml; charset=utf-8\" />\n\
<link rel=\"stylesheet\" type=\"text/css\" href=\"style.css\" />\n\
<title>Okładka</title>\n\
</head>\n\
<body style=\"margin-top: 10; padding: 0; oeb-column-number: 1;\">\n\
<div><img src=\"cover.jpg\" alt=\"%A: %T\"></img></div>\n\
</body>\n</html>\n";

static char *epub_style_txt=".center { text-align: center;  text-indent: 0em; }\n\
.right { text-align: right; }\n\
.caption { font-weight: bold; }\n\
.noindent { text-indent: 0em; }\n\
.smallcaps { font-variant: small-caps; }\n\
.small { font-size: small; }\n\
.large { font-size: large; }\n\
.note { font-size: small; text-indent: 0em; }\n\
.chapter_heading { text-align: center; text-indent: 0em; margin-top: 20pt; margin-bottom: 20pt; }\n\
.toc_heading { text-align: center; margin-top: 20pt; margin-bottom: 20pt; }\n\
.hr_separator {width:30%%;margin: 1em auto;height: 0.2em;background-color:#aaa;}\n\
.p_normal { text-indent: 1.5em; margin-top: 5pt; margin-bottom: 5pt;%J}\n\
.p_first { text-indent: 1.5em; margin-top: 5pt; margin-bottom: 5pt;%J}\n\
.p_toc { text-indent: 1.5em; margin-top: 10pt; margin-bottom: 10pt;}\n";



void epub_emit_title(FILE *f,char *body)
{
    char *c;
    body=strstr(body,"<title");
    if (!body) return;
    body=strchr(body,'>');
    if (!body) return;
    body++;
    c=strchr(body,'<');
    if (c) fwrite(body,c-body,1,f);
}

void epub_emit_string(FILE *f,char *body)
{
    while (*body) {
        if (*body=='\r' || *body=='\n') break;
        if (*body=='<') fprintf(f,"&lt;");
        else if (*body=='>') fprintf(f,"&gt;");
        else if (*body=='&') fprintf(f,"&amp;");
        else if (*body == '"') fprintf(f,"&quot;");
        else {
            fputc(*body,f);
        }
        body++;
    }
}

int zippy(char *fname,char *dir)
{
    int pid,stus;
    char *args[8];
    pid=fork();
    if (pid < 0) return 0;
    if (pid > 0) {
        int n;
        for (;;) {
            n=waitpid(pid,&stus,0);
            if (n ==pid) break;
        }
        return stus?0:1;
    }
    ignore(chdir(dir));
    unlink(fname);
    args[0]="zip";
    args[1]="-rX";
    args[2]=fname;
    args[3]="mimetype";
    args[4]="META-INF/";
    args[5]="OPS/";
    args[6]=NULL;
    close(0);
    close(1);
    close(2);
    execv("/usr/bin/zip",args);
    exit(1);
}

void epub_freedir(char **html,char *epub_temp)
{
    char epub_path[256];
    int i;
    for (i=0;html[i];i++) {
        sprintf(epub_path,"%s/OPS/text_%03d.html",epub_temp,i+1);
        unlink(epub_path);
    }
    book_free_html(html);
    sprintf(epub_path,"%s/OPS/CoverPage.html",epub_temp);unlink(epub_path);
    sprintf(epub_path,"%s/OPS/cover.jpg",epub_temp);unlink(epub_path);
    sprintf(epub_path,"%s/OPS/TableOfContents.html",epub_temp);unlink(epub_path);
    sprintf(epub_path,"%s/OPS/content.opf",epub_temp);unlink(epub_path);
    sprintf(epub_path,"%s/OPS/style.css",epub_temp);unlink(epub_path);
    sprintf(epub_path,"%s/OPS/toc.ncx",epub_temp);unlink(epub_path);
    sprintf(epub_path,"%s/META-INF/container.xml",epub_temp);unlink(epub_path);
    sprintf(epub_path,"%s/mimetype",epub_temp);unlink(epub_path);
    sprintf(epub_path,"%s/META-INF",epub_temp);rmdir(epub_path);
    sprintf(epub_path,"%s/OPS",epub_temp);rmdir(epub_path);
    rmdir(epub_temp);

}

static int get_kindlegen(void)
{
	GtkWidget *dialog=gtk_file_chooser_dialog_new("Wybierz plik kindlegen",
		GTK_WINDOW(main_window),GTK_FILE_CHOOSER_ACTION_OPEN,
		GTK_STOCK_CANCEL, GTK_RESPONSE_CANCEL,
		GTK_STOCK_OPEN, GTK_RESPONSE_ACCEPT,
		NULL);
	GtkFileFilter *filter;
    int rc=0;
	gtk_file_chooser_set_local_only((gpointer)dialog,TRUE);
	gtk_file_chooser_add_filter((gpointer) dialog,
		filter=make_filter("Pliki KindleGen","kindlegen",NULL));
	gtk_file_chooser_add_filter((gpointer) dialog,
		make_filter("Wszystkie pliki","*",NULL));
	gtk_file_chooser_set_filter((gpointer) dialog,filter);
	if (gtk_dialog_run((gpointer)dialog)==GTK_RESPONSE_ACCEPT){
        rc=1;
		strcpy(kindle_path,gtk_file_chooser_get_filename((gpointer)dialog));
	}
	gtk_widget_destroy(dialog);
    return rc;
}

static int AskAuthorTitle(char *author,char *title,char *jpeg,int *kindle)
{
    GtkWidget *dialog=gtk_dialog_new_with_buttons(
		"Podaj tytuł i autora",
		(gpointer)main_window,
		GTK_DIALOG_MODAL,
		GTK_STOCK_OK,GTK_RESPONSE_ACCEPT,
		GTK_STOCK_CANCEL,GTK_RESPONSE_REJECT,
		NULL);
    if (jpeg) *jpeg=0;
    if (kindle) *kindle=0;
	GtkWidget *vbox=gtk_dialog_get_content_area((gpointer)dialog);
	GtkWidget *stable=gtk_table_new(2,4,0);
	gtk_box_pack_start(GTK_BOX(vbox),stable,FALSE,FALSE,0);
    GtkWidget *label=gtk_label_new("Autor");
	gtk_table_attach_defaults((gpointer)stable,label,0,1,0,1);
	GtkWidget *g_autor=gtk_entry_new();
	gtk_table_attach_defaults((gpointer)stable,g_autor,1,2,0,1);
    connect_label(label,g_autor);
    label=gtk_label_new("Tytuł");
	gtk_table_attach_defaults((gpointer)stable,label,0,1,1,2);
	GtkWidget *g_title=gtk_entry_new();
	gtk_table_attach_defaults((gpointer)stable,g_title,1,2,1,2);
    connect_label(label,g_title);

    GtkWidget *cb_cover=NULL;
    GtkWidget *imgchooser=NULL;
    GtkWidget *cb_kindle;

	void set_coverfile_active(GtkWidget *w)
    {
        gtk_widget_set_sensitive(imgchooser,
            gtk_toggle_button_get_active((gpointer)w)
        );
    }

    if (jpeg && kindle) {
        cb_cover=gtk_check_button_new_with_label("Plik okładki");
        gtk_table_attach_defaults((gpointer)stable,cb_cover,0,1,2,3);
        imgchooser=gtk_file_chooser_button_new("Wybierz plik okładki",
            GTK_FILE_CHOOSER_ACTION_OPEN);
        gtk_file_chooser_set_local_only((gpointer)imgchooser,TRUE);
        gtk_file_chooser_button_set_width_chars((gpointer)imgchooser,50);

        GtkFileFilter *filter;
        gtk_file_chooser_add_filter((gpointer) imgchooser,
            filter=make_filter("Pliki JPG","*.jpg","*.JPG","*.jpeg","*.JPEG",NULL));
        if (gtk_check_menu_item_get_active((gpointer)m_epub_procover)) {
            gtk_file_chooser_add_filter((gpointer) imgchooser,
                make_filter("Pliki graficzne","*.jpg","*.JPG","*.jpeg","*.JPEG",
                "*.GIF","*.gif","*.PNG","*.png",
                "*.BMP","*.bmp",NULL));
        }
        gtk_file_chooser_add_filter((gpointer) imgchooser,
            make_filter("Wszystkie pliki","*",NULL));
        gtk_file_chooser_set_filter((gpointer) imgchooser,filter);
        ICPAddPreview((gpointer)imgchooser);
        atk_object_set_name(gtk_widget_get_accessible(imgchooser),"Wybierz plik okładki");

        gtk_table_attach_defaults((gpointer)stable,imgchooser,1,2,2,3);
        gtk_widget_set_sensitive(imgchooser,FALSE);

        cb_kindle=gtk_check_button_new_with_label("Utwórz dodatkowo plik .mobi");
        gtk_table_attach_defaults((gpointer)stable,cb_kindle,0,2,3,4);


        g_signal_connect(G_OBJECT(cb_cover),"toggled",G_CALLBACK(set_coverfile_active),NULL);
    }

    gtk_entry_set_max_length((gpointer)g_autor,255);
    gtk_entry_set_max_length((gpointer)g_title,255);

    gtk_entry_set_width_chars((gpointer)g_autor,48);
    gtk_entry_set_width_chars((gpointer)g_title,48);

    gtk_entry_set_text((gpointer)g_autor,author);
    gtk_entry_set_text((gpointer)g_title,title);


	gtk_widget_show_all((gpointer)vbox);
	int n;
loop:
    n=gtk_dialog_run((gpointer)dialog);
	if (n==GTK_RESPONSE_ACCEPT) {
        strcpy(author,gtk_entry_get_text((gpointer)g_autor));
        strcpy(title,gtk_entry_get_text((gpointer)g_title));
        char *fn="";
        if (jpeg && kindle) {
            if (gtk_toggle_button_get_active((gpointer)cb_cover)) {
                fn=gtk_file_chooser_get_filename((gpointer)imgchooser);
                if (!fn) fn="";
                if (*fn && gtk_check_menu_item_get_active((gpointer)m_epub_procover)) {
                    if (!check_program("convert","ImageMagick")) goto loop;
                }
            }
            if (gtk_toggle_button_get_active((gpointer)cb_kindle)) {
                if (!kindle_path[0] || !g_file_test(kindle_path,G_FILE_TEST_IS_EXECUTABLE)) {
                    if (!Ask("Pytanko","Amazon KindleGen jest potrzebny do tworzenia MOBI.\nCzy chcesz wskazać plik wykonywalny kindlegen?")) {
                        goto loop;
                    }
                    if (!get_kindlegen()) goto loop;
                }
            }
            *kindle=gtk_toggle_button_get_active((gpointer)cb_kindle);
            strcpy(jpeg,fn);
        }
    }
    gtk_widget_destroy(dialog);
    return n == GTK_RESPONSE_ACCEPT;
}

static int copy_file(char *from, char *to)
{
    GFile *f1,*f2;int res;
    f1=g_file_new_for_path(from);
    f2=g_file_new_for_path(to);
    res=g_file_copy(f1,f2,G_FILE_COPY_OVERWRITE,NULL,NULL,NULL,NULL);
    g_object_unref((gpointer)f1);
    g_object_unref((gpointer)f2);
    return res;
}


static int copy_magick_cover(char *from,char *to)
{
    char buf[256];
    FILE *f;
    char *cs;
    char *g_from=g_shell_quote(from);
    char *g_to=g_shell_quote(to);
    char *cmd1=g_strdup_printf("identify -format '%%m %%w %%h' %s 2>/dev/null",g_from);
    f=popen(cmd1,"r");
    g_free(cmd1);
    if (!f) {
        Error("Błąd ImageMagick","Nie mogę uruchomić polecenia identify");
        g_free(g_from);
        g_free(g_to);
        return 0;
    }
    buf[0]=0;
    ignore((int)fgets(buf,256,f));
    pclose(f);
    cs=trim(buf);
    if (!*cs) {
        Error("Błąd ImageMagick","Nierozpoznany format pliku");
        g_free(g_from);
        g_free(g_to);
        return 0;
    }
    if (!strcmp(cs,"JPEG 600 800")) {
        g_free(g_from);
        g_free(g_to);
        return copy_file(from,to);
    }
    cmd1=g_strdup_printf("convert %s -geometry 600x800 -gravity center -background '#000044' -extent 600x800 %s",
        g_from,g_to);
    g_free(g_from);
    g_free(g_to);
    int rc=system(cmd1);
    g_free(cmd1);
    if (rc) {
        Error("Błąd ImageMagick",strerror(errno));
        return 0;
    }
    return 1;
}


char kindle_path[256];

static int runKindle(char *epubfile)
{
    if (!kindle_path[0]) return -1;
    int pid=fork();
    int st;
    if (pid) {
        waitpid(pid,&st,0);
        return st;
    }
    char *ename=g_path_get_basename(epubfile);
    char *c=strrchr(ename,'.');
    char *mobi;
    if (!c) c=ename+strlen(ename);
    mobi=g_strdup_printf("%-*.*s.mobi",c-ename,c-ename,ename);
    execl(kindle_path,"kindlegen",ename,"-c0","-verbose","-o",mobi,NULL);
    return -1;
}


static char *hindex_template="<?xml version=\"1.0\" encoding=\"utf-8\" ?>\n\
<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.1//EN\" \"http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd\">\n\
<html xmlns=\"http://www.w3.org/1999/xhtml\">\n\
<head>\n\
<meta http-equiv=\"Content-Type\" content=\"application/xhtml+xml; charset=utf-8\" />\n\
<link rel=\"stylesheet\" type=\"text/css\" href=\"style.css\" />\n\
<title>%T</title>\n\
</head>\n\
<body>\n\
<h2 class=\"html_author\">%A</h2>\n\
<h2 class=\"html_title\">%T</h2>\n\
<h3 class=\"html_toc\">Spis treści</h3>\n\
%S\n\
<hr />\n\
</body>\n\
</html>\n";

static void save_html_index(char *title,char *autor,char *fname,char **html)
{
    FILE *f;
    char *c,*s;
    char buf[256];

    f=fopen(fname,"w");
    if (!f) {
        Error("HTML","Nie mogę zapisać indeksu");
        return;
    }
    c=strrchr(fname,'/');
    if (c) fname=c+1;
    s=hindex_template;
    for (;;) {
        c=strchr(s,'%');
        if (!c) {
            fwrite(s,strlen(s),1,f);
            break;
        }
        if (c != s) fwrite(s,c-s,1,f);
        c++;
        if (!*c) break;
        s=c+1;
        if (*c == 'A') epub_emit_string(f,autor);
        else if (*c == 'T') epub_emit_string(f,title);
        else if (*c == 'S') {
            int n;char *cs;
            for (n=0;html[n];n++) {
                fprintf(f,"<p class=\"html_toc_item\"><a href=\"");
                cs=strrchr(fname,'.');
                if (cs) {
                    memcpy(buf,fname,cs-fname);
                    sprintf(buf+(cs-fname),"_%03d",n+1);
                    strcat(buf,cs);
                }
                else {
                    sprintf(buf,"%s_%03d.html",fname,n+1);
                }
                epub_emit_string(f,buf);
                fprintf(f,"\">");
                epub_emit_title(f,html[n]);
                fprintf(f,"</a></p>");
            }
        }
    }
    fclose(f);
}


int fbody_is_hash(char *c,int hash)
{
	while (*c && isspace(*c)) c++;
	if (!c) return 0;
	c=strpbrk(c,"\r\n");
	if (!c) return 0;
	while (*c && isspace(*c)) c++;
	if (*c == hash) return 1;
	// ukłon dla fb2 - hash może być w drugiej linii
	c=strpbrk(c,"\r\n");
	if (!c) return 0;
	while (*c && isspace(*c)) c++;
	return (*c == hash);
}

int check_split_possible(char *str,char *marker)
{
	if (!*marker || ((*marker) & 0x80)) return 0;
	if (!fbody_is_hash(str,*marker)) return 0;
	if (!Ask("pytanie","Czy włączyć podział rozdziałów?")) return 0;
	gtk_combo_box_set_active((gpointer)combo_split,1);
	return 1;
}



int save_file_fb2_uni(GtkWidget *dummy,void *data,char *buffermeta)
{
    int do_split,spliter=0,do_foot,do_anno;
    char *body,*mem;
    unsigned char uuid[256];
    char uuid_name[256];
    char today[16];
    time_t cajt;
    struct tm *tm;
    GString *gs;
    char *c,*ostr;
    char *cs=NULL,xbuf[PATH_MAX+1],*path=NULL,fb2path[PATH_MAX+1];
    struct fb2_imagelist *images=NULL;
    struct FB2Context *ctx=NULL;


    if (get_current_editor()) return 0;
    if (!gtk_text_buffer_get_char_count(tresc)) return 0;
    if (current_editor->save_name[0]) cs=current_editor->save_name;
	else if (current_editor->load_name[0]) cs=current_editor->load_name;
    if (cs) {
		strcpy(xbuf,cs);
		path=xbuf;
		strcpy(fb2path,cs);
		c=strrchr(fb2path,'/');
		if (c) {
			char *d=strrchr(c,'.');
			if (!d) d=c+strlen(c);
			strcpy(d,".fbmeta");
		}
		else fb2path[0]=0;
	}
	else fb2path[0]=0;

	if (!fb2path[0]) {
		Error("Błąd","Nie mogę utworzyć ścieżki do fbmeta");
		return 0;
	}
	ctx=FB2ReadContext(fb2path);
  	do_split=gtk_combo_box_get_active((gpointer)combo_split);
    mem=get_actual_body();
    body=mem;
	c=(char *)gtk_entry_get_text((gpointer)char_split);
	if (!do_split) do_split=check_split_possible(mem,c);
    if (do_split) {
		if (!*c || ((*c) & 0x80)) {
			g_free(mem);
			Error("Błąd","Nielegalny znak podziału");
			return 0;
		}
		spliter=*c;
    }
    if (!ctx) {
		if (do_split) {
			ctx=FB2InitContextFromHeadline(body);
		}
		else {
			ctx=FB2ContextInit();
		}
		create_uuid(uuid,uuid_name);
		ctx->id=g_strdup(uuid_name);
	}
	do_foot=fb2_can_have_footnotes(body);
    do_anno=do_split;
	/* tu trza zapytać o dane książki */
	ctx=FB2EditContext(ctx,&do_foot,&do_anno);
	if (!ctx) {
		g_free(mem);
		return 0;
	}
	FB2WriteContext(fb2path,ctx);
	if (buffermeta) {
		strcpy(buffermeta,fb2path);
		FB2FreeContext(ctx);
		return 1;
	}
    cajt=time(NULL);
    tm=localtime(&cajt);
    strftime(today,16,"%d.%m.%Y",tm);
	gs=FB2MakeHeader(ctx,today,do_anno?spliter:0,body,&images);
    create_fb2_sections(gs,body,spliter,do_foot,do_anno,&images);
    if (!FB2_finalize(gs,ctx->cover,images)) {
        g_string_free(gs,TRUE);
        g_free(mem);
        FB2FreeContext(ctx);
        return 0;
    }
    g_free(mem);
    ostr=g_string_free(gs,FALSE);

	GtkWidget *dialog=gtk_file_chooser_dialog_new(
        "Wybierz plik do zapisu",
		GTK_WINDOW(main_window),GTK_FILE_CHOOSER_ACTION_SAVE,
		GTK_STOCK_CANCEL, GTK_RESPONSE_CANCEL,
		GTK_STOCK_SAVE, GTK_RESPONSE_ACCEPT,
		NULL);
	GtkFileFilter *filter;
	gtk_file_chooser_set_local_only((gpointer)dialog,TRUE);
	filter=make_filter("Pliki FB2","*.fb2","*.FB2",NULL);
	gtk_file_chooser_add_filter((gpointer) dialog,filter);
	gtk_file_chooser_add_filter((gpointer) dialog,
		make_filter("Wszystkie pliki","*",NULL));
	gtk_file_chooser_set_filter((gpointer) dialog,filter);
	if (path && *path) {
		char *c=strrchr(path,'/'),*d;
		if (c) {
			*c=0;
			gtk_file_chooser_set_current_folder((gpointer)dialog,path);
			*c='/';
			d=strrchr(c+1,'.');
			if (!d) d=(char*)path+strlen(path);
			strcpy(d,".fb2");
			gtk_file_chooser_set_current_name((gpointer)dialog,c+1);
		}
	}
    gtk_file_chooser_set_do_overwrite_confirmation((gpointer)dialog,TRUE);
    int rc=gtk_dialog_run((gpointer)dialog);
	if (rc == GTK_RESPONSE_ACCEPT) {
        strcpy(xbuf,gtk_file_chooser_get_filename((gpointer)dialog));
    }
    gtk_widget_destroy(dialog);
    int rd=1;
    if (rc == GTK_RESPONSE_ACCEPT) {
        FILE *f=fopen(xbuf,"w");
        if (!f) {
            Error("Błąd","Nie mogę otworzyć pliku do zapisu");
            rd=0;
        }
        else {
            fwrite(ostr,strlen(ostr),1,f);
            fclose(f);
            Info("OK","Zapisane");
            rd=1;
        }
    }
    g_free(ostr);
    return rd;
}



void save_file_fb2(GtkWidget *dummy,void *data)
{
	save_file_fb2_uni(dummy,data,NULL);
}

int save_file_fb2_meta(char *buffer)
{
	return save_file_fb2_uni(NULL,NULL,buffer);
}

void save_file_html(GtkWidget *dummy,void *data)
{
    char **html,*str;
    int do_split=0;
    int do_epub=data?1:0;
    int do_jpeg=0;
    unsigned char epub_uuid[16];
    char epub_uuidname[40];
    char epub_temp[256],epub_fname[256];
    FILE *f;

    char book_title[256];
    char book_author[256];
    char book_jpg[256];
    static int do_kindle=0;

    if (get_current_editor()) return;
    if (!gtk_text_buffer_get_char_count(tresc)) return;
    html=book_create_html(book_title,book_author,
        gtk_check_menu_item_get_active((gpointer)m_epub_dash),
        gtk_check_menu_item_get_active((gpointer)m_epub_format),
        NULL);
    if (!html) return;
    if (!AskAuthorTitle(book_author,book_title,do_epub?book_jpg:NULL,
            do_epub?&do_kindle:NULL)) return;

    if (html[1]) do_split=1;

	GtkWidget *dialog=gtk_file_chooser_dialog_new(
        do_epub?"Wybierz plik":
		do_split?"Wybierz szablon pliku":"Wybierz plik",
		GTK_WINDOW(main_window),GTK_FILE_CHOOSER_ACTION_SAVE,
		GTK_STOCK_CANCEL, GTK_RESPONSE_CANCEL,
		GTK_STOCK_SAVE, GTK_RESPONSE_ACCEPT,
		NULL);
	GtkFileFilter *filter;
	gtk_file_chooser_set_local_only((gpointer)dialog,TRUE);
	if (do_epub) {
        filter=make_filter("Pliki EPUB","*.epub","*.EPUB",NULL);
    }
    else {
        filter=make_filter("Pliki HTML","*.html","*.HTML", "*.htm","*.HTM",NULL);
    }
	gtk_file_chooser_add_filter((gpointer) dialog,filter);
	gtk_file_chooser_add_filter((gpointer) dialog,
		make_filter("Wszystkie pliki","*",NULL));
	gtk_file_chooser_set_filter((gpointer) dialog,filter);

    char *cs=NULL,xbuf[PATH_MAX+1],ybuf[PATH_MAX+1];
    if (current_editor->save_name[0]) cs=current_editor->save_name;
	else if (current_editor->load_name[0]) cs=current_editor->load_name;
	char *path=NULL;
    if (cs) {
		strcpy(xbuf,cs);
		path=xbuf;
	}
	if (path && *path) {
		char *c=strrchr(path,'/'),*d;
		if (c) {
			*c=0;
			gtk_file_chooser_set_current_folder((gpointer)dialog,path);
			*c='/';
			d=strrchr(c+1,'.');
			if (!d) d=(char*)path+strlen(path);
			strcpy(d,do_epub?".epub":".html");
			gtk_file_chooser_set_current_name((gpointer)dialog,c+1);
		}
	}
    gtk_file_chooser_set_do_overwrite_confirmation((gpointer)dialog,TRUE);
    int rc=gtk_dialog_run((gpointer)dialog);
	if (rc == GTK_RESPONSE_ACCEPT) {
        strcpy(xbuf,gtk_file_chooser_get_filename((gpointer)dialog));
    }
    gtk_widget_destroy(dialog);
    if (rc != GTK_RESPONSE_ACCEPT) {
        book_free_html(html);
        return;
    }
    if (do_epub) {
        create_uuid(epub_uuid,epub_uuidname);
        sprintf(epub_temp,"%s/tmp",getenv("HOME"));
        strcat(epub_temp,"/epub_");
        strcat(epub_temp,epub_uuidname);
        if (g_mkdir_with_parents(epub_temp,0700)<0) {
			book_free_html(html);
			ErrorF(NULL,"Błąd","Błąd tworzenia katalogu roboczego:\n%s",strerror(errno));
			return;
		}
        sprintf(epub_fname,"%s/OPS",epub_temp);
        mkdir(epub_fname,0700);
        sprintf(epub_fname,"%s/META-INF",epub_temp);
        mkdir(epub_fname,0700);
        sprintf(epub_fname,"%s/mimetype",epub_temp);
        f=fopen(epub_fname,"w");
        if (!f) {
            Error("err",epub_fname);
            epub_freedir(html,epub_temp);
            return;
        }
        fprintf(f,"application/epub+zip");
        fclose(f);
        if (book_jpg[0]) {
            sprintf(epub_fname,"%s/OPS/cover.jpg",epub_temp);
            if (gtk_check_menu_item_get_active((gpointer)m_epub_procover)) {
                if (!copy_magick_cover(book_jpg,epub_fname)) {
                    epub_freedir(html,epub_temp);
                    return;
                }
                do_jpeg=1;
            }
            else if (copy_file(book_jpg,epub_fname)) do_jpeg=1;
        }
        sprintf(epub_fname,"%s/META-INF/container.xml",epub_temp);
        f=fopen(epub_fname,"w");
        if (!f) {
            Error("Błąd","Nie mogę otworzyć pliku container");
            epub_freedir(html,epub_temp);
            return;
        }
        str="<?xml version=\"1.0\" ?>\n\
<container version=\"1.0\" xmlns=\"urn:oasis:names:tc:opendocument:xmlns:container\">\n\
   <rootfiles>\n\
      <rootfile full-path=\"OPS/content.opf\" media-type=\"application/oebps-package+xml\"/>\n\
   </rootfiles>\n\
</container>\n";
        fwrite(str,strlen(str),1,f);
        fclose(f);
    }
    else if (do_split) {
        book_free_html(html);
        html=book_create_html(book_title,book_author,
            gtk_check_menu_item_get_active((gpointer)m_epub_dash),
            gtk_check_menu_item_get_active((gpointer)m_epub_format),
            xbuf);
    }
    int err=0,i;
    for (i=0;html[i];i++) {
        char *fname=xbuf;
        if (do_epub) {
            sprintf(epub_fname,"%s/OPS/text.html",epub_temp);
            fname=epub_fname;
        }
        if (do_split || do_epub) { // wymuszenie numerka przy epubie
            cs=strrchr(fname,'/');
            if (!cs) cs=fname;
            cs=strrchr(cs,'.');
            if (cs) {
                int n=cs-fname;
                memcpy(ybuf,fname,n);
                sprintf(ybuf+n,"_%03d",i+1);
                strcat(ybuf,cs);
            }
            else {
                sprintf(ybuf,"%s_%03d.html",fname,i+1);
            }
            fname=ybuf;
        }
        f=fopen(fname,"w");
        if (!f) {
            Error("Błąd",fname);
            err=1;
            break;
        }
        fwrite(html[i],1,strlen(html[i]),f);
        fclose(f);
    }
    if (err) {
        if (do_epub) epub_freedir(html,epub_temp);
        else book_free_html(html);
        return;
    }
    if (!do_epub) {
        if (do_split) save_html_index(book_title,book_author,xbuf,html);
        Info("Informacja","Zapisano HTML");
        book_free_html(html);
        return;
    }
    sprintf(epub_fname,"%s/OPS/content.opf",epub_temp);
    f=fopen(epub_fname,"w");
    if (!f) {
        Error("Błąd","Nie mogę otworzyć content.opf");
        epub_freedir(html,epub_temp);
        return;
    }
    str=epub_content_xml;
    while(str && *str) {
        char *c=strchr(str,'%');
        int nc;
        if (!c) c=str+strlen(str);
        fwrite(str,c-str,1,f);
        if (!*c) break;
        str=c;
        str++;
        if (!*str) break;
        nc=*str++;
        if (nc=='%') {
            fputc('%',f);
            continue;
        }
        if (nc=='X') {
            if (do_jpeg) fputs("<meta name=\"cover\" content=\"contentimg\" />\n",f);
            continue;
        }
        if (nc=='Y') {
            if (do_jpeg) fputs("<item id=\"contentimg\" href=\"cover.jpg\" media-type=\"image/jpeg\" />\n",f);
            continue;
        }
        if (nc=='T') {
            epub_emit_string(f,book_title);
            continue;
        }
        if (nc=='A') {
            epub_emit_string(f,book_author);
            continue;
        }
        if (nc=='D') {
            char buf[64];
            time_t tajm;
            struct tm *tm;
            tajm=time(0);
            tm=localtime(&tajm);
            strftime(buf,64,"%F",tm);
            fwrite(buf,strlen(buf),1,f);
            continue;
        }
        if (nc=='U') {
            fwrite(epub_uuidname,strlen(epub_uuidname),1,f);
            continue;
        }
        if (nc=='C') {
            for (i=0;html[i];i++) {
                fprintf(f,"        <item id=\"text_%03d\" href=\"text_%03d.html\"\n\
          media-type=\"application/xhtml+xml\" />\n",i+1,i+1);
            }
            continue;
        }
        if (nc=='I') {
            for (i=0;html[i];i++) {
                fprintf(f,"        <itemref idref=\"text_%03d\" />\n",i+1);
            }
            continue;
        }
    }
    fclose(f);
    sprintf(epub_fname,"%s/OPS/TableOfContents.html",epub_temp);
    f=fopen(epub_fname,"w");
    if (!f) {
        Error("Błąd","Nie mogę otworzyć TableOfContents.html");
        epub_freedir(html,epub_temp);
        return;
    }
    fwrite(epub_toc_xml,strlen(epub_toc_xml),1,f);
    for (i=0;html[i];i++) {
        fprintf(f,"<p class=\"p_toc\"><a href=\"text_%03d.html\">",i+1);
        epub_emit_title(f,html[i]);
        fprintf(f,"</a></p>\n");
    }
    fprintf(f,"</body>\n</html>\n");
    fclose(f);
    sprintf(epub_fname,"%s/OPS/toc.ncx",epub_temp);
    f=fopen(epub_fname,"w");
    if (!f) {
        Error("Błąd","Nie mogę otworzyć toc.ncx");
        epub_freedir(html,epub_temp);
        return;
    }
    str=epub_ncx_xml;
    while(str && *str) {
        char *c=strchr(str,'%');
        int nc;
        if (!c) c=str+strlen(str);
        fwrite(str,c-str,1,f);
        if (!*c) break;
        str=c;
        str++;
        if (!*str) break;
        nc=*str++;
        if (nc=='%') {
            fputc('%',f);
            continue;
        }
        if (nc=='T') {
            epub_emit_string(f,book_title);
            continue;
        }
        if (nc=='A') {
            epub_emit_string(f,book_author);
            continue;
        }
        if (nc=='U') {
            fwrite(epub_uuidname,strlen(epub_uuidname),1,f);
            continue;
        }
        if (nc == 'I') {
            for (i=0;html[i];i++) {
                fprintf(f,"        <navPoint id=\"navPoint-%d\" playOrder=\"%d\">\n\
            <navLabel>\n\
                <text>",i+3,i+3);
                epub_emit_title(f,html[i]);
                fprintf(f,"</text>\n\
            </navLabel>\n\
            <content src=\"text_%03d.html\" />\n\
        </navPoint>\n",i+1);
            }
            continue;
        }
    }
    fclose(f);
    sprintf(epub_fname,"%s/OPS/CoverPage.html",epub_temp);
    f=fopen(epub_fname,"w");
    if (!f) {
        Error("Błąd","Nie mogę otworzyć CoverPage.html");
        epub_freedir(html,epub_temp);
        return;
    }

    str=do_jpeg?epub_cover_img_xml:epub_cover_xml;
    while(str && *str) {
        char *c=strchr(str,'%');
        int nc;
        if (!c) c=str+strlen(str);
        fwrite(str,c-str,1,f);
        if (!*c) break;
        str=c;
        str++;
        if (!*str) break;
        nc=*str++;
        if (nc=='%') {
            fputc('%',f);
            continue;
        }
        if (nc=='T') {
            epub_emit_string(f,book_title);
            continue;
        }
        if (nc=='A') {
            epub_emit_string(f,book_author);
            continue;
        }
    }
    fclose(f);
    sprintf(epub_fname,"%s/OPS/style.css",epub_temp);
    f=fopen(epub_fname,"w");
    if (!f) {
        Error("Błąd","Nie mogę otworzyć style.css");
        epub_freedir(html,epub_temp);
        return;
    }
    str=epub_style_txt;
    while(str && *str) {
        char *c=strchr(str,'%');
        int nc;
        if (!c) c=str+strlen(str);
        fwrite(str,c-str,1,f);
        if (!*c) break;
        str=c;
        str++;
        if (!*str) break;
        nc=*str++;
        if (nc=='%') {
            fputc('%',f);
            continue;
        }
        if (nc=='J') {
            if (gtk_check_menu_item_get_active((gpointer)m_epub_just)) fputs("text-align:justify;",f);
            continue;
        }
    }

    //fwrite(epub_style_txt,strlen(epub_style_txt),1,f);
    fclose(f);
    if (!zippy(xbuf,epub_temp)) {
        Error("Epub","Zip czemuś nie zadziałał");
        epub_freedir(html,epub_temp);
        return;
    }
    if (do_kindle) {
        int es=runKindle(xbuf);
        if (!es) {
            Info("Epub","Zapisałem plik epub i mobi");
        }
        else {
            Error("Epub","Plik epub został zapisany, ale kindlegen zwrócił błąd");
        }
    }
    else {
        Info("Epub","Zapisałem plik epub");
    }
    epub_freedir(html,epub_temp);
}

void save_file(GtkWidget *dummy,void *data)
{
	int edimode=get_current_editor();
	char cp[PATH_MAX+1];
	FILE *f;
	int do_rename_tab=0;

	if (edimode<0) return;
	if (edimode == MILEDIT_MODE_DIC) {
		save_dic_file(data?1:0);
		return;
	}

	if (edimode != 0) return;
	if (!gtk_text_buffer_get_char_count(tresc)) return;

	if (data || !current_editor->save_name[0]) {
		char *c;
		cp[0]=0;
		if (current_editor->save_name[0]) strcpy(cp,current_editor->save_name);
		else if (current_editor->load_name[0]) {
			strcpy(cp,current_editor->load_name);
		}
		else if (last_file_path[0]) {
			strcpy(cp,last_file_path);
		}
		if (cp[0]) {
			c=strrchr(cp,'/');
			if (!c) c=cp;
			c=strrchr(c,'.');
			if (c) strcpy(c,".txt");
			else strcat(cp,".txt");
		}
		if (!get_save_path(cp,0,&current_editor->saveas_iso2)) return;
		do_rename_tab=1;
	}
	else strcpy(cp,current_editor->save_name);
	f=fopen(cp,"w");
	if (!f) {
		g_perror(cp);
		return;
	}
	char *str=current_editor->saveas_iso2 ? get_current_iso2() : get_actual_body(); //get_current_iso2();
	fwrite(str,1,strlen(str),f);
	fclose(f);
	g_free(str);
	strcpy(current_editor->save_name,cp);
	gtk_text_buffer_set_modified((gpointer)tresc,FALSE);
	if (do_rename_tab) {
		char *c=strrchr(cp,'/');
		if (c) c++;else c=cp;
		notek_set_tab_label(c);
#ifdef USE_SUBMIXER
		enable_video_menues(current_editor->editor_type ==0,current_editor);
#endif
		/*
		gtk_notebook_set_tab_label_text((gpointer)notek,
				(gpointer)current_editor->window,
				c);
		*/
	}
	Info("Potwierdzenie","Plik został zapisany");


}

static char *crlf2lf(char *body)
{
	char *d,*c;
	int ncp=0;
	d=c=body;
	while (*c && isspace(*c)) c++;
	while (*c) {
		if (*c=='\n') {
			if (ncp<2) ncp++;
			c++;
			continue;
		}
		if (*c!='\r') {
			while (ncp > 0) {
				*d++='\n';
				ncp--;
			}
			*d++=*c++;
			continue;
		}
		if (ncp<2) ncp++;
		c++;
		if (*c=='\n') c++;
	}
	*d=0;
	return body;
}

static char *deshy(char *body)
{
	char *c,*d;
	for (d=c=body;*c;) {
		if (*c != '\xc2') {
			*d++=*c++;continue;
		}
		c++;
		if (!*c) {
			*d++=0xc2;
			break;
		}
		if (*c != '\xad') {
			*d++=0xc2;
			*d++=*c++;
			continue;
		}
		c++;
		while (*c==' ') c++;
		if (*c=='\n') c++;
	}
	*d=0;
	return body;
}

void simplify_path(char *fname)
{
	char *c,*d;
	for(c=d=fname;*c;) {
		if (*c!='/') {
			*d++=*c++;
			continue;
		}
		if (c[1]=='.') {
			if (c[2]=='/') {
				c+=2;
				continue;
			}
			if (c[2]=='.' && c[3]=='/') {
				if (d>fname) d--;
				while (d>fname) {
					if (*d == '/') break;
					d--;
				}
				c+=3;
				continue;
			}
		}
		*d++=*c++;
	}
	*d=0;
}

int auto_set_langs(char *s)
{
	int flags_set=0;
	int i;char *c,*d,oh[NUM_LANGS];
	struct miltheme *mt;
	for (;;) {
		while (*s && isspace(*s)) s++;
		if (strncmp(s,"//",2)) break;
		s+=2;
		while (*s==' ' || *s=='\t') {
			s++;
		}
		if (*s++!='#') break;
		if (!(flags_set & 1) && !strncmp(s,"LANGS:",6)) {
			s+=6;
			for (i=0;i<NUM_LANGS;i++) oh[i]=0;
			while (*s) {
				if (!islower(s[0]) || !islower(s[1]) || (s[2]!=',' && s[2] != '\n')) break;
				for (i=0;i<NUM_LANGS;i++) if (!strncmp(s,lang_codes[i],2)) {
					oh[i]=1;
					break;
				}
				s+=2;
				if (*s != ',') break;
				s++;
			}
			for (i=0;i<NUM_LANGS;i++) gtk_toggle_button_set_active((gpointer)lang_cb[i],oh[i]!=0);
			flags_set |= 1;
			continue;
		}
		if (!(flags_set & 2) && !strncmp(s,"THEMES:",7)) {
			s+=7;
			for (mt=themes;mt;mt=mt->next) {
				gtk_toggle_button_set_active((gpointer)mt->cb,0);
			}
			for (;;) {
				if (!*s || !islower(*s)) break;
				for (mt=themes;mt;mt=mt->next) {
					for (c=s,d=mt->tname;*d;c++,d++) {
						if (*c!=*d) break;
					}
					if (*d && (*c!=',' && *c!='\n')) continue;
					s=c;
					if (*s==',') s++;
					gtk_toggle_button_set_active((gpointer)mt->cb,1);
					break;
				}
			}
			flags_set |= 2;
			continue;
		}
		break;
	}
	return 1;

}

int no_drm=0;

void open_file(GtkWidget *widget,void *data)
{
	char *fname=NULL;
	char *fbody;
	char dic_path[PATH_MAX+1];
	char buff[PATH_MAX+32];
	char *c;
    struct stat sb;
	int is_include = (widget && (data != NULL));
	int is_g,is_hash,is_iso2;
	static int new_pdf_mode=1;
	static int rtf_foot_mode=0;
    static int should_load_dic=0;
    if (is_include && get_current_editor()) return;
	if (widget) {
		GtkWidget *dialog=gtk_file_chooser_dialog_new(
			is_include?"Wybierz plik do wstawienia":"Wybierz plik",
			GTK_WINDOW(main_window),GTK_FILE_CHOOSER_ACTION_OPEN,
			GTK_STOCK_CANCEL, GTK_RESPONSE_CANCEL,
			GTK_STOCK_OPEN, GTK_RESPONSE_ACCEPT,
			NULL);
		GtkFileFilter *filter;
		GtkWidget *pdf_xml_on=combo(new_pdf_mode,"pdftotext","pdftoxml",
            "tesseract","tesseract (strony)",
            "cuneiform","cuneiform (strony)",
            NULL);
        GtkWidget *pdf_xml_label=gtk_label_new("Sposób konwersji PDF");
        GtkWidget *pdf_box=gtk_hbox_new(0,2);
	GtkWidget *pdf_drm=gtk_check_button_new_with_label("Ignoruj DRM");
	gtk_toggle_button_set_active((gpointer)pdf_drm,no_drm);
        gtk_box_pack_start(GTK_BOX(pdf_box),pdf_xml_label,FALSE,FALSE,0);
        gtk_box_pack_start(GTK_BOX(pdf_box),pdf_xml_on,FALSE,FALSE,0);
		connect_label(pdf_xml_label,pdf_xml_on);
        gtk_box_pack_start(GTK_BOX(pdf_box),pdf_drm,FALSE,FALSE,0);
	void showhide_pdf(void)
	{
	    int n=gtk_combo_box_get_active((gpointer) pdf_xml_on);
	    if (n == 1) gtk_widget_show((gpointer) pdf_drm);
	    else gtk_widget_hide((gpointer) pdf_drm);
	}


        GtkWidget *rtf_foot_on=combo(rtf_foot_mode,"Ignoruj","W treści","Za akapitem","Na końcu",NULL);
		GtkWidget *rtf_box=gtk_hbox_new(0,2);
		GtkWidget *rtf_label=gtk_label_new("Przypisy w plikach RTF");
		gtk_box_pack_start(GTK_BOX(rtf_box),rtf_label,FALSE,FALSE,0);
		gtk_box_pack_start(GTK_BOX(rtf_box),rtf_foot_on,FALSE,FALSE,0);
		connect_label(rtf_label,rtf_foot_on);
		gtk_file_chooser_set_local_only((gpointer)dialog,TRUE);
		gtk_file_chooser_add_filter((gpointer) dialog,
			make_filter("Pliki Worda","*.doc","*.DOC","*.rtf","*.RTF",NULL));
		gtk_file_chooser_add_filter((gpointer) dialog,
			make_filter("Pliki OpenOffice","*.odt",NULL));
		gtk_file_chooser_add_filter((gpointer) dialog,
			make_filter("Pliki tekstowe","*.txt","*.TXT",NULL));
		gtk_file_chooser_add_filter((gpointer) dialog,
			make_filter("Pliki PDF","*.pdf","*.PDF",NULL));
		gtk_file_chooser_add_filter((gpointer) dialog,
			make_filter("Pliki HTML","*.htm","*.HTM","*.html","*.HTML","*.xhtml","*.XHTML",NULL));

#ifdef HAVE_EPUB
		gtk_file_chooser_add_filter((gpointer) dialog,
			make_filter("Pliki ePub","*.epub","*.EPUB",NULL));
#endif
		gtk_file_chooser_add_filter((gpointer) dialog,
			filter=make_filter("Wszystkie pliki","*",NULL));
		gtk_file_chooser_set_filter((gpointer) dialog,filter);
		GtkWidget *ebox=gtk_vbox_new(0,2);
		gtk_box_pack_start(GTK_BOX(ebox),pdf_box,FALSE,FALSE,0);
		gtk_box_pack_start(GTK_BOX(ebox),rtf_box,FALSE,FALSE,0);
		gtk_file_chooser_set_extra_widget((gpointer) dialog,ebox);
		gtk_widget_show_all(ebox);
		g_signal_connect(G_OBJECT(pdf_xml_on),"changed",G_CALLBACK(showhide_pdf),NULL);
		showhide_pdf();
		if (last_file_path[0]) {
			gtk_file_chooser_set_filename((gpointer)dialog,last_file_path);
		}
		if (gtk_dialog_run((gpointer)dialog)==GTK_RESPONSE_ACCEPT){
			fname=gtk_file_chooser_get_filename((gpointer)dialog);
		}
		new_pdf_mode=gtk_combo_box_get_active((gpointer) pdf_xml_on);
		rtf_foot_mode=gtk_combo_box_get_active((gpointer) rtf_foot_on);
		no_drm=gtk_toggle_button_get_active((gpointer)pdf_drm);
		setFootNote("dine"+rtf_foot_mode);
		gtk_widget_destroy(dialog);
	}
	else {
		fname=data;
		new_pdf_mode = cuneiform_pdfp?5:cuneiform_pdf?4:tesseract_pdfp?3:tesseract_pdf?2:old_pdf_behav?0:1;
	}
	if (!fname) return;
	fbody=read_file(fname,&is_g,new_pdf_mode,&is_iso2);
	if (fbody && is_include) {
		fbody=deshy(crlf2lf(fbody));
		gtk_text_buffer_insert_at_cursor(tresc,fbody,strlen(fbody));
		if (is_g)g_free(fbody);
		else g_free(fbody);
		return;
	}
	char *flabel=strrchr(fname,'/');
	if (!flabel) flabel=fname;
	else flabel++;
	is_hash=0;
	if (fbody) {
		is_hash=fbody_is_hash(fbody,'#');
		get_current_editor();
		if (!current_editor || current_editor->editor_type != 0 || !textbuf_is_empty(tresc)) {
			CreateEditor(0,NULL,flabel);
			atk_object_set_name(gtk_widget_get_accessible((gpointer)tresc_v),flabel);
		}
		else {
			notek_set_tab_label(flabel);
			/*
			gtk_notebook_set_tab_label_text((gpointer)notek,
				(gpointer)current_editor->window,
				flabel);
			*/
		}

		set_buffer_text(tresc,deshy(crlf2lf(fbody)),-1,0);
		gtk_widget_grab_focus((gpointer)tresc_v);
		if (is_g) g_free(fbody);
		else g_free(fbody);
        current_editor->saveas_iso2 = is_iso2;
		if (is_hash) {
			char const *xc=gtk_entry_get_text((gpointer)char_split);
			if (*xc == '#') gtk_combo_box_set_active((gpointer)combo_split,1);
		}
	}
	if (g_path_is_absolute(fname)) {
		strcpy(last_file_path,fname);
	}
	else {
		char *cd=g_get_current_dir();
		char *p=g_build_filename(cd,fname,NULL);
		strcpy(last_file_path,p);
		g_free(p);
		g_free(cd);
	}
	simplify_path(last_file_path);
	strcpy(current_editor->load_name,last_file_path);
	strcpy(dic_path,last_file_path);

	if (no_load_dic) should_load_dic=0;
    else if (auto_load_dic) should_load_dic=1;
    else {
        c=strrchr(fname,'.');
        should_load_dic=(c && !strcmp(c,".txt"))?1:0;
    }
    read_zakladka();
    if (widget) g_timeout_add(1200,(gpointer)init_zakladki_cb,NULL);
	g_free(fname);
	auto_window_title();
	if (!widget && !should_load_dic) return;
	c=strrchr(dic_path,'/');
	if (!c) return;
	*c=0;
	fname=c+1;
	char *d=strrchr(fname,'.');
	if (!d) d=fname+strlen(fname);
	strcpy(d,".dic");
	*c='/';
	if (stat(dic_path,&sb)) return;
	if (widget) {
		sprintf(buff,"Załadować słownik %s?",fname);
		if (!Ask("Pytanie",buff)) return;
	}
	fbody=read_file(dic_path,&is_g,0,NULL);
	struct MyGtkEditor *edi=get_subeditor(current_editor,MILEDIT_MODE_DIC);
	set_buffer_text(edi->buf,crlf2lf(fbody),-1,0);
	strcpy(edi->load_name,dic_path);
	auto_set_langs(fbody);
	if (is_g)g_free(fbody);
	else g_free(fbody);
	if (!widget) show_editor(edi->owneditor);
    auto_window_title();

}

void open_dic(GtkWidget *widget,void *dummy)
{
	char dic_path[PATH_MAX+1];
	if (get_current_editor()) return;
	dic_path[0]=0;
	if (current_editor->save_name[0]) {
		strcpy(dic_path,current_editor->save_name);
	}
	else if (current_editor->load_name[0]) {
		strcpy(dic_path,current_editor->load_name);
	}
	char *fname;
	GtkWidget *dialog=gtk_file_chooser_dialog_new("Wybierz plik",
		GTK_WINDOW(main_window),GTK_FILE_CHOOSER_ACTION_OPEN,
		GTK_STOCK_CANCEL, GTK_RESPONSE_CANCEL,
		GTK_STOCK_OPEN, GTK_RESPONSE_ACCEPT,
		NULL);
	GtkFileFilter *filter;
	gtk_file_chooser_set_local_only((gpointer)dialog,TRUE);
	gtk_file_chooser_add_filter((gpointer) dialog,
		filter=make_filter("Pliki DIC","*.dic","*.DIC",NULL));
	gtk_file_chooser_add_filter((gpointer) dialog,
		make_filter("Pliki tekstowe","*.txt","*.TXT",NULL));
	gtk_file_chooser_add_filter((gpointer) dialog,
		make_filter("Wszystkie pliki","*",NULL));
	gtk_file_chooser_set_filter((gpointer) dialog,filter);

	if (dic_path[0]) {
		char *c=strrchr(dic_path,'/');
		struct stat sb;
		if (c) {
			*c=0;
			fname=c+1;
		}
		else {
			fname=dic_path;
		}
		char *d=strrchr(fname,'.');
		if (!d) d=fname+strlen(fname);
		strcpy(d,".dic");
		if (c) *c='/';
		if (!stat(dic_path,&sb)) {
			gtk_file_chooser_set_filename((gpointer)dialog,dic_path);
		}
		else if (c) {
			*c=0;
			gtk_file_chooser_set_current_folder((gpointer)dialog,dic_path);
		}
	}
	fname=NULL;
	if (gtk_dialog_run((gpointer)dialog)==GTK_RESPONSE_ACCEPT){
		fname=gtk_file_chooser_get_filename((gpointer)dialog);
	}
	gtk_widget_destroy(dialog);
	if (!fname) return;
	char *fbody=read_file(fname,NULL,0,NULL);
	struct MyGtkEditor *edi=get_subeditor(current_editor,MILEDIT_MODE_DIC);
	set_buffer_text(edi->buf,fbody,-1,0);
	strcpy(edi->load_name,fname);
	auto_set_langs(fbody);
	g_free(fbody);
	g_free(fname);
}

struct zakladka {
        char path[256];
        char themes[256];
        char langs[64];
        time_t czas;
        int char_offset;
};

#define ILE_ZAKLADEK 100

int open_zakladki(int mode)
{
    char path[sizeof(struct zakladka)];
    char *c;int fd;
    c=getenv("HOME");
    if (!c) return -1;
    sprintf(path,"%s/.milena_abc_mark.dat",c);
    fd=open(path,(mode)?O_RDWR:O_RDONLY,0644);
    if (fd < 0 && mode) {
        fd=open(path,(mode)?O_RDWR|O_CREAT:O_RDONLY,0644);
        if (fd>0) {
            int i;
            memset(path,0,sizeof(struct zakladka));
            for (i=0;i<ILE_ZAKLADEK;i++) {
				ignore(write(fd,path,sizeof(struct zakladka)));
			}
            lseek(fd,0,SEEK_SET);
        }
    }
    return fd;
}


int _zakladka_read(char *fname,struct zakladka *zakladka)
{
        int zapos,i,fd;
        fd=open_zakladki(0);
        if (fd<0) return 0;
        lseek(fd,0,SEEK_SET);
        for (i=0,zapos=0;i<ILE_ZAKLADEK;i++) {
            if (read(fd,zakladka, sizeof(*zakladka)) != sizeof(*zakladka)) break;
            if (!strcmp(zakladka->path,fname)) {
                zapos=1;
                break;
            }
        }
        close(fd);
        return zapos;
}

void read_zakladka(void)
{
    struct zakladka zak;
    int i;
    struct miltheme *mt;
    int find_in_string(char *fstr,char *cs)
    {
        while (fstr && *fstr) {
            if (!strcmp(fstr,cs)) {
                fstr+=strlen(cs);
                if (*fstr==',' || !*fstr) return 1;
            }
            fstr=strchr(fstr,',');
            if (fstr) fstr++;
        }
        return 0;
    }
    if (!_zakladka_read(current_editor->load_name,&zak)) return;
    current_editor->initial_offset=zak.char_offset;
	for (i=0;i<NUM_LANGS;i++) gtk_toggle_button_set_active((gpointer)lang_cb[i],find_in_string(zak.langs,lang_codes[i]));
    for (mt=themes;mt;mt=mt->next) {
        gtk_toggle_button_set_active((gpointer)mt->cb,find_in_string(zak.themes,mt->tname));
    }
}


static void _zakladka_write(char *fname,char *langs,char *themes,int offset)
{
    struct zakladka zakladka;
    time_t teraz=time(NULL);
    int i,mpt,fd,found,empty;
    fd=open_zakladki(1);
    for (i=0,mpt=0,found=-1,empty=-1;i<ILE_ZAKLADEK;i++) {
        if (read(fd,&zakladka,sizeof(zakladka)) != sizeof(zakladka)) break;
        if (empty <0 && !zakladka.path[0]) {
            empty=i;
            continue;
        }
        if (zakladka.czas < teraz) {
            mpt=i;
            teraz=zakladka.czas;
        }
        if (!strcmp(zakladka.path,fname)) {
            found=i;
            break;
        }
    }
    if (found < 0) found=(empty>=0)?empty:mpt;
    strcpy(zakladka.path,fname);
    zakladka.czas=time(NULL);
    zakladka.char_offset=offset;
    strcpy(zakladka.themes,themes);
    strcpy(zakladka.langs,langs);
    lseek(fd,found * sizeof(struct zakladka),SEEK_SET);
    ignore(write(fd,&zakladka,sizeof(struct zakladka)));
    close(fd);
}

void store_zakladka()
{
   	GtkTextIter pos;
    char *fname,*ext;
    int i;
    char thms[256];
    char lngs[64];
    int offset;
    struct miltheme *mt;
    if (get_current_editor()) return;
    fname=current_editor->save_name;
    if (!fname[0]) fname=current_editor->load_name;
    if (!fname[0]) return;
    ext=strrchr(fname,'/');
    if (ext && !strcmp(ext,"/dumpsub.txt")) return;
    ext=strrchr(fname,'.');
    if (!ext || strcmp(ext,".txt")) return;
    GtkTextMark *sel=gtk_text_buffer_get_insert(tresc);
	gtk_text_buffer_get_iter_at_mark(tresc,&pos,sel);
    offset=gtk_text_iter_get_offset(&pos);
    thms[0]=0;
    lngs[0]=0;
    for (mt=themes;mt;mt=mt->next) if (gtk_toggle_button_get_active((gpointer)mt->cb)) {
        if (strlen(mt->tname)+strlen(thms)>254) break;
		if (thms[0]) strcat(thms,",");
		strcat(thms,mt->tname);
	}
	for (i=0;i<NUM_LANGS;i++) if (gtk_toggle_button_get_active((gpointer)lang_cb[i])) {
		if (strlen(lang_codes[i])+strlen(lngs)>62) break;
		if (lngs[0]) strcat(lngs,",");
		strcat(lngs,lang_codes[i]);
	}
    _zakladka_write(fname,lngs,thms,offset);
}
