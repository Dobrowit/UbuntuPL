/*
 * fb2.c - Milena Audiobook Creator
 * Copyright (C) Bohdan R. Rau 2011 <ethanak@polip.com>
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write see:
 *               <http://www.gnu.org/licenses/>.
 */

#include "config.h"
#include "gmilena.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <ctype.h>
#include <errno.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>

/* fb2 sterowanie:

<i> - <emphasis>
<b> - <strong>
<u> - ignored

Zakończenie linii backslashem: przełączenie w tryb <poem>.
Jeśli następny akapit po poem jest również zakończony '\',
tylko zmiana zwrotki
Jeśli następny akapit jest krótki i zaczyna się od spacji,
traktowany jako autor

*/

//static char *_bdash="&#x2013;";
static char *_bdash="\xe2\x80\x93";
static int do_format=1;
static int can_do_footnotes;

static int stack_no,stack_size;
static char *stack_p;

static void _stack_start(void)
{
    if (!stack_p) {
        stack_size=16;
        stack_p=g_malloc(stack_size);
    }
    stack_no=0;
}
static void _stack_push(GString *gs,int what)
{
    if (what<1 || what > 3) return;
    if (stack_no == stack_size) {
        stack_size *=2;
        stack_p=g_realloc(stack_p,stack_size);
    }
    stack_p[stack_no++]=what;
    g_string_append(gs,(what == 1)?"<emphasis>":"<strong>");
}
static void _stack_pull(GString *gs,int what)
{
    while (stack_no > 0) {
        stack_no--;
        g_string_append(gs,(stack_p[stack_no] == 1)?"</emphasis>":"</strong>");
        if (stack_p[stack_no]==what) break;
    }
}

static void _stack_end(GString *gs)
{
    while (stack_no > 0) {
        stack_no--;
        g_string_append(gs,(stack_p[stack_no] == 1)?"</emphasis>":"</strong>");
    }
}

int _m(char *c,char *pat)
{
    int l;
    for (l=0;*pat;l++) if (*pat++ != *c++) return 0;
    return l;
}

static char *_m_quote(char *str)
{
    int i,l;
    gunichar g;
    if (do_format) while (*str=='<') {
        for (i=0;i<6;i++) if ((l=_m(str,ftags[i]))) break;
        if (i>=6) break;
        str+=l;
    }
    g=g_utf8_get_char(str);
    if (g_unichar_isalnum(g)) return "„";
    return "”";
}

int fb2_add_image(char *fname,struct fb2_imagelist **images)
{
    int nid=0;
    for (;*images;) {
        if (!strcmp((*images)->fname,fname)) {
            return (*images)->id;
        }
        if (nid < (*images)->id) nid=(*images)->id;
        images=&(*images)->next;
    }
    (*images)=g_malloc(sizeof(**images));
    (*images)->next=NULL;
    strcpy((*images)->fname,fname);
    nid++;
    (*images)->id=nid;
    return nid;
}

int fb2_skips(char **str)
{
    if (!strncmp(*str,"<fb2:part>",10)) {
        (*str)+=10;
        return 1;
    }
    if (!strncmp(*str,"<fb2:/part>",11)) {
        (*str)+=11;
        return 1;
    }
    if (!strncmp(*str,"<fb2:chapter>",13)) {
        (*str)+=13;
        return '.';
    }
    if (!strncmp(*str,"<fb2:br>",8)) {
        (*str)+=8;
        return ',';
    }
    if (!strncmp(*str,"<fb2:dot>",9)) {
		(*str)+=9;
		return ' ';
	}
    return 0;
}

int fb2_image(char **sstr,char **outstr,char **outsrc)
{
    char *str,*alt,*src;
    
    void mpe(char *a,char **out)
    {
        int bg=0,ug;
        if (*a=='"' || *a=='\'') bg=*a++;
        for (;*a;) {
            if (bg && *a==bg) break;
            if (!bg && (isspace(*a) || *a=='>')) break;
            if (*a!='&') {
                *(*out)++=*a++;
                continue;
            }
            ug=find_html_entity(a,&a);
            if (!ug) {
                *(*out)++=*a++;
                continue;
            }
            if (ug < 0x80) {
                *(*out)++=ug;
            }
            else if (ug < 0x800) {
                *(*out)++=(0xc0 | (ug>>6));
                *(*out)++=(0x80 | (ug & 0x3f));
            }
            else if (ug < 0x10000) {
                *(*out)++=(0xe0 | (ug>>12));
                *(*out)++=(0x80 | ((ug>>6) & 0x3f));
                *(*out)++=(0x80 | (ug & 0x3f));
            }
        }
    }


    char *eoq(char *s)
    {
        int znak=0;
        if (*s=='"' || *s=='\'') {
            znak=*s++;
            s=strchr(s,znak);
            if (!s) return NULL;
            return s+1;
        }
        for (;*s;s++) {
            if (isspace(*s) || *s=='>') break;
        }
        return s;
    }
    
    str=*sstr;
    if (strncmp(str,"<fb2:img",8)) return 0;
    str+=8;
    if (!*str || !isspace(*str)) return 0;
    src=alt=NULL;
    for (;;) {
        while (*str && isspace(*str)) str++;
        if (!*str) return 0;
        if (!src && !strncmp(str,"src=",4)) {
            str+=4;
            src=str;
            str=eoq(str);
            if (!str) return 0;
            continue;
        }
        if (!alt && !strncmp(str,"alt=",4)) {
            str+=4;
            alt=str;
            str=eoq(str);
            if (!str) return 0;
            continue;
        }
        if (*str++!='>') return 0;
        break;
    }
    if (!src) return 0;
    *sstr=str;
    if (alt && outstr) {
        mpe(alt,outstr);
    }
    if (src && outsrc) {
        mpe(src,outsrc);
    }
    return 1;
}

static void _append_to_eol(GString *gs,char **part,char *token,struct fb2_imagelist **images,int usebackn)
{
    char *str=*part;
    char *c;
    gunichar g;
    int do_blank;
    int space2nbsp=!strcmp(token,"code");
    int lbeg_offset=0;
    
    int _hlen(char *s)
    {
		int n=0;
		while (*s) {
			n++;
			if (*s=='&') {
				s=strchr(s,';');
				if (!s) break;
				s++;
				continue;
			}
			s=g_utf8_next_char(s);
		}
		return n;
	}
	if (strcmp(token,"p")) usebackn=0;			
    
    g_string_append_printf(gs,"<%s>",token);
    lbeg_offset=gs->len;
    _stack_start();
    do_blank=0;
    if (!space2nbsp) {
		while(*str==' ' || *str=='\t') str++;
		g=g_utf8_get_char(str);
		if (g=='-' || g == 8208 || g == 8211 || g == 8212 || g == 8213) {
			c=g_utf8_next_char(str);
			while (*c && (*c==' ' || *c== '\t')) c++;
			g=g_utf8_get_char(c);
			if (g_unichar_ispunct(g) || g_unichar_isalnum(g)) {
				g_string_append(gs,_bdash);
				do_blank=1;
				str=c;
			}
		}
	}
    for (;*str;) {
		if (!strncmp(str,"<fb2:dot>",9)) {
			g_string_append(gs,".");
			str += 9;
			continue;
		}
		if (!strncmp(str,"<fb2:br>",8)) {
			if (usebackn) {
				g_string_append(gs,"</p>\n<p>");
			}
			else {
				g_string_append(gs," ");
			}
			str +=8;
			continue;
		}
        if (*str=='\\' && (str[1]=='\r' || str[1]=='\n')) {
            str++;
            break;
        }
        if (*str=='\r' || *str=='\n') break;
        if (*str==' ' || *str =='\t') {
			if (space2nbsp) {
				g_string_append(gs,"&#xA0;");
				if (*str=='\t') {
					while(_hlen(gs->str+lbeg_offset) % 8) g_string_append(gs,"&#xA0;");
				}
				str++;
				continue;
			}
            str++;
            while (*str==' ' || *str =='\t') str++;
            do_blank=1;
            continue;
        }
        if (do_blank) {
            if (space2nbsp) {
				g_string_append(gs,"&#xA0;");
			}
			else {
				g_string_append_c(gs,' ');
			}
            do_blank=0;
        }
        if (!space2nbsp && *str=='"') {
            if (str == *part || isspace(*(str-1))) {
                g_string_append(gs,"„");
            }
            else {
                g_string_append(gs,_m_quote(str+1));
            }
            str++;
            continue;
        }
        if (can_do_footnotes && *str=='[') {
            char *c=str+1;
            if (*c && isdigit(*c)) {
                int n=strtol(c,&c,10);
                if (*c==']') {
                    g_string_append_printf(gs,"<a xlink:href=\"#note_%d\" xlink:type=\"note\">[%d]</a>",n,n);
                    str=c+1;
                    continue;
                }
            }
        }
        if (do_format && *str=='<') {
            char fmt[256],fnm[256];
            char *c=fmt,*d=fnm;
            int imgid;
            if (fb2_image(&str,&d,&c)) {
                *c=0;
                *d=0;
                imgid=fb2_add_image(fmt,images);
                g_string_append_printf(gs,"<image xlink:href=\"#img_%d\"",imgid);
                if (fnm[0]) {
                    g_string_append(gs," alt=\"");
                    g_string_append_htmlescape(gs,fnm);
                    g_string_append(gs,"\"");
                }
                g_string_append(gs," />");
                
                continue;
            }
            if (!strncmp(str,"<i>",3)) {
                _stack_push(gs,1);
                str+=3;
                continue;
            }
            if (!strncmp(str,"<b>",3)) {
                _stack_push(gs,2);
                str+=3;
                continue;
            }
            if (!strncmp(str,"<u>",3)) {
                _stack_push(gs,3);
                str+=3;
                continue;
            }
            if (!strncmp(str,"</i>",4)) {
                _stack_pull(gs,1);
                str+=4;
                continue;
            }
            if (!strncmp(str,"</b>",4)) {
                _stack_pull(gs,2);
                str+=4;
                continue;
            }
            if (!strncmp(str,"</u>",4)) {
                _stack_pull(gs,3);
                str+=4;
                continue;
            }
        }
        if (*str=='<') {
            g_string_append(gs,"&lt;");
            str++;
            continue;
        }
        if (*str=='>') {
            g_string_append(gs,"&gt;");
            str++;
            continue;
        }
        if (*str=='&') {
            g_string_append(gs,"&amp;");
            str++;
            continue;
        }
        g=g_utf8_get_char(str);
        c=g_utf8_next_char(str);
        if (!space2nbsp) {
			if ((g == '-' && (*c==' ' || *c=='\t')) || g == 8208 || g == 8211 || g == 8212 || g == 8213) {
				g_string_append(gs,_bdash);
				do_blank=1;
				str=c;
				continue;
			}
		}
        g_string_append_len(gs,str,c-str);
        str=c;
    }
    if (*str=='\r') str++;
    if (*str=='\n') str++;
    *part=str;
    _stack_end(gs);
    g_string_append_printf(gs,"</%s>\n",token);
}

static void _next_par(char **c)
{
    char *s=strpbrk(*c,"\r\n");
    if (!s) {
        *c=(*c) + strlen(*c);
        return;
    }
    if (*s=='\r') s++;
    if (*s=='\n') s++;
    *c=s;
}



#define FB2M_TITLE 32
#define FB2M_POEM 1
#define FB2M_EPI 2
#define FB2M_CITE 4
#define FB2M_SUBT 8
#define FB2M_CODE 16
#define FB2M_IMAGE 256
#define FB2M_CONT 64
#define FB2M_AUTHOR 512
#define FB2M_EMPTY 128
#define FB2M_UNREAD 256
#define FB2M_U (FB2M_EMPTY | FB2M_UNREAD)
#define FB2M_MASK 31

static int _line_type_t(char **part,int ignore_extras)
{
    int i,mtp,l,znaki,alnum,iscnt;
    char *c;
    gunichar g;
    while (**part && (**part == ' ' || **part=='\t')) (*part)++;
    if (!**part || (**part=='\r') || (**part=='\n')) return FB2M_EMPTY;

    if (!do_format) {
        for (znaki=FB2M_EMPTY,c=*part;*c && *c!='\r' && *c!='\n';) {
            if (*c==' ' || *c=='\t') {
                c++;
                continue;
            }
            g=g_utf8_get_char(c);
            if (g_unichar_isalnum(g)) return 0;
            c=g_utf8_next_char(c);
            znaki=FB2M_UNREAD;
        }
        return znaki;
    }


    mtp=0;
    // sprawdzamy czy to image
    c=*part;
    if (fb2_image(&c,NULL,NULL)) {
        for (;*c ==' ' || *c=='\t';c++);
        if (!*c || *c == '\r' || *c=='\n') return FB2M_IMAGE;
    }
    
    for (i=6;ftags[i];i++) {
        l=_m(*part,ftags[i]);
        if (l) {
            (*part) += l;
            mtp=i;
            break;
        }
    }
    while (**part && (**part == ' ' || **part=='\t')) (*part)++;
    if (!**part || (**part=='\r') || (**part=='\n')) return FB2M_EMPTY;
    c=*part;
    znaki=alnum=iscnt=0;
    for (;*c && *c !='\r' && *c!='\n';) {
        if (*c=='\\' && (c[1]=='\r' || c[1]=='\n')) {
            c++;
            iscnt=FB2M_CONT;
	    if (**part == '\\') {
		//printf("Stanzer found [%-20.20s]\n",*part);
		return FB2M_CONT | FB2M_EMPTY;
	    }
            break;
        }
        if (*c=='<') {
            for (i=0;i<6;i++) {
                l=_m(c,ftags[i]);
                if (l) {
                    c+=l;
                    break;
                }
            }
            if (i<6) continue;
        }
        znaki++;
        g=g_utf8_get_char(c);
        if (g_unichar_isalnum(g)) alnum++;
        c=g_utf8_next_char(c);
    }
    if (!znaki) return FB2M_EMPTY;
    if (!alnum) return FB2M_UNREAD;
    if (ignore_extras) return 0;
    if (iscnt) {
        if (*c=='\r') c++;
        if (*c=='\n') c++;
        if (_line_type_t(&c,1)) iscnt=0;
    }
    if (mtp) {
        if (mtp == 6) iscnt |= FB2M_POEM;
        /* rozróżnienie epigraph-epi tylko dla audio */
        else if (mtp == 7 || mtp == 12) iscnt |= FB2M_EPI;
        else if (mtp == 8) iscnt |= FB2M_CITE;
        else if (mtp == 9) iscnt |= FB2M_AUTHOR;
        else if (mtp == 10) iscnt |= FB2M_TITLE;
        else if (mtp == 11) iscnt |= FB2M_SUBT;
        else if (mtp == 13) iscnt |= FB2M_CODE;
    }
    return iscnt;
}

static int _line_type(char **part)
{
    return _line_type_t(part,0);
}

static int _rdable(char *c)
{
    gunichar g;
    for (;*c && *c!='\n' && *c!='\r';) {
        g=g_utf8_fetch_char(&c);
        if (!g) break;
        if (g_unichar_isalnum(g)) return 1;
    }
    return 0;
}        
        
void create_fb2_section(GString *gs,char *part,int split,int footnote,int annotation,struct fb2_imagelist **images,int *depth,int *htitle)
{
    int ltyp,i,add_el;
    add_el=gtk_check_menu_item_get_active((gpointer)m_fb2_el);
    if (footnote) {
        g_string_append_printf(gs,"<section id=\"note_%d\">",footnote);
    } else if (annotation) {
        g_string_append(gs,"<annotation>\n");
    } else {
        if (split && depth) {
            if (!strncmp(part,"<fb2:/part>",11)) {
                if (*depth > 0) {
                    (*depth)--;
                    g_string_append(gs,"</section>\n");
                }
                part+=11;
            }
            if (!strncmp(part,"<fb2:part>",10)) {
                char *c;
                part+=10;
                if (*depth > 0) {
                    g_string_append(gs,"</section>\n<section>\n");
                }
                else {
                    (*depth)++;
                    g_string_append(gs,"<section>\n");
                }
                for (c=part;*c;c++) {
                    if (*c=='\n') break;
                    if (*c!='<') continue;
                    if (!strncmp(c,"<fb2:chapter>",13)) break;
                }
                if (*c == '<') {
                    *c=0;
                    if (!_rdable(part)) {
                        if (!htitle || !*htitle) {
                            g_string_append(gs,"<title> </title>\n");
                        }
                    }
                    else {
                        g_string_append(gs,"<title>");
                        _append_to_eol(gs,&part,"p",images,1);
                        g_string_append(gs,"</title>\n");
                    }
                    *c='<';
                    part=c+13;
                }
                else {
                    if (!htitle || !*htitle) {
                        g_string_append(gs,"<title> </title>\n");
                    }
                }
                if (htitle) {
                    *htitle=1;
                    htitle[1]=0;
                }
            }
        }
        g_string_append(gs,"<section>\n");
    }
    /* jeśli split sprawdzam, czy pierwsza linia jest czytelna i robię title */
    if (split) {
        ltyp=_line_type(&part);
        if (ltyp & FB2M_U) {
            if (!annotation) {
                if (!htitle || !depth || !htitle[*depth]) {
                    g_string_append(gs,"<title> </title>");
                }
            }
            _next_par(&part);
        }
        else {
            g_string_append(gs,annotation?"<subtitle>":"<title>");
            _append_to_eol(gs,&part,"p",images,1);
            g_string_append(gs,annotation?"</subtitle>\n":"</title>\n");
        }
        if (htitle && depth) htitle[*depth]=1;
        while (*part && isspace(*part)) part++;
    }
    else if (footnote) {
        g_string_append_printf(gs,"<title><p>%d</p></title>\n",footnote);
    }
    while (*part) {
        //printf("%-20.20s\n",part);
        ltyp = _line_type(&part);
        //printf("LT %x\n",ltyp);
        if (ltyp & FB2M_U) {
            char *c=part;
            int emp=0;
            while (*c) {
                if (!_line_type_t(&c,1)) break;
                _next_par(&c);
            }
            if (!*c) break;
            
            // właśnie sprawdził czy jest sens jechać dalej,
            // powiedzmy że jest
        
            while(*part) {
                ltyp=_line_type(&part);
                if (ltyp & FB2M_EMPTY) {
                    emp=1;
                    _next_par(&part);
                }
                else if (ltyp & FB2M_UNREAD) {
                    //if (emp) {
                        g_string_append(gs,"<empty-line/>");
                        if (add_el) g_string_append(gs,"<empty-line/>");
                        emp=1;
                    //}
                    _append_to_eol(gs,&part,"p",images,0);
                }
                else break;
            }
            if (emp && *part) {
                g_string_append(gs,"<empty-line/>");
                if (add_el) g_string_append(gs,"<empty-line/>");
            }
        }
        if (!*part) break;
        // w ltyp mamy ostatni wynik line_type
        
        //ltyp=_line_type(&part);
        if (ltyp == FB2M_CONT) ltyp |= FB2M_POEM;
        if (ltyp & FB2M_AUTHOR) ltyp=0; // error?
        if (ltyp & FB2M_SUBT) ltyp=FB2M_SUBT;
        //nie można zamieścić epigrafu w adnotacji
        if (annotation && ((ltyp & FB2M_MASK) == FB2M_EPI)) {
            ltyp = (ltyp & ~FB2M_MASK) | FB2M_CITE;
        }
        //printf("LTYP=%d\n",ltyp);
        if (ltyp == FB2M_IMAGE) {
            char src[256]="",alt[256]="";
            int imgid;
            char *c=src,*d=alt;
            fb2_image(&part,&d,&c);
            *c=0;*d=0;
            imgid=fb2_add_image(src,images);
            g_string_append_printf(gs,"<image l:href=\"#img_%d\"",imgid);
            if (alt[0]) {
                g_string_append(gs," title=\"");
                g_string_append_htmlescape(gs,alt);
                g_string_append(gs,"\"");
            }
            g_string_append(gs," />\n");
            _next_par(&part);
            continue;
        }
        if ((ltyp & FB2M_MASK) == FB2M_CODE) {
            for (;;) {
				char *pc=part;
                ltyp = _line_type(&part);
                g_string_append(gs,"<p>");
                part=pc;
                _append_to_eol(gs,&part,"code",images,0);
                g_string_append(gs,"</p>");
                if (!(ltyp & FB2M_CONT)) break;
            }
            if (add_el) g_string_append(gs,"<empty-line/>");
            continue;
        }
        if ((ltyp & FB2M_MASK) == FB2M_EPI) {
            char *csx="p";
            g_string_append(gs,"<epigraph>\n");
            for (;;) {
                ltyp = _line_type(&part);
                if (ltyp & FB2M_AUTHOR) csx="text-author";
                _append_to_eol(gs,&part,csx,images,0);
                if (!(ltyp & FB2M_CONT)) break;
            }
            g_string_append(gs,"</epigraph>\n");
            continue;
        }
        if ((ltyp & FB2M_MASK) == FB2M_CITE) {
            char *csx="p";
            g_string_append(gs,"<cite>\n");
            for (;;) {
                ltyp = _line_type(&part);
                if (ltyp & FB2M_AUTHOR) csx="text-author";
                _append_to_eol(gs,&part,csx,images,0);
                if (!(ltyp & FB2M_CONT)) break;
            }
            g_string_append(gs,"</cite>\n");
            
            continue;
        }
        if ((ltyp & FB2M_MASK) == FB2M_SUBT) {
            _append_to_eol(gs,&part,"subtitle",images,0);
            continue;
        }
        // poemtitle musi mieć kontynuację
        if ((ltyp & FB2M_MASK) != FB2M_POEM &&  !(ltyp & FB2M_CONT)) {
            /* normalna linia */
            _append_to_eol(gs,&part,"p",images,0);
            if (add_el) g_string_append(gs,"<empty-line/>");
            continue;
        }
        g_string_append(gs,"<poem>\n");
        if (ltyp & FB2M_TITLE) {
            g_string_append(gs,"<title>");
            _append_to_eol(gs,&part,"p",images,1);
            ltyp=_line_type(&part);
            g_string_append(gs,"</title>");
            
        }
        ltyp=FB2M_CONT;
        for (;;) {
            char *cp;int z;
            g_string_append(gs,"<stanza>\n");
            for (i=0;;i++) {
                if (i) {
                    ltyp=_line_type(&part);
                }
                if (ltyp & FB2M_AUTHOR) break;
		//if (ltyp & FB2M_EMPTY)
		//printf("%X Part [%-20.20s]\n",ltyp,part);
                _append_to_eol(gs,&part,"v",images,0);
                if (!(ltyp & FB2M_CONT)) break;
            }
            g_string_append(gs,"</stanza>\n");
            if (add_el) g_string_append(gs,"<empty-line/>");
            if (ltyp & FB2M_AUTHOR) {
                for (;;) {
                    _append_to_eol(gs,&part,"text-author",images,0);
                    cp=part;
                    z=_line_type(&cp);
                    if (!(z & FB2M_CONT)) break;
                    part=cp;
                }
                break;
            }
            cp=part;
            z=_line_type(&cp);
            if (!(z & FB2M_CONT)) break;
            ltyp=z;
            part=cp;
        }
        g_string_append(gs,"</poem>\n");
        if (add_el) g_string_append(gs,"<empty-line/>");
    }
    g_string_append(gs,annotation?"</annotation>\n":"</section>\n");
}

int FB2_finalize(GString *gs,char *cover,struct fb2_imagelist *ima)
{
    char inbuf[1024];
    char outbuf[2048];
    int fd;
    size_t outlen,inlen;
    gint state,save;
    g_string_append(gs,"</body>");
    char *imgtype(char *s)
    {
        s=strrchr(s,'.');
        if (!s) return "jpeg";
        s++;
        if (!strcasecmp(s,"gif")) return "gif";
        if (!strcasecmp(s,"png")) return "png";
        return "jpeg";
    }
    if (cover && *cover) {
        fd=open(cover,O_RDONLY);
        if (fd < 0) {
            Error("Błąd","Nie mogę odczytać pliku okładki");
            return 0;
        }
        g_string_append_printf(gs,"<binary type=\"image/%s\" id=\"_cover\">",imgtype(cover));
        state=0;save=0;
        for(;;) {
            inlen=read(fd,inbuf,1024);
            if (inlen <= 0) break;
            outlen=g_base64_encode_step((gpointer)inbuf,inlen,1,(gpointer)outbuf,&state,&save);
            g_string_append_len(gs,outbuf,outlen);
        }
        outlen=g_base64_encode_close(1,outbuf,&state,&save);
        g_string_append_len(gs,outbuf,outlen);
        g_string_append(gs,"\n</binary>");
        close(fd);
    }
    for (;ima;ima=ima->next) {
        fd=open(ima->fname,O_RDONLY);
        if (fd < 0) {
            ErrorF(NULL,"Błąd","Nie mogę odczytać pliku obrazka:\n%s",ima->fname);
            return 0;
        }
        g_string_append_printf(gs,"<binary type=\"image/%s\" id=\"img_%d\">",imgtype(ima->fname),ima->id);
        state=0;save=0;
        for(;;) {
            inlen=read(fd,inbuf,1024);
            if (inlen <= 0) break;
            outlen=g_base64_encode_step((gpointer)inbuf,inlen,1,(gpointer)outbuf,&state,&save);
            g_string_append_len(gs,outbuf,outlen);
        }
        outlen=g_base64_encode_close(1,outbuf,&state,&save);
        g_string_append_len(gs,outbuf,outlen);
        g_string_append(gs,"\n</binary>");
        close(fd);
    }
    g_string_append(gs,"</FictionBook>\n");
    return 1;
}

int fb2_can_have_footnotes(char *body)
{
    char *c;
    c=strstr(body,"\n---\n");
    if (c) {
        c+=5;
        while (*c && isspace(*c)) c++;
        if (!strncmp(c,"[1]",3)) return 1;
    }
    return 0;
}

    
void create_fb2_sections(GString *gs,char *body,int spliter,int do_foot,int do_anno,struct fb2_imagelist **images)
{
    char c4[4],*cs;
    char *footnotes=NULL;
    can_do_footnotes=do_foot;
    int depth=0;
    int htit[2]={0,0};
    
    _bdash=gtk_check_menu_item_get_active((gpointer)m_epub_dash)?
        "\xe2\x80\x93":"\xe2\x80\x94";
    do_format=gtk_check_menu_item_get_active((gpointer)m_epub_format);
    if (do_foot) {
        cs=strstr(body,"\n---\n");
        if (cs) {
            char *c=cs+5;
            while (*c && isspace(*c)) c++;
            if (!strncmp(c,"[1]",3)) {
                footnotes=c;
                cs[1]=0;
            }
        }
    }
    if (!spliter) {
        create_fb2_section(gs,body,0,0,0,images,&depth,htit);
        goto make_foots;
    }
    sprintf(c4,"\n%c",spliter);
    cs=strstr(body,c4);
    if (cs) body=cs+2;
    if (do_anno) {
        cs=strstr(body,c4);
        if (cs) body=cs+2;
    }
    for (;;) {
        cs=strstr(body,c4);
        if (!cs) {
            create_fb2_section(gs,body,1,0,0,images,&depth,htit);
            break;
        }
        cs++;
        *cs++=0;
        create_fb2_section(gs,body,1,0,0,images,&depth,htit);
        body=cs;
    }
make_foots:
    if (depth) g_string_append(gs,"</section>\n");
    if (!footnotes) return;
    g_string_append(gs,"</body>\n<body name=\"notes\">\n");
    while (*footnotes) {
        char *c=strstr(footnotes,"\n[");
        int nr;
        if (c) *c++=0;
        nr=strtol(footnotes+1,&footnotes,10);
        if (*footnotes) {
            footnotes++;
            while (*footnotes && isspace(*footnotes)) footnotes++;
        }
        create_fb2_section(gs,footnotes,0,nr,0,images,NULL,NULL);
        if (!c) break;
        footnotes=c;
    }
}


