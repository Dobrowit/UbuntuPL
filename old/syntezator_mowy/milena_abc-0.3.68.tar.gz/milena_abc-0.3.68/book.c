/*
 * book.c - Milena Audiobook Creator
 * Copyright (C) Bohdan R. Rau 2009-2011 <ethanak@polip.com>
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write see:
 *               <http://www.gnu.org/licenses/>.
 */
#include "config.h"
#include "gmilena.h"
#include <stdlib.h>
#include <string.h>
#include "milena_mbrola.h"
#include <iconv.h>
#include <stdio.h>
#include <ctype.h>
#include <glib.h>

#define AUMODE_ON 1
#define AUMODE_KEEP_LINE 2
#define AUMODE_PROLOG 4
#define AUMODE_PROLOG_KEEP 8
#define AUMODE_EPILOG 16
#define AUMODE_EPILOG_KEEP 32
#define AUMODE_LASTCHAPTER 64

int conversion_stop;
int currently_making_book=0;

static char *book;
static char **chapters;
static int chapter_no;
static int *chapter_length;
static int body_length;
static char *title;
static char **chapter_titles;
static char **chapter_files;
static double *chapter_seconds;
static int index_length;
static char *index_title;
static char nokia_path[PATH_MAX+1];
static char mp3_path[PATH_MAX+1];
static int is_nokia;
static int this_chapter;
char *this_pos;
static char *mp3_artist,*mp3_album;
static int mp3_use_chapter;
int stereo_mode;
int stereo_upsample;
static int multipart;

int mp3_make_aac;

static short outbuf[4096];
static char *to_ascii7(char const *str,int from_utf)
{
	if (!str || !*str) return NULL;
	int n;char *s,*c,*d,*e,*sout;
	static char *c_strs[]={
		" " ,"A" ,"-" ,"L" ,"*" ,"L" ,"S" ," par." ,"-" ,"S" ,
		"S" ,"T" ,"Z" ,"-" ,"Z" ,"Z" ," o " ,"a" ,"," ,"l" ,
		"'" ,"l" ,"s" ,"-" ,"," ,"s" ,"s" ,"t" ,"z" ,"-" ,
		"z" ,"z" ,"R" ,"A" ,"A" ,"Aa" ,"Ae" ,"L" ,"C" ,"C" ,
		"C" ,"E" ,"E" ,"E" ,"E" ,"I" ,"I" ,"D" ,"D" ,"N" ,"N" ,
		"O" ,"O" ,"O" ,"Oe" ,"x" ,"R" ,"U" ,"U" ,"U" ,"Ue" ,
		"Y" ,"T" ,"s" ,"r" ,"a" ,"a" ,"aa" ,"ae" ,"l" ,"c" ,"c" ,
		"c" ,"e" ,"e" ,"e" ,"e" ,"i" ,"i" ,"d" ,"d" ,"n" ,"n" ,
		"o" ,"o" ,"o" ,"oe" ,":" ,"r" ,"u" ,"u" ,"u" ,"ue" ,"y" ,"t" ,"-"};
	if (from_utf) {
		n=to_iso2((char *)str,NULL);
		if (!n) return NULL;
		s=g_malloc(n);
		to_iso2((char *)str,s);
	}
	else {
		s=g_strdup(str);
	}
	for (n=0,c=s;*c;c++) {
		if (((*c) & 255)>160) {
			n+=strlen(c_strs[((*c)&255)-160]);
		}
		else {
			n++;
		}
	}
	sout=g_malloc(n+1);
	for (c=s,d=sout;*c;c++) {
		if (((*c) & 255)<=160) {
			*d++=*c;
		}
		else {
			e=c_strs[((*c)&255)-160];
			while (*e) *d++=*e++;
		}
	}
	*d=0;
	g_free(s);
	return sout;
}


double compute_percent(void)
{
	if (!chapter_no) {
		return ((double)(this_pos-book))/(double)body_length;
	}
	int i,n;
	for (i=n=0;i<this_chapter;i++) n+=chapter_length[i];
	return ((double)(n+(this_pos-chapters[i])))/(double)body_length;
}


void nokia_correct(char *c)
{
	if (is_nokia) {
		for (;*c;c++) if (*c==';'||*c==':') *c=',';
	}
}

void free_book(void)
{
	int i;
	if (chapters && chapter_no) {
		for (i=0;i<chapter_no;i++) if (chapters[i]) {
			g_free(chapters[i]);
		}
		g_free(chapters);
	}
	if (index_length) {
		if (chapter_titles) {
			for (i=0;i<index_length;i++) if (chapter_titles[i]) g_free(chapter_titles[i]);
		}
		if (chapter_files) {
			for (i=0;i<index_length;i++) if (chapter_files[i]) g_free(chapter_files[i]);
		}

	}
	index_length=0;
	if (chapter_titles) g_free(chapter_titles);chapter_titles=NULL;
	if (chapter_files) g_free(chapter_files);chapter_files=NULL;
	if (chapter_seconds) g_free(chapter_seconds);chapter_seconds=NULL;
	chapters=NULL;
	chapter_no=0;
	if (book) g_free(book);
	if (chapter_length) g_free(chapter_length);
	if (title) g_free(title);
	if (index_title) g_free(index_title);
    index_title=NULL;
	title=NULL;
	chapter_length=NULL;
	book=NULL;
	if (mp3_artist) g_free(mp3_artist);
	if (mp3_album) g_free(mp3_album);
	mp3_artist=NULL;
	mp3_album=NULL;
}


static int failsplit(char *txt)
{
	Error("Błąd",txt);
	free_book();
	return 1;
}

static int split_book(int automode,int marker)
{
	char *tt,*c,*d,*e,*bdy,*outs;
	int npart,lc,this_part,gline,i;
	char *str=book;
	char *temp_title;
	char *sstr=NULL;
	while (*str && my_space(*str)) str++;
	if (!*str) return 1;
	tt=str;
	str=strpbrk(str,"\r\n");
	if (!str) return 0;
	c=str++;
	while (*str && my_space(*str)) str++;
	if (!*str) return 0;
	if (*str!=marker) {
		str=strpbrk(str,"\r\n");
		c=str++;
		if (!str) return 0;
		while (*str && my_space(*str)) str++;
		if (!*str) return 0;
		if (*str!=marker) return 0;
	}

	for (npart=1,bdy=str+1;bdy && *bdy;) {
		bdy=strpbrk(bdy,"\r\n");
		if (!bdy) break;
		while (*bdy && my_space(*bdy)) bdy++;
		if (*bdy==marker) npart++;
	}
	chapter_no=npart;
	index_length=npart;
	*c=0;
	for (c=d=tt;*c && *c!='\r' && *c!='\n';c++) {
		if (my_alnum(*c)) d=c+1;
	}
	lc=0;
	if (strchr(d,'?')) lc='?';
	else if (strchr(d,'!')) lc='!';
	else lc='.';
	title=g_malloc(d-tt+strlen(c)+10);
	e=title;
	memcpy(e,tt,d-tt);
	e+=d-tt;
	*e++=lc;
	*e=0;
	while (*c && isspace(*c)) c++;
	if (*c) {
		sstr=e;
		*e++=' ';
		tt=c;
		for (c=d=tt;*c && *c!='\r' && *c!='\n';c++) {
			if (my_alnum(*c)) d=c+1;
		}
		lc=0;
		if (strchr(d,'?')) lc='?';
		else if (strchr(d,'!')) lc='!';
		else lc='.';
		memcpy(e,tt,d-tt);
		e+=d-tt;
		*e++=lc;
		*e=0;
	}
	chapters=calloc(npart,sizeof(*chapters));
	chapter_length=calloc(npart,sizeof(*chapter_length));
	chapter_files=calloc(npart,sizeof(*chapter_files));
	chapter_titles=calloc(npart,sizeof(*chapter_titles));
	outs=NULL;
	this_part=0;
	str++;
	while (this_part < chapter_no) {
		while (*str && my_space(*str)) str++;
		if (!*str) return failsplit("Pusty rozdział końcowy");
		if (*str==marker) return failsplit("Pusty rozdział");
		bdy=str;
		for (;;) {
			tt=strpbrk(bdy,"\r\n");
			if (!tt) {
				bdy=tt=bdy+strlen(bdy);
				break;
			}
			bdy=tt;
			while (*bdy && my_space(*bdy)) bdy++;
			if (*bdy==marker) break;
		}
		chapters[this_part]=outs=g_malloc(bdy-str+strlen(title)+256);
		strcpy(outs,title);
		if (sstr) {
			*sstr=0;
			sstr=NULL;
		}
		strcat(outs," ");
		outs+=strlen(outs);
		temp_title=outs;
		this_part++;
		gline=1;
		if (automode) {
			int nroz;
			nroz=this_part;
			if (automode & AUMODE_PROLOG) nroz--;
			if (this_part == 1 && (automode & AUMODE_PROLOG)) {
				if (automode & AUMODE_PROLOG_KEEP) {
					strcat(outs,"Prolog, ");
				}
				else {
					strcat(outs,"Prolog.");
					gline=0;
				}
			}
			else if (this_part == chapter_no && (automode & (AUMODE_EPILOG | AUMODE_LASTCHAPTER))) {
				if (automode & AUMODE_LASTCHAPTER) {
					sprintf(outs+strlen(outs),"Rozdzia\xb3 %d i ostatni",nroz);
					if (automode & AUMODE_KEEP_LINE) strcat(outs,", ");
					else {
						gline=0;
						strcat(outs,".");
					}
				}
				else {
					if (automode & AUMODE_EPILOG_KEEP) {
						strcat(outs,"Epilog, ");
					}
					else {
						strcat(outs,"Epilog.");
						gline=0;
					}
				}
			}
			else {
				if (automode & AUMODE_KEEP_LINE) sprintf(outs+strlen(outs),"Rozdzia\xb3 %d, ",nroz);
				else {
					sprintf(outs+strlen(outs),"Rozdzia\xb3 %d.",nroz);
					gline=0;
				}
			}
		}
		outs+=strlen(outs);
		if (gline) {
			for (;*str && *str!='\r' && *str!='\n';) {
				*outs++=*str++;
			}
			*outs=0;
			while (*str && my_space(*str)) str++;
		}
		*outs=0;
		chapter_titles[this_part-1]=g_strdup(temp_title);
		nokia_correct(chapter_titles[this_part-1]);
		*outs++='\n';
		*outs++='\n';
		strncpy(outs,str,tt-str);
		outs+=tt-str;
		if (this_part == 1 && (automode & AUMODE_PROLOG)) {
			strcpy(outs,"\n\nkoniec prologu.\n");
		}
		else if (this_part == chapter_no) {
			strcpy(outs,"\n\nkoniec ksi\xb1\xbfki.\n");
		}
		else {
			strcpy(outs,"\n\nkoniec rozdzia\xb3u.\n");
		}
		str=bdy+1;
	}
	body_length=0;
	for (i=0;i<chapter_no;i++) {
		chapter_length[i]=strlen(chapters[i]);
		body_length+=chapter_length[i];
	}
	return 0;
}

/*
 * Powinno to działać tak:
 * Dla linii z kontynuacją:
 * 1) linia poemtitle - zamienia kontynuację na kropkę
 *    i wchodzi w tryb poem
 * 2) linia cite/epi - wchodzi w tryb epicite
 * 2a) linia epigraph - wchodzi w tryb epigraph
 * 3) linia author - wchodzi w tryb author
 * 4) linia kontynuacji w trybie 0 - przełącza w tryb poem
 * 5) w trybie epicite kontynuacja jest usuwana (pozostaje akapit)
 * 6) w trybie poem kontynuacja jest zamieniona na spację, o ile
 *    następną linią nie jest author. Jeśli jest author,
 *    kontynuacja jest usuwana.
 * 7) w trybie author linia kontynuacji zamieniana jest
 *    na przecinek
 * 8) w trybie epigraph linia kontynuacji zamieniana jest
 *    na przecinek
 */

#define BKMD_POEM 1
#define BKMD_CITE 2
#define BKMD_AUTHOR 3
#define BKMD_TITLE 4
#define BKMD_EPI 5
#define BKMD_SUBT 6



static void remake_formatted_book(char *c)
{
    char *d;
    int i,l=0;
    int fmt=gtk_check_menu_item_get_active((gpointer)m_epub_format);
    int mode=0; /* brak formatowania */
    for (d=c;*c;) {
        if (fmt && *c=='<') {
            for (i=6;ftags[i];i++) if ((l=_m(c,ftags[i]))) {
                c+=l;
                break;
            }
            if (l) {
                if (i == 6) mode = BKMD_POEM;
                else if (i == 7 || i == 8 || i == 13) mode = BKMD_CITE;
                else if (i == 9) mode = BKMD_AUTHOR;
                else if (i == 10) mode = BKMD_TITLE;
                else if (i == 12) mode = BKMD_EPI;
                else if (i == 11) mode = BKMD_SUBT;
                else mode=0;
            }

        }
        if (mode == BKMD_SUBT) {
            *d++='\n';
            while (*c && *c != '\r' && *c!='\n') *d++=*c++;
            while (*c && isspace(*c)) c++;
            *d++='\n';
            *d++='\n';
            mode=0;
            continue;
        }
        while (*c) {
            if (*c=='\\' && (c[1]=='\r' || c[1]=='\n')) {
                if (!mode) mode=BKMD_POEM;
                if (mode == BKMD_TITLE) {
                    c++;
                    if (*c=='\r') c++;
                    if (*c=='\n') c++;
                    *d++='.';
                    *d++=' ';
                    mode=BKMD_POEM;
                    break;
                }
                if (mode == BKMD_AUTHOR) {
                    c++;
                    if (*c=='\r') c++;
                    if (*c=='\n') c++;
                    *d++=',';
                    *d++=' ';
                    break;
                }
                if (mode == BKMD_EPI) {
                    c++;
                    if (*c=='\r') c++;
                    if (*c=='\n') c++;
                    *d++=',';
                    *d++=' ';
                    break;
                }
                if (mode == BKMD_CITE) {
                    c++;
                    if (*c=='\r') c++;
                    if (*c=='\n') c++;
                    *d++='\n';
                    break;
                }
                /* default is poem */
                c++;
                if (*c=='\r') c++;
                if (*c=='\n') c++;
                for (i=6;ftags[i];i++) if (_m(c,ftags[i])) break;
                if (ftags[i]) *d++='\n';
                else *d++=' ';
                break;
            }
            if (*c=='\r' || *c=='\n') {
                mode=0;
                if (*c=='\r') c++;
                if (*c=='\n') c++;
                *d++='\n';
                break;
            }
            if (fmt && *c=='<') {
                for (i=0;i<6;i++) if ((l=_m(c,ftags[i]))) break;
                if (l) {
                    c+=l;
                    *d++=' ';
                    continue;
                }
                i=fb2_skips(&c);
                if (i) {
                    if (i!=1) {
                        *d++=i;
                        *d++=' ';
                    }
                    continue;
                }
                if (fb2_image(&c,&d,NULL)) continue;
            }
            *d++=*c++;
        }
    }
    *d=0;
}
#if 0
static void _remake_book_fr(char *c)
{
    char *d;int ix,le;
    int fmt=gtk_check_menu_item_get_active((gpointer)m_epub_format);
    for (d=c;*c;) {
        if (*c=='\\') {
            c++;
            if (*c != 'r' && *c != '\n') {
                *d++='\\';
                continue;
            }
            if (*c=='\r') c++;
            if (*c=='\n') c++;
            if (*c !='\r' && *c !='\n') {
                *d++=' ';
            }
            continue;
        }
        if (fmt && *c=='<') {
            for (ix=0;ftags[ix];ix++) {
                if ((le=_m(c,ftags[ix]))) break;
            }
            if (le) {
                *d++=' ';
                c+=le;
                continue;
            }
        }
        *d++=*c++;
    }
    *d=0;
}
#endif

int init_book(char *c,int split,int aumode,int marker)
{
    ignore_oor=1;
	free_book();
    remake_formatted_book(c);
    book=c;
	body_length=strlen(book);
	chapter_no=0;
	if (split) {
		if (split_book(aumode,marker)) return -1;
	}
	if (!chapter_no) {
		index_length=1;
		chapter_files=calloc(1,sizeof(*chapter_files));
		chapter_titles=calloc(1,sizeof(*chapter_titles));

	}
	chapter_seconds=calloc(index_length,sizeof(*chapter_seconds));
	return chapter_no;

}

static char *book_tryb(void)
{
	static char buf[256];int n;char *c=NULL;
	if (!chapter_no) return "Pojedynczy plik";
	sprintf(buf,"Podział na %d rozdział",chapter_no);
	if (chapter_no>1) {
		n=chapter_no % 100;
		if (n>10 && n<20) c="ów";
		else {
			n=n%10;
			if (n>=2 && n<=4) c="y";
			else c="ów";
		}
	}
	if (c) strcat(buf,c);
	return buf;

}

static GtkWidget *confirm_dialog;
static GtkWidget *fentry;

static void open_book_target_nokia(void)
{
	GtkWidget *dialog=gtk_file_chooser_dialog_new(
		"Wybierz katalog docelowy",
		GTK_WINDOW(confirm_dialog),GTK_FILE_CHOOSER_ACTION_CREATE_FOLDER,
		GTK_STOCK_CANCEL, GTK_RESPONSE_CANCEL,
		GTK_STOCK_SAVE, GTK_RESPONSE_ACCEPT,
		NULL);
	gtk_file_chooser_set_local_only((gpointer)dialog,TRUE);
	char const *path=gtk_entry_get_text((gpointer)fentry);
	char xbuf[PATH_MAX+1];
	if (!path || !*path) {
		char *c=NULL;
		get_current_editor();
		if (current_editor->save_name[0]) c=current_editor->save_name;
		else if (current_editor->load_name[0]) c=current_editor->load_name;
		if (c) {
			strcpy(xbuf,c);
			c=strrchr(xbuf,'/');
			if (c) {
				*c=0;
				path=xbuf;
			}
		}
	}
	if (path && *path) {
		gtk_file_chooser_set_current_folder((gpointer)dialog,path);
	}
	if (gtk_dialog_run((gpointer)dialog)==GTK_RESPONSE_ACCEPT){
		gtk_entry_set_text((gpointer)fentry,gtk_file_chooser_get_filename((gpointer)dialog));
	}
	gtk_widget_destroy(dialog);
}

static void open_book_target(GtkWidget *widget,void *dummy)
{
	if (is_nokia) {
		open_book_target_nokia();
		return;
	}
	GtkWidget *dialog=gtk_file_chooser_dialog_new(
		"Wybierz plik",
		GTK_WINDOW(confirm_dialog),GTK_FILE_CHOOSER_ACTION_SAVE,
		GTK_STOCK_CANCEL, GTK_RESPONSE_CANCEL,
		GTK_STOCK_SAVE, GTK_RESPONSE_ACCEPT,
		NULL);
	GtkFileFilter *filter;
	gtk_file_chooser_set_local_only((gpointer)dialog,TRUE);
	if (mp3_make_aac) {
		filter=make_filter("Pliki AAC","*.aac","*.AAC",NULL);
	}
	else {
		filter=make_filter("Pliki MP3","*.mp3","*.MP3",NULL);
	}
	gtk_file_chooser_add_filter((gpointer) dialog,filter);
	gtk_file_chooser_add_filter((gpointer) dialog,
		make_filter("Wszystkie pliki","*",NULL));
	gtk_file_chooser_set_filter((gpointer) dialog,filter);
	char const *path=gtk_entry_get_text((gpointer)fentry);
	char xbuf[PATH_MAX+1];
	if (path && *path) {
		strcpy(xbuf,path);
		path=xbuf;
	}

	if (!path || !*path) {
		char *cs=NULL;
		get_current_editor();
		if (current_editor->save_name[0]) cs=current_editor->save_name;
		else if (current_editor->load_name[0]) cs=current_editor->load_name;
		if (cs) {
			strcpy(xbuf,cs);
			path=xbuf;
		}
	}
	if (path && *path) {
		char *c=strrchr(path,'/'),*d;
		if (c) {
			*c=0;
			gtk_file_chooser_set_current_folder((gpointer)dialog,path);
			*c='/';
			d=strrchr(c+1,'.');
			if (!d) d=(char*)path+strlen(path);
			strcpy(d,mp3_make_aac?".aac":".mp3");
			gtk_file_chooser_set_current_name((gpointer)dialog,c+1);
		}
	}
	if (gtk_dialog_run((gpointer)dialog)==GTK_RESPONSE_ACCEPT){
		gtk_entry_set_text((gpointer)fentry,gtk_file_chooser_get_filename((gpointer)dialog));
	}
	gtk_widget_destroy(dialog);
}

static int nokia_confirm_book()
{
	GtkWidget *dialog=gtk_dialog_new_with_buttons(
		"Utwórz Nokia Audiobook",
		(gpointer)main_window,
		GTK_DIALOG_MODAL,
		GTK_STOCK_OK,GTK_RESPONSE_ACCEPT,
		GTK_STOCK_CANCEL,GTK_RESPONSE_REJECT,
		NULL);
	GtkWidget *box=gtk_dialog_get_content_area((gpointer)dialog);
	GtkWidget *vbox=gtk_vbox_new(0,2);
	gtk_box_pack_start(GTK_BOX(box),(gpointer)vbox,FALSE,FALSE,0);
	GtkWidget *stable=gtk_table_new(3,3,0);
	gtk_box_pack_start(GTK_BOX(vbox),stable,FALSE,FALSE,0);
	GtkWidget *label=gtk_label_new("Tytuł do spisu");
	GtkWidget *tentry=gtk_entry_new();
	gtk_table_attach_defaults((gpointer)stable,label,0,1,0,1);
	gtk_table_attach_defaults((gpointer)stable,tentry,1,3,0,1);
	connect_label(label,tentry);
	gtk_widget_set_size_request((gpointer)tentry, 320,-1);
	label=gtk_label_new("Tryb konwersji");
	gtk_table_attach_defaults((gpointer)stable,label,0,1,1,2);
	//GtkWidget *xentry=gtk_entry_new();
	//gtk_editable_set_editable((gpointer)xentry,0);
	//gtk_entry_set_text((gpointer)xentry,book_tryb());
	GtkWidget *xentry=gtk_label_new(book_tryb());
	gtk_label_set_selectable((gpointer)xentry,TRUE);
	connect_label(label,xentry);
	gtk_table_attach_defaults((gpointer)stable,xentry,1,3,1,2);
	label=gtk_label_new("Katalog wynikowy");
	gtk_table_attach_defaults((gpointer)stable,label,0,1,2,3);
	fentry=gtk_entry_new();
	gtk_editable_set_editable((gpointer)fentry,0);
	gtk_table_attach_defaults((gpointer)stable,fentry,1,2,2,3);
	connect_label(label,fentry);
	confirm_dialog=dialog;
	GtkWidget *chooser=gtk_button_new_from_stock(GTK_STOCK_OPEN);
	gtk_table_attach_defaults((gpointer)stable,chooser,2,3,2,3);
	connect_label(label,chooser);

	g_signal_connect(G_OBJECT(chooser),"clicked",
		G_CALLBACK(open_book_target),NULL);
	char *c;
	if (title) {
		c=g_convert(title,-1,"UTF-8","ISO-8859-2",NULL,NULL,NULL);
		if (!c) return 0;
		gtk_entry_set_text((gpointer)tentry,c);
		gtk_editable_set_position((gpointer)tentry,-1);
		g_free(c);
	}

	gtk_widget_show_all((gpointer)box);
	int n=0;
	for (;;) {
		if (gtk_dialog_run((gpointer)dialog) != GTK_RESPONSE_ACCEPT) {
			n=0;
			break;
		}
		c=(char *)gtk_entry_get_text((gpointer)tentry);
		if (!c || !*c) {
			Error("Błąd","Podaj tytuł do spisu");
			gtk_widget_grab_focus(tentry);
			continue;
		}
		char *d=(char *)gtk_entry_get_text((gpointer)fentry);
		if (!d || !*d) {
			Error("Błąd","Wybierz katalog docelowy");
			gtk_widget_grab_focus(fentry);
			continue;
		}
		index_title=g_strdup(c);
		strcpy(nokia_path,d);
		//printf("NP [%s]\n",nokia_path);
		n=1;
		break;
	}
	gtk_widget_destroy(dialog);
	multipart=0;
	return n;

}


double multipartial_value=5.0;
double multipartial_margin=0.0;
int multipartial_on=0;
static GtkWidget *id31_cb,*id32_cb,*id3table;
int id3_tag_mode;
static void showhide_id3(GtkWidget *widget,void *data)
{
	id3_tag_mode=0;
	if (gtk_toggle_button_get_active((gpointer) id31_cb)) id3_tag_mode |=1;
	if (gtk_toggle_button_get_active((gpointer) id32_cb)) id3_tag_mode |=2;
	if (id3_tag_mode) {
		gtk_widget_show((gpointer)id3table);
	}
	else {
		gtk_widget_hide((gpointer)id3table);
	}
}
static int ask_confirm_book()
{
	void ulc(char *d)
	{
	    char *c=d+strlen(d)-1;
	    if (c>d+1 && *c=='.') *c=0;
	}
	if (is_nokia) return nokia_confirm_book();
	GtkWidget *dialog=gtk_dialog_new_with_buttons(
		mp3_make_aac?"Utwórz AAC":"Utwórz MP3",
		(gpointer)main_window,
		GTK_DIALOG_MODAL,
		GTK_STOCK_OK,GTK_RESPONSE_ACCEPT,
		GTK_STOCK_CANCEL,GTK_RESPONSE_REJECT,
		NULL);
	GtkWidget *aut_entry=NULL,*boo_entry=NULL,*tit_cbox,*mp_cbox,*mp_spin,*mp_margspin,*titnum_cbox;
	GtkWidget *box=gtk_dialog_get_content_area((gpointer)dialog);
	GtkWidget *vbox=gtk_vbox_new(0,2);
    GtkWidget *ndx_on=NULL,*ndx_title=NULL;

	void widget_asensitive(GtkWidget *widget, void *data)
	{
		gtk_widget_set_sensitive((gpointer)mp_spin,gtk_toggle_button_get_active((gpointer)widget));
		gtk_widget_set_sensitive((gpointer)mp_margspin,gtk_toggle_button_get_active((gpointer)widget));
        if (ndx_on) gtk_widget_set_sensitive((gpointer)ndx_on,!gtk_toggle_button_get_active((gpointer)widget));
        if (ndx_title) gtk_widget_set_sensitive((gpointer)ndx_title,!gtk_toggle_button_get_active((gpointer)widget));
	}
	
	void showhide_titnum(GtkWidget *widget, void *data)
	{
	    gtk_widget_set_sensitive((void *) titnum_cbox,
		gtk_toggle_button_get_active((gpointer)tit_cbox));
	}




	gtk_box_pack_start(GTK_BOX(box),(gpointer)vbox,FALSE,FALSE,0);
	GtkWidget *stable=gtk_table_new(5,4,0);
	gtk_box_pack_start(GTK_BOX(vbox),stable,FALSE,FALSE,0);
	GtkWidget *label=gtk_label_new("Tryb konwersji");
	gtk_table_attach_defaults((gpointer)stable,label,0,1,0,1);
	//GtkWidget *xentry=gtk_entry_new();
	//gtk_editable_set_editable((gpointer)xentry,0);
	//gtk_entry_set_text((gpointer)xentry,book_tryb());
	GtkWidget *xentry=gtk_label_new(book_tryb());
	gtk_label_set_selectable((gpointer)xentry,TRUE);
	gtk_table_attach_defaults((gpointer)stable,xentry,1,4,0,1);
	label=gtk_label_new(chapter_no?"Szablon plików":"Plik wynikowy");
	gtk_table_attach_defaults((gpointer)stable,label,0,1,1,2);
	fentry=gtk_entry_new();
	gtk_editable_set_editable((gpointer)fentry,0);
	gtk_table_attach_defaults((gpointer)stable,fentry,1,3,1,2);
	confirm_dialog=dialog;
	GtkWidget *chooser=gtk_button_new_from_stock(GTK_STOCK_OPEN);
	gtk_table_attach_defaults((gpointer)stable,chooser,3,4,1,2);
	g_signal_connect(G_OBJECT(chooser),"clicked",
		G_CALLBACK(open_book_target),NULL);
	connect_label(label,fentry);
	connect_label(label,chooser);
	tit_cbox=NULL;
	titnum_cbox=NULL;
	label=gtk_label_new("Podział czasowy");
	gtk_table_attach_defaults((gpointer)stable,label,0,1,2,3);
	mp_cbox=gtk_check_button_new_with_label("Włącz");
	connect_label(label,mp_cbox);
	gtk_table_attach_defaults((gpointer)stable,mp_cbox,1,2,2,3);
	mp_spin=gtk_spin_button_new_with_range(3,30,0.1);
	connect_label(label,mp_spin);
	gtk_table_attach_defaults((gpointer)stable,mp_spin,2,3,2,3);
	GtkWidget *icbox=gtk_hbox_new(0,2);
	label=gtk_label_new("Zakładka (sek)");
	mp_margspin=gtk_spin_button_new_with_range(0,3,0.1);
	gtk_box_pack_start(GTK_BOX(icbox),label,FALSE,FALSE,0);
	gtk_box_pack_start(GTK_BOX(icbox),mp_margspin,FALSE,FALSE,0);
	connect_label(label,mp_margspin);
	gtk_table_attach_defaults((gpointer)stable,icbox,3,4,2,3);

	gtk_toggle_button_set_active((gpointer)mp_cbox,multipartial_on);
	gtk_widget_set_sensitive((gpointer)mp_spin,multipartial_on);
	gtk_spin_button_set_value((gpointer)mp_spin,multipartial_value);
	gtk_spin_button_set_value((gpointer)mp_margspin,multipartial_margin);
	g_signal_connect(G_OBJECT(mp_cbox),"toggled",G_CALLBACK(widget_asensitive),NULL);
	
	if (!mp3_make_aac) {
		label=gtk_label_new("Tagi ID3");
		gtk_table_attach_defaults((gpointer)stable,label,0,1,3,4);
		GtkWidget *hbox=gtk_hbox_new(0,2);
		gtk_table_attach_defaults((gpointer)stable,hbox,1,4,3,4);
		id31_cb=gtk_check_button_new_with_label("ID3v1");
		gtk_box_pack_start(GTK_BOX(hbox),id31_cb,FALSE,FALSE,0);
		id32_cb=gtk_check_button_new_with_label("ID3v2");
		gtk_box_pack_start(GTK_BOX(hbox),id32_cb,FALSE,FALSE,0);
		id3table=gtk_table_new(5,2,0);
		gtk_table_attach_defaults((gpointer)stable,id3table,0,4,4,5);
		label=gtk_label_new("Autor");
		gtk_table_attach_defaults((gpointer)id3table,label,0,1,0,1);
		aut_entry=gtk_entry_new();
		gtk_table_attach_defaults((gpointer)id3table,aut_entry,1,3,0,1);
		connect_label(label,aut_entry);
		label=gtk_label_new("Tytuł");
		gtk_table_attach_defaults((gpointer)id3table,label,0,1,1,2);
		boo_entry=gtk_entry_new();
		gtk_table_attach_defaults((gpointer)id3table,boo_entry,1,3,1,2);
		connect_label(label,boo_entry);

		if (chapter_no) {
			char *c=strchr(title,','),*d;
			if (c) {
				gsize dmy;
				*c=0;
				if (*title) {
					d=g_convert(title,-1,"UTF-8","ISO-8859-2",NULL,&dmy,NULL);
					if (d) {
						gtk_entry_set_text((gpointer)aut_entry,d);
						g_free(d);
					}
				}
				*c++=',';
				while (*c && isspace(*c)) c++;
				if (*c) {
					d=g_convert(c,-1,"UTF-8","ISO-8859-2",NULL,&dmy,NULL);
					ulc(d);
					if (d) {
						gtk_entry_set_text((gpointer)boo_entry,d);
						g_free(d);
					}
				}
			}
			label=gtk_label_new("Rozdział");
			gtk_table_attach_defaults((gpointer)id3table,label,0,1,2,3);
			tit_cbox=gtk_check_button_new_with_label("Użyj tytułów rozdziałów");
			gtk_table_attach_defaults((gpointer)id3table,tit_cbox,1,2,2,3);
			titnum_cbox=gtk_check_button_new_with_label("Z numeracją");
			gtk_table_attach_defaults((gpointer)id3table,titnum_cbox,2,3,2,3);
			g_signal_connect(G_OBJECT(tit_cbox),"toggled",G_CALLBACK(showhide_titnum),NULL);

		}
		g_signal_connect(G_OBJECT(id31_cb),"toggled",G_CALLBACK(showhide_id3),NULL);
		g_signal_connect(G_OBJECT(id32_cb),"toggled",G_CALLBACK(showhide_id3),NULL);

	label=gtk_label_new("mABPlayer.inx");
        gtk_table_attach_defaults((gpointer)stable,label,0,1,5,6);
        ndx_on=gtk_check_button_new_with_label("Włącz");
        connect_label(label,ndx_on);
        gtk_table_attach_defaults((gpointer)stable,ndx_on,1,2,5,6);
        ndx_title=gtk_entry_new();

        char *d;
	if (title) {
	    d=g_convert(title,-1,"UTF-8","ISO-8859-2",NULL,NULL,NULL);
	    ulc(d);
	    gtk_entry_set_text((gpointer)ndx_title,d);
	    g_free(d);
	}
        connect_label(label,ndx_title);
        gtk_table_attach_defaults((gpointer)stable,ndx_title,2,4,5,6);
	}
	gtk_widget_show_all((gpointer)box);
	if (!mp3_make_aac) showhide_id3(NULL,NULL);
	if (tit_cbox) showhide_titnum(NULL,NULL);
	int n=0;
	for (;;) {
		if (gtk_dialog_run((gpointer)dialog) != GTK_RESPONSE_ACCEPT) {
			n=0;
			break;
		}
		char *c=(char *)gtk_entry_get_text((gpointer)fentry);
		if (!c || !*c) {
			Error("Błąd","Wybierz plik");
			gtk_widget_grab_focus(chooser);
			continue;
		}
		strcpy(mp3_path,c);
		n=1;

		mp3_use_chapter=0;
		if (!mp3_make_aac) {
			mp3_artist=to_ascii7(gtk_entry_get_text((gpointer)aut_entry),1);
			mp3_album=to_ascii7(gtk_entry_get_text((gpointer)boo_entry),1);
			if (tit_cbox) {
			    if (gtk_toggle_button_get_active((gpointer)tit_cbox)) {
				mp3_use_chapter=1;
				if (gtk_toggle_button_get_active((gpointer)titnum_cbox)) {
				    mp3_use_chapter=2;
				}
			    }
			}
		}
		break;
	}
	if (gtk_toggle_button_get_active((gpointer)mp_cbox)) {
		multipart=60000*gtk_spin_button_get_value((gpointer)mp_spin);
	}
	else {
		multipart=0;
	}
	if (n) {
		multipartial_on=gtk_toggle_button_get_active((gpointer)mp_cbox);
		multipartial_value=gtk_spin_button_get_value((gpointer)mp_spin);
		multipartial_margin=gtk_spin_button_get_value((gpointer)mp_margspin);
	}
    else {
        multipartial_on=0;
    }
    if (ndx_on && !multipartial_on && gtk_toggle_button_get_active((gpointer)ndx_on)) {
        index_title=g_strdup(gtk_entry_get_text((gpointer)ndx_title));
    }
	gtk_widget_destroy(dialog);
	return n;
}

static void init_all_book(void)
{
	init_paragraph();
	this_chapter=-1;
	this_pos=book;
}

static void init_part_book(int n)
{
	init_paragraph();
	this_chapter=n;
	this_pos=chapters[n];
}

void reset_mbrola(void)
{
	int n,len;
	for (;;) {
		n=read_MBR(mbr,outbuf,4096,&len);
		if (n<0) return;
		if (n>0) break;
	}
	flush_MBR(mbr);
	for (;;) {
		n=read_MBR(mbr,outbuf,4096,&len);
		if (n) return;
	}
}

static char *get_paragraph(void)
{
	char *c,*d;
	if (!*this_pos) {
		return NULL;
	}
	d=c=this_pos;
    for (;;) {
        c=strchr(c,'\n');
        if (!c) break;
        if (c > this_pos && *(c-1) == '\'') {
            *(c-1)=' ';
            *c=' ';
        }
        else break;
    }
	if (!c) c=this_pos+strlen(this_pos);
	else *c++=0;
	this_pos=c;
	return d;
}
static int lame_bitrate;
static int this_multipart,this_track;
static int current_len;
static void *stereo_filter;

int init_stream(int chapter)
{
	char fname[256];
	char *tytul=NULL;
	int rc,nr;
	char *path;
	this_track++;
#ifdef HAVE_IVONA
    int freq=use_ivona?ivona_getfreq():16000;
    if (!freq) {
        Error("Błąd","Ivona nie podaje częstotliwości");
        return 0;
    }
#else
    int freq=16000;
#endif
	if (is_nokia) {
		char *c,*d;int le,lv;
		multipart=0;
		path=nokia_path;
		strcpy(fname,path);
		c=strrchr(fname,'/');
		if (!c) c=fname;
		else c++;
		le=strlen(c);
		strcat(fname,"/");
		lv=strlen(fname);
		d=fname+lv;
		memcpy(fname+lv,c,le);
		lv+=le;
		fname[lv]=0;
        // zmiana numeracji audiobook!
		if (chapter) sprintf(fname+strlen(fname),"%03d",chapter);
		strcat(fname,".awb");
		nr=0;
		if (chapter) nr=chapter-1;
		chapter_files[nr]=g_strdup(d);
		nokia_correct(chapter_files[nr]);
		audioparam_init_f(1,freq);
		return start_amrwb(fname,3,0);
	}
	path=mp3_path;
	strcpy(fname,path);
	if (chapter) {
		int n,t;
		char *c,*d;
		n=2;
		if (chapter_no>=100) n=3;
		c=strrchr(path,'/');
		if (!c) c=path;
		d=strrchr(c,'.');
		if (!d) {
			strcpy(fname,path);
			sprintf(fname+strlen(fname),"_%0*d",n,chapter);
			if (multipart) sprintf(fname+strlen(fname),"-%03d",this_multipart);
			strcat(fname,mp3_make_aac?".aac":".mp3");
		}
		else {
			t=d-path;
			memcpy(fname,path,t);
			sprintf(fname+t,"_%0*d",n,chapter);
			if (multipart) sprintf(fname+strlen(fname),"-%03d",this_multipart);
			strcat(fname,d);
		}
		if (!multipart) {
            nr=0;
            if (chapter) nr=chapter-1;
            d=strrchr(fname,'/');
            if (d) d++;else d=fname;
            chapter_files[nr]=g_strdup(d);
            nokia_correct(chapter_files[nr]);
        }
	}
	else if (multipart) {
		char *c,*d;int t;
		c=strrchr(path,'/');
		if (!c) c=path;
		d=strrchr(c,'.');
		if (!d) {
			strcpy(fname,path);
			sprintf(fname+strlen(fname),"-%03d",this_multipart);
			strcat(fname,mp3_make_aac?".aac":".mp3");
		}
		else {
			t=d-path;
			memcpy(fname,path,t);
			sprintf(fname+t,"-%03d",this_multipart);
			strcat(fname,d);
		}

	}
	current_len=0;
	if (!mp3_make_aac) {
		if (mp3_use_chapter && chapter && chapter_titles && chapter_titles[chapter-1]) {
			tytul=to_ascii7(chapter_titles[chapter-1],0);
			if (multipart || mp3_use_chapter == 2) {
				tytul=g_realloc(tytul,strlen(tytul)+20);
				if (mp3_use_chapter == 2) {
				    memmove(tytul+4,tytul,strlen(tytul));
				    sprintf(tytul,"%03d",chapter);
				    tytul[3]='_';
				}
				if (multipart) {
				    sprintf(tytul+strlen(tytul),".%03d",this_multipart);
				}
			}
		}
		else if (mp3_album) {
			tytul=g_malloc(strlen(mp3_album)+20);
			strcpy(tytul,mp3_album);
			if (chapter) {
				sprintf(tytul+strlen(tytul),"_%03d",chapter);
			}
			if (multipart) sprintf(tytul+strlen(tytul),".%03d",this_multipart);
		}
	}
	if (stereo_mode) {
		stereo_upsample = (freq>16000)?0:(lame_bitrate >= 2)?1:0;
		stereo_filter=reverb_init(stereo_rev,stereo_hfd,stereo_room,stereo_depth,stereo_upsample);
	}
	audioparam_init_f(1,freq);
#ifdef USE_FAAC
	if (mp3_make_aac) return init_aac_encoder(fname);
#endif
	rc=init_lame_encoder(fname,lame_bitrate,mp3_artist,mp3_album,tytul,this_track,freq);
	if (tytul) g_free(tytul);
	return rc;
}

int encode_audio(short *inp,int count)
{
	static short stereo[32768];
	if (contrast) do_contrast(inp,count);
	audioparam(inp,count);
#ifdef USE_RESAMPLER
	static short resampled[16384];
	if (use_resampler && resample_factor < 0.99 || resample_factor > 1.01) {
		memcpy(resampled,inp,count * sizeof(short));
		inp=resampled;
		count=do_resample(inp,count);
	}
#endif
	if (is_nokia) return encode_amrwb(inp,count);
	if (stereo_mode) {
		reverb_flow(stereo_filter,inp,stereo,count);
		inp=stereo;
		count*=2;
		if (stereo_upsample) count *=2;
	}
#ifdef USE_FAAC
	if (mp3_make_aac) return aac_encode(inp,count);
#endif
	return lame_encode(inp,count);
	return 1;
}

static int finish_stream()
{
#ifdef USE_RESAMPLER
	close_resampler();
#endif
	if (is_nokia) return finish_amrwb();
	if (stereo_mode) reverb_free(stereo_filter);
#ifdef USE_FAAC
	if (mp3_make_aac) return finish_aac();
#endif
	return lame_finish();
	return 1;
}


int record_paragraph(void)
{
	if (debug_level) fprintf(stderr,"START: RecordParagraph\n");
    char *cs=get_paragraph();
	struct phone_buffer *phb;
	int pos,nbr;
	char *c,*d;
	char buf[256];
	int n,nv;
	int mpflush=multipart?((multipartial_margin * 1000)/current_mbrola_speed):400;
	if (debug_level) fprintf(stderr,"PARAGRAPH=%s\n",cs);
#ifdef HAVE_IVONA
    if (use_ivona) return ivona_record_paragraph(cs);
#endif
	//printf("MF=%d\n",mpflush);
	int compute_para_len()
	{
		int plen=0;
		char *c,*d;
		int apos=0;
		while (apos < phb->str_len) {
			c=phb->str+apos;
			d=strchr(c,'\n');
			if (!d) break;
			else apos=(d+1)-phb->str;
			while (*c && isspace(*c) && *c!='\n') c++;
			if (*c==';' || *c=='\n') continue;
			while (*c != '\n' && !isdigit(*c))  c++;
			if (!*c || *c=='\n') continue;
			plen+=strtol(c,&c,10);
		}
		plen*=current_mbrola_speed;
		return plen;
	}

	int get_a_line()
	{
		int l;
		if (pos>=phb->str_len) return 0;
		c=phb->str+pos;
		d=strchr(c,'\n');
		if (!d) {
			pos=phb->str_len;
			return 0;
		}
		d++;
		l=d-c;
		strncpy(buf,c,l);
		buf[l]=0;
		pos+=l;
		return 1;
	}

	int flushy(int secs)
	{
		nv=2;
		char s[32];
		sprintf(s,"_ %d\n",secs);
		while (nv) {
			if (nv == 2) {
				n=write_MBR(mbr,s);
				if (n<0) return -3;
				if (!n) nv--;
			}
			if (nv == 1) {
				n=flush_MBR(mbr);
				if (n<0) return -3;
				if (!n) nv--;
			}
			for (;;) {
				n=read_MBR(mbr,outbuf,4096,&nbr);
				if (n<0) return -3;
				if (n>0) break;
				yield();
				if (!allow_run) return 0;
				if (!encode_audio(outbuf,nbr)) return -2;
			}
		}
		return 0;

	}

	if (!cs) {
		return flushy((mpflush>400)?mpflush:400);
	}
	phb=translate_paragraph(cs);
	if (!phb) return 1;
	if (multipart) {
		int p=compute_para_len();
		int n;
		//printf("%d %d %d\n",current_len,p,multipart);
		if (current_len && current_len+p > multipart) {
			//printf("New file\n");
			n=flushy((mpflush>4)?mpflush:4);
			if (n) return n;
			finish_stream();
			this_multipart++;
			if (chapter_no) n=this_chapter+1;
			else n=0;
			if (!init_stream(n)) return -3;
			current_len=0;
		}
		current_len+=p;
	}
	pos=0;
	if (!get_a_line()) return 1;
	while (pos < phb->str_len) {
		//printf("Writing mbrola %d\n",nc);
		for (;;) {
			int nc=write_MBR(mbr,buf);
			if (nc<0) return -3;
			if (nc) break;
			if (!get_a_line()) {
				break;
			}
		}
		//printf("Mbrola wrote %d %d\n",pos,phb->str_len);
		for (;;) {
			n=read_MBR(mbr,outbuf,4096,&nbr);
			if (n<0) return -3;
			if (n>0) break;
			yield();
			if (!allow_run) return 0;
			if (!encode_audio(outbuf,nbr)) return -2;
		}
	}
	return 1;
}

void nokia_make_index(int is_mp3)
{
	int i;
	iconv_t ic;
	FILE *f;
	char b1[1024],b2[1024],bx[32];

	void uputs(char *c)
	{
		char *d;
		size_t l1,l2;
		d=b2;
		l1=strlen(c);
		l2=1024;
		iconv(ic,&c,&l1,&d,&l2);
		fwrite(b2,1,1024-l2,f);
	}

	void mcpy(char *dst,char *src)
	{
		for (;*src;src++) if (*src!='\n' && *src!=':' && *src!=';') *dst++=*src;
		*dst=0;
	}

	ic=iconv_open("UTF-16","ISO-8859-2");

	char fname[PATH_MAX+1],*c;int le,lv;
    if (!is_mp3) {
        strcpy(fname,nokia_path);
        c=strrchr(fname,'/');
        if (!c) c=fname;
        else c++;
        le=strlen(c);
        strcat(fname,"/");
        lv=strlen(fname);
        memcpy(fname+lv,c,le);
        lv+=le;
        strcpy(fname+lv,".inx");
    }
    else {
        if (!index_title) return;
        strcpy(fname,mp3_path);
        c=strrchr(fname,'/');
        if (!c) c=fname;
        else c++;
        c=strrchr(fname,'.');
        if (!c) c+=strlen(c);
        strcpy(c,".inx");
    }
	f=fopen(fname,"wb");
	uputs("#BOOK\n");
	//sprintf(b1,"%s;\n",index_title);
	mcpy(b1,index_title);
	strcat(b1,";\n");
	glong len;
	gunichar2 *title=g_utf8_to_utf16(b1,-1,NULL,&len,NULL);
	fwrite(title,2,len,f);
	g_free(title);
	//sprintf(b1,"%s;\n",index_title);uputs(b1);
	uputs("#TRACKS\n");
    fflush(f);
	for (i=0;i<index_length;i++) {
        int uss=chapter_seconds[i]*1000;
		sprintf(b1,"%s:%d.%03d;\n",chapter_files[i],uss/1000,uss%1000);

		uputs(b1);
        fflush(f);
	}
	uputs("#CHAPTERS\n");
	for (i=0;i<index_length;i++) {
		c=chapter_titles[i];
		if (!c) {
			sprintf(bx,"Rozdzia\xb3 %d",i+1);
			c=bx;
		}
		else if (strlen(c)>31) {
			memcpy(bx,c,28);
			strcpy(bx+28,"...");
			c=bx;
		}
		sprintf(b1,"%s:0s:%d:",chapter_files[i],i+1);
		mcpy(b1+strlen(b1),c);
		strcat(b1,";\n");
		//sprintf(b1,"%s:0s:%d:%s;\n",chapter_files[i],i+1,c);
		uputs(b1);
	}
	uputs("#VERSION\n0.7\n");
	iconv_close(ic);
	fclose(f);
}

void book_free_html(char **html)
{
    int i;
    for (i=0;html[i];i++) g_free(html[i]);
    g_free(html);
}

char **book_create_html(char *title,char *author,int endash,int formatting,char *fname)
{
	int split=0,aumode=0,marker=0;
	char *c,*book,*str,tbuf[128];
    char **html;
    int nparts,tpart,n;
    if (get_current_editor()) return NULL;
    book=get_actual_body();
    if (!gtk_combo_box_get_active((gpointer)combo_split)) {
		check_split_possible(book,(char *)gtk_entry_get_text((gpointer)char_split));
	}
	if (gtk_combo_box_get_active((gpointer)combo_split)) {
		split=1;
		n=gtk_combo_box_get_active((gpointer)combo_autonum);
		if (n>0) aumode |= AUMODE_ON;
		if (n==2) aumode |= AUMODE_KEEP_LINE;
		n=gtk_combo_box_get_active((gpointer)combo_prolog);
		if (n) aumode |= AUMODE_PROLOG;
		if (n==2) aumode |= AUMODE_PROLOG_KEEP;
		n=gtk_combo_box_get_active((gpointer)combo_epilog);
		if (n>0 && n<3) aumode |= AUMODE_EPILOG;
		if (n==2) aumode |= AUMODE_EPILOG_KEEP;
		if (n==3) aumode |= AUMODE_LASTCHAPTER;
		c=(char *)gtk_entry_get_text((gpointer)char_split);
		if (!*c || ((*c) & 0x80)) {
			Error("Błąd","Nielegalny znak podziału");
			g_free(book);
			return NULL;
		}
		marker=*c;
	}
    if (!split) {
        html=g_malloc(2*sizeof(*html));
        html[0]=make_html(NULL,book,NULL,endash,formatting,-1,-1,NULL);
        html[1]=NULL;
        g_free(book);
        if (title) *title=0;
        if (author) *author=0;
        return html;
    }
    html=NULL;
    str=strpbrk(book,"\r\n");
	if (!str) goto rturn;
    *str++=0;
    if (title || author) {
        char *coma=strchr(book,',');
        if (coma) {
            *coma++=0;
            while (coma && isspace(*coma)) coma++;
            if (title) strncpy(title,coma,255);
            if (author) strncpy(author,book,255);
        }
        else {
            if (author) *author=0;
            if (title) strncpy(title,book,255);
        }
    }
	while (*str && my_space(*str)) str++;
	if (!*str) goto rturn;
	if (*str!=marker) {
		str=strpbrk(str,"\r\n");
		if (!str) goto rturn;
		while (*str && my_space(*str)) str++;
		if (*str != marker) goto rturn;
	}
    nparts=10;
    html=g_malloc(nparts*sizeof(*html));
    tpart=0;

    for (;;) {
        *str++=0;
        if (tpart >= nparts-1) {
            nparts=2*nparts;
            html=g_realloc(html,nparts*sizeof(*html));
        }
        html[tpart++]=str;
        for (;;) {
			str=strpbrk(str,"\r\n");
			if (!str) {
                str=NULL;
                break;
            }
			while (*str && my_space(*str)) str++;
			if (*str==marker) break;
		}
        if (!str) break;
    }
    html[tpart]=NULL;
    for (n=0;n<tpart;n++) {
        char *title,*body,*fl;
        int nl;
        int rem_title;
        if (debug_level) fprintf(stderr,"Creating html %d/%d\n",n+1,tpart);
        if (!aumode) {
            html[n]=make_html(NULL,html[n],NULL,endash,formatting,
                fname?(n-1):-1,(fname && n<tpart-1)?(n+1):-1,fname);
            continue;
        }
        rem_title=0;
        if (n==0) {
            if (!(aumode & AUMODE_PROLOG)) {
                rem_title=aumode & AUMODE_KEEP_LINE;
            }
            else {
                rem_title=aumode & AUMODE_PROLOG_KEEP;
            }
        } else if (n == tpart-1) {
            if (!(aumode & AUMODE_EPILOG)) {
                rem_title=aumode & AUMODE_KEEP_LINE;
            }
            else {
                rem_title=aumode & AUMODE_EPILOG_KEEP;
            }
        } else {
            rem_title=aumode & AUMODE_KEEP_LINE;
        }
        body=html[n];
        title=NULL;
        if ((n == 0) && (aumode & AUMODE_PROLOG)) {
            strcpy(tbuf,"Prolog");
        }
        else if ((n == tpart-1) && (aumode & AUMODE_EPILOG)) {
            strcpy(tbuf,"Epilog");
        }
        else {
            sprintf(tbuf,"Rozdział %d",(aumode & AUMODE_PROLOG)?n:(n+1));
            if ((n == tpart) && (aumode & AUMODE_LASTCHAPTER)) strcat(tbuf,"i ostatni");
        }
        if (rem_title) {
            fl=body;
            body=strpbrk(body,"\r\n");
            if (!body) {
                body=fl;
                nl=0;
            }
            else {
                nl=body-fl;
                while (*body && my_space(*body)) body++;
                title=g_malloc(nl+256);
                strcpy(title,tbuf);
                strcat(title,", ");
                c=title+strlen(title);
                for (;nl>0;nl--) *c++=*fl++;
                *c=0;
            }
        }
        if (title) {
            html[n]=make_html(title,body,NULL,endash,formatting,
                fname?(n-1):-1,(fname && n<tpart-1)?(n+1):-1,fname);
            g_free(title);
        }
        else {
            html[n]=make_html(tbuf,body,NULL,endash,formatting,
                fname?(n-1):-1,(fname && n<tpart-1)?(n+1):-1,fname);
        }
    }
rturn:
    g_free(book);
    return html;
}


void book_create_internal(GtkWidget *widget,void *dummy)
{
	is_nokia=dummy?1:0;
#ifdef HAVE_IVONA
    check_ivona_enabled();
#endif
    currently_making_book=1;
	int split=0,aumode=0,marker=0;
	int n;
	char *c;
	if (get_current_editor()) return;
	if (gtk_combo_box_get_active((gpointer)combo_split)) {
		split=1;
		n=gtk_combo_box_get_active((gpointer)combo_autonum);
		if (n>0) aumode |= AUMODE_ON;
		if (n==2) aumode |= AUMODE_KEEP_LINE;
		n=gtk_combo_box_get_active((gpointer)combo_prolog);
		if (n) aumode |= AUMODE_PROLOG;
		if (n==2) aumode |= AUMODE_PROLOG_KEEP;
		n=gtk_combo_box_get_active((gpointer)combo_epilog);
		if (n>0 && n<3) aumode |= AUMODE_EPILOG;
		if (n==2) aumode |= AUMODE_EPILOG_KEEP;
		if (n==3) aumode |= AUMODE_LASTCHAPTER;
		c=(char *)gtk_entry_get_text((gpointer)char_split);
		if (!*c || ((*c) & 0x80)) {
			Error("Błąd","Nielegalny znak podziału");
			return;
		}
		marker=*c;
	}
	c=get_current_iso2();
	if (!c) return;
	if (init_book(c,split,aumode,marker)<0) return;
	if (!init_milena_libs(0)) {
		free_book();
		return;
	}
	if (!milena_add_local_dic()) {
		free_book();
		close_milena_libs();
		return;
	}
    if (use_ivona) {
#ifdef HAVE_IVONA
        if (ivolektor_init()<0)
#endif
        {
            close_milena_libs();
            free_book();
            return;
        }

    }
    else {
        mbr=init_MBR(mbrola_voice,mbrola_real_freq);
        if (!mbr) {
            close_milena_libs();
            free_book();
            Error("Mbrola","Brak");
            return;
        }
    }
	lame_bitrate=gtk_combo_box_get_active((gpointer)combo_mp3);
#ifndef USE_FAAC
	if (lame_bitrate > 2) lame_bitrate=2;
#endif
	mp3_make_aac=(lame_bitrate == 3);
    if (mp3_make_aac && use_ivona) {
        Error("Niezaimplementowane","Nie zaimplementowano kodeka AAC dla Ivony");
        close_milena_libs();
        free_book();
        return;
    }

	if (!ask_confirm_book()) {
		free_book();
		close_milena_libs();
		return;
	}
    if (multipart && use_ivona) {
        Error("Niezaimplementowane","Brak tyrybu multipart dla Ivony");
		free_book();
		close_milena_libs();
		return;
	}
	if (is_nokia) stereo_mode=0;
	else stereo_mode=gtk_toggle_button_get_active((gpointer)cb_stereo);
	int was_error=0;
	if (!use_ivona) init_mbrola_tp();
	this_track=0;
	if (chapter_no) {
		int npart;
		StartProgressMeter(chapter_no);
		allow_run=1;
		for (npart=0;npart<chapter_no && allow_run && !was_error;npart++) {
            init_part_book(npart);
			this_multipart=0;
			if (!init_stream(npart+1)) {
				was_error=1;
				break;
			}
			if (was_error) break;
#ifdef HAVE_IVONA
            if (use_ivona) {
                SetProgress(npart+1,compute_percent());
                n=ivona_record_part(npart+1);
                if (!n) was_error=1;
            }
            else
#endif
			while (allow_run) {
				yield();
				if (!allow_run) break;
				SetProgress(npart+1,compute_percent());
				int n=record_paragraph();
				if (n>0 && allow_run) continue;
				if (n==-3) {
					Error("Błąd krytyczny","Mbrola sobie zdechła");
					exit(1);
				}
				if (n<0) {
					Error("Błąd","Ogólnie cos się stało");
					was_error=1;
				}
				break;
			}
			finish_stream();
			if (is_nokia) chapter_seconds[npart]=amr_get_seconds();
			else chapter_seconds[npart]=lame_get_seconds();
		}
	}
	else {
		this_multipart=0;
		if (!init_stream(0)) {
			free_book();
			close_milena_libs();
			//reset_mbrola();
			return;
		}
		init_all_book();
		allow_run=1;
		StartProgressMeter(0);
#ifdef HAVE_IVONA
        if (use_ivona) {
            SetProgress(1,compute_percent());
            n=ivona_record_part(1);
            if (!n) was_error=1;
        }
        else
#endif
		{
            while (allow_run) {
                yield();
                if (!allow_run) break;
                SetProgress(1,compute_percent());
                int n=record_paragraph();
                if (n>0 && allow_run) continue;
                if (n==-3) {
                    Error("Błąd krytyczny","Mbrola sobie zdechła");
                    exit(1);
                }
                if (n<0) {
                    Error("Błąd","Ogólnie cos się stało");
                    was_error=1;
                }
                break;
            }
        }
		finish_stream();
		if (is_nokia) chapter_seconds[0]=amr_get_seconds();
	}
	StopProgressMeter();
	if (!was_error && allow_run) {
		char abuf[256];
		if (is_nokia) nokia_make_index(0);
        else nokia_make_index(1);
		if (this_track > 1) sprintf(abuf,"Przetwarzanie zakończone\nIlość plików audio: %d",this_track);
		else strcpy(abuf,"Przetwarzanie zakończone");
		Info("Informacja",abuf);
	}
	free_book();
	close_milena_libs();
}

void book_create(GtkWidget *widget,void *dummy)
{
    currently_making_book=1;
    book_create_internal(widget,dummy);
    currently_making_book=0;
}

