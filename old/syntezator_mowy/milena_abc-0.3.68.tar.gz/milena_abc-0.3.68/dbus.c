#error Nie ma na razie... nie uzywaj "with-dbus" w make!



