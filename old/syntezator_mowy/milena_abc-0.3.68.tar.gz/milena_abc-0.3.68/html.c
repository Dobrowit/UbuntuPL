/*
 * html.c - Milena Audiobook Creator
 * Copyright (C) Bohdan R. Rau 2009-2011 <ethanak@polip.com>
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write see:
 *               <http://www.gnu.org/licenses/>.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <iconv.h>
#include <glib.h>
#include "html.h"

extern gint pdf_keep_boldit;

static struct enti {
	char *ent;
	int val;
	int len;
} enti[]={
{"&lt;",'<',4},	
{"&gt;",'>',4},	
{"&amp;",'&',5},	
{"&quot;",'"',6},	
{"&nbsp;",0xa0,6},	
{"&excl;",33,6},
{"&num;",35,5},
{"&dollar;",36,8},
{"&percnt;",37,8},
{"&lpar;",40,6},
{"&rpar;",41,6},
{"&ast;",42,5},
{"&plus;",43,6},
{"&comma;",44,7},
{"&hyphen;",45,8},
{"&period;",46,8},
{"&sol;",47,5},
{"&colon;",58,7},
{"&semi;",59,6},
{"&equals;",61,8},
{"&quest;",63,7},
{"&commat;",64,8},
{"&lsqb;",91,6},
{"&bsol;",92,6},
{"&sbsol;",92,7},
{"&rsqb;",93,6},
{"&lowbar;",95,8},
{"&grave;",96,7},
{"&lcub;",123,6},
{"&verbar;",124,8},
{"&rcub;",125,6},
{"&nbsp;",160,6},
{"&iexcl;",161,7},
{"&cent;",162,6},
{"&pound;",163,7},
{"&curren;",164,8},
{"&yen;",165,5},
{"&brvbar;",166,8},
{"&brkbar;",166,8},
{"&sect;",167,6},
{"&uml;",168,5},
{"&die;",168,5},
{"&Dot;",168,5},
{"&copy;",169,6},
{"&ordf;",170,6},
{"&laquo;",171,7},
{"&not;",172,5},
{"&shy;",173,5},
{"&reg;",174,5},
{"&hibar;",175,7},
{"&macr;",175,6},
{"&deg;",176,5},
{"&plusmn;",177,8},
{"&sup2;",178,6},
{"&sup3;",179,6},
{"&acute;",180,7},
{"&micro;",181,7},
{"&para;",182,6},
{"&middot;",183,8},
{"&cedil;",184,7},
{"&sup1;",185,6},
{"&ordm;",186,6},
{"&raquo;",187,7},
{"&frac14;",188,8},
{"&frac12;",189,8},
{"&half;",189,6},
{"&frac34;",190,8},
{"&iquest;",191,8},
{"&Agrave;",192,8},
{"&Aacute;",193,8},
{"&Acirc;",194,7},
{"&Atilde;",195,8},
{"&Auml;",196,6},
{"&Aring;",197,7},
{"&AElig;",198,7},
{"&Ccedil;",199,8},
{"&Egrave;",200,8},
{"&Eacute;",201,8},
{"&Ecirc;",202,7},
{"&Euml;",203,6},
{"&Igrave;",204,8},
{"&Iacute;",205,8},
{"&Icirc;",206,7},
{"&Iuml;",207,6},
{"&ETH;",208,5},
{"&Ntilde;",209,8},
{"&Ograve;",210,8},
{"&Oacute;",211,8},
{"&Ocirc;",212,7},
{"&Otilde;",213,8},
{"&Ouml;",214,6},
{"&times;",215,7},
{"&Oslash;",216,8},
{"&Ugrave;",217,8},
{"&Uacute;",218,8},
{"&Ucirc;",219,7},
{"&Uuml;",220,6},
{"&Yacute;",221,8},
{"&THORN;",222,7},
{"&szlig;",223,7},
{"&agrave;",224,8},
{"&aacute;",225,8},
{"&acirc;",226,7},
{"&atilde;",227,8},
{"&auml;",228,6},
{"&aring;",229,7},
{"&aelig;",230,7},
{"&ccedil;",231,8},
{"&egrave;",232,8},
{"&eacute;",233,8},
{"&ecirc;",234,7},
{"&euml;",235,6},
{"&igrave;",236,8},
{"&iacute;",237,8},
{"&icirc;",238,7},
{"&iuml;",239,6},
{"&eth;",240,5},
{"&ntilde;",241,8},
{"&ograve;",242,8},
{"&oacute;",243,8},
{"&ocirc;",244,7},
{"&otilde;",245,8},
{"&ouml;",246,6},
{"&divide;",247,8},
{"&oslash;",248,8},
{"&ugrave;",249,8},
{"&uacute;",250,8},
{"&ucirc;",251,7},
{"&uuml;",252,6},
{"&yacute;",253,8},
{"&thorn;",254,7},
{"&yuml;",255,6},
{"&Amacr;",256,7},
{"&amacr;",257,7},
{"&Abreve;",258,8},
{"&abreve;",259,8},
{"&Aogon;",260,7},
{"&aogon;",261,7},
{"&Cacute;",262,8},
{"&cacute;",263,8},
{"&Ccirc;",264,7},
{"&ccirc;",265,7},
{"&Cdot;",266,6},
{"&cdot;",267,6},
{"&Ccaron;",268,8},
{"&ccaron;",269,8},
{"&Dcaron;",270,8},
{"&dcaron;",271,8},
{"&Dstrok;",272,8},
{"&dstrok;",273,8},
{"&Emacr;",274,7},
{"&emacr;",275,7},
{"&Edot;",278,6},
{"&edot;",279,6},
{"&Eogon;",280,7},
{"&eogon;",281,7},
{"&Ecaron;",282,8},
{"&ecaron;",283,8},
{"&Gcirc;",284,7},
{"&gcirc;",285,7},
{"&Gbreve;",286,8},
{"&gbreve;",287,8},
{"&Gdot;",288,6},
{"&gdot;",289,6},
{"&Gcedil;",290,8},
{"&gcedil;",291,8},
{"&Hcirc;",292,7},
{"&hcirc;",293,7},
{"&Hstrok;",294,8},
{"&hstrok;",295,8},
{"&Itilde;",296,8},
{"&itilde;",297,8},
{"&Imacr;",298,7},
{"&imacr;",299,7},
{"&Iogon;",302,7},
{"&iogon;",303,7},
{"&Idot;",304,6},
{"&inodot;",305,8},
{"&IJlig;",306,7},
{"&ijlig;",307,7},
{"&Jcirc;",308,7},
{"&jcirc;",309,7},
{"&Kcedil;",310,8},
{"&kcedil;",311,8},
{"&kgreen;",312,8},
{"&Lacute;",313,8},
{"&lacute;",314,8},
{"&Lcedil;",315,8},
{"&lcedil;",316,8},
{"&Lcaron;",317,8},
{"&lcaron;",318,8},
{"&Lmidot;",319,8},
{"&lmidot;",320,8},
{"&Lstrok;",321,8},
{"&lstrok;",322,8},
{"&Nacute;",323,8},
{"&nacute;",324,8},
{"&Ncedil;",325,8},
{"&ncedil;",326,8},
{"&Ncaron;",327,8},
{"&ncaron;",328,8},
{"&napos;",329,7},
{"&ENG;",330,5},
{"&eng;",331,5},
{"&Omacr;",332,7},
{"&omacr;",333,7},
{"&Odblac;",336,8},
{"&odblac;",337,8},
{"&OElig;",338,7},
{"&oelig;",339,7},
{"&Racute;",340,8},
{"&racute;",341,8},
{"&Rcedil;",342,8},
{"&rcedil;",343,8},
{"&Rcaron;",344,8},
{"&rcaron;",345,8},
{"&Sacute;",346,8},
{"&sacute;",347,8},
{"&Scirc;",348,7},
{"&scirc;",349,7},
{"&Scedil;",350,8},
{"&scedil;",351,8},
{"&Scaron;",352,8},
{"&scaron;",353,8},
{"&Tcedil;",354,8},
{"&tcedil;",355,8},
{"&Tcaron;",356,8},
{"&tcaron;",357,8},
{"&Tstrok;",358,8},
{"&tstrok;",359,8},
{"&Utilde;",360,8},
{"&utilde;",361,8},
{"&Umacr;",362,7},
{"&umacr;",363,7},
{"&Ubreve;",364,8},
{"&ubreve;",365,8},
{"&Uring;",366,7},
{"&uring;",367,7},
{"&Udblac;",368,8},
{"&udblac;",369,8},
{"&Uogon;",370,7},
{"&uogon;",371,7},
{"&Wcirc;",372,7},
{"&wcirc;",373,7},
{"&Ycirc;",374,7},
{"&ycirc;",375,7},
{"&Yuml;",376,6},
{"&Zacute;",377,8},
{"&zacute;",378,8},
{"&Zdot;",379,6},
{"&zdot;",380,6},
{"&Zcaron;",381,8},
{"&zcaron;",382,8},
{"&fnof;",402,6},
{"&gacute;",501,8},
{"&apos;",700,6},
{"&circ;",710,6},
{"&caron;",711,7},
{"&breve;",728,7},
{"&dot;",729,5},
{"&ring;",730,6},
{"&ogon;",731,6},
{"&tilde;",732,7},
{"&dblac;",733,7},
{"&Aacgr;",902,7},
{"&Eacgr;",904,7},
{"&EEacgr;",905,8},
{"&Iacgr;",906,7},
{"&Oacgr;",908,7},
{"&Uacgr;",910,7},
{"&OHacgr;",911,8},
{"&idiagr;",912,8},
{"&Alpha;",913,7},
{"&Agr;",913,5},
{"&Beta;",914,6},
{"&Bgr;",914,5},
{"&Gamma;",915,7},
{"&Ggr;",915,5},
{"&b.Gamma;",915,9},
{"&Delta;",916,7},
{"&Dgr;",916,5},
{"&b.Delta;",916,9},
{"&Epsilon;",917,9},
{"&Egr;",917,5},
{"&Zeta;",918,6},
{"&Zgr;",918,5},
{"&Eta;",919,5},
{"&EEgr;",919,6},
{"&Theta;",920,7},
{"&THgr;",920,6},
{"&b.Theta;",920,9},
{"&Iota;",921,6},
{"&Igr;",921,5},
{"&Kappa;",922,7},
{"&Kgr;",922,5},
{"&Lambda;",923,8},
{"&Lgr;",923,5},
{"&b.Lambda;",923,10},
{"&Mu;",924,4},
{"&Mgr;",924,5},
{"&Nu;",925,4},
{"&Ngr;",925,5},
{"&Xi;",926,4},
{"&Xgr;",926,5},
{"&b.Xi;",926,6},
{"&Omicron;",927,9},
{"&Ogr;",927,5},
{"&Pi;",928,4},
{"&Pgr;",928,5},
{"&b.Pi;",928,6},
{"&Rho;",929,5},
{"&Rgr;",929,5},
{"&Sigma;",931,7},
{"&Sgr;",931,5},
{"&b.Sigma;",931,9},
{"&Tau;",932,5},
{"&Tgr;",932,5},
{"&Upsi;",933,6},
{"&Ugr;",933,5},
{"&b.Upsi;",933,8},
{"&Upsilon;",933,9},
{"&Phi;",934,5},
{"&PHgr;",934,6},
{"&b.Phi;",934,7},
{"&Chi;",935,5},
{"&KHgr;",935,6},
{"&Psi;",936,5},
{"&PSgr;",936,6},
{"&b.Psi;",936,7},
{"&Omega;",937,7},
{"&OHgr;",937,6},
{"&b.Omega;",937,9},
{"&Idigr;",938,7},
{"&Udigr;",939,7},
{"&aacgr;",940,7},
{"&eacgr;",941,7},
{"&eeacgr;",942,8},
{"&iacgr;",943,7},
{"&udiagr;",944,8},
{"&alpha;",945,7},
{"&agr;",945,5},
{"&b.alpha;",945,9},
{"&beta;",946,6},
{"&bgr;",946,5},
{"&b.beta;",946,8},
{"&gamma;",947,7},
{"&ggr;",947,5},
{"&b.gamma;",947,9},
{"&delta;",948,7},
{"&dgr;",948,5},
{"&b.delta;",948,9},
{"&epsi;",949,6},
{"&egr;",949,5},
{"&b.epsi;",949,8},
{"&b.epsis;",949,9},
{"&b.epsiv;",949,9},
{"&epsilon;",949,9},
{"&zeta;",950,6},
{"&zgr;",950,5},
{"&b.zeta;",950,8},
{"&eta;",951,5},
{"&eegr;",951,6},
{"&b.eta;",951,7},
{"&thetas;",952,8},
{"&thgr;",952,6},
{"&b.thetas;",952,10},
{"&theta;",952,7},
{"&iota;",953,6},
{"&igr;",953,5},
{"&b.iota;",953,8},
{"&kappa;",954,7},
{"&kgr;",954,5},
{"&b.kappa;",954,9},
{"&lambda;",955,8},
{"&lgr;",955,5},
{"&b.lambda;",955,10},
{"&mu;",956,4},
{"&mgr;",956,5},
{"&b.mu;",956,6},
{"&nu;",957,4},
{"&ngr;",957,5},
{"&b.nu;",957,6},
{"&xi;",958,4},
{"&xgr;",958,5},
{"&b.xi;",958,6},
{"&omicron;",959,9},
{"&ogr;",959,5},
{"&pi;",960,4},
{"&pgr;",960,5},
{"&b.pi;",960,6},
{"&rho;",961,5},
{"&rgr;",961,5},
{"&b.rho;",961,7},
{"&sigmav;",962,8},
{"&sfgr;",962,6},
{"&b.sigmav;",962,10},
{"&sigmaf;",962,8},
{"&sigma;",963,7},
{"&sgr;",963,5},
{"&b.sigma;",963,9},
{"&tau;",964,5},
{"&tgr;",964,5},
{"&b.tau;",964,7},
{"&upsi;",965,6},
{"&ugr;",965,5},
{"&b.upsi;",965,8},
{"&upsilon;",965,9},
{"&phis;",966,6},
{"&phgr;",966,6},
{"&b.phis;",966,8},
{"&phi;",966,5},
{"&chi;",967,5},
{"&khgr;",967,6},
{"&b.chi;",967,7},
{"&psi;",968,5},
{"&psgr;",968,6},
{"&b.psi;",968,7},
{"&omega;",969,7},
{"&ohgr;",969,6},
{"&idigr;",970,7},
{"&udigr;",971,7},
{"&oacgr;",972,7},
{"&uacgr;",973,7},
{"&ohacgr;",974,8},
{"&b.omega;",974,9},
{"&thetav;",977,8},
{"&b.thetav;",977,10},
{"&thetasym;",977,10},
{"&upsih;",978,7},
{"&phiv;",981,6},
{"&b.phiv;",981,8},
{"&piv;",982,5},
{"&b.piv;",982,7},
{"&gammad;",988,8},
{"&b.gammad;",988,10},
{"&kappav;",1008,8},
{"&b.kappav;",1008,10},
{"&rhov;",1009,6},
{"&b.rhov;",1009,8},
{"&IOcy;",1025,6},
{"&DJcy;",1026,6},
{"&GJcy;",1027,6},
{"&Jukcy;",1028,7},
{"&DScy;",1029,6},
{"&Iukcy;",1030,7},
{"&YIcy;",1031,6},
{"&Jsercy;",1032,8},
{"&LJcy;",1033,6},
{"&NJcy;",1034,6},
{"&TSHcy;",1035,7},
{"&KJcy;",1036,6},
{"&Ubrcy;",1038,7},
{"&DZcy;",1039,6},
{"&Acy;",1040,5},
{"&Bcy;",1041,5},
{"&Vcy;",1042,5},
{"&Gcy;",1043,5},
{"&Dcy;",1044,5},
{"&IEcy;",1045,6},
{"&ZHcy;",1046,6},
{"&Zcy;",1047,5},
{"&Icy;",1048,5},
{"&Jcy;",1049,5},
{"&Kcy;",1050,5},
{"&Lcy;",1051,5},
{"&Mcy;",1052,5},
{"&Ncy;",1053,5},
{"&Ocy;",1054,5},
{"&Pcy;",1055,5},
{"&Rcy;",1056,5},
{"&Scy;",1057,5},
{"&Tcy;",1058,5},
{"&Ucy;",1059,5},
{"&Fcy;",1060,5},
{"&KHcy;",1061,6},
{"&TScy;",1062,6},
{"&CHcy;",1063,6},
{"&SHcy;",1064,6},
{"&SHCHcy;",1065,8},
{"&HARDcy;",1066,8},
{"&Ycy;",1067,5},
{"&SOFTcy;",1068,8},
{"&Ecy;",1069,5},
{"&YUcy;",1070,6},
{"&YAcy;",1071,6},
{"&acy;",1072,5},
{"&bcy;",1073,5},
{"&vcy;",1074,5},
{"&gcy;",1075,5},
{"&dcy;",1076,5},
{"&iecy;",1077,6},
{"&zhcy;",1078,6},
{"&zcy;",1079,5},
{"&icy;",1080,5},
{"&jcy;",1081,5},
{"&kcy;",1082,5},
{"&lcy;",1083,5},
{"&mcy;",1084,5},
{"&ncy;",1085,5},
{"&ocy;",1086,5},
{"&pcy;",1087,5},
{"&rcy;",1088,5},
{"&scy;",1089,5},
{"&tcy;",1090,5},
{"&ucy;",1091,5},
{"&fcy;",1092,5},
{"&khcy;",1093,6},
{"&tscy;",1094,6},
{"&chcy;",1095,6},
{"&shcy;",1096,6},
{"&shchcy;",1097,8},
{"&hardcy;",1098,8},
{"&ycy;",1099,5},
{"&softcy;",1100,8},
{"&ecy;",1101,5},
{"&yucy;",1102,6},
{"&yacy;",1103,6},
{"&iocy;",1105,6},
{"&djcy;",1106,6},
{"&gjcy;",1107,6},
{"&jukcy;",1108,7},
{"&dscy;",1109,6},
{"&iukcy;",1110,7},
{"&yicy;",1111,6},
{"&jsercy;",1112,8},
{"&ljcy;",1113,6},
{"&njcy;",1114,6},
{"&tshcy;",1115,7},
{"&kjcy;",1116,6},
{"&ubrcy;",1118,7},
{"&dzcy;",1119,6},
{"&ensp;",8194,6},
{"&emsp;",8195,6},
{"&emsp13;",8196,8},
{"&emsp14;",8197,8},
{"&numsp;",8199,7},
{"&puncsp;",8200,8},
{"&thinsp;",8201,8},
{"&hairsp;",8202,8},
{"&zwnj;",8204,6},
{"&zwj;",8205,5},
{"&lrm;",8206,5},
{"&rlm;",8207,5},
{"&dash;",8208,6},
{"&ndash;",8211,7},
{"&endash;",8211,8},
{"&mdash;",8212,7},
{"&emdash;",8212,8},
{"&horbar;",8213,8},
{"&Verbar;",8214,8},
{"&lsquo;",8216,7},
{"&rsquor;",8216,8},
{"&rsquo;",8217,7},
{"&sbquo;",8218,7},
{"&lsquor;",8218,8},
{"&ldquo;",8220,7},
{"&rdquor;",8220,8},
{"&rdquo;",8221,7},
{"&bdquo;",8222,7},
{"&ldquor;",8222,8},
{"&dagger;",8224,8},
{"&Dagger;",8225,8},
{"&bull;",8226,6},
{"&nldr;",8229,6},
{"&hellip;",8230,8},
{"&mldr;",8230,6},
{"&permil;",8240,8},
{"&prime;",8242,7},
{"&vprime;",8242,8},
{"&Prime;",8243,7},
{"&tprime;",8244,8},
{"&bprime;",8245,8},
{"&lsaquo;",8249,8},
{"&rsaquo;",8250,8},
{"&oline;",8254,7},
{"&caret;",8257,7},
{"&hybull;",8259,8},
{"&frasl;",8260,7},
{"&euro;",8364,6},
{"&tdot;",8411,6},
{"&DotDot;",8412,8},
{"&incare;",8453,8},
{"&hamilt;",8459,8},
{"&planck;",8463,8},
{"&image;",8465,7},
{"&lagran;",8466,8},
{"&ell;",8467,5},
{"&numero;",8470,8},
{"&copysr;",8471,8},
{"&weierp;",8472,8},
{"&real;",8476,6},
{"&rx;",8478,4},
{"&trade;",8482,7},
{"&ohm;",8486,5},
{"&angst;",8491,7},
{"&bernou;",8492,8},
{"&phmmat;",8499,8},
{"&order;",8500,7},
{"&alefsym;",8501,9},
{"&aleph;",8501,7},
{"&beth;",8502,6},
{"&gimel;",8503,7},
{"&daleth;",8504,8},
{"&frac13;",8531,8},
{"&frac23;",8532,8},
{"&frac15;",8533,8},
{"&frac25;",8534,8},
{"&frac35;",8535,8},
{"&frac45;",8536,8},
{"&frac16;",8537,8},
{"&frac56;",8538,8},
{"&frac18;",8539,8},
{"&frac38;",8540,8},
{"&frac58;",8541,8},
{"&frac78;",8542,8},
{"&larr;",8592,6},
{"&uarr;",8593,6},
{"&rarr;",8594,6},
{"&darr;",8595,6},
{"&harr;",8596,6},
{"&xhArr;",8596,7},
{"&xharr;",8596,7},
{"&varr;",8597,6},
{"&nwarr;",8598,7},
{"&nearr;",8599,7},
{"&drarr;",8600,7},
{"&dlarr;",8601,7},
{"&nlarr;",8602,7},
{"&nrarr;",8603,7},
{"&rarrw;",8605,7},
{"&Larr;",8606,6},
{"&Rarr;",8608,6},
{"&larrtl;",8610,8},
{"&rarrtl;",8611,8},
{"&map;",8614,5},
{"&larrhk;",8617,8},
{"&rarrhk;",8618,8},
{"&larrlp;",8619,8},
{"&rarrlp;",8620,8},
{"&harrw;",8621,7},
{"&nharr;",8622,7},
{"&lsh;",8624,5},
{"&rsh;",8625,5},
{"&crarr;",8629,7},
{"&cularr;",8630,8},
{"&curarr;",8631,8},
{"&olarr;",8634,7},
{"&orarr;",8635,7},
{"&lharu;",8636,7},
{"&lhard;",8637,7},
{"&uharr;",8638,7},
{"&uharl;",8639,7},
{"&rharu;",8640,7},
{"&rhard;",8641,7},
{"&dharr;",8642,7},
{"&dharl;",8643,7},
{"&rlarr2;",8644,8},
{"&lrarr2;",8646,8},
{"&larr2;",8647,7},
{"&uarr2;",8648,7},
{"&rarr2;",8649,7},
{"&darr2;",8650,7},
{"&lrhar2;",8651,8},
{"&rlhar2;",8652,8},
{"&nlArr;",8653,7},
{"&nhArr;",8654,7},
{"&nrArr;",8655,7},
{"&lArr;",8656,6},
{"&xlArr;",8656,7},
{"&uArr;",8657,6},
{"&rArr;",8658,6},
{"&xrArr;",8658,7},
{"&dArr;",8659,6},
{"&hArr;",8660,6},
{"&iff;",8660,5},
{"&vArr;",8661,6},
{"&lAarr;",8666,7},
{"&rAarr;",8667,7},
{"&forall;",8704,8},
{"&comp;",8705,6},
{"&part;",8706,6},
{"&exist;",8707,7},
{"&nexist;",8708,8},
{"&empty;",8709,7},
{"&nabla;",8711,7},
{"&isin;",8712,6},
{"&notin;",8713,7},
{"&epsis;",8714,7},
{"&ni;",8715,4},
{"&bepsi;",8717,7},
{"&prod;",8719,6},
{"&coprod;",8720,8},
{"&amalg;",8720,7},
{"&samalg;",8720,8},
{"&sum;",8721,5},
{"&minus;",8722,7},
{"&mnplus;",8723,8},
{"&plusdo;",8724,8},
{"&setmn;",8726,7},
{"&ssetmn;",8726,8},
{"&lowast;",8727,8},
{"&compfn;",8728,8},
{"&radic;",8730,7},
{"&prop;",8733,6},
{"&vprop;",8733,7},
{"&infin;",8734,7},
{"&ang90;",8735,7},
{"&ang;",8736,5},
{"&angmsd;",8737,8},
{"&angsph;",8738,8},
{"&mid;",8739,5},
{"&nmid;",8740,6},
{"&par;",8741,5},
{"&spar;",8741,6},
{"&npar;",8742,6},
{"&nspar;",8742,7},
{"&and;",8743,5},
{"&or;",8744,4},
{"&cap;",8745,5},
{"&cup;",8746,5},
{"&int;",8747,5},
{"&conint;",8750,8},
{"&there4;",8756,8},
{"&becaus;",8757,8},
{"&sim;",8764,5},
{"&thksim;",8764,8},
{"&bsim;",8765,6},
{"&wreath;",8768,8},
{"&nsim;",8769,6},
{"&sime;",8771,6},
{"&nsime;",8772,7},
{"&cong;",8773,6},
{"&ncong;",8775,7},
{"&asymp;",8776,7},
{"&ap;",8776,4},
{"&thkap;",8776,7},
{"&nap;",8777,5},
{"&ape;",8778,5},
{"&bcong;",8780,7},
{"&bump;",8782,6},
{"&bumpe;",8783,7},
{"&esdot;",8784,7},
{"&eDot;",8785,6},
{"&efDot;",8786,7},
{"&erDot;",8787,7},
{"&colone;",8788,8},
{"&ecolon;",8789,8},
{"&ecir;",8790,6},
{"&cire;",8791,6},
{"&wedgeq;",8793,8},
{"&trie;",8796,6},
{"&ne;",8800,4},
{"&equiv;",8801,7},
{"&nequiv;",8802,8},
{"&le;",8804,4},
{"&les;",8804,5},
{"&ge;",8805,4},
{"&ges;",8805,5},
{"&lE;",8806,4},
{"&gE;",8807,4},
{"&lnE;",8808,5},
{"&lne;",8808,5},
{"&lvnE;",8808,6},
{"&gnE;",8809,5},
{"&gne;",8809,5},
{"&gvnE;",8809,6},
{"&Lt;",8810,4},
{"&Gt;",8811,4},
{"&twixt;",8812,7},
{"&nlt;",8814,5},
{"&ngt;",8815,5},
{"&nle;",8816,5},
{"&nles;",8816,6},
{"&nge;",8817,5},
{"&nges;",8817,6},
{"&lsim;",8818,6},
{"&gsim;",8819,6},
{"&lg;",8822,4},
{"&gl;",8823,4},
{"&pr;",8826,4},
{"&sc;",8827,4},
{"&pre;",8828,5},
{"&cupre;",8828,7},
{"&sce;",8829,5},
{"&sccue;",8829,7},
{"&prsim;",8830,7},
{"&scsim;",8831,7},
{"&npr;",8832,5},
{"&nsc;",8833,5},
{"&sub;",8834,5},
{"&sup;",8835,5},
{"&nsub;",8836,6},
{"&nsup;",8837,6},
{"&sube;",8838,6},
{"&subE;",8838,6},
{"&supe;",8839,6},
{"&supE;",8839,6},
{"&nsube;",8840,7},
{"&nsubE;",8840,7},
{"&nsupe;",8841,7},
{"&nsupE;",8841,7},
{"&subne;",8842,7},
{"&subnE;",8842,7},
{"&vsubne;",8842,8},
{"&vsubnE;",8842,8},
{"&supne;",8843,7},
{"&supnE;",8843,7},
{"&vsupne;",8843,8},
{"&vsupnE;",8843,8},
{"&uplus;",8846,7},
{"&sqsub;",8847,7},
{"&sqsup;",8848,7},
{"&sqsube;",8849,8},
{"&sqsupe;",8850,8},
{"&sqcap;",8851,7},
{"&sqcup;",8852,7},
{"&oplus;",8853,7},
{"&ominus;",8854,8},
{"&otimes;",8855,8},
{"&osol;",8856,6},
{"&odot;",8857,6},
{"&ocir;",8858,6},
{"&oast;",8859,6},
{"&odash;",8861,7},
{"&plusb;",8862,7},
{"&minusb;",8863,8},
{"&timesb;",8864,8},
{"&sdotb;",8865,7},
{"&vdash;",8866,7},
{"&dashv;",8867,7},
{"&top;",8868,5},
{"&perp;",8869,6},
{"&bottom;",8869,8},
{"&models;",8871,8},
{"&vDash;",8872,7},
{"&Vdash;",8873,7},
{"&Vvdash;",8874,8},
{"&nvdash;",8876,8},
{"&nvDash;",8877,8},
{"&nVdash;",8878,8},
{"&nVDash;",8879,8},
{"&vltri;",8882,7},
{"&vrtri;",8883,7},
{"&ltrie;",8884,7},
{"&rtrie;",8885,7},
{"&mumap;",8888,7},
{"&intcal;",8890,8},
{"&veebar;",8891,8},
{"&barwed;",8892,8},
{"&diam;",8900,6},
{"&sdot;",8901,6},
{"&sstarf;",8902,8},
{"&divonx;",8903,8},
{"&bowtie;",8904,8},
{"&ltimes;",8905,8},
{"&rtimes;",8906,8},
{"&lthree;",8907,8},
{"&rthree;",8908,8},
{"&bsime;",8909,7},
{"&cuvee;",8910,7},
{"&cuwed;",8911,7},
{"&Sub;",8912,5},
{"&Sup;",8913,5},
{"&Cap;",8914,5},
{"&Cup;",8915,5},
{"&fork;",8916,6},
{"&ldot;",8918,6},
{"&gsdot;",8919,7},
{"&Ll;",8920,4},
{"&Gg;",8921,4},
{"&leg;",8922,5},
{"&gel;",8923,5},
{"&els;",8924,5},
{"&egs;",8925,5},
{"&cuepr;",8926,7},
{"&cuesc;",8927,7},
{"&npre;",8928,6},
{"&nsce;",8929,6},
{"&lnsim;",8934,7},
{"&gnsim;",8935,7},
{"&prnsim;",8936,8},
{"&scnsim;",8937,8},
{"&nltri;",8938,7},
{"&nrtri;",8939,7},
{"&nltrie;",8940,8},
{"&nrtrie;",8941,8},
{"&vellip;",8942,8},
{"&Barwed;",8966,8},
{"&lceil;",8968,7},
{"&rceil;",8969,7},
{"&lfloor;",8970,8},
{"&rfloor;",8971,8},
{"&drcrop;",8972,8},
{"&dlcrop;",8973,8},
{"&urcrop;",8974,8},
{"&ulcrop;",8975,8},
{"&telrec;",8981,8},
{"&target;",8982,8},
{"&ulcorn;",8988,8},
{"&urcorn;",8989,8},
{"&dlcorn;",8990,8},
{"&drcorn;",8991,8},
{"&frown;",8994,7},
{"&sfrown;",8994,8},
{"&smile;",8995,7},
{"&ssmile;",8995,8},
{"&lang;",9001,6},
{"&rang;",9002,6},
{"&blank;",9251,7},
{"&oS;",9416,4},
{"&boxh;",9472,6},
{"&boxv;",9474,6},
{"&boxdr;",9484,7},
{"&boxdl;",9488,7},
{"&boxur;",9492,7},
{"&boxul;",9496,7},
{"&boxvr;",9500,7},
{"&boxvl;",9508,7},
{"&boxhd;",9516,7},
{"&boxhu;",9524,7},
{"&boxvh;",9532,7},
{"&boxH;",9552,6},
{"&boxV;",9553,6},
{"&boxdR;",9554,7},
{"&boxDr;",9555,7},
{"&boxDR;",9556,7},
{"&boxdL;",9557,7},
{"&boxDl;",9558,7},
{"&boxDL;",9559,7},
{"&boxuR;",9560,7},
{"&boxUr;",9561,7},
{"&boxUR;",9562,7},
{"&boxuL;",9563,7},
{"&boxUl;",9564,7},
{"&boxUL;",9565,7},
{"&boxvR;",9566,7},
{"&boxVr;",9567,7},
{"&boxVR;",9568,7},
{"&boxvL;",9569,7},
{"&boxVl;",9570,7},
{"&boxVL;",9571,7},
{"&boxHd;",9572,7},
{"&boxhD;",9573,7},
{"&boxHD;",9574,7},
{"&boxHu;",9575,7},
{"&boxhU;",9576,7},
{"&boxHU;",9577,7},
{"&boxvH;",9578,7},
{"&boxVh;",9579,7},
{"&boxVH;",9580,7},
{"&uhblk;",9600,7},
{"&lhblk;",9604,7},
{"&block;",9608,7},
{"&blk14;",9617,7},
{"&blk12;",9618,7},
{"&blk34;",9619,7},
{"&squ;",9633,5},
{"&square;",9633,8},
{"&squf;",9642,6},
{"&rect;",9645,6},
{"&marker;",9646,8},
{"&xutri;",9651,7},
{"&utrif;",9652,7},
{"&utri;",9653,6},
{"&rtrif;",9656,7},
{"&rtri;",9657,6},
{"&xdtri;",9661,7},
{"&dtrif;",9662,7},
{"&dtri;",9663,6},
{"&ltrif;",9666,7},
{"&ltri;",9667,6},
{"&loz;",9674,5},
{"&cir;",9675,5},
{"&xcirc;",9675,7},
{"&starf;",9733,7},
{"&star;",9734,6},
{"&phone;",9742,7},
{"&female;",9792,8},
{"&male;",9794,6},
{"&spades;",9824,8},
{"&clubs;",9827,7},
{"&hearts;",9829,8},
{"&diams;",9830,7},
{"&sung;",9834,6},
{"&flat;",9837,6},
{"&natur;",9838,7},
{"&sharp;",9839,7},
{"&check;",10003,7},
{"&cross;",10007,7},
{"&malt;",10016,6},
{"&lozf;",10022,6},
{"&loz;",10023,5},
{"&sext;",10038,6},
{"&fflig;",64256,7},
{"&filig;",64257,7},
{"&fllig;",64258,7},
{"&ffilig;",64259,8},
{"&ffllig;",64260,8},
{0,0,0}};


int find_html_entity(char *in,char **out)
{
	int i;
        if (in[1]=='#') {
            char *c;
            if (in[2] && isdigit(in[2])) i=strtol(in+2,&c,10);
            else if ((in[2]=='x' || in[2]=='X') && in[3] && isxdigit(in[3])) i=strtol(in+3,&c,16);
            else return 0;
            if (!i) return 0;
            if (*c==';') c++;
            *out=c;
            return i;
        }
	for (i=0;enti[i].ent;i++) {
		if (!strncmp(enti[i].ent,in,enti[i].len)) {
			if (out) *out=in+enti[i].len;
			return enti[i].val;
		}
	}
	return 0;
}

#define houtchar(c) do {if (outb) *outb++=c;pos++;} while(0)

#define HTML_INLINE_NORMAL 0
#define HTML_BLOCK_START 1
#define HTML_BLOCK_END 2
#define HTML_INLINE_SPACE 3

struct tag {
    char name[64];
    int olcnt;
    int tag_mode;
};

static struct tagspec {
    char name[64];
    int tag_mode;
    int autoclose;
} tagspec[]={
    {"br",1,1},
    {"hr",9,1},
    {"p",3,0},
    {"div",1,0},
    {"li",5,0},
    {"ol",0x21,0},
    {"ul",0x41,0},
    {"menu",0x41,0},
    {"dir",0x41,0},
    {"dl",1,0},
    {"dt",1,1},
    {"dd",1,1},
    {"h1",17,0},
    {"h2",17,0},
    {"h3",17,0},
    {"h4",1,0},
    {"h5",1,0},
    {"h6",1,0},
    {"img",0,1},
    {"area",0,1},
    {"base",0,1},
    {"basefont",0,1},
    {"col",0,1},
    {"input",0,1},
    {"isindex",0,1},
    {"link",0,1},
    {"meta",0,1},
    {"param",0,1},
    {"frame",0,1},
    {"table",1,0},
    {"caption",1,0},
    {"thead",1,0},
    {"tbody",1,0},
    {"tfoot",1,0},
    {"th",1,0},
    {"td",1,0},
    {"tr",1,0}
};

#define HT_TAGNO (sizeof(tagspec)/sizeof(tagspec[0]))

int ht_is_blank(int n)
{
    if (n>=0 && n<=32) return 1;
    if (n==160) return 1;
    return 0;
}

int html2txt(char *html,char *outb)
{
    int pos=0;
    int mode=HTML_BLOCK_START;
    int tagspos=0;
    char tagname[64];
    struct tag tagstack[256];
    char encoding[64]="";
    char *final;
    iconv_t ic;
    char *extra_buf=NULL,exbuf[32];
    
    
    int get_char()
    {
        int n;
        wchar_t ob;
        char *hc;
        size_t _isa,_osa;
        if (*html=='&') {
            n=find_html_entity(html,&html);
            if (n) return n;
        }
        _osa=sizeof(wchar_t);
        _isa=final-html;
        hc=(char *)&ob;
        
        iconv(ic,&html,&_isa,&hc,&_osa);
        if (_osa != 0) {
            iconv(ic,NULL,NULL,NULL,NULL);
            return (*html++) & 255;
        }
        return ob;
    }
    
    int fnd_encoding(char *str,int len)
    {
        char st[len+1];
        char *he=NULL,*co=NULL,**whr,*c;
        memcpy(st,str,len);
        st[len]=0;
        str=st;
        while (str && (!co || !he)) {
            while (*str && isspace(*str)) str++;
            if (!*str) break;
            whr=NULL;
            if (!strncasecmp(str,"http-equiv",10)) {
                c=str+10;
                if (isspace(*c)) while (*c && isspace(*c)) c++;
                if (*c=='=') {
                    whr=&he;
                    str=c;
                }
            }
            else if (!strncasecmp(str,"content",7)) {
                c=str+7;
                if (isspace(*c)) while (*c && isspace(*c)) c++;
                if (*c=='=') {
                    whr=&co;
                    str=c;
                }
            }
            if (!whr) {
                while (*str && !isspace(*str)) str++;
                while (*str && isspace(*str)) str++;
                if (!*str) break;
                if (*str !='=') continue;
            }
            str++;
            while (*str && isspace(*str)) str++;
            if (*str=='"' || *str=='\'') {
                int n=*str++;
                if (whr) *whr=str;
                str=strchr(str,n);
                if (!str) break;
                *str++=0;
            }
            else {
                if (whr) *whr=str;
                while (*str && !isspace(*str)) str++;
                if (*str) *str++=0;
            }
        }
        if (!co || !he) return 0;
        if (strcasecmp(he,"content-type")) return 0;
        while (co && *co) {
            co=strchr(co,';');
            if (!co) break;
            co++;
            while(*co && isspace(*co)) co++;
            if (strncmp(co,"charset=",8)) continue;
            co+=8;
            c=encoding;
            while (*co && (isalnum(*co) || *co=='-')) {
                if (c-encoding < 63) *c++=toupper(*co);
                co++;
            }
            *c=0;
            return 1;
        }
        return 0;
    }
    int get_encoding()
    {
        char *cin=html,*cs;
        while (*cin && isspace(*cin)) cin++;
        if (!strncmp(cin,"<?xml",5)) {
            cin+=5;
            if (isspace(*cin)) {
                cs=strstr(cin,"?>");
                char *c=strstr(cin,"encoding=");
                if (c && c<cs) {
                    c+=9;
                    if (*c=='"' || *c=='\'') c++;
                    cs=encoding;
                    while (cs-encoding < 63 && *c && (isalnum(*c) || *c=='-')) *cs++=toupper(*c++);
                    *cs=0;
                    return 1;
                }
            }
        }
        cin=html;
        while (cin && *cin) {
            cin=strchr(cin,'<');
            if (!cin) break;
            cin++;
            if (strncasecmp(cin,"meta",4)) continue;
            cin+=4;
            if (!*cin || !isspace(*cin)) continue;
            while (*cin && isspace(*cin)) cin++;
            cs=strchr(cin,'>');
            if (!cs) break;
            cs--;
            while (cs>cin && (isspace(*cs) || *cs=='/')) cs--;
            if (fnd_encoding(cin,cs+1-cin)) return 1;
            
        }
        return 0;
    }
    int get_tag()
    {
        char *c;
        for (c=tagname;*html && isalnum(*html);html++) if (c-tagname < 63) *c++=tolower(*html);
        *c=0;
        c=strchr(html,'>');
        if (!c) {
            html+=strlen(html);
            return 0;
        }
        html=c+1;
        c--;
        if (*c == '/') return 1;
        return 0;
    }
    
    int do_tag()
    {
        int i,tmode,acls;
        if (*html == '/') {
            html++;
            get_tag();
            for (i=tagspos-1,acls=0;i>=0;i--) {
                acls |= tagstack[i].tag_mode;
                if (!strcmp(tagname,tagstack[i].name)) break;
            }
            if (i>=0) {
                if (acls & 1) mode = HTML_BLOCK_END;
                if (acls & 16) {
                    houtchar('\n');
                    houtchar('\n');
                    mode=HTML_INLINE_NORMAL;
                }
                tagspos=i;
            }
            return 0;
        }
        acls=get_tag();
        tmode=-1;
        for (i=0;i<HT_TAGNO;i++) if (!strcmp(tagname,tagspec[i].name)) {
            tmode=tagspec[i].tag_mode;
            acls |= tagspec[i].autoclose;
            break;
        }
        if (i >= HT_TAGNO) {
            tmode=0;
        }
        if (!tmode && acls) {
            return 0;
        }
        if (tmode & 1) {
            for (i=tagspos-1;i>=0;i--) if (tagstack[i].tag_mode & 2) {
                tagspos=i;
                break;
            }
        }
        if (tmode & 8) {
            acls=1;
            if (mode != HTML_BLOCK_START) houtchar('\n');
            houtchar('*');
            houtchar('*');
            houtchar('*');
            houtchar('\n');
            mode=HTML_BLOCK_END;
            return 0;
        }
        if (!acls) {
            if (tagspos>= 256) {
                return -1;
            }
            strcpy(tagstack[tagspos].name,tagname);
            tagstack[tagspos].olcnt=0;
            tagstack[tagspos].tag_mode=tmode;
            tagspos++;
        }
        if (tmode & 1) {
            if (tmode & 4) {
                for (i=tagspos-1;i>=0;i--) if (tagstack[i].tag_mode & 0x60) break;
                if (i>=0 && (tagstack[i].tag_mode & 0x20)) {
                    tagstack[i].olcnt++;
                    sprintf(exbuf,"%d. ",tagstack[i].olcnt);
                    extra_buf=exbuf;
                }
            }
            if (tmode & 16) {
                houtchar('\n');
                houtchar('\n');
                houtchar('#');
            }
            else if (mode != HTML_BLOCK_START) {
                houtchar('\n');
            }
            mode=HTML_BLOCK_START;
        }
        return 0;
    }
    
    int should_html_push(int n)
    {
        if (n == 0xad) return 0;
        switch(mode) {
            case HTML_INLINE_NORMAL:
                if (ht_is_blank(n)) {
                    mode=HTML_INLINE_SPACE;
                    return 0;
                }
                return 1;
            case HTML_INLINE_SPACE:
                if (ht_is_blank(n)) {
                    return 0;
                }
                mode=HTML_INLINE_NORMAL;
                houtchar(' ');
                return 1;
            
            case HTML_BLOCK_START:
                if (ht_is_blank(n)) {
                    return 0;
                }
                mode=HTML_INLINE_NORMAL;
                return 1;
            case HTML_BLOCK_END:
                if (ht_is_blank(n)) {
                    return 0;
                }
                mode=HTML_INLINE_NORMAL;
                return 1;
            default:
                return 0;
            
        }
    }
    
    if (!get_encoding()) return -1;
    ic=iconv_open("WCHAR_T",encoding);
    if (ic == (iconv_t)-1) return -1;
    
    for (;;) {
        html=strchr(html,'<');
        if (!html) return -1;
        html++;
        if (strncasecmp(html,"BODY",4)) continue;
        html+=4;
        if (!*html) return -1;
        if (*html=='/') return -1;
        if (*html!='>' && !isspace(*html)) continue;
        html=strchr(html,'>');
        if (!html) return -1;
        html++;
        break;
    }
    
    final=html+strlen(html);
    while (*html) {
        while (*html) {
            int n;
            if (extra_buf && *extra_buf) {
                n=*extra_buf++;
            }
            else {
                if (*html=='<') {
		    if (pdf_keep_boldit) {
			if (!strncasecmp(html,"<i>",3) ||
				!strncasecmp(html,"<b>",3) ||
				!strncasecmp(html,"</i>",4) ||
				!strncasecmp(html,"</b>",4)) {
			    for (;;) {
				n=*html++;
				houtchar(n);
				if (n=='>') break;
			    }
			    continue;
			}
		    }
		    break;
		}
                n=get_char();
                if (!n) {
                    if (should_html_push((*html) & 255)) {
                        houtchar(*html);
                    }
                    html++;
                    continue;
                }
            }
            if (!should_html_push(n)) continue;
            if (n>65535) continue;
            if (n>0x7ff) {
                houtchar(0xe0 | (n>>12));
                houtchar(0x80 | ((n>>6) & 0x3f));
                houtchar(0x80 | (n & 0x3f));
            }
            else if (n>=0x80) {
                houtchar(0xc0 | (n>>6));
                houtchar(0x80 | (n & 0x3f));
            }
            else {
                houtchar(n);
            }
        }
        if (!*html) break;
        html++;
        if (!strncasecmp(html,"/BODY",5)) break;
        if (do_tag()<0) break;
    }
    houtchar('\n');
    houtchar('\n');
    houtchar(0);
    iconv_close(ic);
    return pos;
    
}

static char *ecub_template="<?xml version=\"1.0\" encoding=\"utf-8\" ?>\n\
<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.1//EN\" \"http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd\">\n\
<html xmlns=\"http://www.w3.org/1999/xhtml\">\n\
<head>\n\
<meta http-equiv=\"Content-Type\" content=\"application/xhtml+xml; charset=utf-8\" />\n\
<link rel=\"stylesheet\" type=\"text/css\" href=\"style.css\" />\n\
<title>%T</title>\n\
</head>\n\
<body>%R\n\
<h3 class=\"chapter_heading\">%T</h3>\n\
%S%Q\n\
</body>\n\
</html>\n";

#define put_char(a) do {if (outbuf) outbuf[len]=a;len++;} while(0)

char *ftags[]={
    "</i>","</b>","</u>",
    "<i>", "<b>", "<u>",
    "<fb2:poem>",
    "<fb2:epi>",
    "<fb2:cite>",
    "<fb2:author>",
    "<fb2:poemtitle>",
    "<fb2:subtitle>",
    "<fb2:epigraph>",
    "<fb2:code>",
    NULL};

static int make_html_ee(char *title,char *body,char *outbuf,char *template,int endash,int formatting,int pred,int succ,char *fname)
{
    char *tmp;
    int len;
    len=0;
    char *dash=endash?" &#x2013; ":" &#x2014; ";
    char *bdash=endash?"&#x2013;&nbsp;":"&#x2014;&nbsp;";
    int stack[16];
    int stklen;
    
    if (fname) {
        char *c=strrchr(fname,'/');
        if (c) fname=c+1;
    }
    
    void put_tag(char *a)
    {
        while (*a) {
            put_char(*a);
            a++;
        }
    }
    
    void empty_stack(void)
    {
        while (stklen > 0) {
            stklen--;
            put_tag(ftags[stack[stklen]]);
        }
    }
    
    void correct_stack(n)
    {
        int i;
        if (n>=6) return;
        if (n>=3) {
            if (stklen<16) {
                stack[stklen++]=n-3;
            }
            put_tag(ftags[n]);
            return;
        }
        for (i=0;i<stklen;i++) if (stack[i]==n) break;
        if (i>=stklen) return;
        while(stklen>0) {
            stklen--;
            put_tag(ftags[stack[stklen]]);
            if(stack[stklen]==n) break;
        }
    }
    
    void put_body(char *body,int is_multiline)
    {
        int hr,tagon,znak;
        stklen=0;
        if (is_multiline) {
            put_tag("<p class=\"p_first\">");
        }
        char *bg=body;
        while (*body && isspace(*body)) body++;
        tagon=1;
        for (;*body;) {
            if (is_multiline) {
                if (*body == '\r') {
                    if (body[1]=='\n') body++;
                }
                if (*body=='\r' || *body=='\n') {
                    empty_stack();
                    put_tag("</p>\n");
                    tagon=0;
                    body++;
                    hr=0;
                    while (*body && isspace(*body)) {
                        if (*body=='\n' || *body=='\r') hr=1;
                        body++;
                    }
                    if (!*body) break;
                    if (hr) {
                        put_tag("<hr class=\"hr_separator\" />\n");
                        put_tag("<p class=\"p_first\">");
                    } else {
                        put_tag("<p class=\"p_normal\">");
                    }
                    tagon=1;
                    if (formatting) {
                        int ix;
                        while (*body == '<') { 
                            for (ix=0;ftags[ix];ix++) if (!strncmp(body,
                                ftags[ix],
                                strlen(ftags[ix]))) break;
                            if (!ftags[ix]) break;
                            correct_stack(ix);
                            body+=strlen(ftags[ix]);
                        }
                    }
                        
                    znak=g_utf8_get_char(body);
                    if (znak == '-' || znak == 8208 || znak == 8211 || znak == 8212 || znak == 8213) {
                        put_tag(bdash);
                        body=g_utf8_next_char(body);
                        while (*body && (*body == ' ' || *body =='\t')) body++;
                        continue;
                    }
                }
                else if (*body==' ' || *body=='\t') {
                    body++;
                    while (*body==' ' || *body=='\t') body++;
                    if (!*body) break;
                    if (*body=='\r' || *body=='\n') continue;
                    znak=g_utf8_get_char(body);
                    if (znak == '-' || znak == 8208 || znak == 8211 || znak == 8212 || znak == 8213) {
                        put_tag(dash);
                        body=g_utf8_next_char(body);
                        while (*body && (*body == ' ' || *body =='\t')) body++;
                        continue;
                    }
                    put_char(' ');
                    continue;
                }
                else {
                    znak=g_utf8_get_char(body);
                    char *s=g_utf8_next_char(body);
                    if ((znak == '-' && (*s==' ' || *s=='\t')) || znak == 8208 || znak == 8211 || znak == 8212 || znak == 8213) {
                         put_tag(dash);
                         body=s;
                         while (*body && (*body == ' ' || *body =='\t')) body++;
                        continue;
                    }
                }
            }
            else if (*body=='\r' || *body=='\n') break;
            if (*body=='<') {
                if (formatting) {
                    int ix;
                    for (ix=0;ftags[ix];ix++) if (!strncmp(body,
                        ftags[ix],
                        strlen(ftags[ix]))) break;
                    if (ftags[ix]) {
                        correct_stack(ix);
                        body+=strlen(ftags[ix]);
                        continue;
                    }
                }
                put_tag("&lt;");
            }
            else if (*body=='>') put_tag("&gt;");
            else if (*body=='&') put_tag("&amp;");
            else if (*body == '"') {
                int g;
                g=g_utf8_get_char(body+1);
                if (g_unichar_isalnum(g) || body == bg || isspace(body[-1])) put_tag("„");
                else put_tag("”");
            }
            /* poetry mode... */
            else if (*body == '\\' && (body[1]=='\r' || body[1]=='\n')) {
                body++;
                if (*body=='\r') body++;
                if (*body=='\n') body++;
                if (*body=='\r' || *body=='\n') break;
                put_tag("<br />\n");
                continue;
            }
            else {
                put_char(*body);
            }
            body++;
        }
        if (is_multiline && tagon) {
            empty_stack();
            put_tag("</p>\n");
        }
    }
    
    void put_urb(char *c)
    {
        for (;*c;c++) {
            if (*c=='&') put_tag("&amp;");
            else if (*c=='<') put_tag("&lt;");
            else if (*c=='>') put_tag("&gt;");
            else if (*c=='"') put_tag("&quot;");
            else put_char(*c);
        }
    }
    
    void put_ura(int urn)
    {
        char *c;
        char ybuf[256];
        c=strrchr(fname,'.');
        if (c) {
            int n=c-fname;
            memcpy(ybuf,fname,n);
            sprintf(ybuf+n,"_%03d",urn+1);
            strcat(ybuf,c);
        }
        else {
                sprintf(ybuf,"%s_%03d.html",fname,urn+1);
        }
        put_urb(ybuf);
    }
    
    for (tmp=template;*tmp;tmp++) {
        if (*tmp=='%' && (tmp[1]=='S' || tmp[1]=='T' || tmp[1]=='Q' || tmp[1]=='R')) {
            tmp++;
            if (*tmp=='T') put_body(title,0);
            else if (*tmp == 'S') put_body(body,1);
            else if ((pred >=0 || succ >= 0) && fname) {
                if (*tmp=='Q')put_tag("<hr />\n");
                if (pred >= 0) {
                    put_tag("<a href=\"");
                    put_ura(pred);
                    put_tag("\">&lt;&lt;&lt; Poprzedni</a>&nbsp;|&nbsp;");
                }
                put_tag("<a href=\"");
                put_urb(fname);
                put_tag("\">Spis treści</a>");
                if (succ >= 0) {
                    put_tag("&nbsp;|&nbsp;");
                    put_tag("<a href=\"");
                    put_ura(succ);
                    put_tag("\">Następny &gt;&gt;&gt;</a>");
                }
                if (*tmp=='R')put_tag("<hr />\n");
            }
        }
        else {
            put_char(*tmp);
        }
    }
    put_char(0);
    return len;
}

char *make_html(char *title,char *body,char *template,int endash,int formatting,int pred,int succ,char *fname)
{
    int len;
    if (!template) template=ecub_template;
    if (!title) {
        title=body;
        for (;*body;body++) if (strchr("\r\n",*body)) break;
        for (;*body;body++) if (!strchr("\r\n",*body)) break;
    }
    len=make_html_ee(title,body,NULL,template,endash,formatting,pred,succ,fname);
    char *r=g_malloc(len);
    make_html_ee(title,body,r,template,endash,formatting,pred,succ,fname);
    return r;
}

