/*
 * editor.c - Milena Audiobook Creator
 * Copyright (C) Bohdan R. Rau 2009-2011 <ethanak@polip.com>
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write see:
 *               <http://www.gnu.org/licenses/>.
 */
#include "config.h"
#include <gtk/gtk.h>
#include <string.h>
#include <stdlib.h>
#include "gmilena.h"
#ifndef HAVE_GTK3
#include <gtksourceview/gtksourceiter.h>
#endif
#include <gdk/gdkkeysyms.h>
#include <pcre.h>
#include <glib.h>
//#include <glib/gunicode.h>
#include <ctype.h>

#ifdef HAVE_GTK3
#define GTK_SOURCE_SEARCH_TEXT_ONLY GTK_TEXT_SEARCH_TEXT_ONLY
#define GTK_SOURCE_SEARCH_CASE_INSENSITIVE GTK_TEXT_SEARCH_CASE_INSENSITIVE
#define GTK_SOURCE_SEARCH_VISIBLE_ONLY GTK_TEXT_SEARCH_VISIBLE_ONLY
#endif


#define F_ALONE 0x01
#define F_EMPTY 0x02
#define F_DIALOG 0x04
#define F_SPLIT 0x08
#define F_HYPHEN 0x10
#define F_SHORT 0x20

#define F_NONE 0x100
#define F_ENTER 0x200
#define F_SPACE 0x400



static GtkWidget *createSearchLibDialog(int mode);

extern char *to_utf8(char *fbuf,int flen,char *cset,int freeme);
extern int ignore_oor;
//static GtkWidget *find_dialog;
//static GtkWidget *fd_entry_find,*fd_entry_replace;
//static GtkWidget *fd_cb_regexp,*fd_cb_nocase,*fd_cb_word;

char *get_actual_body(void)
{
	GtkTextIter start,end;
	gtk_text_buffer_get_start_iter((gpointer)tresc,&start);
	gtk_text_buffer_get_end_iter((gpointer)tresc,&end);
	return gtk_text_buffer_get_text((gpointer)tresc,&start,&end,FALSE);

}


char *get_editor_body(struct MyGtkEditor *editor)
{
	GtkTextIter start,end;
	gtk_text_buffer_get_start_iter((gpointer)editor->buf,&start);
	gtk_text_buffer_get_end_iter((gpointer)editor->buf,&end);
	return gtk_text_buffer_get_text((gpointer)editor->buf,&start,&end,FALSE);
}

void convert_to_iso2(GtkWidget *widget,void *dummy)
{
	int n;
	n=get_current_editor();
	if (n<0) return;
	if (n) {
		Error("Błędne polecenie","Konwersja nie jest możliwa dla trybów DASH i DIC");
		return;
	}
	if (!gtk_text_buffer_get_char_count(tresc)) return;
	char *ustr,*istr,*str=get_actual_body();
	ignore_oor=2;
	n=to_iso2(str,NULL);
	if (!n) {
		g_free(str);
		return;
	}
	istr=g_malloc(n);
	ignore_oor=2;
	to_iso2(str,istr);
	ustr=to_utf8(istr,strlen(istr),"ISO-8859-2",1);
	if (!strcmp(str,ustr)) {
		Info("Informacja","Plik nie zawierał znaków spoza ISO2");
	}
	else {
		set_buffer_text(tresc,ustr,-1,1);
		if (count_bad_char) {
			char buf[256];
			sprintf(buf,"Konwersja wykonana, nieskonwertowane znaki: %d",count_bad_char);
			Info ("Informacja",buf);
		}
		else Info("Informacja","Konwersja wykonana");
	}
	g_free(str);
	g_free(ustr);
	return;
}


static GtkWidget *cbx_autonum;
static GtkWidget *spin_wiersz;

static void set_minwiersz_active(void)
{
	gtk_widget_set_sensitive(spin_wiersz,
		gtk_toggle_button_get_active((gpointer)cbx_autonum));
}

void correct_jacosub(GtkWidget *dummy,void *data)
{
	char *str=get_current_iso2(),buf[64],*str2;
	int otir;
	if (!str) return;
	int timeres=jacosub_timeres(str,&otir);
	if (!timeres) {
		Error("Hm...","To nie wygląda na plik Jacosub");
		g_free(str);
		return;
	}
	if (timeres == otir)  {
		sprintf(buf,"Korygujesz Jacosub?");
	}
	else {
		sprintf(buf,"Korygujesz Jacosub zmieniając TIMERES na %d?",timeres);
	}
	if (!Ask("Pytanko",buf)) {
		g_free(str);
		return;
	}
	str2=jacosub_simplify(str,timeres);
	if (str2) {
		str2=to_utf8(str2,strlen(str2),"ISO-8859-2",1);
		set_buffer_text(current_editor->buf,str2,-1,1);
		g_free(str2);
	}
	g_free(str);
}

void unformat_text(GtkWidget *dummy, void *data)
{

	char *str=get_current_iso2();
	if (!str) return;
    int spliter=0;
	if (gtk_combo_box_get_active((gpointer)combo_split)) {
		char *c=(char *)gtk_entry_get_text((gpointer)char_split);
		if (!*c || ((*c) & 0x80)) {
			Error("Błąd","Nielegalny znak podziału");
			return;
		}
        spliter=*c;
    }


	GtkWidget *dialog=gtk_dialog_new_with_buttons(
		"Ustaw odformatowanie",
		(gpointer)main_window,
		GTK_DIALOG_MODAL,
		GTK_STOCK_OK,GTK_RESPONSE_ACCEPT,
		GTK_STOCK_CANCEL,GTK_RESPONSE_REJECT,
		NULL);
	GtkWidget *box=gtk_dialog_get_content_area((gpointer)dialog);
	GtkWidget *vbox=gtk_vbox_new(0,2);
	gtk_box_pack_start(GTK_BOX(box),(gpointer)vbox,FALSE,FALSE,0);

	GtkWidget *cbx_autopages=gtk_check_button_new_with_label("Usuń numerację stron");
	gtk_box_pack_start(GTK_BOX(vbox),cbx_autopages,FALSE,FALSE,0);
	GtkWidget *hbox=gtk_hbox_new(0,2);
	gtk_box_pack_start(GTK_BOX(vbox),hbox,FALSE,FALSE,0);
	cbx_autonum=gtk_check_button_new_with_label("Minimalna długość wiersza");
	gtk_box_pack_start(GTK_BOX(hbox),cbx_autonum,FALSE,FALSE,0);
	gtk_toggle_button_set_active((gpointer)cbx_autonum,TRUE);
	spin_wiersz=gtk_spin_button_new_with_range(20.0,120.0,1.0);
	gtk_spin_button_set_value((gpointer)spin_wiersz,50);
	atk_object_set_name(gtk_widget_get_accessible((gpointer)spin_wiersz),"Minimalna długość wiersza");
	atk_object_set_description(gtk_widget_get_accessible((gpointer)spin_wiersz),"Ustawia minimalną długość wiersza, poniżej której będzie on traktowany jako kończący akapit");
	//connect_label(cbx_autonum,spin_wiersz);
	g_signal_connect(G_OBJECT(cbx_autonum),"toggled",G_CALLBACK(set_minwiersz_active),NULL);
	gtk_box_pack_start(GTK_BOX(hbox),spin_wiersz,FALSE,FALSE,0);
	gtk_widget_show_all(box);
	int n=gtk_dialog_run((gpointer)dialog);
	if (n!=GTK_RESPONSE_ACCEPT) {
		gtk_widget_destroy(dialog);
		g_free(str);
		return;
	}

	int autopar=0;
	int nopages=gtk_toggle_button_get_active((gpointer)cbx_autopages);
	if (gtk_toggle_button_get_active((gpointer)cbx_autonum)) {
		autopar=gtk_spin_button_get_value_as_int((gpointer)spin_wiersz);
	}
	gtk_widget_destroy(dialog);
	str=unformat_me(str,nopages,autopar,spliter);
	str=to_utf8(str,strlen(str),"ISO-8859-2",1);

	set_buffer_text(current_editor->buf,str,-1,1);
	g_free(str);
	return;
}

static GtkWidget *search_dialog;
static GtkWidget *search_entry,*replace_label,*replace_entry;
static GtkWidget *search_regex,*search_case,*search_word,*search_bword,*search_eword,*search_backward,*search_extw;
static GtkWidget *search_replace_selection,*replace_box;
static int editor_do_replace,search_dialog_return_code;

static int words_extended;

static void libre_set(void);
static void libre_get(void);

static int iter_starts_word(GtkTextIter *iter)
{
	if (gtk_text_iter_starts_line(iter)) return 1;
	GtkTextIter sword=*iter;
	if (!gtk_text_iter_backward_char(&sword)) return 1;
	gunichar z=gtk_text_iter_get_char(&sword);
	if (g_unichar_isalnum(z)) return 0;
	if (!words_extended) return 1;
	if (z != '\'' && z!='-') return 1;
	if (!gtk_text_iter_backward_char(&sword)) return 1;
	z=gtk_text_iter_get_char(&sword);
	return !g_unichar_isalnum(z);
}

static int iter_ends_word(GtkTextIter *iter)
{
	if (gtk_text_iter_ends_line(iter)) return 1;
	GtkTextIter sword=*iter;
	//if (!gtk_text_iter_backward_char(&sword)) return;
	gunichar z=gtk_text_iter_get_char(&sword);
	if (g_unichar_isalnum(z)) return 0;
	if (!words_extended) return 1;
	if (z != '\'' && z!='-') return 1;
	if (!gtk_text_iter_forward_char(&sword)) return 1;
	z=gtk_text_iter_get_char(&sword);
	if (!z) return 1;
	return !g_unichar_isalnum(z);
}


int search_in_buffer(struct MyGtkEditor *editor,char *str,int insens,int bkward,int as_word)
{
	struct MyGtkEditor *edi;
	GtkTextIter pos,start,end;
	if (editor) edi=editor;
	else {
		get_current_editor();
		edi=current_editor;
	}
	GtkTextMark *sel;
	if (debug_level) printf("Searching for: [%s] i=%d b=%d w=%d\n",str,insens,bkward,as_word);
	if (bkward) {
		sel=gtk_text_buffer_get_insert(edi->buf);
	}
	else {
		sel=gtk_text_buffer_get_selection_bound(edi->buf);
	}
	gtk_text_buffer_get_iter_at_mark(edi->buf,&pos,sel);
	int flags = GTK_SOURCE_SEARCH_TEXT_ONLY | GTK_SOURCE_SEARCH_VISIBLE_ONLY;
	if (insens) flags |= GTK_SOURCE_SEARCH_CASE_INSENSITIVE;
	words_extended=gtk_toggle_button_get_active((gpointer)search_extw);
	for(;;) {
		if (bkward) {
			if (!gtk_source_iter_backward_search(&pos,str,flags,&start,&end,NULL)) return 0;
		}
		else {
			if (!gtk_source_iter_forward_search(&pos,str,flags,&start,&end,NULL)) return 0;
		}
#ifdef HAVE_GTK3
    
		if (bkward) {
		    //int of1=gtk_text_iter_get_offset(&start)+g_utf8_strlen(str,-1);
		    //if (debug_level) printf("OF1 = %d, S=%d\n",of1,g_utf8_strlen(str,-1));
		    //gtk_text_buffer_get_iter_at_offset(edi->buf,&end,of1);
		    end=start;
		    gtk_text_iter_forward_chars(&end,g_utf8_strlen(str,-1));
		}
	    
#endif
		if (!as_word) break;
		if ((as_word & 1) && !iter_starts_word(&start)) {
			if (bkward) pos=start;else pos=end;
			continue;
		}
		if ((as_word & 2) && !iter_ends_word(&end)) {
			if (bkward) pos=start;else pos=end;
			continue;
		}
		break;
	}
	if (debug_level) printf("Found %d -> %d\n",
	    gtk_text_iter_get_offset(&start),
	    gtk_text_iter_get_offset(&end));
	gtk_text_buffer_select_range(edi->buf,&start,&end);
	gtk_text_view_scroll_to_iter(edi->view,&start,0.2,FALSE,0.0,0.0);
	return 1;
}



struct editor_history {
	struct editor_history *succ,*pred;
	int flags;
	char *search;
	char *replace;
} editor_history={&editor_history,&editor_history,0x80};

static void insert_editor_history(int is_replace)
{
	struct editor_history *eh;
	char const *str=gtk_entry_get_text((gpointer)search_entry);
	char const *rep=gtk_entry_get_text((gpointer)replace_entry);
	int flags = 0;
	if (gtk_toggle_button_get_active((gpointer)search_regex)) flags |=1;
	if (gtk_toggle_button_get_active((gpointer)search_word)) flags |=2;
	if (gtk_toggle_button_get_active((gpointer)search_bword)) flags |=4;
	if (gtk_toggle_button_get_active((gpointer)search_eword)) flags |=8;
	if (gtk_toggle_button_get_active((gpointer)search_case)) flags |=16;
	if (gtk_toggle_button_get_active((gpointer)search_extw)) flags |=32;
	for (eh=editor_history.pred;eh && eh->flags != 0x80;eh=eh->succ) {
		if (eh->flags != flags) continue;
		if (strcmp(eh->search,str)) continue;
		if (is_replace) {
			if (strcmp(eh->replace,rep)) continue;
		}
		break;
	}
	if (eh && eh->flags != 0x80) {
		eh->succ->pred=eh->pred;
		eh->pred->succ=eh->succ;
	}
	else {
		eh=g_malloc(sizeof(*eh));
		eh->search=g_strdup(str);
		if (is_replace) {
			eh->replace=g_strdup(rep);
		}
		else {
			eh->replace=g_strdup("");
		}
		eh->flags=flags;
	}
	eh->succ=editor_history.succ;
	eh->pred=&editor_history;
	eh->succ->pred=eh;
	eh->pred->succ=eh;
}

static struct editor_history *editor_history_pointer;

static void next_editor_history(int dir)
{
	struct editor_history *eh;
	if (dir) {
		eh=editor_history_pointer->succ;
	}
	else {
		eh=editor_history_pointer->pred;
	}
	if (eh->flags & 0x80) return;
	editor_history_pointer=eh;
	gtk_entry_set_text((gpointer)search_entry,eh->search);
	gtk_entry_set_text((gpointer)replace_entry,eh->replace);
	gtk_toggle_button_set_active((gpointer)search_regex,(eh->flags & 1)?1:0);
	gtk_toggle_button_set_active((gpointer)search_word,(eh->flags & 2)?1:0);
	gtk_toggle_button_set_active((gpointer)search_bword,(eh->flags & 4)?1:0);
	gtk_toggle_button_set_active((gpointer)search_eword,(eh->flags & 8)?1:0);
	gtk_toggle_button_set_active((gpointer)search_case,(eh->flags & 16)?1:0);
	gtk_toggle_button_set_active((gpointer)search_extw,(eh->flags & 32)?1:0);
	if (eh->flags & 1) {
		gtk_toggle_button_set_active((gpointer)search_backward,FALSE);
	}
}


static void set_searcher_active(GtkWidget *widget,void *data)
{
	/*
	if (widget == (gpointer) search_backward) {
		if (gtk_toggle_button_get_active((gpointer)search_backward)) {
			gtk_toggle_button_set_active((gpointer)search_regex,0);
		}
	}
	if (widget == (gpointer) search_regex) {
		if (gtk_toggle_button_get_active((gpointer)search_regex)) {
			gtk_toggle_button_set_active((gpointer)search_backward,0);
		}
	}
	gtk_widget_set_sensitive(search_regex,
		!gtk_toggle_button_get_active((gpointer)search_backward));
	gtk_widget_set_sensitive(search_backward,
		!gtk_toggle_button_get_active((gpointer)search_regex));
						      */
	int n;
	n= gtk_toggle_button_get_active((gpointer)search_bword) |
		gtk_toggle_button_get_active((gpointer)search_eword);
	gtk_widget_set_sensitive(search_word,!n);
	n= gtk_toggle_button_get_active((gpointer)search_word) |
		gtk_toggle_button_get_active((gpointer)search_eword);
	gtk_widget_set_sensitive(search_bword,!n);
	n= gtk_toggle_button_get_active((gpointer)search_bword) |
		gtk_toggle_button_get_active((gpointer)search_word);
	gtk_widget_set_sensitive(search_eword,!n);

}


static int search_key_press(GtkWidget *widget,GdkEventKey *event,void *data)
{
	int sym=event->keyval;
	if (sym == GDK_Escape) {
		gtk_dialog_response((gpointer)search_dialog,GTK_RESPONSE_REJECT);
		return 1;
	}
	if (sym == GDK_Up) {
		//printf("Up\n");
		next_editor_history(1);
		return 1;
	}
	if (sym == GDK_Down) {
		//printf("Down\n");
		next_editor_history(0);
		return 1;
	}
	if ((sym == GDK_Return || sym == GDK_KP_Enter) && !editor_do_replace) {
		gtk_dialog_response((gpointer)search_dialog,GTK_RESPONSE_ACCEPT);
		return 1;
	}

	return 0;
}

static void set_searcher_return(GtkWidget *widget,void *dummy)
{
	gtk_dialog_response((gpointer)search_dialog,(int)dummy);
}

static void create_search_dialog(void)
{
	if (search_dialog) return;
	search_dialog=gtk_dialog_new_with_buttons(
		"Szukaj",
		(gpointer)main_window,
		GTK_DIALOG_MODAL,
		GTK_STOCK_OK,GTK_RESPONSE_ACCEPT,
		GTK_STOCK_CANCEL,GTK_RESPONSE_REJECT,
		NULL);
	GtkWidget *box=gtk_dialog_get_content_area((gpointer)search_dialog);
	GtkWidget *vbox=gtk_vbox_new(0,2);
	gtk_box_pack_start(GTK_BOX(box),(gpointer)vbox,FALSE,FALSE,0);

	GtkWidget *stable=gtk_table_new(2,2,0);
	gtk_box_pack_start(GTK_BOX(vbox),stable,FALSE,FALSE,0);
	GtkWidget *lab1=gtk_label_new("Szukaj");
	gtk_table_attach_defaults((gpointer)stable,lab1,0,1,0,1);
	search_entry=gtk_entry_new();
	gtk_table_attach_defaults((gpointer)stable,search_entry,1,2,0,1);
	gtk_widget_set_size_request((gpointer)search_entry, 320,-1);

	replace_label=gtk_label_new("Zmień na");
	gtk_table_attach_defaults((gpointer)stable,replace_label,0,1,1,2);
	replace_entry=gtk_entry_new();
	gtk_table_attach_defaults((gpointer)stable,replace_entry,1,2,1,2);


	g_signal_connect(G_OBJECT(search_entry),"key-press-event",G_CALLBACK(search_key_press),NULL);
	connect_label(lab1,search_entry);
	connect_label(replace_label,replace_entry);

	GtkWidget *sbox=gtk_hbox_new(0,2);
	gtk_box_pack_start(GTK_BOX(vbox),sbox,FALSE,FALSE,0);

	search_regex=gtk_check_button_new_with_mnemonic("_RegExp");
	gtk_box_pack_start(GTK_BOX(sbox),search_regex,FALSE,FALSE,0);

	search_case=gtk_check_button_new_with_mnemonic("_Wielkość liter");
	gtk_box_pack_start(GTK_BOX(sbox),search_case,FALSE,FALSE,0);

	search_word=gtk_check_button_new_with_mnemonic("_Słowo");
	gtk_box_pack_start(GTK_BOX(sbox),search_word,FALSE,FALSE,0);

	search_bword=gtk_check_button_new_with_mnemonic("_Początek słowa");
	gtk_box_pack_start(GTK_BOX(sbox),search_bword,FALSE,FALSE,0);

	search_eword=gtk_check_button_new_with_mnemonic("_Koniec słowa");
	gtk_box_pack_start(GTK_BOX(sbox),search_eword,FALSE,FALSE,0);

	GtkWidget *xbox=gtk_hbox_new(0,2);
	gtk_box_pack_start(GTK_BOX(vbox),xbox,FALSE,FALSE,0);

	search_backward=gtk_check_button_new_with_mnemonic("Ws_tecz");
	gtk_box_pack_start(GTK_BOX(xbox),search_backward,FALSE,FALSE,0);
	search_extw=gtk_check_button_new_with_mnemonic("E_xt. słowo");
	gtk_box_pack_start(GTK_BOX(xbox),search_extw,FALSE,FALSE,0);

	g_signal_connect(G_OBJECT(search_regex),"toggled",G_CALLBACK(set_searcher_active),NULL);
	g_signal_connect(G_OBJECT(search_word),"toggled",G_CALLBACK(set_searcher_active),NULL);
	g_signal_connect(G_OBJECT(search_bword),"toggled",G_CALLBACK(set_searcher_active),NULL);
	g_signal_connect(G_OBJECT(search_eword),"toggled",G_CALLBACK(set_searcher_active),NULL);
	g_signal_connect(G_OBJECT(search_backward),"toggled",G_CALLBACK(set_searcher_active),NULL);

	GtkWidget *search_libbox=gtk_frame_new("Biblioteka");
	GtkWidget *search_libibox=gtk_hbox_new(0,2);
	// odkomentuj!
	gtk_box_pack_end(GTK_BOX(xbox),search_libbox,FALSE,FALSE,0);

	gtk_container_add(GTK_CONTAINER(search_libbox),search_libibox);
	GtkWidget *but=gtk_button_new_with_mnemonic("Doda_j");
	gtk_box_pack_start(GTK_BOX(search_libibox),but,FALSE,FALSE,0);
	g_signal_connect(G_OBJECT(but),"clicked",G_CALLBACK(libre_set),NULL);
	but=gtk_button_new_with_mnemonic("Po_bierz");
	gtk_box_pack_start(GTK_BOX(search_libibox),but,FALSE,FALSE,0);
	g_signal_connect(G_OBJECT(but),"clicked",G_CALLBACK(libre_get),NULL);

	replace_box=gtk_frame_new("Zamień wszystkie");
	GtkWidget *replace_ibox=gtk_hbox_new(0,2);
	gtk_box_pack_end(GTK_BOX(xbox),replace_box,FALSE,FALSE,0);
	gtk_container_add(GTK_CONTAINER(replace_box),replace_ibox);

	//gtk_box_pack_start(GTK_BOX(replace_ibox),(gpointer)gtk_label_new("Zmień wszystkie"),FALSE,FALSE,0);
	but=gtk_button_new_with_mnemonic("W _całym tekście");
	gtk_box_pack_start(GTK_BOX(replace_ibox),but,FALSE,FALSE,0);
	g_signal_connect(G_OBJECT(but),"clicked",G_CALLBACK(set_searcher_return),(void *)100);
	search_replace_selection=gtk_button_new_with_mnemonic("W _zaznaczeniu");
	gtk_box_pack_start(GTK_BOX(replace_ibox),search_replace_selection,FALSE,FALSE,0);
	g_signal_connect(G_OBJECT(search_replace_selection),"clicked",G_CALLBACK(set_searcher_return),(void *)101);

	gtk_widget_show_all(box);
}


int search_ask(int do_replace)
{
	if (get_current_editor()<0) return 0;
	create_search_dialog();
	gtk_entry_set_text((gpointer)search_entry,"");
	gtk_entry_set_text((gpointer)replace_entry,"");
	gtk_toggle_button_set_active((gpointer)search_regex,FALSE);
	gtk_toggle_button_set_active((gpointer)search_word,FALSE);
	gtk_toggle_button_set_active((gpointer)search_bword,FALSE);
	gtk_toggle_button_set_active((gpointer)search_eword,FALSE);
	gtk_toggle_button_set_active((gpointer)search_case,FALSE);
	gtk_toggle_button_set_active((gpointer)search_backward,FALSE);
	gtk_toggle_button_set_active((gpointer)search_extw,FALSE);
	editor_do_replace=do_replace;
	gtk_widget_grab_focus(search_entry);
	gtk_widget_set_sensitive(search_replace_selection,
		gtk_text_buffer_get_has_selection(tresc));
	if (do_replace) {
		gtk_widget_show(replace_entry);
		gtk_widget_show(replace_label);
		gtk_widget_show_all(replace_box);
	}
	else {
		gtk_widget_hide(replace_entry);
		gtk_widget_hide(replace_label);
		gtk_widget_hide(replace_box);
	}
	editor_history_pointer=&editor_history;
	gtk_window_resize(GTK_WINDOW(search_dialog),1,1);
	int n=gtk_dialog_run(GTK_DIALOG(search_dialog));
	gtk_widget_hide(search_dialog);
	if (n!=GTK_RESPONSE_ACCEPT && n!=100 && n !=101) return 0;
	insert_editor_history(do_replace);
	search_dialog_return_code=n;
	return gtk_entry_get_text_length((gpointer)search_entry);
}

#define PREPRE_NEG 2
#define PREPRE_N 4
#define PREPRE_S 8
#define PREPRE_NONS 16


static char *preproc_regex(char *c)
{
	char *e;
	static char buf[1024];
	int in_class=0;
	e=buf;
	while (*c) {
		if (!in_class && *c=='[') {
			*e++=*c++;
			in_class=1;
			if (*c=='^') {
				*e++=*c++;
				in_class |= PREPRE_NEG;
			}
			continue;
		}
		if (in_class && *c==']') {
			//printf("IC=%d\n",in_class);
			in_class &= ~1;
			if ((in_class & (PREPRE_S | PREPRE_NONS)) == (PREPRE_S | PREPRE_NONS)) {
				in_class = (in_class & 3) | PREPRE_N;
			}
			if (in_class & PREPRE_NEG) {
				// negacja
				in_class &= ~PREPRE_NEG;
				if (in_class & PREPRE_S) {
					// tylko \s - pozostaje \s
					*e++='\\';
					*e++='s';
				}
				else if (in_class & PREPRE_NONS) {
					*e++='\\';
					*e++='S';
					*e++='\\';
					*e++='n';
				}
				else {
					*e++='\\';
					*e++='n';
				}
			}
			else {
				if ((in_class & (PREPRE_S | PREPRE_N)) == (PREPRE_S | PREPRE_N)) {
					*e++='\\';
					*e++='s';
				}
				else if (in_class & PREPRE_S) {
					*e++=' ';
					*e++='\\';
					*e++='t';
				}
				else if (in_class & PREPRE_NONS) {
					*e++='\\';
					*e++='S';
				}
				else if (in_class & PREPRE_N) {
					*e++='\\';
					*e++='n';
				}
			}
			in_class=0;
			*e++=*c++;
			continue;
		}
		if (*c!='\\') {
			*e++=*c++;
			continue;
		}
		c++;
		if (*c == 's') {
			c++;
			if (!in_class) {
				strcpy(e,"[ \\t]");
				e+=strlen(e);
			}
			else {
				in_class |= PREPRE_S;
			}
			continue;
		}
		if (*c == 'n' && in_class) {
			c++;
			in_class |= PREPRE_N;
			continue;
		}
		if (*c == 'S' && in_class) {
			c++;
			in_class |= PREPRE_NONS;
			continue;
		}
		*e++='\\';
		*e++=*c++;
	}
	*e=0;
	//printf("Buf='%s'\n",buf);
	return buf;
}

static char *preproc_regex_old(char *c)
{
	char *d,*e;
	static char buf[1024];
	int in_class;
	int m=0;
	for (d=c,e=buf,in_class=0;*d;d++) {
		if (*d=='[') {
			*e++=*d;
			if (in_class) {
				in_class |= 4;
				continue;
			}
			in_class=1;
			m=0;
			if (d[1]=='^') {
				in_class=2;
				d++;
				*e++='^';
			}
			continue;
		}
		if (*d==']' && in_class) {
			if (in_class & 4) {
				*e++=*d;
				in_class &= 3;
				continue;
			}
			if (in_class==2) {
				if (!(m & 1)) {
					*e++='\\';*e++='r';
				}
				if (!(m & 2)) {
					*e++='\\';*e++='n';
				}
			}
			*e++=']';
			in_class=0;
			continue;
		}
		if (*d!='\\') {
			*e++=*d;
			continue;
		}
		if (d[1] !='s' || in_class) {
			*e++='\\';d++;
			if (in_class==2) {
				if (*d=='r') m|=1;
				if (*d=='n') m|=2;
			}
			*e++=*d;
			continue;
		}
		d++;
		strcpy(e,"[^\\S\\n\\r]");
		e+=9;
	}
	*e=0;
//	printf("RE <%s>\n",buf);
	return buf;
}


pcre *compile_preg_pattern(const char *str)
{
	int flags=PCRE_MULTILINE | PCRE_UTF8 | PCRE_NEWLINE_ANY;
	const char *err;int eoffset;
	pcre *pcr;
	if (!gtk_toggle_button_get_active((gpointer)search_case)) {
		flags |= PCRE_CASELESS;
	}
	str=preproc_regex((char *)str);
	pcr=pcre_compile(str,flags,&err,&eoffset,NULL);
	if (!pcr) {
		Error("Błąd kompilacji",(char *)err);
		return NULL;
	}
	words_extended=gtk_toggle_button_get_active((gpointer)search_extw);
	return pcr;
}

static int unichar_dec(char *str,char *buf)
{
	int z,i;
	for (z=i=0;i<4;i++) {
		z<<=4;
		if (!str[i] || !isxdigit(str[i])) return 0;
		else if (isdigit(str[i])) z+=str[i]-'0';
		else z+=tolower(str[i])-'a'+10;
	}
	i=0;
	if (z<128) {
		if (buf) buf[i++]=z;
		else return 1;
	}
	else if (z<0x800) {
		if (!buf) return 2;
		buf[i++]= 0xc0 | (z>>6);
		buf[i++]= 0x80 | (z & 0x3f);
	}
	else {
		if (!buf) return 3;
		buf[i++]= 0xe0 | (z >> 12);
		buf[i++]= 0x80 | ((z>>6) & 0x3f);
		buf[i++]= 0x80 | (z & 0x3f);
	}
	buf[i]=0;
	return i;
}

static char *create_replacement(char *repstr,int *xmatch,char *str,int xmsize)
{
	int n=0,t;char buf[4];
	char *r=repstr,*c,*d;
	while (*r) {
		if (*r != '\\') {
			n++;
			r++;
			continue;
		}
		r++;
		if (!*r) {
			n++;
			break;
		}
		if (xmatch && *r>='0' && *r<='9') {
			int v=(*r) - '0';
			if (v >= xmsize) {
				ErrorF(main_window,"Błąd","Grupa %d nie istnieje",v);
				return NULL;
			}
			n+=xmatch[2*v+1]-xmatch[2*v];
		}
		else if (*r=='u' && (t=unichar_dec(r+1,NULL))) {
			r+=4;
			n+=t;
		}
		else {
			n++;
		}
		r++;
	}
	c=d=g_malloc(n+1);
	r=repstr;
	while (*r) {
		if (*r != '\\') {
			*d++=*r++;
			continue;
		}
		r++;
		if (!*r) {
			*d++='\\';
			break;
		}
		if (xmatch && *r>='0' && *r<='9') {
			int v=(*r) - '0';
			int i;
			for (i=xmatch[2*v];i<xmatch[2*v+1];i++) *d++=str[i];
		}
		else if (*r == 'u' && unichar_dec(r+1,buf)) {
			char *s=buf;
			r+=4;
			while (*s) *d++=*s++;
		}
		else if (*r=='n') {
			*d++='\n';
		}
		else if (*r=='t') {
			*d++='\t';
		}
		else {
			*d++=*r;
		}
		r++;
	}
	*d=0;
	return c;
}

static int is_start_word(char *str,int pos)
{
	gunichar ut;
	char *c=g_utf8_find_prev_char(str,str+pos);
	if (!c) return TRUE;
	ut=g_utf8_get_char(c);

	if (g_unichar_isalnum(ut)) return 0;
	if (!words_extended) return TRUE;
	if (ut != '\'' && ut != '-') return TRUE;
	c=g_utf8_find_prev_char(str,c);
	if (!c) return TRUE;
	ut=g_utf8_get_char(c);
	return !g_unichar_isalnum(ut);

}

static int is_end_word(char *str,int pos)
{
	gunichar ut;
	if (!str[pos]) return TRUE;
	ut=g_utf8_get_char(str+pos);
	if (g_unichar_isalnum(ut)) return 0;
	if (!words_extended) return TRUE;
	if (ut != '\'' && ut != '-') return TRUE;
	pos++;
	if (!str[pos]) return TRUE;
	ut=g_utf8_get_char(str+pos);
	return !g_unichar_isalnum(ut);
}

static void not_found()
{
	Info("Informacja","Nic nie znaleziono");
}

static void found_occurences(int n)
{
	char buf[256];
	sprintf(buf,"Znaleziono %d wystąpie",n);
	if (n==1) strcat(buf,"nie");
	else {
		n%=100;
		if (n>10 && n<20) strcat(buf,"ń");
		else {
			n%=10;
			if (n>=2 && n<=4) strcat(buf,"nia");
			else strcat(buf,"ń");
		}
	}
	Info("Informacja",buf);
}

static int find_backward_by_regex(GtkTextIter *start,GtkTextIter *end,int as_word,char **repstr)
{

	int len,found,xmlen;
	int ovector[30],fvector[30];
	pcre *pat;
	GtkTextIter plast;
	int naddch,reallen;
	pat=compile_preg_pattern((gpointer)gtk_entry_get_text((gpointer)search_entry));
	if (!pat) {
		return 0;
	}
	GtkTextMark *sel=gtk_text_buffer_get_insert(tresc);
	gtk_text_buffer_get_iter_at_mark(tresc,end,sel);

	naddch=0;
	plast=*end;
	if (gtk_text_iter_forward_char(&plast)) {
		naddch=1;
		if (gtk_text_iter_forward_char(&plast)) naddch=2;
	}

	gtk_text_buffer_get_start_iter(tresc,start);
	char *str=gtk_text_iter_get_text(start,&plast);
	len=strlen(str);
	reallen=len;
	while (naddch>0) {
		naddch--;
		char *c=g_utf8_find_prev_char(str,str+len);
		if (c) len=c-str;
	}
	int pos=len/2;
	int lastpos=0;
	int endpos=len;
	found=-1;
	int this_found,n,i,epos;
	for (;;) {
		if (lastpos >= endpos) break;
		while (pos >= lastpos && (str[pos] & 0xc0)==0x80) pos--;
		if (pos <lastpos) break;
		this_found=0;
		epos=pos;
		for (;;) {

			n=pcre_exec(pat,NULL,str,reallen,epos,PCRE_NOTEMPTY,ovector,30);
			if (n<0) break;
			if (ovector[0]>=len) break;
			if ((as_word & 1) && !is_start_word(str,ovector[0])) {
				epos=ovector[0];
				if (str[epos++] & 0x80) {
					while((str[epos] & 0xc0)==0x80) epos++;
				}
				continue;
			}
			if ((as_word & 2) && !is_end_word(str,ovector[1])) {
				epos=ovector[0];
				if (str[epos++] & 0x80) {
					while((str[epos] & 0xc0)==0x80) epos++;
				}
				continue;
			}
			this_found=1;
			if (ovector[0]>found) {
				found=ovector[0];
				xmlen=n;
				for (i=0;i<30;i++) fvector[i]=ovector[i];
			}
			break;
		}
		if (!this_found) {
			endpos=pos;
			pos-=(pos-lastpos+1)/2;
			continue;
		}
		lastpos=pos+1;
		pos+=(endpos-pos+1)/2;
	}
	if (found >= 0) {
		*end=*start;
		n=g_utf8_strlen(str,fvector[0]);
		gtk_text_iter_forward_chars(start,n);
		n=g_utf8_strlen(str,fvector[1]);
		gtk_text_iter_forward_chars(end,n);

		if (repstr) {
			*repstr=create_replacement(
				(char *)gtk_entry_get_text((gpointer)replace_entry),
				fvector,str,xmlen);
			if (!*repstr) found=0;
		}
		gtk_text_buffer_select_range(tresc,start,end);
		gtk_text_view_scroll_to_iter(tresc_v,start,0.2,FALSE,0.0,0.0);
	}
	g_free(str);
	pcre_free(pat);
	return found >= 0;
}

static int find_by_regex(GtkTextIter *start,GtkTextIter *end,int as_word,char **repstr)
{

	int len,found;
	int ovector[30];
	pcre *pat;
	pat=compile_preg_pattern((gpointer)gtk_entry_get_text((gpointer)search_entry));
	if (!pat) {
		return 0;
	}
	GtkTextMark *sel=gtk_text_buffer_get_selection_bound(tresc);
	gtk_text_buffer_get_iter_at_mark(tresc,start,sel);
	int pos=gtk_text_iter_get_line_index(start);
	while (!gtk_text_iter_starts_line(start)) {
		gtk_text_iter_backward_cursor_position(start);
	}
	gtk_text_buffer_get_end_iter(tresc,end);
	char *str=gtk_text_iter_get_text(start,end);
	found=0;len=strlen(str);
	for (;;) {
		int n;
		int xmlen=pcre_exec(pat,NULL,str,len,pos,PCRE_NOTEMPTY,ovector,30);
		if (xmlen<0) break;
		if ((as_word & 1) && !is_start_word(str,ovector[0])) {
			pos=ovector[0];
			if (str[pos++] & 0x80) {
				while((str[pos] & 0xc0)==0x80) pos++;
			}
			continue;
		}
		if ((as_word & 2) && !is_end_word(str,ovector[1])) {
			pos=ovector[0];
			if (str[pos++] & 0x80) {
				while((str[pos] & 0xc0)==0x80) pos++;
			}
			continue;
		}
		found=1;
		*end=*start;
		n=g_utf8_strlen(str,ovector[0]);
		gtk_text_iter_forward_chars(start,n);
		n=g_utf8_strlen(str,ovector[1]);
		gtk_text_iter_forward_chars(end,n);

		if (repstr) {
			*repstr=create_replacement(
				(char *)gtk_entry_get_text((gpointer)replace_entry),
				ovector,str,xmlen);
			if (!*repstr) found=0;
		}
		break;
	}
	g_free(str);
	pcre_free(pat);
	if (found) {
		gtk_text_buffer_select_range(tresc,start,end);
		gtk_text_view_scroll_to_iter(tresc_v,start,0.2,FALSE,0.0,0.0);
	}

	return found;
}


static char *u_strstr(char *str,gunichar *needle,char **estr)
{
	char *slo,*sup,*s;gunichar *st;
	for (;;) {
		slo=g_utf8_strchr(str,-1,*needle);
		sup=g_utf8_strchr(str,-1,g_unichar_toupper(*needle));
		if (!slo) {
			if (!sup) {
				return NULL;
			}
			s=sup;

		}
		else if (!sup) {
			if (!slo) {
				return NULL;
			}
			s=slo;
		}
		else {
			s=slo;
			if (s>sup) s=sup;
		}
		str=s;
		s=g_utf8_next_char(s);
		st=needle+1;
		while (*st) {
			if (!*s) return NULL;
			if (*st != g_unichar_tolower(g_utf8_get_char(s))) break;
			s=g_utf8_next_char(s);
			st++;
		}
		if (!*st) {
			*estr=s;
			return str;
		}
		str=g_utf8_next_char(str);
	}
}

static void replace_all(char *search,
		char *replace,
		int insen,
		int as_word,
		int is_regex)

{
	pcre *pat=NULL;
	pcre_extra *pe=NULL;
	char const *pe_error;
	int ovector[30];
	GtkTextMark *m1,*m2;
	GtkTextIter start,finish,ps;
	int in_selection=0;
	char *str;
	char *ostr,*rc;
	int ostr_len,ostr_size,ostr_adder;
	int rtc;
	int found;
	int pos,slen,last;
	gunichar *u_search=NULL;

	void ostr_add(char *str,int len)
	{
		if (ostr_len+len>=ostr_size-2) {
			int adder=ostr_adder;
			if (len > adder/2) adder+=len;
			ostr_adder*=2;
			ostr_size+=adder;
			ostr=g_realloc(ostr,ostr_size);
		}
		memcpy(ostr+ostr_len,str,len);
		ostr_len+=len;
	}
	if (is_regex) {
		if (!(pat=compile_preg_pattern(search))) {
			return;
		}
		pe=pcre_study(pat,0,&pe_error);
	}
	else if (insen) {
		gunichar *gc;
		u_search=g_utf8_to_ucs4(search,-1,NULL,NULL,NULL);
		if (!u_search) return;
		for (gc=u_search;*gc;gc++) *gc=g_unichar_tolower(*gc);

	}

	if (search_dialog_return_code == 101) {
		in_selection = 1;
	}
	if (!in_selection) {
		gtk_text_buffer_get_start_iter(tresc,&start);
		gtk_text_buffer_get_end_iter(tresc,&finish);
	}
	else {
		m1=gtk_text_buffer_get_insert(tresc);
		m2=gtk_text_buffer_get_selection_bound(tresc);
		gtk_text_buffer_get_iter_at_mark(tresc,&start,m1);
		gtk_text_buffer_get_iter_at_mark(tresc,&finish,m2);
	}
	str=gtk_text_buffer_get_text(tresc,&start,&finish,FALSE);
	slen=strlen(str);
	ostr_size=slen+1;
	ostr=g_malloc(ostr_size);
	ostr_len=0;
	rtc=0;
	pos=0;
	last=0;
	ostr_adder=1024;
	start_busy_cursor();
	yield();
	if (!is_regex) replace=create_replacement(replace,NULL,NULL,0);
	for (;;) {
		char *fstr,*estr;
		int mcount;
		found=0;
		for (;;) {
			if (is_regex) {
				if ((mcount=pcre_exec(pat,pe,str,slen,pos,PCRE_NOTEMPTY,ovector,30))<0) break;
			}
			else {
				if (!insen) {
					fstr=strstr(str+pos,search);
					estr=fstr+strlen(search);
				}
				else {
					fstr=u_strstr(str+pos,u_search,&estr);
				}
				if (!fstr) {
					ovector[0]=-1;
					break;
				}
				ovector[0]=(fstr-str);
				ovector[1]=(estr-str);
			}
			if ((as_word & 1) && !is_start_word(str,ovector[0])) {
				pos=ovector[0];
				if (str[pos++] & 0x80) {
					while((str[pos] & 0xc0)==0x80) pos++;
				}
				continue;
			}
			if ((as_word & 2) && !is_end_word(str,ovector[1])) {
				pos=ovector[0];
				if (str[pos++] & 0x80) {
					while((str[pos] & 0xc0)==0x80) pos++;
				}
				continue;
			}
			found=1;
			break;
		}
		if (!found) break;
		if (is_regex) {
			rc=create_replacement(
				replace,
				ovector,str,mcount);
			if (!rc) {
				found=0;
				break;
			}
		}
		else {
			rc=replace;
		}
		ostr_add(str+last,ovector[0]-last);

		ostr_add(rc,strlen(rc));
		if (is_regex) {
			g_free(rc);
		}
		pos=last=ovector[1];
		rtc++;
	}
	if (is_regex) {
		pcre_free(pat);
		if (pe) pcre_free(pe);
	}
	else g_free(replace);
	if (rtc) {
		if (last < slen) {
			ostr_add(str+last,slen-last);
		}
		gtk_text_buffer_begin_user_action(tresc);
		if (!in_selection) {
			gtk_text_buffer_set_text(tresc,ostr,ostr_len);
			gtk_text_buffer_get_end_iter(tresc,&ps);
			gtk_text_buffer_place_cursor(tresc,&ps);
			gtk_text_view_scroll_to_iter(tresc_v,&ps,0.2,FALSE,0.0,0.0);
		}
		else {
			gtk_text_buffer_delete(tresc,&start,&finish);
			gtk_text_buffer_insert(tresc,&start,ostr,ostr_len);
			gtk_text_buffer_place_cursor(tresc,&start);
			gtk_text_view_scroll_to_iter(tresc_v,&start,0.2,FALSE,0.0,0.0);
			ps=start;
		}
		gtk_text_buffer_end_user_action(tresc);
	}

	g_free(str);
	g_free(ostr);
	if (u_search) g_free(u_search);
	end_busy_cursor();
	if (rtc) found_occurences(rtc);
	else if (a11y_not_found) {
		not_found();
	}
}

void StartReplace(GtkWidget *widget,void *data)
{
	int bkwd,insen,inwor;
	char *replace;
	GtkTextIter pos,end;
	if (!search_ask(1)) return;
	get_current_editor();
	bkwd=gtk_toggle_button_get_active((gpointer)search_backward);
	insen=!gtk_toggle_button_get_active((gpointer)search_case);
	inwor=0;
	if (gtk_toggle_button_get_active((gpointer)search_word)) inwor|=3;
	if (gtk_toggle_button_get_active((gpointer)search_bword)) inwor|=1;
	if (gtk_toggle_button_get_active((gpointer)search_eword)) inwor|=2;
	replace=(gpointer) gtk_entry_get_text((gpointer)replace_entry);
	if (search_dialog_return_code == GTK_RESPONSE_ACCEPT) {
		if (gtk_toggle_button_get_active((gpointer)search_regex)) {
			if (bkwd) {
				if (!find_backward_by_regex(&pos,&end,inwor,&replace)) {
					if (a11y_not_found) not_found();
					return;
				}
			}
			else {
				if (!find_by_regex(&pos,&end,inwor,&replace)) {
					if (a11y_not_found) not_found();
					return;
				}			}
		}
		else {
			if (!search_in_buffer(NULL,(gpointer)gtk_entry_get_text((gpointer)search_entry),
				insen,
				bkwd,
				inwor)) {
					if (a11y_not_found) not_found();
					return;
			}
			replace=create_replacement(replace,NULL,NULL,0);
		}
		gtk_text_buffer_begin_user_action (tresc);
		gtk_text_buffer_delete_selection (tresc, FALSE, TRUE);
		gtk_text_buffer_insert_at_cursor (tresc, replace, strlen (replace));
		gtk_text_buffer_end_user_action (tresc);
		g_free(replace);
		return;
	}
	replace_all((gpointer)gtk_entry_get_text((gpointer)search_entry),
		replace,
		insen,
		inwor,
		gtk_toggle_button_get_active((gpointer)search_regex));
}
void StartSearch(GtkWidget *widget,void *data)
{
	int _data=(int)data;
	int bkwd=0,insen,inwor;
	GtkTextIter pos,end;
	if (_data == 2) bkwd=1;
	get_current_editor();
	if (!data || !search_dialog || !gtk_entry_get_text_length((gpointer)search_entry)) {
		if (!search_ask(0)) return;
		bkwd=gtk_toggle_button_get_active((gpointer)search_backward);
	}
	insen=!gtk_toggle_button_get_active((gpointer)search_case);
	inwor=0;
	if (gtk_toggle_button_get_active((gpointer)search_word)) inwor|=3;
	if (gtk_toggle_button_get_active((gpointer)search_bword)) inwor|=1;
	if (gtk_toggle_button_get_active((gpointer)search_eword)) inwor|=2;

	if (!gtk_toggle_button_get_active((gpointer)search_regex)) {
		if (!search_in_buffer(NULL,(gpointer)gtk_entry_get_text((gpointer)search_entry),
			insen,
			bkwd,
			inwor) && a11y_not_found) not_found();
		return;
	}
	int n;
	if (bkwd) n=find_backward_by_regex(&pos,&end,inwor,NULL);
	else n=find_by_regex(&pos,&end,inwor,NULL);
	if (!n && a11y_not_found) not_found();
}

void find_entity(GtkWidget *widget,void *data)
{
	int t=get_current_editor();
	GtkTextIter end,pos;
	if (t <0) return;
	create_search_dialog();
	gtk_entry_set_text((gpointer)search_entry,"&((#(([0-9]{1,6})|(x[0-9a-f]{1,4})))|([a-z]{2,8}));");
	gtk_entry_set_text((gpointer)replace_entry,"");
	gtk_toggle_button_set_active((gpointer)search_regex,1);
	gtk_toggle_button_set_active((gpointer)search_word,0);
	gtk_toggle_button_set_active((gpointer)search_bword,0);
	gtk_toggle_button_set_active((gpointer)search_eword,0);
	gtk_toggle_button_set_active((gpointer)search_extw,0);
	gtk_toggle_button_set_active((gpointer)search_case,0);
	gtk_toggle_button_set_active((gpointer)search_backward,FALSE);
	int inwor=0;
	if (!find_by_regex(&pos,&end,inwor,NULL) && a11y_not_found) not_found();
	//insert_editor_history(0);
	return;
}


void find_current_word(GtkWidget *widget,void *data)
{
	int t=get_current_editor();
	GtkTextIter start,end,pos;
	if (t != MILEDIT_MODE_DIC && t != MILEDIT_MODE_DASH) return;
	GtkTextMark *sel=gtk_text_buffer_get_insert(tresc);
	gtk_text_buffer_get_iter_at_mark(tresc,&start,sel);
	while (!gtk_text_iter_starts_line(&start)) {
		gtk_text_iter_backward_cursor_position(&start);
	}
	end=start;
	gtk_text_iter_forward_to_line_end(&end);
	char *str=gtk_text_buffer_get_text(tresc,&start,&end,0);
	char *cs,*ds,*ecs=NULL,*eds;
	int n;
	gunichar ut;int has_up=0,has_star=0,has_tilde=0;
	if (!str) return;
	cs=strstr(str,"//");
	if (cs) *cs=0;
	cs=str;
	while (*cs && isspace(*cs)) cs++;
	if (!*cs) {
		g_free(str);
		return;
	}
	for (ds=cs;*ds;) {
		ut=g_utf8_get_char(ds);
        if (ut == '~') has_tilde=1;
		else if (g_unichar_isupper(ut)) has_up=1;
		else if (!g_unichar_isalnum(ut) && ut!='-' && ut!='\'') break;
		ds=g_utf8_next_char(ds);
	}
	if (*ds=='*') has_star=1;
	*ds=0;
	if (!*cs) {
		g_free(str);
		return;
	}
	if (has_up || has_tilde) {
		ecs=g_malloc(8*strlen(cs));
		for (ds=cs,eds=ecs;*ds;ds=g_utf8_next_char(ds)) {
			ut=g_utf8_get_char(ds);
            if (ut=='~') {
                *eds++='[';
                *eds++='-';
                *eds++=' ';
                *eds++='\\';
                *eds++='t';
                *eds++=']';
                *eds++='+';
            }
			else if (has_up && g_unichar_islower(ut)) {
				*eds++='[';
				n=g_unichar_to_utf8(ut,eds);
				eds+=n;
				n=g_unichar_to_utf8(g_unichar_toupper(ut),eds);
				eds+=n;
				*eds++=']';
			}
			else {
				n=g_unichar_to_utf8(ut,eds);
				eds+=n;
			}
		}
		*eds=0;
		cs=ecs;
	}

	create_search_dialog();
	gtk_entry_set_text((gpointer)search_entry,cs);
	gtk_entry_set_text((gpointer)replace_entry,"");
	gtk_toggle_button_set_active((gpointer)search_regex,has_up || has_tilde);
	gtk_toggle_button_set_active((gpointer)search_word,has_star?0:1);
	gtk_toggle_button_set_active((gpointer)search_bword,has_star);
	gtk_toggle_button_set_active((gpointer)search_eword,0);
	gtk_toggle_button_set_active((gpointer)search_extw,widget?1:0);
	gtk_toggle_button_set_active((gpointer)search_case,has_up);
	gtk_toggle_button_set_active((gpointer)search_backward,FALSE);
	show_editor(current_editor->owneditor);
	get_current_editor();
	int insen=!gtk_toggle_button_get_active((gpointer)search_case);
	int inwor=0;
	if (gtk_toggle_button_get_active((gpointer)search_word)) inwor|=3;
	if (gtk_toggle_button_get_active((gpointer)search_bword)) inwor|=1;
	if (gtk_toggle_button_get_active((gpointer)search_eword)) inwor|=2;

	gtk_text_buffer_get_start_iter((gpointer)tresc,&start);
	gtk_text_buffer_place_cursor((gpointer)tresc,&start);
	gtk_text_view_scroll_to_iter((gpointer)tresc_v,&start,FALSE,FALSE,0.0,0.0);
	if (!gtk_toggle_button_get_active((gpointer)search_regex)) {
		if (!search_in_buffer(NULL,(gpointer)gtk_entry_get_text((gpointer)search_entry),
			insen,
			0,
			inwor) && a11y_not_found) not_found();
	}
	else {
		if (!find_by_regex(&pos,&end,inwor,NULL) && a11y_not_found) not_found();
	}
	//insert_editor_history(0);
	g_free(str);
	if (ecs) g_free(ecs);
	return;
}


void set_buffer_text(gpointer buf,char *str,int len,int undoable)
{
	GtkTextIter pos;
	if (undoable) {
		gtk_text_buffer_begin_user_action(buf);
	}
	else {
		gtk_source_buffer_begin_not_undoable_action(buf);
	}
	gtk_text_buffer_set_text(buf,str,len);
	gtk_text_buffer_get_start_iter(buf,&pos);
	gtk_text_buffer_place_cursor(buf,&pos);
	if (undoable) {
		gtk_text_buffer_end_user_action(buf);
	}
	else {
		gtk_source_buffer_end_not_undoable_action(buf);
		gtk_text_buffer_set_modified((gpointer)tresc,FALSE);
	}
}

void go_to_line(GtkWidget *widget,void *dummy)
{
	if (get_current_editor()<0) return;
	int n=GetNumber("Skocz do linii","Linia");
	if (n<=0) return;
	GtkTextIter line;
	gtk_text_buffer_get_iter_at_line(tresc,&line,n-1);
	gtk_text_buffer_place_cursor(tresc,&line);
	gtk_text_view_scroll_to_iter((gpointer)tresc_v,&line,FALSE,TRUE,0.0,0.5);
}

void editor_delete_line(GtkWidget *widget,void *data)
{
	GtkTextMark *m;
	GtkTextIter start,finisz;
	int cnt;
	if (get_current_editor()<0) return;
	m=gtk_text_buffer_get_insert(tresc);
	gtk_text_buffer_get_iter_at_mark(tresc,&start,m);
	cnt=gtk_text_iter_get_line_offset(&start);
	if (cnt) gtk_text_iter_backward_chars(&start,cnt);
	finisz=start;
	gtk_text_iter_forward_line(&finisz);
	gtk_text_buffer_begin_user_action(tresc);
	gtk_text_buffer_delete(tresc,&start,&finisz);
	gtk_text_buffer_end_user_action(tresc);

}


char *my_utf8_capitalsent(char *str,int len)
{
	GString *gs;
	int umode,znak;
	char *fin;
	if (len<0) len=strlen(str);
	fin=str+len;
	gs=g_string_new("");
	umode=1;
	while (str<fin) {
		znak=g_utf8_get_char(str);
		str=g_utf8_next_char(str);
		if (g_unichar_isalnum(znak)) {
			if (umode==1) {
				znak=g_unichar_toupper(znak);
				umode=0;
			}
			else znak=g_unichar_tolower(znak);
        }
        else if (g_unichar_isspace(znak)) {
            if (umode==2) umode=1;
        }
        else if (znak < 128 && strchr(".?!",znak)) {
            umode=1;
        }
		g_string_append_unichar(gs,znak);
	}
	return g_string_free(gs,0);
}

#ifdef HAVE_MORFOLOGIK
#include <dlfcn.h>
void *morfologik_dll=NULL;
static int morfologik_dll_checked;
int (*my_IdentifyWord)(void *,char *,char **,char **,char **,void *);
int (*my_IdentifyNext)(void *,int,char **,char **,char **,void *);

void init_morfologik(void)
{
	int typ;
	if (morfologik_dll_checked) return;
	morfologik_dll_checked=1;
	typ=morfo_get_value();
	if (typ < 0 || typ > 2) return;
	
	morfologik_dll=dlopen("libmorfologik.so",RTLD_LAZY);
	if (!morfologik_dll) return;
	my_IdentifyWord=(void *) dlsym(morfologik_dll,"morfologik_IdentifyWordStd");
	if (!my_IdentifyWord) {
		my_IdentifyWord=(void *) dlsym(morfologik_dll,"morfologik_IdentifyWord");
	}
	if (!my_IdentifyWord) {
		morfologik_dll=NULL;
		return;
	}
	my_IdentifyNext=(void *) dlsym(morfologik_dll,"morfologik_IdentifyNext");
	if (!my_IdentifyNext) {
		morfologik_dll=NULL;
		return;
	}
	check_morfo_shm();
	if (!morfologik_shm) morfologik_dll=NULL;
}


#ifdef HAVE_MORFOLOGIK
#define WT_SHIFT 58
#define WT_GET(a) (((a) >> WT_SHIFT) & 31)

int morfologik_is_verb(char *word)
{
	init_morfologik();
	if (!morfologik_shm) return -1;
	u_int64_t grama;
	int nr=my_IdentifyWord(morfologik_shm,word,NULL,NULL,NULL,&grama);
	while (nr >= 0) {
		int w=WT_GET(grama);
		if (w == 16 || w == 6 || w == 7 || w == 8 || w == 9) return 1;
		nr=my_IdentifyNext(morfologik_shm,nr,NULL,NULL,NULL,&grama);
	}
	return 0;
}
#endif
	


static int morfoIsUpper(char *str)
{
	static char **lowercasers;
	static int lowercasers_ok=0;
	char *pisownia;
	int i,rc,ucase,found,znak;
	if (!lowercasers_ok) {
		char *rmem,*c;
		int count;
		lowercasers_ok=1;
		if (g_file_get_contents(
			DATADIR "/lowercasers.dat",
			&rmem,
			NULL,
			NULL)) {
			for (count=2,c=rmem;*c;) {
				if (*c++=='\n') i += count;
			}
			lowercasers=malloc(count * sizeof(char *));
			i=0;
			c=rmem;
			
			while (c && *c) {
				while (*c && *c=='\n') c++;
				if (!*c) break;
				lowercasers[i++]=c;
				c=strchr(c,'\n');
				if (!c) break;
				*c++=0;
			}
			lowercasers[i++]=0;
		}
		else {
			lowercasers=malloc(3*sizeof(char *));
			lowercasers[0]="tutaj";
			lowercasers[1]=NULL;
		}
	}
	for (i=0;lowercasers[i];i++) if (!strcmp(lowercasers[i],str)) {
		return 0;
	}
	ucase=found=0;
	rc=my_IdentifyWord(morfologik_shm,str,
			&pisownia,NULL,NULL,NULL);
	while (rc >= 0 && ucase == 0) {
		found=1;
		znak=g_utf8_get_char(pisownia);
		if (g_unichar_isupper(znak)) {
			pisownia=g_utf8_next_char(pisownia);
			if (*pisownia && !g_unichar_isupper(g_utf8_get_char(pisownia))) {
				ucase=1;
				break;
			}
		}
		rc=my_IdentifyNext(morfologik_shm,rc,
				&pisownia,NULL,NULL,NULL);
	}
	return !found || ucase;
}



#endif

char *my_utf8_capitalize_morfol(char *str,int len)
{

#ifdef HAVE_MORFOLOGIK
	int umode,znak;
	char *fin;
	GString *gs,*gsd;
	init_morfologik();
	if (!morfologik_dll) 
		return my_utf8_capitalsent(str,len);
	if (len < 0) len=strlen(str);
	fin=str+len;
	
	umode=1;
	gs=g_string_new("");
	gsd=g_string_new("");
	while (str < fin) {
		znak=g_utf8_get_char(str);
		str=g_utf8_next_char(str);
		if (!g_unichar_isalnum(znak)) {
			if (znak < 128 && strchr(".?!",znak)) {
				umode=1;
			}
			g_string_append_unichar(gs,znak);
			continue;
		}
		if (umode == 1) {
			umode=0;
			znak=g_unichar_toupper(znak);
			g_string_append_unichar(gs,znak);
			while (str < fin) {
				znak=g_utf8_get_char(str);
				if (!g_unichar_isalnum(znak)) break;
				g_string_append_unichar(gs,g_unichar_tolower(znak));
				str=g_utf8_next_char(str);
			}
			continue;
		}
		g_string_assign(gsd,"");
		g_string_append_unichar(gsd,g_unichar_tolower(znak));
		if (str < fin && *str=='.') {
			// initial?
			g_string_append_unichar(gs,g_unichar_toupper(znak));
			continue;
		}
		while (str < fin) {
			znak=g_utf8_get_char(str);
			if (!g_unichar_isalnum(znak)) break;
			g_string_append_unichar(gsd,g_unichar_tolower(znak));
			str=g_utf8_next_char(str);
		}
		//printf("GSD [%s]\n",gsd->str);
		if (morfoIsUpper(gsd->str)) {
			znak=g_unichar_toupper(g_utf8_get_char(gsd->str));
			g_string_append_unichar(gs,znak);
			g_string_append(gs,g_utf8_next_char(gsd->str));
		}
		else {
			g_string_append(gs,gsd->str);
		}
        }
	g_string_free(gsd,1);
	return g_string_free(gs,0);
#else
	return my_utf8_capitalsent(str,len);
#endif
}	


char *my_utf8_capitalize(char *str,int len)
{
	GString *gs;
	int umode,znak;
	char *fin;
	if (len<0) len=strlen(str);
	fin=str+len;
	gs=g_string_new("");
	umode=1;
	while (str<fin) {
		znak=g_utf8_get_char(str);
		str=g_utf8_next_char(str);
		if (g_unichar_isalnum(znak)) {
			if (umode) {
				znak=g_unichar_toupper(znak);
				umode=0;
			}
			else znak=g_unichar_tolower(znak);
		}
		else umode=1;
		g_string_append_unichar(gs,znak);
	}
	return g_string_free(gs,0);
}


void insertPartChapter(GtkWidget *widget,void *data)
{
	GtkTextIter start,end;
	GtkTextMark *m1;
	int loffset,znak,ipar,chapter,ioffset;
	static char *inserts[]={NULL,"#<fb2:/part>",
		"<fb2:epi>","<fb2:epigraph>",
		"<fb2:cite>","<fb2:citation>",
		"<fb2:author>","<fb2:poemtitle>"};
	if (get_current_editor()!=0) return;
	ipar=(int)data;
	m1=gtk_text_buffer_get_insert(tresc);
	gtk_text_buffer_get_iter_at_mark(tresc,&start,m1);
	loffset=gtk_text_iter_get_line_offset(&start);
	if (loffset) gtk_text_iter_backward_chars(&start,loffset);
	
	int get_char_at_iter(GtkTextIter *iter)
	{
		GtkTextIter next=*iter;
		char *s;int znak;
		if (!gtk_text_iter_forward_char(&next)) return 0;
		s=gtk_text_iter_get_text(iter,&next);
		if (!s) return 0;
		znak=g_utf8_get_char(s);
		g_free(s);
		return znak;
	}
	
	
	
	if (ipar) {
		loffset=0;
		if (ipar == 1) {
			znak=get_char_at_iter(&start);
			if (znak == '#') {
				gtk_text_iter_forward_char(&start);
				loffset=1;
			}
		}
		char *c=inserts[ipar];
		gtk_text_buffer_begin_user_action(tresc);
		gtk_text_buffer_insert(tresc,&start,c+loffset,-1);
		gtk_text_buffer_end_user_action(tresc);
		return;
	}
	end=start;
	
	if (!gtk_text_iter_forward_to_line_end(&end)) return;
	chapter=0;
	while (1) {
		znak=get_char_at_iter(&end);
		if (!znak) return;
		if (!g_unichar_isspace(znak)) break;
		gtk_text_iter_forward_char(&end);
	}
	if (znak == '#') {
		chapter=1;
	}
	gtk_text_buffer_begin_user_action(tresc);
	char *stri=gtk_text_iter_get_text(&start,&end);
	if (chapter) {
		gtk_text_iter_forward_char(&end);
	}
	ioffset=gtk_text_iter_get_offset(&start);
	gtk_text_buffer_delete(tresc,&start,&end);
	GString *gs=g_string_new("#<fb2:part>");
	char *s=trim(stri);
	if (*s == '#') s++;
	g_string_append(gs,s);
	if (chapter) g_string_append(gs,"<fb2:chapter>");
	else g_string_append(gs,"\n\n");
	gtk_text_buffer_get_iter_at_offset(tresc,&start,ioffset);
	gtk_text_buffer_insert(tresc,&start,gs->str,-1);
	g_string_free(gs,TRUE);
	g_free(stri);
	gtk_text_buffer_end_user_action(tresc);
	return;
}

		
		
		


void editor_ulcase(GtkWidget *widget,void *data)
{
	GtkTextMark *m1,*m2;
	GtkTextIter start,finish;
	char *str,*ustr;
	int sc,idata;
	char *bolditalic(char *str,int len)
	{
		GString *gs;
		if (len < 0) len=strlen(str);
		gs=g_string_new("");
		g_string_printf(gs,"<%c>%-*.*s</%c>",
			(idata == 4)?'b':'i',
			len,len,str,
			(idata == 4)?'b':'i');
		return g_string_free(gs,0);
	}
	
	
	if (get_current_editor()!=0) return;
	m1=gtk_text_buffer_get_insert(tresc);
	m2=gtk_text_buffer_get_selection_bound(tresc);
	gtk_text_buffer_get_iter_at_mark(tresc,&start,m1);
	gtk_text_buffer_get_iter_at_mark(tresc,&finish,m2);
	idata=(int)data;
    if (gtk_text_iter_equal(&start,&finish)) {
        if (idata < 2) return;
        int ofset=gtk_text_iter_get_line_offset(&start);
        if (ofset) gtk_text_iter_backward_chars(&start,ofset);
        gtk_text_iter_forward_to_line_end(&finish);
        if (gtk_text_iter_equal(&start,&finish)) return;
    }
	str=gtk_text_buffer_get_text(tresc,&start,&finish,FALSE);
	if (idata==1) {
		ustr=g_utf8_strup(str,-1);
	}
	else if (idata==2) {
		ustr=my_utf8_capitalize(str,-1);
	}
	else if (idata==3) {
		//ustr=my_utf8_capitalsent(str,-1);
		ustr=my_utf8_capitalize_morfol(str,-1);
	}
	else if (idata == 0) {
		ustr=g_utf8_strdown(str,-1);
	}
	else {
		ustr=bolditalic(str,-1);
	}
	sc=strcmp(str,ustr);
	//printf("A1=%s, A2=%s, S=%d\n",str,ustr,sc);
	g_free(str);
	if (sc) {
		int n1=gtk_text_iter_get_offset(&start);
		int n2=gtk_text_iter_get_offset(&finish);
		if (n1 > n2) n1=n2;
		gtk_text_buffer_begin_user_action(tresc);
		gtk_text_buffer_delete(tresc,&start,&finish);
		gtk_text_buffer_insert(tresc,&start,ustr,strlen(ustr));
		//gtk_text_buffer_place_cursor(tresc,&start);
		gtk_text_buffer_get_iter_at_offset(tresc,&start,n1);
		finish=start;
		gtk_text_iter_forward_chars(&finish,g_utf8_strlen(ustr,-1));
		gtk_text_buffer_select_range(tresc,&start,&finish);
		//gtk_text_buffer_place_cursor(tresc,&finish);
		//gtk_text_view_scroll_to_iter(tresc_v,&start,0.2,FALSE,0.0,0.0);
		gtk_text_buffer_end_user_action(tresc);
	}
	g_free(ustr);
}

static char recoder_uname[32];
//static int recoder_ux[128];
static int *recoder_ux;

static struct recoder_data {
	char *name;
	int data[128];
} recoder_data[2]={{"CP1250",{
        8364,0,8218,0,8222,8230,8224,8225,0,8240,352,8249,346,356,381,377,
        0,8216,8217,8220,8221,8226,8211,8212,0,8482,353,8250,347,357,382,378,
        160,711,728,321,164,260,166,167,168,169,350,171,172,173,174,379,
        176,177,731,322,180,181,182,183,184,261,351,187,317,733,318,380,
        340,193,194,258,196,313,262,199,268,201,280,203,282,205,206,270,
        272,323,327,211,212,336,214,215,344,366,218,368,220,221,354,223,
        341,225,226,259,228,314,263,231,269,233,281,235,283,237,238,271,
        273,324,328,243,244,337,246,247,345,367,250,369,252,253,355,729}},
{"ISO-8859-2",{
        128,129,130,131,132,133,134,135,136,137,138,139,140,141,142,143,
        144,145,146,147,148,149,150,151,152,153,154,155,156,157,158,159,
        160,260,728,321,164,317,346,167,168,352,350,356,377,173,381,379,
        176,261,731,322,180,318,347,711,184,353,351,357,378,733,382,380,
        340,193,194,258,196,313,262,199,268,201,280,203,282,205,206,270,
        272,323,327,211,212,336,214,215,344,366,218,368,220,221,354,223,
        341,225,226,259,228,314,263,231,269,233,281,235,283,237,238,271,
        273,324,328,243,244,337,246,247,345,367,250,369,252,253,355,729
        }}};


static int recoder_read_encoding(char *enc)
{
	int i;
	if(!strcmp(recoder_uname,enc)) return 1;
	for (i=0;i<2;i++) {
		if (!strcmp(enc,recoder_data[i].name)) break;
	}
	if (i>=2) {
		Error("Błąd","Nie mogę wczytać tablicy kodowania");
		return 0;
	}
	strcpy(recoder_uname,recoder_data[i].name);
	recoder_ux=recoder_data[i].data;
	return 1;
}


void editor_fake_latin(GtkWidget *widget,void *data)
{
	GtkTextIter start,finish;
	char *str,*ustr,*c,*d;
	int sc,len;

	int gzn(int sc)
	{
		if (sc>=128 && sc <256) sc=recoder_ux[sc&0x7f];
		else if (sc == 0x153) sc=0x15b;
		else if (sc == 0x152) sc=0x15a;
		else if (sc == 0x178) sc=0x17a;
		/* a jak jest duże 'Ź'? */
		return sc;
	}

	if (get_current_editor()<0) return;
	if (!recoder_read_encoding((char *)data)) return;
	gtk_text_buffer_get_start_iter(tresc,&start);
	gtk_text_buffer_get_end_iter(tresc,&finish);


	str=gtk_text_buffer_get_text(tresc,&start,&finish,FALSE);
	len=1;
	for (c=str;*c;c=g_utf8_next_char(c)) {
		sc=g_utf8_get_char(c);
		sc=gzn(sc);
		if (sc < 128) len++;
		else if (sc <=0x7ff) len+=2;
		else if (sc <=0xffff) len+=3;
		else continue;
	}
	ustr=g_malloc(len);
	for (c=str,d=ustr;*c;c=g_utf8_next_char(c)) {
		sc=g_utf8_get_char(c);
		sc=gzn(sc);
		if (sc < 128) {
			*d++=sc;
		}
		else if (sc <= 0x7ff) {
			*d++=(sc>>6) | 0xc0;
			*d++=(sc & 0x3f) | 0x80;
		}
		else if (sc <= 0xffff) {
			*d++=(sc>>12) | 0xe0;
			*d++=((sc >> 6) & 0x3f) | 0x80;
			*d++=(sc & 0x3f) | 0x80;
		}
		else continue;
	}
	*d=0;
	g_free(str);
	gtk_text_buffer_begin_user_action(tresc);
	gtk_text_buffer_set_text(tresc,ustr,-1);
	gtk_text_buffer_get_start_iter(tresc,&start);
	gtk_text_buffer_place_cursor(tresc,&start);
	gtk_text_buffer_end_user_action(tresc);
	g_free(ustr);
}

void autocorrect_dialog_connections(GtkWidget *widget,void *dummy)
{
	GtkTextIter start;
    if (get_current_editor()) return;
	int tres=get_current_timeres();
	if (!tres) {
		Error("Błąd","Plik nie zaczyna się od #TIMERES");
		return;
	}
    char *txt=get_actual_body();
    char *str=txt;
    int count=0;int size=0;
    for (;;) {
        while (str > txt) {
            str--;
            if (*str == '\n') {
                str++;
                break;
            }
        }
        int n=jacosub_find_dialcon(str,&size,tres,1);
        if (n<0) break;
        count++;
        str+=n;
	//printf("Kopiuję [%-20.20s] do [%-20.20s]\n",str+size,str);
        mystrcpy(str,str+size);
    }
    if (!count) {
        Info("Napisy","Nie znaleziono połączeń kwestii");
    }
    else {
        InfoF(NULL,"Napisy","Znalezione połączenia: %d",count);
	//printf("%s\n",txt);
        gtk_text_buffer_begin_user_action(tresc);
        gtk_text_buffer_set_text(tresc,txt,-1);
        gtk_text_buffer_get_start_iter(tresc,&start);
        gtk_text_buffer_place_cursor(tresc,&start);
        gtk_text_buffer_end_user_action(tresc);
    }
    g_free(txt);
}

void find_dialog_connection(GtkWidget *widget,void *dummy)
{

	GtkTextIter pos,end;int n,size;
	if (get_current_editor()) return;
	int tres=get_current_timeres();
	if (!tres) {
		Error("Błąd","Plik nie zaczyna się od #TIMERES");
		return;
	}
	GtkTextMark *sel=gtk_text_buffer_get_selection_bound(tresc);
	gtk_text_buffer_get_iter_at_mark(tresc,&pos,sel);
	int cnt=gtk_text_iter_get_line_offset(&pos);
	if (cnt) gtk_text_iter_backward_chars(&pos,cnt);
	gtk_text_buffer_get_end_iter(tresc,&end);
	char *txt=gtk_text_buffer_get_slice(tresc,&pos,&end,FALSE);
	n=jacosub_find_dialcon(txt,&size,tres,0);
	if (txt) g_free(txt);
	if (n<0) {
		if (a11y_not_found) {
			not_found();
			return;
		}
	}
	gtk_text_iter_forward_chars(&pos,n);
	end=pos;
	gtk_text_iter_forward_chars(&end,size);
	gtk_text_buffer_select_range(tresc,&pos,&end);
	gtk_text_view_scroll_to_iter(tresc_v,&pos,0.2,FALSE,0.0,0.0);
	return;
}

void find_scanner_error(GtkWidget *widget, void *dummy)
{
	GtkTextIter start,end;
	char *str;
	int len;

	if (get_current_editor()) return;

	GtkTextMark *sel=gtk_text_buffer_get_selection_bound(tresc);
	gtk_text_buffer_get_iter_at_mark(tresc,&start,sel);
	gtk_text_buffer_get_end_iter(tresc,&end);
	str=gtk_text_iter_get_text(&start,&end);
	int pos=find_bad_construction(str,&len);
	if (pos>=0) {
		int ofs=g_utf8_strlen(str,pos);
		gtk_text_iter_forward_chars(&start,ofs);
		end=start;
		gtk_text_iter_forward_chars(&end,len);
		gtk_text_buffer_select_range(tresc,&start,&end);
		gtk_text_view_scroll_to_iter(tresc_v,&start,0.2,FALSE,0.0,0.0);
	}
	else {
		not_found();
	}
	g_free(str);
}


//static GtkWidget *search_entry,*replace_label,*replace_entry;
//static GtkWidget *search_regex,*search_case,*search_word,*search_bword,*search_eword,*search_backward,*search_extw;
//static GtkWidget *search_replace_selection,*replace_box;


static struct libre_item {
	struct libre_item *next;
	int flags;
	char *name;
	char *search;
	char *replace;
} *libre_item_list;

static int libre_list_initialized;
static void add_libre_item(char *name,char *search,char *replace,int flags,int sorted)
{
	struct libre_item **lli,*li;
	for (lli=&libre_item_list;*lli;lli=&(*lli)->next) {
		if (sorted && strcmp(name,(*lli)->name)<0) break;
	}
	li=g_malloc(sizeof(*li));
	li->next=*lli;
	*lli=li;
	li->name=g_strdup(name);
	li->search=g_strdup(search);
	li->replace=replace?g_strdup(replace):NULL;
	li->flags=flags;
}


static struct libre_item *read_libre_item(FILE *f)
{
	char buf[8192],*cs;
	struct libre_item *li;
	int is_rep,flags;

	if (!fgets(buf,8192,f)) return NULL;
	cs=trim(buf);
	if (*cs=='R') is_rep=1;
	else if (*cs=='S') is_rep=0;
	else return NULL;
	cs++;
	if (*cs++!=':') return NULL;
	flags=0;
	for (;*cs && *cs!=':';cs++) {
			if (*cs=='r') flags |=1;
			else if (*cs=='c') flags |= 2;
			else if (*cs=='w') flags |= 4;
			else if (*cs=='b') flags |= 8;
			else if (*cs=='e') flags |= 16;
	}
	if (*cs++!=':') return NULL;
	li=g_malloc(sizeof(*li));
	li->name=g_strdup(cs);
	li->search=NULL;
	li->replace=NULL;
	li->flags=flags;
	if (!fgets(buf,8192,f)) {
		g_free(li->name);
		g_free(li);
		return NULL;
	}
	cs=strchr(buf,'\n');
	if (cs) *cs=0;
	li->search=g_strdup(buf);
	if (is_rep) {
		if (!fgets(buf,8192,f)) {
			g_free(li->name);
			g_free(li->search);
			g_free(li);
			return NULL;
		}
		cs=strchr(buf,'\n');
		if (cs) *cs=0;
		li->replace=g_strdup(buf);
	}
	return li;
}

void initialize_libre_list(void)
{
	FILE *f;char fname[256];int i;
	if (libre_list_initialized) return;
	libre_list_initialized=1;
	for (i=0;i<2;i++) {
		if (!i) sprintf(fname,"%s/.milena_abc_reglib",getenv("HOME"));
		else strcpy(fname,DATADIR"/milena_abc_reglib");
		f=fopen(fname,"r");
		if (f) {
			struct libre_item **lli,*li;
			while ((li=read_libre_item(f))) {
				for (lli=&libre_item_list;*lli;lli=&(*lli)->next) {
					if (strcmp(li->name,(*lli)->name)<0) break;
				}
				li->next=*lli;
				*lli=li;
			}
			fclose(f);
		}
		if (libre_item_list) return;
	}
	add_libre_item("Przeniesienie wyrazu","(\\p{Ll})-\\n(\\p{Ll})","\\1\\2",1,1);
	add_libre_item("Przeniesienie linii","(\\p{Ll})\\n(\\p{Ll})","\\1 \\2",1,1);
	add_libre_item("Podejrzany koniec linii","[^.?!:]$",NULL,1,1);
}


static void save_libre_item(struct libre_item *li,FILE *f)
{
	fprintf(f,"%s:",li->replace?"R":"S");
	if (li->flags & 1) fprintf(f,"r");
	if (li->flags & 2) fprintf(f,"c");
	if (li->flags & 4) fprintf(f,"w");
	if (li->flags & 8) fprintf(f,"b");
	if (li->flags & 16) fprintf(f,"e");
	fprintf(f,":%s\n",li->name);
	fprintf(f,"%s\n",li->search);
	if (li->replace) fprintf(f,"%s\n",li->replace);
}

static void save_libre(void)
{
	struct libre_item *li;
	FILE *f;char fname[256];
	sprintf(fname,"%s/.milena_abc_reglib",getenv("HOME"));
	f=fopen(fname,"w");
	if (!f) return;
	for (li=libre_item_list;li;li=li->next) save_libre_item(li,f);
	fclose(f);
}


static void libre_set(void)
{
	char *rep;int flags;

	char *str=(char *)gtk_entry_get_text((gpointer) search_entry);
	if (!str || !*str) {
		return;
	}
	flags=0;
	if (gtk_toggle_button_get_active((gpointer)search_regex)) flags |=1;
	if (gtk_toggle_button_get_active((gpointer)search_case)) flags |=2;
	if (gtk_toggle_button_get_active((gpointer)search_word)) flags |=4;
	if (gtk_toggle_button_get_active((gpointer)search_bword)) flags |= 8;
	if (gtk_toggle_button_get_active((gpointer)search_eword)) flags |=16;
	rep=NULL;
	if (editor_do_replace) rep=(char *)gtk_entry_get_text((gpointer) replace_entry);
	char *name=AskString2("Pytanie","Podaj nazwę wyrażenia",search_dialog);
	if (!name) return;
	add_libre_item(name,str,rep,flags,1);
	g_free(name);
	save_libre();
	Info2("Informacja","Dodane",search_dialog);
	return;
}

static void libre_get(void)
{
	openSearchLibWindow(NULL,(void *)1);
	return;
}
static GtkTreeView *search_treeview;
static GtkListStore *search_liststore;
static GtkWidget *libre_dialog;
static GtkWidget *libre_name_entry,*libre_search_entry,*libre_replace_entry,*libre_flags_cb[5];

static struct libre_item *tree_last_libre_item;
static GtkTreeIter tree_last_iter_libre;
void libre_get_row_on_cursor(void)
{
	struct libre_item *li;
	int i;

	if (!libre_search_entry) return;
	GtkTreeSelection *sel=gtk_tree_view_get_selection(search_treeview);
	GtkTreeModel *model;
	if (!gtk_tree_selection_get_selected(sel,&model,&tree_last_iter_libre)) {
		gtk_entry_set_text((gpointer)libre_search_entry,"");
		gtk_entry_set_text((gpointer)libre_replace_entry,"");
		gtk_entry_set_text((gpointer)libre_name_entry,"");
		gtk_widget_set_sensitive(libre_search_entry,FALSE);
		gtk_widget_set_sensitive(libre_replace_entry,FALSE);
		gtk_widget_set_sensitive(libre_name_entry,FALSE);
		for (i=0;i<5;i++) {
			gtk_widget_set_sensitive(libre_flags_cb[i],FALSE);
			gtk_toggle_button_set_active((gpointer)libre_flags_cb[i],FALSE);
		}
		tree_last_libre_item=NULL;
		return;
	}
	gtk_tree_model_get(model,&tree_last_iter_libre,2,&li,-1);
	if (tree_last_libre_item == li) return;
	tree_last_libre_item=li;
	gtk_widget_set_sensitive(libre_search_entry,TRUE);
	gtk_widget_set_sensitive(libre_name_entry,TRUE);
	gtk_entry_set_text((gpointer)libre_search_entry,li->search);
	gtk_entry_set_text((gpointer)libre_name_entry,li->name);
	if (li->replace) {
		gtk_widget_set_sensitive(libre_replace_entry,TRUE);
		gtk_entry_set_text((gpointer)libre_replace_entry,li->replace);
	} else {
		gtk_entry_set_text((gpointer)libre_replace_entry,"");
		gtk_widget_set_sensitive(libre_replace_entry,FALSE);
	}
	for (i=0;i<5;i++) {
		gtk_widget_set_sensitive(libre_flags_cb[i],TRUE);
		gtk_toggle_button_set_active((gpointer)libre_flags_cb[i],li->flags & (1<<i));
	}
}

static void libre_dele(void)
{
	if (!tree_last_libre_item) return;
	char buf[1024];struct libre_item **lli;
	sprintf(buf,"Na pewno usuwasz\n%s?",tree_last_libre_item->name);
	for (lli=&libre_item_list;*lli;lli=&(*lli)->next) {
		if ((*lli) == tree_last_libre_item) break;
	}
	if (!*lli) return;
	if (!Ask2("Pytanie",buf,libre_dialog)) return;
	(*lli)=tree_last_libre_item->next;
	g_free(tree_last_libre_item->name);
	g_free(tree_last_libre_item->search);
	if (tree_last_libre_item->replace) g_free(tree_last_libre_item->replace);
	g_free(tree_last_libre_item);
	gtk_list_store_remove(search_liststore, &tree_last_iter_libre);
	save_libre();
	libre_get_row_on_cursor();
}
static void libre_store(void)
{
	char const *c;int flags,i;
	if (!tree_last_libre_item) return;
	if (!libre_name_entry) return;
	c=gtk_entry_get_text((gpointer)libre_search_entry);
	for (i=flags=0;i<5;i++) if (gtk_toggle_button_get_active((gpointer)libre_flags_cb[i])) flags |= 1<<i;
	if (strcmp(c,tree_last_libre_item->search)) {
/*
		if (flags & 1) { //regexp
			pcre *pcr=pcre_compile(str,flags,&err,&eoffset,NULL);
			if (!pcr) {
				Error("Błąd kompilacji",(char *)err);
				return;
			}
			pcre_free(pcr);
		}
*/
		g_free(tree_last_libre_item->search);
		tree_last_libre_item->search=g_strdup(c);
	}
	if (tree_last_libre_item->replace) {
		c=gtk_entry_get_text((gpointer)libre_replace_entry);
		if (strcmp(c,tree_last_libre_item->replace)) {
			g_free(tree_last_libre_item->replace);
			tree_last_libre_item->replace=g_strdup(c);
		}
	}
	c=gtk_entry_get_text((gpointer)libre_name_entry);
	if (strcmp(c,tree_last_libre_item->name)) {
		g_free(tree_last_libre_item->name);
		tree_last_libre_item->name=g_strdup(c);
		gtk_list_store_set (search_liststore, &tree_last_iter_libre,
                      0, c,-1);
	}
	tree_last_libre_item->flags=flags;
	save_libre();
	Info2("Informacja","Zapisane",libre_dialog);
}

static GtkWidget *createSearchLibDialog(int mode)
{
	struct libre_item *li;
	static char *cbs[]={"RegExp","Wielkość","Słowo","Początek słowa","Koniec słowa"};
	int i;
	GtkWidget *dialog=gtk_dialog_new_with_buttons(
		"Biblioteka",
		mode?(gpointer)search_dialog:(gpointer)main_window,
		GTK_DIALOG_MODAL,
		GTK_STOCK_OK,GTK_RESPONSE_ACCEPT,
		mode?GTK_STOCK_CANCEL:NULL,GTK_RESPONSE_REJECT,
		NULL);
	GtkTreeIter iter;
	GtkWidget *box=gtk_dialog_get_content_area((gpointer)dialog);
	GtkWidget *vbox=gtk_vbox_new(0,2);
	gtk_box_pack_start(GTK_BOX(box),(gpointer)vbox,FALSE,FALSE,0);


	search_treeview=(gpointer)gtk_tree_view_new();
	GtkCellRenderer *renderer=gtk_cell_renderer_text_new();
	gtk_tree_view_insert_column_with_attributes (search_treeview,-1,
                                               "Nazwa wyrażenia",
                                               renderer,
                                               "text", 0, NULL);
	renderer=gtk_cell_renderer_text_new();
	gtk_tree_view_insert_column_with_attributes (search_treeview,-1,
                                               "Typ",
                                               renderer,
                                               "text", 1, NULL);

	search_liststore=gtk_list_store_new(3,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_POINTER);
	gtk_tree_view_set_model(search_treeview,(gpointer)search_liststore);
	g_object_unref(search_liststore);

	GtkTreeViewColumn *cols[2];
	cols[0]=gtk_tree_view_get_column(search_treeview,0);
	cols[1]=gtk_tree_view_get_column(search_treeview,1);
	gtk_tree_view_column_set_sizing(cols[0],GTK_TREE_VIEW_COLUMN_FIXED);
	gtk_tree_view_column_set_fixed_width(cols[0],320);
	gtk_tree_view_column_set_sizing(cols[1],GTK_TREE_VIEW_COLUMN_FIXED);
	gtk_tree_view_column_set_fixed_width(cols[1],64);


	for (li=libre_item_list;li;li=li->next) {
		gtk_list_store_append (search_liststore, &iter);
		gtk_list_store_set (search_liststore, &iter,
                      0, li->name,
                      1, li->replace?"Zamiana":"Szukaj",
                      2, li,
                      -1);
	}
#ifndef HAVE_GTK3
	gtk_widget_set_size_request((gpointer)search_treeview,mode?390:-1,300);
#endif
	GtkWidget *w=(gpointer)gtk_scrolled_window_new(NULL,NULL);
	gtk_box_pack_start(GTK_BOX(vbox),(gpointer)w,FALSE,FALSE,0);
	gtk_container_add((gpointer)w,(gpointer)search_treeview);
#ifdef HAVE_GTK3
	gtk_widget_set_size_request((gpointer)w,mode?390:-1,300);
#endif
    libre_search_entry=NULL;
	libre_name_entry=NULL;
	libre_replace_entry=NULL;
	if (!mode) {
		GtkWidget *stable=gtk_table_new(2,3,0);
		gtk_box_pack_start(GTK_BOX(vbox),stable,FALSE,FALSE,0);
		GtkWidget *label=gtk_label_new("Nazwa");
		libre_name_entry=gtk_entry_new();
		connect_label(label,libre_name_entry);
		gtk_table_attach_defaults((gpointer)stable,label,0,1,0,1);
		gtk_table_attach_defaults((gpointer)stable,libre_name_entry,1,2,0,1);
		label=gtk_label_new("Szukaj");
		libre_search_entry=gtk_entry_new();
		connect_label(label,libre_search_entry);
		gtk_table_attach_defaults((gpointer)stable,label,0,1,1,2);
		gtk_table_attach_defaults((gpointer)stable,libre_search_entry,1,2,1,2);
		label=gtk_label_new("Zamień na");
		libre_replace_entry=gtk_entry_new();
		connect_label(label,libre_replace_entry);
		gtk_table_attach_defaults((gpointer)stable,label,0,1,2,3);
		gtk_table_attach_defaults((gpointer)stable,libre_replace_entry,1,2,2,3);
		GtkWidget *hbox=gtk_hbox_new(0,2);
		for (i=0;i<5;i++) {
			libre_flags_cb[i]=(gpointer)gtk_check_button_new_with_label(cbs[i]);
			gtk_box_pack_start((gpointer)hbox,libre_flags_cb[i],FALSE,FALSE,0);
		}
		gtk_box_pack_start((gpointer)vbox,hbox,FALSE,FALSE,0);
		hbox=gtk_hbox_new(0,2);
		GtkWidget *but=gtk_button_new_with_mnemonic("_Usuń");
		g_signal_connect((gpointer)but,"clicked",(gpointer)libre_dele,NULL);
	    gtk_box_pack_start((gpointer)hbox,but,FALSE,FALSE,0);
	    but=gtk_button_new_with_mnemonic("_Zapisz");
		g_signal_connect((gpointer)but,"clicked",(gpointer)libre_store,NULL);
	    gtk_box_pack_end((gpointer)hbox,but,FALSE,FALSE,0);
		gtk_box_pack_start((gpointer)vbox,hbox,FALSE,FALSE,0);
		g_signal_connect(G_OBJECT(gtk_tree_view_get_selection(search_treeview)),"changed",(gpointer)libre_get_row_on_cursor,NULL);

	}

	tree_last_libre_item=NULL;
	gtk_widget_show_all(box);
	return dialog;

}
void openSearchLibWindow(GtkWidget *widget,void *dummy)
{
	int mode=(int)dummy;
	int n;
	struct libre_item *li;

	libre_dialog=createSearchLibDialog(mode);
	void retco(void)
	{
		gtk_dialog_response((gpointer)libre_dialog,GTK_RESPONSE_ACCEPT);
	}
	if (!mode) libre_get_row_on_cursor();
	else {
		g_signal_connect((gpointer)search_treeview,"row-activated",(gpointer)retco,NULL);
	}
	n=gtk_dialog_run((gpointer)libre_dialog);
	li=NULL;
	if (mode && (n == GTK_RESPONSE_ACCEPT)) {
		GtkTreeSelection *sel=gtk_tree_view_get_selection(search_treeview);
		GtkTreeIter iter;
		GtkTreeModel *model;
		if (gtk_tree_selection_get_selected(sel,&model,&iter)) {
			gtk_tree_model_get(model,&iter,2,&li,-1);
		}
	}
	gtk_widget_destroy(libre_dialog);
	if (li) {
		gtk_entry_set_text((gpointer)search_entry,li->search);
		if (editor_do_replace) {
			char *c="";
			if (li->replace) c=li->replace;
			gtk_entry_set_text((gpointer)replace_entry,c);
		}
		gtk_toggle_button_set_active((gpointer)search_regex,li->flags & 1);
		gtk_toggle_button_set_active((gpointer)search_case,li->flags & 2);
		gtk_toggle_button_set_active((gpointer)search_word,li->flags & 4);
		gtk_toggle_button_set_active((gpointer)search_bword,li->flags & 8);
		gtk_toggle_button_set_active((gpointer)search_eword,li->flags & 16);
	}
}

static char autonumber_pattern[10]="@@";
void edit_autonumber(void)
{
    GtkTextIter pos,start,end;
    GtkTextMark *sel;
    int found=0;
    char fbuf[128];
    char *pattern;
    if (get_current_editor()!=MILEDIT_MODE_NORMAL) return;
    pattern=AskStringP("Pytanko","Podaj wzorzec do autonumeracji",autonumber_pattern);
    if (!pattern) return;
    if (!*pattern) {
        g_free(pattern);
        return;
    }
    if (strlen(pattern)>5) {
        Error("Błąd","Wzorzec może zawierać maksymalnie 5 znaków");
        g_free(pattern);
        return;
    }
    strcpy(autonumber_pattern,pattern);
    g_free(pattern);
    gtk_text_buffer_get_start_iter(tresc,&pos);
    for (;;) {
        if (!gtk_source_iter_forward_search(&pos,
            autonumber_pattern,
            GTK_SOURCE_SEARCH_TEXT_ONLY | GTK_SOURCE_SEARCH_VISIBLE_ONLY,
            &start,&end,NULL)) break;
        gtk_text_buffer_select_range(tresc,&start,&end);
        found++;
        sprintf(fbuf,"%d",found);
        if (found == 1) {
            gtk_text_buffer_begin_user_action (tresc);
        }
        //printf("Found %d\n",found);
		gtk_text_buffer_delete_selection (tresc, FALSE, TRUE);
		gtk_text_buffer_insert_at_cursor (tresc, fbuf, strlen (fbuf));
        sel=gtk_text_buffer_get_selection_bound(tresc);
        gtk_text_buffer_get_iter_at_mark(tresc,&pos,sel);
    }
    if (!found) Error("Błąd","Nie znaleziono żadnego wystąpienia wzorca");
	else {
    	gtk_text_buffer_end_user_action (tresc);
        gtk_text_view_scroll_to_iter(tresc_v,&pos,0.2,FALSE,0.0,0.0);
        sprintf(fbuf,"Ilość autonumeracji: %d",found);
        Info("Informacja",fbuf);
    }
}

void editor_glue_dashspace(GtkWidget *widget,void *dummy)
{
    GtkTextIter start,end;
    char *str,*c,*d;
    gunichar g;
    GString *gstr;
    if (get_current_editor()!=MILEDIT_MODE_NORMAL) return;
    if (!gtk_text_buffer_get_selection_bounds(tresc,&start,&end)) return;
    str=gtk_text_buffer_get_text(tresc,&start,&end,FALSE);
    gstr=g_string_sized_new(strlen(str));
    for (c=d=str;*c;) {
        g=g_utf8_get_char(c);
        if (!g_unichar_isspace(g) && !unichar_dash(g)) {
            g_string_append_unichar(gstr,g);
        }
        c=g_utf8_next_char(c);
    }
    gtk_text_buffer_begin_user_action (tresc);
    int n1=gtk_text_iter_get_offset(&start);
    int n2=gtk_text_iter_get_offset(&end);
    gtk_text_buffer_delete(tresc,&start,&end);
    gtk_text_buffer_insert(tresc,&start,gstr->str,-1);
    if (n1 > n2) n1=n2;
    gtk_text_buffer_get_iter_at_offset(tresc,&start,n1);
    end=start;
    gtk_text_iter_forward_chars(&end,g_utf8_strlen(gstr->str,-1));
    gtk_text_buffer_select_range(tresc,&start,&end);
    gtk_text_buffer_end_user_action (tresc);
    g_free(str);
    g_string_free(gstr,TRUE);
}

char *get_word_at_cursor(GtkTextBuffer *t,int highlight)
{
    GtkTextIter start,end;
    char *str;
    gtk_text_buffer_get_selection_bounds(t,&start,&end);
    if (!gtk_text_iter_starts_word(&start)) {
        if (!gtk_text_iter_backward_word_start(&start)) return NULL;
    }
    end=start;
    if (!gtk_text_iter_forward_word_end(&end)) return NULL;
    if (highlight) {
        gtk_text_buffer_select_range(t,&start,&end);
    }
    str=gtk_text_buffer_get_text(t,&start,&end,FALSE);

    if (!str) return NULL;
    if (!*str) {
        g_free(str);
        return NULL;
    }
    return str;
}

void editorFindCover(GtkWidget *widget, void *param)
{
    GtkTextIter start,end;
    void urlenc(GString *gs,char *str)
    {
        for (;*str;str++) {
            if (isalnum(*str) || strchr(".-_",*str)) {
                g_string_append_c(gs,*str);
            }
            else {
                g_string_append_printf(gs,"%%%02X",(*str) & 255);
            }
        }
    }
    if (get_current_editor()!=MILEDIT_MODE_NORMAL) return;
	gtk_text_buffer_get_start_iter((gpointer)tresc,&start);
    end=start;
    gtk_text_iter_forward_line(&end);
    char *c=gtk_text_buffer_get_text(tresc,&start,&end,FALSE);
    GString *str;

    if (param) {
		str=g_string_new("http://www.bing.com/images/search?pq=");
		urlenc(str,c);
		g_string_append(str,"&sc=0-13&sp=-1&sk=&qpvt=");
		urlenc(str,c);
		g_string_append(str,"&q=");
		urlenc(str,c);
		g_string_append(str,"&qft=+(filterui:imagesize-medium+|+filterui:imagesize-large)+filterui:aspect-tall&FORM=R5IR8");
	}
    else {
		str=g_string_new("http://www.google.com/search?oe=UTF-8&um=1&ie=UTF-8&tbm=isch&hl=pl&tbs=iar:t&q=");
		urlenc(str,c);
	}
    g_free(c);
    c=g_string_free(str,FALSE);
#ifdef USE_WEBKIT
    browser(c);
#else
        gtk_show_uri(NULL,c,GDK_CURRENT_TIME,NULL);
#endif
    g_free(c);
}

void edit_autochapter(GtkWidget *widget,void *data)
{

    GtkTextIter start,end;
    GtkTextMark *sel;
    int cnt,npar,i,spliter;
    char *txt,*etxt,*c,*str;
    struct {
        char *text;
        int length;
        int ptype;
        int flags;
    } *paragraphs;
    GString *gs=NULL;
    int llimit=20000,hlimit=40000;

    char ebuf[128];

    if (get_current_editor()) return;

	c=(char *)gtk_entry_get_text((gpointer)char_split);
	if (!*c || ((*c) & 0x80)) {
		Error("Błąd","Nielegalny znak podziału");
		return;
	}
	spliter=*c;


    /* pobieram tekst od bieżącej linii,
     * w niej wstawię pierwszy rozdział */

	sel=gtk_text_buffer_get_insert(tresc);
	gtk_text_buffer_get_iter_at_mark(tresc,&start,sel);
	cnt=gtk_text_iter_get_line_offset(&start);
	if (cnt) gtk_text_iter_backward_chars(&start,cnt);
    gtk_text_buffer_get_end_iter((gpointer)tresc,&end);
    txt=gtk_text_buffer_get_text(tresc,&start,&end,FALSE);
    sprintf(ebuf,"\n%c",spliter);
    etxt=strstr(txt,ebuf);
    if (!etxt) etxt=txt+strlen(txt);
    else etxt++;
    if ((etxt-txt) < 10000) {
        g_free(txt);
        Error("Błąd","Za krótki fragment do podziału");
        return;
    }
    for (npar=2,c=txt;c < etxt;c++) if (*c=='\n') npar++;
    if (npar < 4) {
        g_free(txt);
        Error("Błąd","Za mało akapitów do podziału");
        return;
    }
    paragraphs=g_malloc(sizeof(*paragraphs) * npar);
    memset(paragraphs,0,sizeof(*paragraphs) * npar);
    paragraphs[0].text=txt;
    for (npar=1,c=txt; c < etxt;c++) {
        if (*c == '\n' && c < etxt-1) {
            paragraphs[npar++].text=c+1;
        }
    }
    for (i=0;i<npar;i++) {
        int found=0;
        gunichar g;
        for (c=paragraphs[i].text;*c && *c != '\n';) {
            g=g_utf8_get_char(c);
            if (g_unichar_isalnum(g)) {
                found=1;
                break;
            }
            c=g_utf8_next_char(c);
        }
        paragraphs[i].flags=found;
    }
    for (i=0;i<npar;i++) if (paragraphs[i].flags) break;
    if (i>=npar) {
        Error("Błąd","Brak jakichkolwiek czytelnych akapitów");
        goto efree;
    }
    for (cnt=1;;) {
        for (;i<npar;i++) if (!paragraphs[i].flags) break;
        for (;i<npar;i++) if (paragraphs[i].flags) break;
        if (i>=npar) break;
        paragraphs[cnt++]=paragraphs[i];
    }
    npar=cnt;
    for (i=0;i<npar-1;i++) {
        paragraphs[i].length=paragraphs[i+1].text-paragraphs[i].text;
    }
    paragraphs[i].length=etxt-paragraphs[i].text;
    paragraphs[0].flags=1;
    for (i=1;i<npar;i++) paragraphs[i].flags=0;

    int beg=0;
    int len=0;
    for (;;) {
        len=0;
        if (beg >= npar-1) break;
        for (i=beg;i<npar;i++) len+=paragraphs[i].length;
        if (len <= llimit) break;
        if (len <= hlimit) {
            int l;
            for (i=beg,l=0;i<npar && l < len/2; i++) {
                l+=paragraphs[i].length;
            }
            if (len-l >= llimit/2) {
                paragraphs[i].flags = 1;
            }
            break;
        }
        len=0;
        for (i=beg;i<npar;i++) {
            if (len + paragraphs[i].length > llimit) break;
            len+=paragraphs[i].length;
        }
        beg=i+1;
        paragraphs[i].flags = 1;
    }
    for (i=0,len=0,cnt=0;i<npar;i++) {
        if (paragraphs[i].flags) {
            cnt++;
        }
    }
    sprintf(ebuf,"Podaj wzorzec autonumeracji do podziału na %d rozdziałów",cnt);
    char *patr;
    for (;;) {
        patr=AskStringP("Autopodział",ebuf,autonumber_pattern);
        if (!patr) goto efree;
        if (!*patr || strlen(patr)>5) {
            sprintf(ebuf,"Długość wzorca to od 1 do 5 znaków\nPodaj wzorzec autonumeracji do podziału na %d rozdziałów",cnt);
            g_free(patr);
            continue;
        }
        strcpy(autonumber_pattern,patr);
        g_free(patr);
        break;
    }
    sprintf(ebuf,"\n%cRozdział %s\n\n",spliter,autonumber_pattern);
    //if (!AskF(NULL,"Pytanie","Podzielić na %d rozdziałów?",cnt)) goto efree;
    gtk_combo_box_set_active((gpointer)combo_split,1);
    gs=g_string_sized_new(1024+(etxt-txt));
    for (i=0;i<npar;i++) {
        if (paragraphs[i].flags && (i > 0 || *txt != spliter)) {
            g_string_append(gs,ebuf);
        }
        g_string_append_len(gs,paragraphs[i].text,paragraphs[i].length);
    }
    str=g_string_free(gs,FALSE);
    gtk_text_buffer_begin_user_action(tresc);
    gtk_text_buffer_delete(tresc,&start,&end);
    gtk_text_buffer_insert(tresc,&start,str,-1);
	gtk_text_buffer_end_user_action(tresc);
    g_free(str);

efree:
    g_free(paragraphs);
    g_free(txt);
}

void editorNormalizeText(GtkWidget *widget, void *data)
{
    if (get_current_editor()) return;
    char *str=get_actual_body();
    char *c,*d,*e;
    int line_start;
    int spaces;
    gunichar g;
    line_start=1;
    spaces=0;
    for (d=c=str;*c;) {
        if (*c=='\r') {
            c++;
            if (*c=='\n') c++;
            *d++='\n';
            line_start=1;
            spaces=0;
            e=c;
            continue;
        }
        if (*c=='\n') {
            *d++=*c++;
            line_start=1;
            spaces=0;
            e=c;
            continue;
        }
        g=g_utf8_get_char(c);
        e=g_utf8_next_char(c);
        if (g_unichar_isspace(g)) {
            spaces=1;
            c=e;
        }
        else {
            if (spaces && !line_start) *d++=' ';
            while (c < e) *d++=*c++;
            line_start=0;
            spaces=0;
        }
    }
    *d=0;
    gtk_text_buffer_begin_user_action(tresc);
    gtk_text_buffer_set_text(tresc,str,-1);
	gtk_text_buffer_end_user_action(tresc);
    g_free(str);
}

void editorInsertImage(GtkWidget *widget, void *data)
{
    GtkTextIter start,end;
    char *str,*cs,xpath[PATH_MAX+1],ypath[PATH_MAX+1];

    void append_qh(GString *gs,char *s)
    {
        for (;*s;s++) {
            if (*s=='<') g_string_append(gs,"&lt;");
            else if (*s=='>') g_string_append(gs,"&gt;");
            else if (*s=='&') g_string_append(gs,"&amp;");
            else if (*s=='"') g_string_append(gs,"&quot;");
            else g_string_append_c(gs,*s);
        }
    }

    if (get_current_editor()) return;
    if (current_editor->save_name[0]) cs=current_editor->save_name;
	else if (current_editor->load_name[0]) cs=current_editor->load_name;
    else if (last_file_path[0]) cs=last_file_path;
    else return;
    strcpy(xpath,cs);
    cs=strrchr(xpath,'/');
    if (cs) *cs++=0;
    else xpath[0]=0;
    gtk_text_buffer_get_selection_bounds(tresc,&start,&end);

	GtkWidget *dialog=gtk_file_chooser_dialog_new("Wybierz plik obrazka",
		GTK_WINDOW(main_window),GTK_FILE_CHOOSER_ACTION_OPEN,
		GTK_STOCK_CANCEL, GTK_RESPONSE_CANCEL,
		GTK_STOCK_OPEN, GTK_RESPONSE_ACCEPT,
		NULL);
	GtkFileFilter *filter;
    int rc=0;
	gtk_file_chooser_set_local_only((gpointer)dialog,TRUE);
    gtk_file_chooser_add_filter((gpointer) dialog,
            filter=make_filter("Pliki graficzne","*.jpg","*.JPG","*.jpeg","*.JPEG",
                "*.GIF","*.gif","*.PNG","*.png",
                "*.BMP","*.bmp",NULL));
    gtk_file_chooser_add_filter((gpointer) dialog,
            make_filter("Wszystkie pliki","*",NULL));
	gtk_file_chooser_set_filter((gpointer) dialog,filter);
	gtk_file_chooser_set_current_folder((gpointer)dialog,xpath);
    ICPAddPreview((gpointer)dialog);
    rc=gtk_dialog_run((gpointer)dialog);
    if (rc !=GTK_RESPONSE_ACCEPT) {
        gtk_widget_destroy(dialog);
        return;
    }
    strcpy(ypath,gtk_file_chooser_get_filename((gpointer)dialog));
    gtk_widget_destroy(dialog);
    cs=strrchr(ypath,'/');
    if (cs) {
        *cs=0;
        if (!strcmp(xpath,ypath)) strcpy(ypath,cs+1);
        else *cs='/';
    }
    str=gtk_text_buffer_get_text(tresc,&start,&end,FALSE);
	GString *gs=g_string_new("<fb2:img src=\"");
    append_qh(gs,ypath);
    g_string_append(gs,"\" alt=\"");
    append_qh(gs,str);
    g_string_append(gs,"\">");
    g_free(str);
	gtk_text_buffer_begin_user_action(tresc);
    gtk_text_buffer_delete(tresc,&start,&end);
    gtk_text_buffer_insert(tresc,&start,gs->str,-1);
    g_string_free(gs,TRUE);
    gtk_text_buffer_place_cursor(tresc,&start);
	gtk_text_buffer_end_user_action(tresc);
}
