/*
 * imgchp.c - Milena Audiobook Creator
 * Copyright (C) Bohdan R. Rau 2011 <ethanak@polip.com>
 *
 *     This program is free software; you can redistribute it and/or modify
 *     it under the terms of the GNU General Public License as published by
 *     the Free Software Foundation; either version 3 of the License, or
 *     (at your option) any later version.
 *
 *     This program is distributed in the hope that it will be useful,
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.    See the
 *     GNU General Public License for more details.
 *
 *     You should have received a copy of the GNU General Public License
 *     along with this program; if not, write see:
 *                             <http://www.gnu.org/licenses/>.
 */

#include "config.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>
#include <sys/stat.h>
#include "gmilena.h"
#include <glib/gstdio.h>


struct wh {
    int width;
    int height;
    int owidth;
    int oheight;
};

#define info ((struct wh *)wh_info)
static void
size_prepared_cb (GdkPixbufLoader *loader,
                  int width,
                  int height,
                  gpointer wh_info)
{
    info->owidth=width;
    info->oheight=height;
    if (height > info->height || width > info->width) {
        if ((double)height * (double)info->width >
                (double)width * (double)info->height) {
            width = 0.5 + (double)width * (double)info->height / (double)height;
            height = info->height;
        } else {
            height = 0.5 + (double)height * (double)info->width / (double)width;
            width = info->width;
        }
    }
    gdk_pixbuf_loader_set_size (loader, width, height);
}

GdkPixbuf *
my_new_from_file_at_size (const char *filename,struct wh *wh)
{
    GdkPixbufLoader *loader;
    GdkPixbuf       *pixbuf;
    struct stat st;
    guchar buffer [4096];
    int length;
    FILE *f;

    if (g_stat (filename, &st) != 0) return NULL;
    if (!S_ISREG (st.st_mode)) return NULL;
    f = g_fopen (filename, "rb");
    if (!f) return NULL;
    loader = gdk_pixbuf_loader_new ();
    g_signal_connect (loader, "size-prepared", G_CALLBACK (&size_prepared_cb), wh);
    while (!feof (f)) {
        length = fread (buffer, 1, sizeof (buffer), f);
        if (length <= 0) break;
        if (!gdk_pixbuf_loader_write (loader, buffer, length, NULL)) {
            gdk_pixbuf_loader_close (loader, NULL);
            fclose (f);
            g_object_unref (G_OBJECT (loader));
            return NULL;
        }
    }
    fclose (f);
    if (!gdk_pixbuf_loader_close (loader, NULL)) {
        g_object_unref (G_OBJECT (loader));
        return NULL;
    }
    pixbuf = gdk_pixbuf_loader_get_pixbuf (loader);
    if (pixbuf) g_object_ref(pixbuf);
    g_object_unref (G_OBJECT (loader));
    return pixbuf;
}

static void
update_preview_cb (GtkFileChooser *file_chooser, gpointer data)
{
    GtkWidget *preview;
    char *filename;
    GdkPixbuf *pixbuf;
    char bbf[64];
    struct wh wh;
    preview = GTK_WIDGET (data);
    filename = gtk_file_chooser_get_preview_filename (file_chooser);
    if (!filename) {
        gtk_file_chooser_set_preview_widget_active (file_chooser, FALSE);
        return;
    }
    wh.width=128;
    wh.height=192;
    pixbuf = my_new_from_file_at_size (filename, &wh);
    if (pixbuf) {
        sprintf(bbf,"%d×%d",wh.owidth,wh.oheight);
    }
    else bbf[0]=0;
    
    void fun(GtkWidget *child,void *data)
    {
        if (GTK_IS_IMAGE(child)) {
            gtk_image_set_from_pixbuf (GTK_IMAGE (child), pixbuf);
        }
        else if (GTK_IS_LABEL(child)) {
            char const *c=gtk_widget_get_name(child);
            if (!strcmp(c,"fdim")) {
                gtk_label_set_text(GTK_LABEL(child),bbf);
            }
            else {
                c=strrchr(filename,'/');
                if (!c) c=filename;
                else c++;
                gtk_label_set_text(GTK_LABEL(child),c);
            }
        }
    }
    
    if (pixbuf) {
        gtk_container_foreach((gpointer)preview,(gpointer)fun,NULL);
        g_object_unref (pixbuf);
    }
    g_free (filename);
    gtk_file_chooser_set_preview_widget_active (file_chooser, (pixbuf != NULL));
}

void ICPAddPreview(GtkFileChooser *chooser)
{
    
    GtkWidget *preview=gtk_vbox_new(0,2);
    GtkWidget *label;
    gtk_box_pack_start((gpointer)preview,(gpointer)gtk_image_new(),0,0,2);
    gtk_box_pack_start((gpointer)preview,label=(gpointer)gtk_label_new(""),0,0,2);
    gtk_widget_set_name(label,"fdim");
#ifndef HAVE_GTK3
    gtk_box_pack_start((gpointer)preview,label=(gpointer)gtk_label_new(""),0,0,2);
    gtk_widget_set_name(label,"fname");
    gtk_label_set_ellipsize((gpointer)label,PANGO_ELLIPSIZE_MIDDLE);
    gtk_widget_set_size_request((gpointer)label,128,22);
#endif
    gtk_file_chooser_set_preview_widget (chooser, (gpointer)preview);
    gtk_file_chooser_set_use_preview_label(chooser,FALSE);
    g_signal_connect (chooser, "update-preview",
                        G_CALLBACK (update_preview_cb), preview);
    gtk_widget_show_all(preview);
}
