/*
 * dykcjonarz.c - Milena Audiobook Creator
 * Copyright (C) Bohdan R. Rau 2009 <ethanak@polip.com>
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write see:
 *               <http://www.gnu.org/licenses/>.
 */
#include "config.h"
#include <gtk/gtk.h>
#include <string.h>
#include <stdlib.h>
#include "gmilena.h"
#include <milena.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <ctype.h>


unsigned long long tica,ticb,ticc;
inline volatile unsigned long long _RDTSC()
{
    unsigned long long x;
    __asm__ volatile (".byte 0x0f, 0x31" : "=A" (x));
    return x;

}


extern char *to_utf8(char *fbuf,int flen,char *cset,int freeme);

static char lci[256]={
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	'0','1','2','3','4','5','6','7','8','9',0,0,0,0,0,0,
	0,'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o',
	'p','q','r','s','t','u','v','w','x','y','z',0,0,0,0,0,
	0,'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o',
	'p','q','r','s','t','u','v','w','x','y','z',0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,'�',0,'�',0,'�','�',0,0,'�','�','�','�',0,'�','�',
	0,'�',0,'�',0,'�','�',0,0,'�','�','�','�',0,'�','�',
	'�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�',
	'�','�','�','�','�','�','�',0,'�','�','�','�','�','�','�','�',
	'�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�',
	'�','�','�','�','�','�','�',0,'�','�','�','�','�','�','�',0};

static char l2u[256]={
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	'0','1','2','3','4','5','6','7','8','9',0,0,0,0,0,0,
	0,'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O',
	'P','Q','R','S','T','U','V','W','X','Y','Z',0,0,0,0,0,
	0,'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O',
	'P','Q','R','S','T','U','V','W','X','Y','Z',0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,'�',0,'�',0,'�','�',0,0,'�','�','�','�',0,'�','�',
	0,'�',0,'�',0,'�','�',0,0,'�','�','�','�',0,'�','�',
	'�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�',
	'�','�','�','�','�','�','�',0,'�','�','�','�','�','�','�','S',
	'�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�',
	'�','�','�','�','�','�','�',0,'�','�','�','�','�','�','�',0};

static char uci[256]={
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
	1,1,1,1,1,1,1,1,1,1,1,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,1,0,1,0,1,1,0,0,1,1,1,1,0,1,1,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
	1,1,1,1,1,1,1,0,1,1,1,1,1,1,1,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};

int my_tolower(int n)
{
    return lci[n & 255];
}


#define STRBLOCK_SIZE 16000
static struct strblock {
	struct strblock *next;
	int pos_str,pos_txt;
	char buf[STRBLOCK_SIZE];
} *memo;

static struct slowo {
	struct slowo *l,*r;
	int flags;
	int count;
	char *str;
	char *homopron;
} *slowa;

static void * alloc_table(int count)
{
    struct strblock *s;
    count *= sizeof(void *);
    /*
    if (memo && memo->pos_str-memo->pos_txt <=count) {
        memo->pos_str-=count;
        return (void *)(memo->buf+memo->pos_str);
    }
    */
    s=g_malloc(sizeof(*s)+count-STRBLOCK_SIZE);
    s->pos_str=s->pos_txt=0;
    if (memo) {
        s->next=memo->next;
        memo->next=s;
    }
    else memo=s;
    return (void *)s->buf;
}

static void alloc_block(void)
{
	struct strblock *s=g_malloc(sizeof(*s));
	s->next=memo;
	memo=s;
	s->pos_txt=STRBLOCK_SIZE;
	s->pos_str=0;
}

static char *dups(char *c)
{
	int l=strlen(c)+1;
	if (memo->pos_str+l>memo->pos_txt) alloc_block();
	memo->pos_txt-=l;
	strcpy(memo->buf+memo->pos_txt,c);
	return memo->buf+memo->pos_txt;
}

static void free_memo(void)
{
	struct strblock *s;
	while ((s=memo)) {
		memo=memo->next;
		g_free(s);
	}
}

static int dash_word_num;

static struct slowo *allocword(void)
{

	struct slowo *s;
	if (memo->pos_str+sizeof(struct slowo)>memo->pos_txt) alloc_block();
	s=(struct slowo *)(memo->buf+memo->pos_str);
	memo->pos_str+=sizeof(struct slowo);
	return s;
}

static void insert_word(struct slowo **s,char *str,int flags)
{
	while (*s) {
		int n=strcmp((*s)->str,str);
		if (n<0) s=&(*s)->l;
		else if (n>0) s=&(*s)->r;
		else break;
	}
	if (!*s) {
		dash_word_num++;
		*s=allocword();
		(*s)->str=dups(str);
		(*s)->l=(*s)->r=NULL;
		(*s)->flags=flags;
        (*s)->count=1;
	}
	else {
        (*s)->flags |= flags;
        (*s)->count++;
    }
}

static int get_dash_word(char **str)
{
	char *s;
	int flags;
	if (!**str) return 0;
	flags=0;
	for (;**str;(*str)++) {
		if (lci[(**str) & 255]) break;
	}
	if (!**str) return 0;
	s=*str;
	for (;**str;(*str)++) {
		if (lci[(**str) & 255]) {
			**str=lci[(**str) & 255];
			continue;
		}
		if (**str !='\'' && **str != '-') break;
		if (!lci[(*str)[1] & 255]) break;
		if (**str=='-') flags=1;
	}
	if (**str) {
		*(*str)++=0;
	}
	if (flags) insert_word(&slowa,s,0);
	return 1;

}

static GString *dash_word_string;



static void append_buf(char *buf,int len)
{
	g_string_append_len(dash_word_string,buf,len);
}

static void dash_walk(struct slowo *s)
{
	char buf[1024];
	while (s) {
		dash_walk(s->r);
		strcpy(buf,s->str);
		strcat(buf,"\n");
		append_buf(buf,-1);
		s=s->l;
	}
}

extern int ignore_oor;
char *get_current_iso2(void)
{
	int n;
	char *str,*istr;
	n=get_current_editor();
	if (n<0) return NULL;

	if (n) {
		Error("Błędne polecenie","Polecenie nie jest możliwe dla trybów DASH i DIC");
		return NULL;
	}
	if (!gtk_text_buffer_get_char_count(tresc)) return NULL;
	str=get_actual_body();
	ignore_oor=1;
	n=to_iso2(str,NULL);
	if (!n) {
		g_free(str);
		return NULL;
	}
	istr=g_malloc(n);
	to_iso2(str,istr);
	g_free(str);
	return istr;
}


void make_dash(GtkWidget *dummy, void *data)
{

	struct MyGtkEditor *edi;
	char *bstr,*str=get_current_iso2();
	if (!str) return;
	memo=NULL;
	slowa=NULL;
	alloc_block();
	bstr=str;
	dash_word_num=0;
	while(get_dash_word(&bstr));
	if (!dash_word_num) {
		Info("Informacja","Brak podejrzanych myślników");
		g_free(str);
		return;
	}
	dash_word_string=g_string_sized_new(65500);
	g_string_append(dash_word_string,
"// Korektor my�lnik�w\n\
// Usu� lini� zawieraj�c� wyrazy, z kt�rych chcesz usun�� my�lniki\n\
// lub\n\
// Zamie� niepotrzebne my�lniki na znak tyldy (~)\n\
// Zamie� na znak plus (+) my�lniki, kt�re chcesz otoczy� spacjami\n\
// Nast�pnie prze��cz si� do okna tre�ci i wybierz \"Zastosuj DASH\"\n\n");

	
	dash_walk(slowa);
	g_free(str);
	str=to_utf8(dash_word_string->str,dash_word_string->len,"ISO-8859-2",0);
    g_string_free(dash_word_string,TRUE);
    free_memo();
	edi=get_subeditor(current_editor,MILEDIT_MODE_DASH);
	set_buffer_text(edi->buf,str,-1,0);
	g_free(str);
}

static char **words,*wrdbdy;
static int wordcnt,wordsiz;

static int morfologik_rbase(void)
{
	int fd,i;
	size_t len;
	char *bdy;
	struct stat sb;

	char fname[PATH_MAX+1];
	sprintf(fname,"%s-words/pl_basewords.dat",milena_GetDataPath());
	if (wordcnt) return 1;
	if (stat(fname,&sb)) {
		g_perror(fname);
		return 0;
	}
	len=sb.st_size;
	fd=open(fname,O_RDONLY);
	if (fd<0) {
		g_perror(fname);
		return 0;
	}

	bdy=g_malloc(len);
	if (read(fd,bdy,len)!=len) {
		g_free(bdy);
		g_perror(fname);
		return 0;
	}
	close(fd);
	wrdbdy=bdy;
	wordcnt=wordsiz=strtol(bdy,NULL,10);
	bdy+=10;
	words=g_malloc(wordcnt*sizeof(*words));
	for (i=0;i<wordcnt;i++) {
		words[i]=bdy;
		bdy+=strlen(bdy)+1;
	}
	return 1;
}

static int morfologik_find(char *c)
{
	int lo,hi,mid,n;
	lo=0;hi=wordcnt-1;
	while (lo<=hi) {
		mid=(lo+hi)/2;
		n=strcmp(words[mid],c);
		if (!n) return 1;
		if (n>0) hi=mid-1;
		else lo=mid+1;
	}
	return 0;
}

static struct dict {
	struct dict *next;
	char *wrd;
	char *trans;
	int mode;
} *sdict,**ssdict;


static char *trans(char *str)
{
	static char buf[8192],buf2[8192];
	int dummy;
	milena_GetPhrase(milena,&str,buf,8192,&dummy);
	milena_Prestresser(milena,buf,buf2,8192);
	milena_TranslatePhrase(milena,(unsigned char *)buf2,buf,8192,0);
    buf2[0]=0;
#ifdef HAVE_IVONA
    if (use_ivona) {
        milena_ivonizer(0,buf,buf2,8192);
    }
    else
#endif
    milena_Poststresser(buf,buf2,8192);
	return buf2;
}

static void outtrans(struct slowo *s)
{
	char buf[8192];
	if ((s->flags & 7) == 1 && l2u[(*s->str) & 255]) {
		buf[0]=l2u[(*s->str) & 255];
		strcpy(buf+1,s->str+1);
	}
	else {
		strcpy(buf,s->str);
	}
	sprintf(buf+strlen(buf)," //%d ",s->count);
	strcat(buf,trans(s->str));
	strcat(buf,"\n");
	append_buf(buf,-1);
}

static int dic_count=0;
static struct dict **dic_array;
int rdic_compar(void **v1,void **v2)
{
    return strcmp((*(struct dict **)v1)->wrd,
        (*(struct dict **)v2)->wrd);
}

void init_rdic(void)
{
    struct dict *d;int i;
    for (d=sdict,dic_count=0;d;d=d->next,dic_count++);
    if (!dic_count) return;
    dic_array=alloc_table(dic_count);
    for (d=sdict,i=0;d;d=d->next) dic_array[i++]=d;
    qsort(dic_array,dic_count,sizeof(struct dict *),(void *)rdic_compar);
    //for(i=0;i<dic_count;i++) printf("%d %s\n",i,dic_array[i]->wrd);
}

int found_rdic(struct slowo *s)
{
    char buf[1024];
    strcpy(buf,s->str);
    int mid,lo,hi,n;
    if ((s->flags & 7) == 1 && l2u[(buf[0]) & 255]) {
        buf[0]=l2u[(buf[0]) & 255];
    }
    lo=0;hi=dic_count-1;
    while (lo <= hi) {
        mid=(lo+hi)/2;
        //printf("Compare %s/%d <%s> i <%s> [%d %d %d]\n",s->str,s->flags,buf,dic_array[mid]->wrd,lo,mid,hi);
        n=strcmp(buf,dic_array[mid]->wrd);
        if (n<0) hi=mid-1;
        else if (n>0) lo=mid+1;
        else return 1;
    }
    return 0;
}

#if 0
static int wequiv(struct slowo *s,char *dic)
{
    if ((s->flags & 7) == 1) {
        if (!l2u[(s->str[0]) & 255]) {
            return !strcmp(s->str,dic);
        }
        if (l2u[(s->str[0]) & 255] != *dic) return 0;
        return !strcmp(s->str+1,dic+1);
    }
    return !strcmp(s->str,dic);
}
#endif
static void walk_check(struct slowo *s)
{
    while(s) {
        walk_check(s->r);
        if (found_rdic(s) || milena_IsIgnoredWord(milena,s->str)) s->flags |= 16;
        s=s->l;
    }
}
static void walk_nomorf(struct slowo *s,int uca)
{
	while (s) {
		walk_nomorf(s->r,uca);
		if (!(s->flags & 16) &&
				((uca && (s->flags & 7) == 1) ||
				(!uca && (s->flags & 7) != 1)))  {
            if (!morfologik_find(s->str)) {
				outtrans(s);
				s->flags |= 16;
			}
		}
		s=s->l;
	}
}
static void walk(struct slowo *s)
{
	static char *pstr="������������������������������������qvx'-";
	//static char *estr="aeiouy���";
	while (s) {
		walk(s->r);
		if (!(s->flags & 16)) {
			if ((s->flags & 3)==1 || strpbrk(s->str,pstr)) { // || !strpbrk(s->str,estr)) {
				outtrans(s);
			}
		}
		s=s->l;
	}
}

static int profiled_mstuw(struct milena *milena,char **str)
{
    int rc;
    ticc=_RDTSC();
    rc=milena_SkipToUnknownWord(milena,str);
    ticb+=(_RDTSC()-ticc);
    return rc;
}

static int get_word(char **str,int *bof)
{
	char *s;
	int flags,lst;
	//int bof;
	if (!**str) return 0;
//	if (!((*bof)=milena_SkipToUnknownWord(milena,str))) {
	if (!((*bof)=profiled_mstuw(milena,str))) {
		return 0;
	}
	s=*str;
	if ((*bof)==2) flags=0;
	else if (uci[(**str) & 255]) flags=1;
	else flags = 2;
//	printf("BOF %d/%d ",*bof,flags);
	for (;**str;(*str)++) {
		if (lci[(**str) & 255]) {
			if (isdigit(**str)) flags |= 4;
			else flags |= 8;
			**str=lci[(**str) & 255];
			continue;
		}
		if (**str !='\'' && **str != '-') break;
		if (!lci[(*str)[1] & 255]) break;
	}
	if ((flags & 12)==4) return 1;
	if (*str - s <3) return 1;
	//(*bof)=1;
	lst=**str;
	if (lst) {
		//if (strchr(".?!\n",**str)) (*bof)=2;
		//*(*str)++=0;
		lst=**str;
		**str=0;
	}
//	printf("[%s]\n",s);
	insert_word(&slowa,s,flags);
	if (lst) **str=lst;
	return 1;

}

static struct dict *allocdict(void)
{

	struct dict *s;
	if (memo->pos_str+sizeof(struct dict)>memo->pos_txt) alloc_block();
	s=(struct dict *)(memo->buf+memo->pos_str);
	memo->pos_str+=sizeof(struct dict);
	return s;
}

void read_dict(char *line,int mode)
{
	char *c,*c1,*c2;
	struct dict *d;
	c=strstr(line,"//");
	if (c) {*c++=0;*c++=0;}
	while (*line && isspace(*line)) line++;
	if (!*line) return;
	for (c=line;*c && !isspace(*c); c++);
	*c++=0;
	while (*c && isspace(*c)) c++;
	for (c1=c2=c;*c1;c1++) if (!isspace(*c1)) c2=c1+1;
	*c2=0;
	d=allocdict();
	d->next=NULL;
	*ssdict=d;
	ssdict=&d->next;
	d->wrd=dups(line);
	d->trans=NULL;
	d->mode=mode;
	if (mode && c && *c) d->trans=dups(c);
}

static int read_dic_file(char *fname,int mode)
{
	FILE *f;
	char buf[1024];
	f=fopen(fname,"r");
	if(!f) {
		g_perror(fname);
		return 0;
	}
	if (mode) {
        memset(buf,0,1024);
        fread(buf,1023,1,f);
        auto_set_langs(buf);
        fseek(f,0,SEEK_SET);
    }
	while(fgets(buf,1024,f)) read_dict(buf,mode);
	fclose(f);
	return 1;
}


static void outdic(struct dict *d)
{
	char buf[8192];
	strcpy(buf,d->wrd);
	strcat(buf," ");
	if (d->trans) {
		strcat(buf,d->trans);
	}
	strcat(buf,"//");
	strcat(buf,trans(d->wrd));
	strcat(buf,"\n");
	append_buf(buf,-1);
}

void dict_from_selection(GtkWidget *dummy, void *data)
{
    struct MyGtkEditor *edi;
    GtkTextIter start,end,loc;
    char *str,*c,*d;
    int chc;

    if (get_current_editor() != 0) return;
    if (!gtk_text_buffer_get_selection_bounds(tresc,&start,&end)) return;
    str=gtk_text_buffer_get_text(tresc,&start,&end,FALSE);
    for (c=d=str;*c;) {
        if (isspace(*c)) {
            *d++='+';
            c++;
            while (*c && isspace(*c)) c++;
            continue;
        }
        *d++=*c++;
    }
    *d=0;

//    c=g_strconcat(str," $//\n",NULL);
//    g_free(str);
//    str=c;
    int slen=strlen(str);
    int pos=-1;

	edi=get_subeditor(current_editor,MILEDIT_MODE_DIC);
    chc=gtk_text_buffer_get_char_count(edi->buf);
    if (chc) {
        char *body;
        gtk_text_buffer_get_bounds(edi->buf,&start,&end);
        body=gtk_text_buffer_get_text(edi->buf,&start,&end,FALSE);
        for (c=body;*c;) {
            if (strncmp(c,str,slen)) {
                goto end_loop;
            }
            c+=slen;
            if (!*c || isspace(*c) || *c=='$' || (*c=='/' && c[1]=='/')) {
                while (*c && *c!='\n' && isspace(*c)) c++;

                pos=c-body;
                break;
            }

end_loop:
            c=strchr(c,'\n');
            if (!c) break;
            c++;
        }
        if (pos>=0) {
            int buflen=g_utf8_strlen(body,pos);
            gtk_text_buffer_get_iter_at_offset(edi->buf,&loc,buflen);
            if (*c=='\n') d=" $//";
            else if (*c=='/') d=" $";
            else if (!*c) d=" $//\n";
            else d=NULL;
            if (d) {
                gtk_text_buffer_insert(edi->buf,&loc,d,-1);
                d=strchr(d,'$');
                if (d && d[1]) {
                    gtk_text_iter_backward_chars(&loc,g_utf8_strlen(d+1,-1));
                }
            }
            gtk_text_buffer_place_cursor(edi->buf,&loc);
            g_free(body);
            g_free(str);
            editor_scroll_to_cursor(edi);
            return;
        }
        g_free(body);
    }
    c=g_strconcat(str," $//\n",NULL);
    g_free(str);
    str=c;
    gtk_text_buffer_get_end_iter(edi->buf,&end);
    start=end;
    if (gtk_text_iter_backward_char(&start)) {
        c=gtk_text_buffer_get_text(edi->buf,&start,&end,FALSE);
        if (*c != '\n') {
            d=g_strconcat("\n",str,NULL);
            g_free(str);
            str=d;
        }
        g_free(c);
    }
    gtk_text_buffer_insert(edi->buf,&end,str,-1);
    c=strchr(str,'$');
    if (c && c[1]) {
        gtk_text_iter_backward_chars(&end,g_utf8_strlen(c,-1));
    }
    g_free(str);
    gtk_text_buffer_place_cursor(edi->buf,&end);
    //editor_scroll_to_cursor(edi);
    //gtk_text_buffer_get_end_iter(edi->buf,&end);
    yield();
    gtk_text_view_scroll_to_iter(edi->view,&end,0.2,FALSE,0,0);
}

static struct glue_word {
    struct glue_word *l;
    struct glue_word *r;
    short done;
    short forced;
    int count;
    char *word;
} *glue_tree;


static void add_glue_word(char *word,int forced)
{
    struct glue_word **ggw,*gw;
    int n;
    ggw=&glue_tree;
    while (*ggw) {
        n=strcmp((*ggw)->word,word);
        if (n<0) ggw=&(*ggw)->l;
        else if (n>0) ggw=&(*ggw)->r;
        else {
            (*ggw)->count++;
            return;
        }
    }
	if (memo->pos_str+sizeof(struct glue_word)>memo->pos_txt) alloc_block();
	gw=(struct glue_word *)(memo->buf+memo->pos_str);
	memo->pos_str+=sizeof(struct glue_word);
    gw->l=gw->r=NULL;
    gw->done=0;
    gw->count=1;
    gw->forced=forced;
    gw->word=dups(word);
    *ggw=gw;
}

static void glue_walk(struct glue_word *tree,int done,int langmask)
{
    char *c;char bcom[32],wbuf[256];
    for (;;) {
        if (!tree) return;
        glue_walk(tree->r,done,langmask);
        c=strchr(tree->word,'~');
        if (c) {
            if (done != 2) goto loop;
            append_buf(tree->word,-1);
            append_buf(" ",1);
            append_buf(tree->word,c-tree->word);
            append_buf(c+1,-1);
            sprintf(bcom," //%d\n",tree->count);
            append_buf(bcom,-1);
            goto loop;
        }
        if (done == 2) goto loop;
        if (done) {
            if (tree->done) goto loop;
            if (done == 3) {
                if (strlen(tree->word)>64) goto loop;
                strcpy(wbuf,tree->word);
                if (!try_find_ocr_error(wbuf,0,langmask)) goto loop;
                tree->done=1;
                append_buf(tree->word,strlen(tree->word));
                append_buf(" ",1);
                append_buf(wbuf,-1);
                sprintf(bcom," //%d\n",tree->count);
                append_buf(bcom,-1);
                goto loop;
            }
            //if (tree->forced) goto loop; // forced tylko w trybie b��du OCR
            append_buf(tree->word,strlen(tree->word));
            sprintf(bcom," //%d\n",tree->count);
            append_buf(bcom,-1);
            goto loop;
        }
        c=unglue_word_perfectly(tree->word);
        if (c) {
            append_buf(tree->word,strlen(tree->word));
            tree->done=1;
            append_buf(" ",1);
            append_buf(c,strlen(c));
            sprintf(bcom," //%d\n",tree->count);
            append_buf(bcom,-1);
        }
loop:
        tree=tree->l;
    }
}


void glue_to_dict(GtkWidget *dummy,void *data)
{
	char *body,*str,*c;
    gunichar g;
    char wordbuf[1024];
    char secbuf[1024];
    char abuf[2048];
    int can_glue=0,was_known=0,is_known=0,is_forced=0,langmask=0;
    int i;
    for (i=0;i<4;i++) {
		if (gtk_check_menu_item_get_active((gpointer)m_ocrtodic[i])) break;
	}
	if (i >= 4) {
		Error("Blad","Zaznacz opcje slownika");
		return;
	}
    int word_is_number(char *w)
    {
        for (;*w;w++) if (!isdigit(*w)) return 0;
        return 1;
    }
    int word_is_roman(char *w)
    {
        // range 0..99
        if (*w == 'L') {
            w++;
            if (*w=='X') w++;
            if (*w=='X') w++;
            if (*w=='X') w++;
        }
        else if (*w == 'X') {
            w++;
            if (*w=='L' || *w=='C') w++;
            else {
                if (*w=='X') {w++;if (*w=='X') w++;}
            }
        }
        if (*w=='V') {
            w++;
            if (*w=='I') w++;
            if (*w=='I') w++;
            if (*w=='I') w++;
        }
        else if (*w=='I') {
            w++;
            if (*w=='X' || *w=='V') w++;
            else {
                if (*w=='I') w++;
                if (*w=='I') w++;
            }
        }
        if (*w) return 0;
        return 1;
    }

    if (get_current_editor() != 0) return;
	if (current_editor->dic_editor) {
		if (!Ask("Pytanko","Słownik już istnieje, czy mam go zastąpić?")) return;
	}
    if (!init_badscan_data()) return;
    body=get_actual_body();
    alloc_block();
    glue_tree=NULL;
    dash_word_string=g_string_sized_new(65500);
    can_glue=0;
    secbuf[0]=0;
    for (i=0;i<NUM_LANGS;i++) if (gtk_toggle_button_get_active((gpointer)lang_cb[i])) {
	langmask |= 1<<i;
    }

    for (str=body;;) {
        while (*str) {
            g=g_utf8_get_char(str);
            if (!g) break;
            if (g_unichar_isalnum(g)) break;
            if (!unichar_dash(g) && g != '\t' && g != ' ') can_glue=0;
            str=g_utf8_next_char(str);
        }
        if (!g || !*str) break;
        c=str;
        for (;;) {
            g=g_utf8_get_char(c);
            if (!g) break;
            if (g=='\'') {
                g=g_utf8_get_char(c+1);
                if (g && g_unichar_isalnum(g)) {
                    c=g_utf8_next_char(c+1);
                    continue;
                }
                break;
            }
            if (!g_unichar_isalnum(g)) break;
            c=g_utf8_next_char(c);
        }
        if (c-str < 1024) {
            memcpy(wordbuf,str,c-str);
            wordbuf[c-str]=0;
        }
        else wordbuf[0]=0;
        str=c;
        if (!wordbuf[0]) {
            can_glue=0;
            continue;
        }
        if (word_is_number(wordbuf) || word_is_roman(wordbuf)) {
            can_glue=0;
            continue;
        }
        is_known=!word_is_unknown(wordbuf);
        is_forced=is_known?is_bad_ocr_word(wordbuf,langmask):0;
        
        if (can_glue && (!is_known || !was_known)) {
            strcpy(abuf,secbuf);
            strcat(abuf,wordbuf);
            if (!word_is_unknown(abuf)) {
                strcpy(abuf,secbuf);
                strcat(abuf,"~");
                strcat(abuf,wordbuf);
                add_glue_word(abuf,0);
            }
        }
        can_glue=1;
        strcpy(secbuf,wordbuf);
        was_known=is_known;
        if (!is_known || is_forced) add_glue_word(wordbuf,is_forced);
    }
    g_free(body);
    append_buf("//#DONOTUSE - nie usuwaj tej linii!!!\n",-1);
    if (gtk_check_menu_item_get_active((gpointer)m_ocrtodic[0])) {
        append_buf("//\n// Bledy OCR/poppler\n//\n\n",-1);
        glue_walk(glue_tree,3,langmask);
    }
    if (gtk_check_menu_item_get_active((gpointer)m_ocrtodic[1])) {
		append_buf("//\n// Mozliwe sklejenia wyrazow\n//\n\n",-1);
		glue_walk(glue_tree,0,langmask);
	}
    if (gtk_check_menu_item_get_active((gpointer)m_ocrtodic[2])) {
		append_buf("\n//\n// Nieznane wyrazy\n//\n\n",-1);
		glue_walk(glue_tree,1,langmask);
	}
    if (gtk_check_menu_item_get_active((gpointer)m_ocrtodic[3])) {
		append_buf("\n//\n// Podzielone wyrazy\n//\n",-1);
		glue_walk(glue_tree,2,langmask);
	}
    g_free(memo);
	struct MyGtkEditor *edi=get_subeditor(current_editor,MILEDIT_MODE_DIC);
	set_buffer_text(edi->buf,dash_word_string->str,dash_word_string->len,0);
    g_string_free(dash_word_string,TRUE);
}


void dict_suggest_word(GtkWidget *dummy,void *data)
{
	GtkTextIter start,end;
	GtkTextMark *sel;
    char wordbuf[1024];
    int langmask=0,i;

    if (get_current_editor() != MILEDIT_MODE_DIC) return;
    if (!init_badscan_data()) return;
    for (i=0;i<NUM_LANGS;i++) if (gtk_toggle_button_get_active((gpointer)lang_cb[i])) {
	langmask |= 1<<i;
    }
    sel=gtk_text_buffer_get_insert(tresc);
	gtk_text_buffer_get_iter_at_mark(tresc,&start,sel);
	while (!gtk_text_iter_starts_line(&start)) {
		gtk_text_iter_backward_cursor_position(&start);
	}
	end=start;
	gtk_text_iter_forward_to_line_end(&end);
	char *str=gtk_text_buffer_get_text(tresc,&start,&end,0);
    char *c=strstr(str,"//");
    if (c) *c=0;
    c=trim(str);
    char *d;
    d=strchr(c,' ');
    if (!d) d=strchr(c,'\t');
    if (d) {
        g_free(str);
        return;
    }
    if (strlen(str)>64) {
        g_free(str);
        return;
    }
    strcpy(wordbuf," ");
    strcat(wordbuf,str);
    int nq=try_find_ocr_error(wordbuf+1,1,langmask);
    if (!nq) strcat(wordbuf," // -");
    gtk_text_iter_forward_chars(&start,
        g_utf8_strlen(str,-1));
    g_free(str);
    gtk_text_buffer_insert(tresc,&start,wordbuf,-1);
    gtk_text_buffer_place_cursor(tresc,&start);
}

struct glue_dic {
    char *chain;
    char *str;
    char *res;
    char *sec;
};

// ogolnie - dowolny slownik

void unglue_with_dict(GtkWidget *dummy, void *data)
{
    char *dbody,*body,*str,*nstr,*c,*d;GtkTextIter start,end;
    struct MyGtkEditor *edi;
    int lcount;
    struct glue_dic *gd;
    int fnd;
    GString *my_str;
    gunichar g;
    char wordbuf[1024];

    char *mreplace(char *c)
    {
        int lo=0;
        int hi=lcount-1;
        int mid,n;
        while (lo <=hi) {
            mid=(lo+hi)/2;
            n=strcmp(c,gd[mid].str);
            if (n<0) hi=mid-1;
            else if (n>0) lo=mid+1;
            else return gd[mid].res;
        }
        return c;
    }

    int mreglue(char *c)
    {
        int lo=0;
        int hi=lcount-1;
        int mid,n;
        while (lo <=hi) {
            mid=(lo+hi)/2;
            n=strcmp(c,gd[mid].str);
            if (n<0) hi=mid-1;
            else if (n>0) lo=mid+1;
            else {
                for (;mid>0;mid--) {
                    if (strcmp(c,gd[mid-1].str)) break;
                }
                return mid;
            }
        }
        return -1;
    }

    int gd_comp(struct glue_dic *v1,struct glue_dic *v2)
    {
        int n=strcmp(v1->str,v2->str);
        if (n) return n;
        if (!v1->sec && !v2->sec) return 0;
        if (!v1->sec) return 1;
        if (!v2->sec) return -1;
        return strcmp(v1->sec,v2->sec);
    }

    if (get_current_editor() != 0) return;
    edi=current_editor->dic_editor;
    if (!edi) return;
    if (gtk_text_buffer_get_char_count(edi->buf)<10) return;
    lcount=gtk_text_buffer_get_line_count(edi->buf);
    if (!lcount) return;
    gtk_text_buffer_get_bounds(edi->buf,&start,&end);
    dbody=gtk_text_buffer_get_text(edi->buf,&start,&end,FALSE);
    gd=g_malloc(sizeof(struct glue_dic)*lcount);
    lcount=0;
    for (str=dbody;*str;) {
        nstr=strchr(str,'\n');
        if (nstr) *nstr++=0;
        else nstr=str+strlen(str);
        c=strstr(str,"//");
        if (c) *c=0;
        c=trim(str);
        str=nstr;
        if (!c) continue;
        for (d=c;*d;d++) if (isspace(*d)) break;
        if (!*d) continue;
        *d++=0;
        d=trim(d);
        if (!*c || !*d) continue;
        gd[lcount].str=c;
        gd[lcount].res=d;
        gd[lcount].chain=0;
        c=strchr(c,'~');
        if (c) *c++=0;
        gd[lcount++].sec=c;
    }
    if (!lcount) {
        g_free(dbody);
        return;
    }
    qsort(gd,lcount,sizeof(*gd),(void *)gd_comp);
    body=get_actual_body();
    my_str=g_string_sized_new(strlen(body)+10*lcount);
    for (str=body;*str;) {
        nstr=str;
        for (;*nstr;) {
            g=g_utf8_get_char(nstr);
            if (g_unichar_isalnum(g)) break;
            nstr=g_utf8_next_char(nstr);
        }
        if (nstr > str) {
            g_string_append_len(my_str,str,nstr-str);
            str=nstr;
        }
        if (!*str) break;
        for (;*nstr;) {
            g=g_utf8_get_char(nstr);
            if (g == '\'') {
                if (!g_unichar_isalnum(g_utf8_get_char(nstr+1))) break;
            }
            else if (!g_unichar_isalnum(g) ) break;
            nstr=g_utf8_next_char(nstr);
        }
        if (nstr-str < 1024) {
            memcpy(wordbuf,str,nstr-str);
            wordbuf[nstr-str]=0;
        }
        else {
            g_string_append_len(my_str,str,nstr-str);
            wordbuf[0]=0;
        }
        str=nstr;
        if (!wordbuf[0]) continue;
        fnd=mreglue(wordbuf);
        if (fnd<0) {
            g_string_append(my_str,wordbuf);
            continue;
        }
        if (!gd[fnd].sec) {
            g_string_append(my_str,gd[fnd].res);
            continue;
        }
        int can_glue=1;
        c=nstr;
        for (;;) {
            g=g_utf8_get_char(c);
            if (g_unichar_isalnum(g)) break;
            if (g!= ' ' && g!='\t' && !unichar_dash(g)) {
                can_glue=0;
                break;
            }
            c=g_utf8_next_char(c);
        }
        if (!can_glue) {
            for (;fnd<lcount;fnd++) {
                if (strcmp(gd[fnd].str,wordbuf)) {
                    fnd=lcount;
                    break;
                }
            }
            if (fnd < lcount && !gd[fnd].sec) {
                g_string_append(my_str,gd[fnd].res);
            }
            else {
                g_string_append(my_str,wordbuf);
            }
            continue;
        }
        int found=0,n=0;
        for (;fnd<lcount;fnd++) {
            if (strcmp(gd[fnd].str,wordbuf)) {
                break;
            }
            if (!gd[fnd].sec) {
                found=2;
                break;
            }
            n=strlen(gd[fnd].sec);
            if (!strncmp(gd[fnd].sec,c,n)) {
                g=g_utf8_get_char(c+n);
                if (!g_unichar_isalnum(g)) {
                    found=1;
                    break;
                }
            }
        }

        if (found) {
            g_string_append(my_str,gd[fnd].res);
            if (found==1) str=c+n;
        }
        else {
            g_string_append(my_str,wordbuf);
        }
    }
    g_free(body);
    g_free(dbody);
    g_free(gd);
	gtk_text_buffer_begin_user_action(tresc);
    gtk_text_buffer_set_text(tresc,my_str->str,-1);
    g_string_free(my_str,TRUE);
	gtk_text_buffer_end_user_action(tresc);

}


void make_dict(GtkWidget *dummy, void *data)
{

	struct MyGtkEditor *edi;
	char *bstr,*str;
	char buf[1024];
	char *extra=NULL;
	struct dict *d;
	int i,nw,bof;struct miltheme *mt;
    int idata=(int)data;

	if (get_current_editor() != 0) return;
	if (current_editor->dic_editor) {
        if (idata == 2) return;
		if (!Ask("Pytanko","Słownik już istnieje, czy mam go zastąpić?")) return;
	}
    if (idata == 2) {
        get_subeditor(current_editor,MILEDIT_MODE_DIC);
        return;
    }
	if (idata == 1) {
		GtkWidget *dialog=gtk_file_chooser_dialog_new("Wybierz plik dodatkowy",
			GTK_WINDOW(main_window),GTK_FILE_CHOOSER_ACTION_OPEN,
			GTK_STOCK_CANCEL, GTK_RESPONSE_CANCEL,
			GTK_STOCK_OPEN, GTK_RESPONSE_ACCEPT,
			NULL);
		GtkFileFilter *filter;
		gtk_file_chooser_set_local_only((gpointer)dialog,TRUE);
		gtk_file_chooser_add_filter((gpointer) dialog,
			filter=make_filter("Pliki DIC","*.dic",NULL));
		gtk_file_chooser_add_filter((gpointer) dialog,
			make_filter("Pliki tekstowe","*.txt","*.TXT",NULL));
		gtk_file_chooser_add_filter((gpointer) dialog,
			make_filter("Wszystkie pliki","*",NULL));
		gtk_file_chooser_set_filter((gpointer) dialog,filter);
		char *cs=gtk_file_chooser_get_filename((gpointer)dic_filechooser);
		if (!cs || !*cs) {
			if (last_file_path[0]) {
				cs=last_file_path;
			}
		}
		if (cs && *cs) {
			char csa[256],*cc;
			strcpy(csa,cs);
			cc=strrchr(csa,'/');
			if (cc) *cc=0;
			gtk_file_chooser_set_current_folder((gpointer)dialog,csa);
		}
		if (gtk_dialog_run((gpointer)dialog)==GTK_RESPONSE_ACCEPT) {
			extra=gtk_file_chooser_get_filename((gpointer)dialog);
		}
		gtk_widget_destroy(dialog);
		if (!extra || !*extra) return;
	}
	else {
		if (!Ask("Pytanko","Na pewno? To potrwa kilka minut.")) return;
	}
#ifdef HAVE_IVONA
    check_ivona_enabled();
#endif
	start_busy_cursor();
	memo=NULL;
	slowa=NULL;
	alloc_block();
	sdict=NULL;
	ssdict=&sdict;
	if (extra && *extra) {
		if (!read_dic_file(extra,1)) {
			end_busy_cursor();
            free_memo();
			return;
		}
    }
	if (!init_milena_libs(1)) {
		Error("Hm...","Milena niezainicjalizowana");
        end_busy_cursor();
        free_memo();
		return;
	}
	if (!(str=get_current_iso2())) {
		Error("Hm...","Brak Current ISO2");
		close_milena_libs();
        end_busy_cursor();
        free_memo();
		return;
	}
	if (!read_dic_file(milena_FilePath("pl_dict.dat",buf),0)) {
		g_free(str);
		close_milena_libs();
		free_memo();
		end_busy_cursor();
		return;
	}
	if (extra && *extra) {
		if (!milena_ReadUserDicWithFlags(milena,extra,MILENA_UDIC_DICTMODE)) {
			g_free(str);
			close_milena_libs();
			free_memo();
			end_busy_cursor();
			return;
		}
	}
	if (!morfologik_rbase()) {
		g_free(str);
		close_milena_libs();
		free_memo();
		end_busy_cursor();
		return;
	}
    init_rdic();
	bstr=str;
	if (!strncmp(bstr,"#TIMERES",8)) {
		char *c=bstr+8;
		if (*c == ' ' || *c=='\t') {
			c++;
			while (*c==' ' || *c=='\t') c++;
			if (*c && isdigit(*c)) {
				c++;
				while (*c && isdigit(*c)) c++;
				if (*c=='\r' || *c=='\n') bstr=c+1;
			}
		}
	}
	dash_word_num=0;
	bof=2;
    //tica=_RDTSC();
    //printf("TICA=%lld\n");
    //ticb=0;
	while(get_word(&bstr,&bof));
    //tica=_RDTSC()-tica;
    //printf("%lld %lld %lld\n",tica,ticb,tica/ticb);
    dash_word_string=g_string_sized_new(1048000);

	strcpy(buf,"//#LANGS:");
	for (i=nw=0;i<NUM_LANGS;i++) if (gtk_toggle_button_get_active((gpointer)lang_cb[i])) {
		if (nw) strcat(buf,",");
		nw++;
		strcat(buf,lang_codes[i]);
	}
	strcat(buf,"\n//#THEMES:");
	for (mt=themes,nw=0;mt;mt=mt->next) if (gtk_toggle_button_get_active((gpointer)mt->cb)) {
		if (nw) strcat(buf,",");
		nw++;
		strcat(buf,mt->tname);
	}
	strcat(buf,"\n\n");
	append_buf(buf,-1);

	if (extra && *extra) {
		int nw=0;
		for (d=sdict;d;d=d->next) {
			if (!d->mode) continue;
			if (!d->trans) {
				if (!nw) {
					char *c;
					c=strrchr(extra,'/');
					if (c) c++;else c=extra;
					sprintf(buf,"\n// POMIJANE z %s\n\n",c);
					append_buf(buf,-1);
					nw=1;
				}
				outdic(d);
			}
		}
		append_buf("\n\n",-1);
	}
/*

	if (extra && *extra) {

		nw=0;
		for (d=sdict;d;d=d->next) {
			if (!d->mode) continue;
			if (d->trans) {
				if (!nw) {
					char *c;
					c=strrchr(extra,'/');
					if (c) c++;else c=extra;
					sprintf(buf,"\n// KOPIA WYMOWY z %s\n\n",c);
					append_buf(buf,-1);
					nw=1;
				}
				outdic(d);
			}
		}
		append_buf("\n\n",-1);
	}
    */
    walk_check(slowa);
    append_buf("// BRAK W MORFOLOGIKU\n\n",-1);
    walk_nomorf(slowa,1);
    walk_nomorf(slowa,0);
	append_buf("\n\n// WYSTEPUJA W MORFOLOGIKU\n\n",-1);
    walk(slowa);



	close_milena_libs();
	g_free(str);
	str=to_utf8(dash_word_string->str,dash_word_string->len,"ISO-8859-2",0);
	free_memo();
    g_string_free(dash_word_string,TRUE);
	edi=get_subeditor(current_editor,MILEDIT_MODE_DIC);
	set_buffer_text(edi->buf,str,-1,0);
	g_free(str);
	end_busy_cursor();

}

static char *find_dash(char *beg,char *end,char *dash)
{
	for (;;) {
		char *c,*d;
		while (*dash && isspace(*dash)) dash++;
		if (*dash == '#') {
			dash=strchr(dash,'\n');
			if (!dash) return NULL;
			continue;
		}
		if (!*dash) return NULL;
		for (c=beg,d=dash;c<end;c++,d++) {
			if (!*d) break;
			if (*c=='\'' && *d=='\'') continue;
			if (*c=='-' && (*d=='~' || *d=='-')) continue;
			if (lci[(*c)&255] != lci[(*d)&255]) break;
		}
		if (c==end) {
			if (!*d || my_space(*d)) return dash;
		}
		while (*dash && !my_space(*dash)) dash++;
	}

}





void apply_dash(GtkWidget *widget,void *dummy)
{
	char *str=get_current_iso2(),*bdy,*ibdy,*efbdy;
	int n;
	struct MyGtkEditor *edi;
	char *ic,*sc,*c;int ws;
    GString *dstr;
	if (!str) return;
	edi=current_editor->dash_editor;
	if (!edi) {
		Error("Błąd","Utwórz DASH i usuń nieprawidłowe");
		g_free(str);
		return;
	}
	bdy=get_editor_body(edi);
	ignore_oor=1;
	efbdy=bdy;
	while (*efbdy) {
	    if (isspace(*efbdy)) {
		efbdy++;
		continue;
	    }
	    if (*efbdy=='/' && efbdy[1] == '/') {
		efbdy=strchr(efbdy,'\n');
		if (!efbdy) {
		    efbdy="";
		    break;
		}
		continue;
	    }
	    break;
	}
	
	n=to_iso2(efbdy,NULL);
	if (!n) ibdy=g_strdup("");
	else {
		ibdy=g_malloc(n);
		to_iso2(efbdy,ibdy);
	}
	g_free(bdy);
	ic=str;
    dstr=g_string_sized_new(strlen(str));
	while (*ic) {
		if (!my_alnum(*ic)) {
			g_string_append_c(dstr,*ic++);
			continue;
		}
		sc=ic;
		ws=0;
		while (*sc) {
			if (my_alnum(*sc)) {
				sc++;
				continue;
			}
			if (*sc != '-' && *sc != '\'') break;
			if (!sc[1] || !my_alnum(sc[1])) break;
			if (*sc=='-') ws=1;
			sc++;
		}
		if (!ws) {
			while (ic<sc) g_string_append_c(dstr,*ic++);
			continue;
		}
		c=find_dash(ic,sc,ibdy);
		if (!c) {
			while (ic<sc) {
				if (*ic != '-') g_string_append_c(dstr,*ic);
				ic++;
			}
			continue;
		}
		while (ic < sc) {
			if (*c=='+') {
                g_string_append(dstr," - ");
			}
			else if (*c != '~') g_string_append_c(dstr,*ic);
			ic++;
			c++;
		}
	}
	g_free(str);
	g_free(ibdy);
    g_string_append_c(dstr,0);
	str=to_utf8(dstr->str,dstr->len,"ISO-8859-2",0);
	g_string_free(dstr,TRUE);
    set_buffer_text(current_editor->buf,str,-1,1);
	g_free(str);
	remove_subeditor(current_editor->dash_editor);
	current_editor->dash_editor=NULL;
}

#if 0

/* format pliku homograph.dat

word translation when...
word ?

przyk�ad:
Julio h~'uljo Juliem Juliowi Juliu
Julia h~'ulja Juliem Juliowi Juliu
Julia j~'ulia Julj� Julj� Julii
Julio j~'ulio Julj� Julj� Julii
Julio ?
Julia ?

*/

#define FHOMO_UCA 1
#define FHOMO_NODEF 2

struct homograph {
    struct homograph *l,*r;
    char *word;
    int flags;
    int filex; // zmiana dla ka�dego nowego pliku
    struct homograph_part {
	struct homograph_part *next;
	char *pron;
	char *conditons;
    } *parts;
}

static int homos_got;

static struct homograph *homos;

/* wczytywanie: dla ka�dego wczytywanego pliku jest nowy filex
 * je�li taki ju� jest a ma inny filex, jego zawarto�� jest
 * podmieniana na now� z nowym filex
 */

/* zwraca wymow�, '?' je�li wymusi� brak domy�lnej, NULL je�li przyj�� domy�ln� */


static struct slowo *homo_find_word(char *str,int uca)
{
	struct slowo *s=slowa;
	while (s) {
		int n=strcmp(s->str,str);
		if (n<0) s=s->l;
		else if (n>0) s=*s->r;
		else break;
	}
	if (!s) return NULL;
	if (uca && (s->flags & 3) != 1) return NULL;
	return s;
	

static char *homo_pronunciation(struct homograph *h)
{
    struct homograph_part *hp;
    char *result=NULL;
    char *c;
    for (hp=h->parts;hp;hp=hp->next) {
	for (c=hp->conditions;c && *c;c+=strlen(c)) {
	    if (!homo_find_word(c+1,slowa,*c=='u')) continue;
	    if (result) return '?';
	    result=hp->pron;
	}
    }
    if (!result && h->nodef) result='?';
    return result;
}

static char *make_homos(struct homograph *branch)
{
    struct homograph *h;
    struct slowo *s;
    if (!homos_got) {
	read_homos();
	homos_got=1;
    }
    if (!branch) branch=homos;
    for (h=homos;h;h=h->r) {
	if (h->l) make_homos(h->l);
	s=homo_find_word(h->word,h->flags & FHOMO_UCA);
	if (!s) continue;
	if ((s->homopron=homo_pronunciation(h))) {
	    s->flags |= 32;
	    if (s->homopron[0]=='?') s->homopron=NULL;
	}
    }
}
#endif
