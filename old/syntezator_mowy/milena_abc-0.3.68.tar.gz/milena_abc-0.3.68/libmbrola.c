/*
 * libmbrola.c - Mbrola driver
 * Copyright (C) Bohdan R. Rau 2009 <ethanak@polip.com>
 *
 * Libmbrola is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * Libmbrola is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with libmbrola.  If not, write to:
 * 	The Free Software Foundation, Inc.,
 * 	51 Franklin Street, Fifth Floor
 * 	Boston, MA  02110-1301, USA.
 */
#include "config.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <ctype.h>
#include <dirent.h>
#include <signal.h>
#include <fcntl.h>
#include <assert.h>
#include <errno.h>
#include <sys/wait.h>

static void mbrola(int *from_mbrola,int *to_mbrola,char *voice,char *bfreq)
{
	char *est[16];
	int n;
	est[0]=(char *)"mbrola";
	n=1;
	if (bfreq) {
		est[n++]="-l";
		est[n++]=bfreq;
	}
	est[n++]="-e";
	est[n++]=strdup(voice);
	est[n++]="-";
	est[n++]="-";
	est[n++]=NULL;
	close(from_mbrola[0]);
	close(to_mbrola[1]);
	dup2(from_mbrola[1],1);
	dup2(to_mbrola[0],0);
	execvp("mbrola",est);
	exit(1);
}

struct mbrola_handler {
	int to_mbrola;
	int from_mbrola;
	int pid;
	int flush_status;
	int error;
};

static int mbr_wpid(struct mbrola_handler *mbr)
{
	int p;
	if (mbr->pid) {
		p=waitpid(mbr->pid,NULL,WNOHANG);
		if (p>=0) {
			if (p) {
				usleep(20000);
				p=waitpid(mbr->pid,NULL,WNOHANG);
			}
			if (!p) {
				kill(mbr->pid,15);
				waitpid(mbr->pid,NULL,0);
			}
		}
	}
	mbr->pid=0;
	mbr->error=1;
	return -1;
}


int write_MBR(struct mbrola_handler *mbr,char *buf)
{
	int n;
	__sighandler_t sig;
	if (mbr->error) return -1;
	sig=signal(SIGPIPE,SIG_IGN);
	n=write(mbr->to_mbrola,buf,strlen(buf));
	signal(SIGPIPE,sig);
	if (!n) return mbr_wpid(mbr);
	if (n<0) {
		if (errno == EAGAIN) return 1;
		return mbr_wpid(mbr);
	}
	return 0;
}

int flush_MBR(struct mbrola_handler *mbr)
{
	int n;
	if (mbr->flush_status == 0) {
		n=write_MBR(mbr,"_ 1\n");
		if (n) return n;
		n=write_MBR(mbr,"#\n");
		if (n>0) mbr->flush_status=1;
		return n;
	}
	n=write_MBR(mbr,"#\n");
	if (!n) mbr->flush_status=0;
	return n;
}


int read_MBR(struct mbrola_handler *mbr,short *buf,int len,int *outlen)
{
	fd_set rdfs;
	struct timeval tv;
	int retval,n;
	__sighandler_t sig;
	if (mbr->error) return -1;
	FD_ZERO(&rdfs);
	FD_SET(mbr->from_mbrola,&rdfs);
	tv.tv_sec=0;
	tv.tv_usec=20000;
	sig=signal(SIGPIPE,SIG_IGN);
	retval=select(mbr->from_mbrola+1,&rdfs,NULL,NULL,&tv);
	if (retval < 0) { // tak nie ma!
		perror("Select");
		exit(0);
	}
	if (!retval) return 1;
	n=read(mbr->from_mbrola,buf,2*len);
	signal(SIGPIPE,sig);
	if (!n) {
		return mbr_wpid(mbr);;
	}
	if (n<0) {
		if (errno == EAGAIN) return 1;
		return mbr_wpid(mbr);
	}
	*outlen=n/2;
	return 0;
}

struct mbrola_handler *init_MBR(char *voice,int freq)
{
	struct mbrola_handler *mbr;
	int to_mbrola[2],from_mbrola[2];
	int pid;
	char isfreq[8];
	if (freq && freq != 16000) {
		sprintf(isfreq,"%d",freq);
	}
	else freq=0;
	mbr=malloc(sizeof(*mbr));
	pipe(to_mbrola);
	pipe(from_mbrola);
	pid=fork();
	if (pid<0) {
		perror("fork");
		exit(1);
	}
	if (pid==0) {
		mbrola(from_mbrola,to_mbrola,voice,freq?isfreq:NULL);
		exit(1);
	}
	close(to_mbrola[0]);
	close(from_mbrola[1]);
	fcntl(to_mbrola[1],F_SETFL,O_NONBLOCK);
	fcntl(from_mbrola[0],F_SETFL,O_NONBLOCK);
	mbr->pid=pid;
	mbr->to_mbrola=to_mbrola[1];
	mbr->from_mbrola=from_mbrola[0];
	mbr->flush_status=0;
	mbr->error=0;
	return mbr;
}

void close_MBR(struct mbrola_handler *mbr)
{
	close(mbr->to_mbrola);
	close(mbr->from_mbrola);
	if (mbr->pid) {
		kill(mbr->pid,15);
		waitpid(mbr->pid,NULL,0);
	}
	free(mbr);
}

