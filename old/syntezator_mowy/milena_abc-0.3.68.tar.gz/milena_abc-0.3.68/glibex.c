/*
 * glibex.c - Milena Audiobook Creator
 * Copyright (C) Bohdan R. Rau 2011 <ethanak@polip.com>
 *
 *     This program is free software; you can redistribute it and/or modify
 *     it under the terms of the GNU General Public License as published by
 *     the Free Software Foundation; either version 3 of the License, or
 *     (at your option) any later version.
 *
 *     This program is distributed in the hope that it will be useful,
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.    See the
 *     GNU General Public License for more details.
 *
 *     You should have received a copy of the GNU General Public License
 *     along with this program; if not, write see:
 *                             <http://www.gnu.org/licenses/>.
 */

#include <glib.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>

#if !GLIB_CHECK_VERSION(2,28,0)
#include <sys/time.h>
gint64 g_get_real_time(void)
{
	gint64 rt;
	struct timeval tv;
	gettimeofday(&tv,NULL);	
	rt=tv.tv_sec;
	rt=1000000 * rt + tv.tv_usec;
	return rt;
}
#endif
void g_string_append_htmlescape(GString *gc,char *c)
{
    char *d;
    for (;*c;) {
        d=strpbrk(c,"\"&<>");
        if (!d) {
            g_string_append(gc,c);
            return;
        }
        g_string_append_len(gc,c,d-c);
        c=d;
        while (*c && strchr("\"&<>",*c)) {
            if (*c=='&') g_string_append(gc,"&amp;");
            else if (*c=='<') g_string_append(gc,"&lt;");
            else if (*c=='>') g_string_append(gc,"&gt;");
            else g_string_append(gc,"&quot;");
            c++;
        }
    }
}

gunichar g_utf8_fetch_char(char **ptr)
{
    gunichar g=g_utf8_get_char(*ptr);
    if (g) *ptr=g_utf8_next_char(*ptr);
    return g;
}

int g_utf8_strncasecmp(char *a1,char *a2,int n)
{
	gunichar g1,g2;
	while (n-- > 0) {
		if (!*a1) {
			if (*a2) return -1;
			return 0;
		}
		if (!*a2) return 1;
		g1=g_utf8_fetch_char(&a1);
		if (!g1) return -1;
		g2=g_utf8_fetch_char(&a2);
		if (!g2) return 1;
		g1=g_unichar_tolower(g1);
		g2=g_unichar_tolower(g2);
		if (g1 < g2) return -1;
		if (g1 > g2) return 1;
	}
	return 0;
}

int g_timer_can_step(gint64 *gt,int msec)
{
	extern int is_slowtimer(void);
	gint64 gta=g_get_real_time();
	if (!is_slowtimer()) return 1;
	if (gta - *gt > msec * 1000) {
		*gt=gta;
		return 1;
	}
	return 0;
}
