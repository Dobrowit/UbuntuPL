/*
 * gtkeditor.c - Milena Audiobook Creator
 * Copyright (C) Bohdan R. Rau 2009 <ethanak@polip.com>
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write see:
 *               <http://www.gnu.org/licenses/>.
 */
#include "config.h"
#include <gtk/gtk.h>
#include <stdlib.h>
#include <string.h>
#include "gmilena.h"

#ifdef HAVE_GTK3
#include <gtksourceview/gtksourcestyleschememanager.h>
#endif

struct MyGtkEditor *editors,*current_editor;


PangoFontDescription *font_desc;
char font_name[256];
void ApplyFont(char *fontname)
{
	struct MyGtkEditor *edi;
	PangoFontDescription *font=pango_font_description_from_string(fontname);
	if (!font) return;
	if (font_desc) pango_font_description_free (font_desc);
	font_desc=font;
	for (edi=editors;edi;edi=edi->next) {
		gtk_widget_modify_font ((gpointer)edi->view, font_desc);
	}
}

#if GTK_CHECK_VERSION(3,2,0)
#define HAVE_GTK32 1
#endif

void ChooseFont(GtkWidget *widget,void *dummy)
{
	GtkWidget *dialog=
#ifdef HAVE_GTK32
	gtk_font_chooser_dialog_new("Wybierz czcionkę edytora",NULL);
#else
	gtk_font_selection_dialog_new("Wybierz czcionkę edytora");
#endif
	if (font_name[0]) {
#ifdef HAVE_GTK32
		gtk_font_chooser_set_font((gpointer)dialog,font_name);
#else
		gtk_font_selection_dialog_set_font_name((gpointer)dialog,font_name);
#endif
	}
#ifdef HAVE_GTK32
	gtk_font_chooser_set_preview_text((gpointer)dialog,
#else
	gtk_font_selection_dialog_set_preview_text((gpointer)dialog,
#endif
		"Pójdź, kińże tę chmurność w głąb flaszy");
	if (gtk_dialog_run((gpointer)dialog)==GTK_RESPONSE_OK) {
		char *c=
#ifdef HAVE_GTK32
		gtk_font_chooser_get_font((gpointer)dialog);
#else
		gtk_font_selection_dialog_get_font_name((gpointer)dialog);
#endif
		strcpy(font_name,c);
		g_free(c);
		ApplyFont(font_name);
	}
	gtk_widget_destroy(dialog);
}

void MyEditorCB(GtkWidget *widget,struct MyGtkEditor *editor)
{
	int n;GtkWidget *label;char const *txt;
	char *c,*d;int pl;
	label=gtk_notebook_get_tab_label((gpointer)notek,(gpointer)editor->window);
	if (!label) return;
	n=gtk_text_buffer_get_modified(editor->buf);
	txt=gtk_label_get_text((gpointer)label);
	for (c=(char *)txt,pl=0;*c;c++) {
		if (*c=='&') pl+=5;
		else if (*c=='<' || *c=='>') pl+=4;
		else pl++;
	}
	char buf[128+pl];
	sprintf(buf,"<span weight=\"%s\">",n?"bold":"normal");
	for (c=(char *)txt,d=buf+strlen(buf);*c;c++) {
		if (*c=='&') {
			strcpy(d,"&amp;");d+=5;
		}
		else if (*c=='<') {
			strcpy(d,"&lt;");d+=4;
		}
		else if (*c=='>') {
			strcpy(d,"&g;");d+=4;
		}
		else *d++=*c;
	}
	strcpy(d,"</span>");
	gtk_label_set_markup((gpointer)label,(gpointer)buf);
}

void show_position_on_sb(struct MyGtkEditor *ed)
{
	static int o_ove=-1,o_line=-1,o_col=-1;
	char buf[64];
	if (!ed) ed=gimma_current_editor();
	if (!ed) {
		gtk_widget_hide(statusbar);
		return;
	}
	gtk_widget_show(statusbar);
	int ove=gtk_text_view_get_overwrite(ed->view);
	GtkTextMark *mark=gtk_text_buffer_get_insert(ed->buf);
	GtkTextIter pos;
	gtk_text_buffer_get_iter_at_mark(ed->buf,&pos,mark);
	int line=gtk_text_iter_get_line(&pos);
	int col=gtk_text_iter_get_line_offset(&pos);
	if (ove != o_ove) {
		o_ove=ove;
		gtk_statusbar_pop((gpointer)statusbar_ove,0);
		gtk_statusbar_push((gpointer)statusbar_ove,0,ove?"Nadpisz":"Wstaw");
	}
	if (o_line != line || o_col !=col) {
		o_line=line;
		o_col=col;
		sprintf(buf,"Linia %d, kol %d",line+1,col+1);
		gtk_statusbar_pop((gpointer)statusbar_line,0);
		gtk_statusbar_push((gpointer)statusbar_line,0,buf);
	}
}

static void (*orig_mark_set)(GtkTextBuffer *widget,GtkTextIter *location,GtkTextMark *mark);
static void (*orig_toggle_ins)(GtkTextView *widget);
static void my_mark_set(GtkTextBuffer *widget,GtkTextIter *location,GtkTextMark *mark)
{
	if (orig_mark_set) orig_mark_set(widget,location,mark);
	struct MyGtkEditor *ed=gimma_current_editor();
	if (!ed || ed->buf != widget) return;
	show_position_on_sb(ed);
}
static void my_toggle_ins(GtkTextView *widget)
{
	if (orig_toggle_ins) orig_toggle_ins(widget);
	struct MyGtkEditor *ed=gimma_current_editor();
	if (!ed || ed->view != widget) return;
	show_position_on_sb(ed);
}

struct MyGtkEditor *CreateEditor(int mode,struct MyGtkEditor *owner,char *label)
{
	struct MyGtkEditor *editor;
	int page;
	static int edino=0;
	editor=g_malloc(sizeof(*editor));
	memset(editor,0,sizeof(*editor));
	editor->view=(gpointer)gtk_source_view_new();
	editor->buf=(gpointer)gtk_text_view_get_buffer(editor->view);
	if (font_desc) gtk_widget_modify_font ((gpointer)editor->view, font_desc);
	gtk_source_view_set_show_line_numbers((gpointer)editor->view,TRUE);
	gtk_source_view_set_highlight_current_line((gpointer)editor->view,TRUE);
	gtk_widget_set_size_request((gpointer)editor->view, 250, 240);
	gtk_text_view_set_left_margin(editor->view,5);
	gtk_text_view_set_right_margin(editor->view,5);
	editor->editor_type=mode;
	
#ifdef HAVE_GTK3
	static GtkSourceStyleSchemeManager *GSM=NULL;
	static GtkSourceStyleScheme *GSS=NULL;
	static char *paths[]={
		"/usr/share/gtksourceview-3.0/styles/",
		DATADIR,
		"/home/ethanak/styles",
		NULL};
		
	if (!GSM) {
		GSM=gtk_source_style_scheme_manager_new();
		gtk_source_style_scheme_manager_set_search_path(GSM,paths);
		GSS=gtk_source_style_scheme_manager_get_scheme(GSM,"milena");
	}
	if (GSS) {
		gtk_source_buffer_set_style_scheme((gpointer)(editor->buf),GSS);
	}
#endif
	
	if (mode == 0) {
		gtk_text_view_set_wrap_mode(editor->view,word_wrap);
		gtk_text_view_set_pixels_below_lines(editor->view,9);
		editor->speaktag=gtk_text_tag_new("speaking");
		g_object_set((gpointer)editor->speaktag,"background","black","foreground","yellow",
			     "justification",GTK_JUSTIFY_FILL,
			     /*"weight",PANGO_WEIGHT_BOLD,"scale",1.5,*/NULL);
		GtkTextTagTable *ta=gtk_text_buffer_get_tag_table(editor->buf);
		gtk_text_tag_table_add(ta,editor->speaktag);
		editor->editor_number = ++edino;
	}
	else {
		gtk_text_view_set_wrap_mode(editor->view,GTK_WRAP_NONE);
		if (owner) {
			editor->editor_number = owner ->editor_number;
			editor->owneditor = owner;
			if (mode == MILEDIT_MODE_DASH) owner->dash_editor=editor;
			else owner->dic_editor=editor;
		}
		else {
			editor->editor_number=0;
		}
	}
	editor->window=(gpointer)gtk_scrolled_window_new(NULL,NULL);
	editor->next=editors;
	editors=current_editor=editor;
	gtk_container_add(GTK_CONTAINER(editor->window),(gpointer)editor->view);
	gtk_widget_show_all((gpointer)editor->window);
	if (!owner) {
		page=gtk_notebook_append_page((gpointer)notek,(gpointer) editor->window,gtk_label_new(label));
	}
	else {
		page=gtk_notebook_page_num((gpointer)notek,(gpointer)owner->window)+1;
		gtk_notebook_insert_page((gpointer)notek,(gpointer)editor->window,gtk_label_new(label),page);
	}
	gtk_notebook_set_current_page((gpointer)notek,page);
	tresc=editor->buf;
	tresc_v=editor->view;
	g_signal_connect(G_OBJECT(tresc),"modified-changed",G_CALLBACK(MyEditorCB),editor);
	menu_active_notek(NULL,NULL);
	
	if (!orig_mark_set) {
		GtkTextBufferClass *bclass=GTK_TEXT_BUFFER_GET_CLASS(editor->buf);
		orig_mark_set=(void *)bclass->mark_set;
		bclass->mark_set=(void *)my_mark_set;
	}
	if (!orig_toggle_ins) {
		GtkTextViewClass *vclass=GTK_TEXT_VIEW_GET_CLASS(editor->view);
		orig_toggle_ins=(void *)vclass->toggle_overwrite;
		vclass->toggle_overwrite=(void *)my_toggle_ins;
	}
	return editor;
	
	//atk_object_set_name(gtk_widget_get_accessible((gpointer)tresc_v),"Edytor");
	//atk_object_set_description(gtk_widget_get_accessible((gpointer)tresc_v),"Główne okno edytora");
}

struct MyGtkEditor *gimma_current_editor(void)
{
	struct MyGtkEditor *editor;
	GtkScrolledWindow *win;
	int npage;
	
	npage=gtk_notebook_get_current_page((gpointer)notek);
	if (npage<0) return NULL;
	win=(gpointer) gtk_notebook_get_nth_page((gpointer)notek,npage);
	for (editor=editors;editor;editor=editor->next) {
		if (win == editor->window) break;
	}
	return editor;

}
int get_current_editor()
{
	struct MyGtkEditor *editor=gimma_current_editor();
	if (!editor) {
		//printf("Cannot find editor\n"); 
		current_editor=NULL;
		tresc=NULL;
		tresc_v=NULL;
		return -1;
	}
	tresc=editor->buf;
	tresc_v=editor->view;
	current_editor=editor;
	return editor->editor_type;
}

void remove_subeditor(struct MyGtkEditor *editor)
{
	int page=gtk_notebook_page_num((gpointer)notek,(gpointer)editor->window);
	gtk_notebook_remove_page((gpointer)notek,page);
	struct MyGtkEditor **edi;
	for (edi=&editors;*edi;edi=&(*edi)->next) {
		if ((*edi) == editor) {
			*edi=editor->next;
			break;
		}
	}
	g_free(editor);
}

void close_current_editor(GtkWidget *dummy,void *data)
{
	struct MyGtkEditor **edi;
	int n;
	if (get_current_editor() < 0) return;
	if (gtk_text_buffer_get_char_count(tresc)) {
		if (!Ask("Pytanie","Zamknąć?")) return;
	}
	n=gtk_notebook_get_current_page((gpointer)notek);
	gtk_notebook_remove_page((gpointer)notek,n);
	for (edi=&editors;*edi;edi=&(*edi)->next) {
		if ((*edi) == current_editor) {
			*edi=current_editor->next;
			break;
		}
	}
	if (current_editor->owneditor) {
		if (current_editor->editor_type == MILEDIT_MODE_DASH) {
			current_editor->owneditor->dash_editor=NULL;
		}
		else if (current_editor->editor_type == MILEDIT_MODE_DIC) {
			current_editor->owneditor->dic_editor=NULL;
		}
	}
	if (current_editor->dash_editor) remove_subeditor(current_editor->dash_editor);
	if (current_editor->dic_editor) remove_subeditor(current_editor->dic_editor);
	
	g_free(current_editor);
}


void show_editor(struct MyGtkEditor *editor)
{
	int page=gtk_notebook_page_num((gpointer)notek,(gpointer)editor->window);
	gtk_notebook_set_current_page((gpointer)notek,page);
	gtk_widget_grab_focus((gpointer)editor->view);
}

void switch_editor(void *dummy,void *bw)
{
	struct MyGtkEditor *cured,*nexted,*preved;
	cured=gimma_current_editor();
	if (!cured) return;
	if (cured->owneditor) cured=cured->owneditor;
	nexted=NULL;
	if (bw) {
		for (nexted=cured->next;nexted;nexted=nexted->next) {
			if (!nexted->editor_type) break;
		}
		if (!nexted) {
			for (preved=editors;preved;preved=preved->next) {
				if (preved == cured) {
					break;
				}
				if (!preved->editor_type) {
					nexted=preved;
					break;
				}
			}
		}
	}
	else {
		for (preved=editors;preved;preved=preved->next) {
			if (preved == cured) {
				break;
			}
			if (!preved->editor_type) nexted=preved;
		}
		if (!nexted) {
			for(preved=cured->next;preved;preved=preved->next) {
				if (!preved->editor_type) nexted=preved;
			}
		}
	}
	if (nexted) show_editor(nexted);
	//printf("CED=%p\n",current_editor);
}


struct MyGtkEditor *get_subeditor(struct MyGtkEditor *editor,int mode)
{
	struct MyGtkEditor **ee;
	if (mode == MILEDIT_MODE_DASH) {
		ee=&editor->dash_editor;
	}
	else if (mode == MILEDIT_MODE_DIC) {
		ee=&editor->dic_editor;
	}
	else return NULL;
	if (*ee) {
		show_editor(*ee);
		return *ee;
	}
	return CreateEditor(mode,editor,
		(mode==MILEDIT_MODE_DIC)?"DIC":"DASH");
}

void swap_editors(GtkWidget *dummy, void *data)
{
	struct MyGtkEditor *e;
	int n=get_current_editor();
	if (n==MILEDIT_MODE_NORMAL) e=(data)?current_editor->dash_editor:
		current_editor->dic_editor?current_editor->dic_editor:
		current_editor->dash_editor;
	else if (n==MILEDIT_MODE_DIC || n==MILEDIT_MODE_DASH) e=current_editor->owneditor;
	else return;
	if (e) show_editor(e);
}

int init_zakladki_cb(void)
{
    struct MyGtkEditor *edi;
    GtkTextIter pos;
	for (edi=editors;edi;edi=edi->next) {
        if (edi->initial_offset) {
            gtk_text_buffer_get_iter_at_offset(edi->buf,&pos,edi->initial_offset);
            edi->initial_offset=0;
            gtk_text_buffer_place_cursor(edi->buf,&pos);
            gtk_text_view_scroll_to_iter(edi->view,&pos,0.2,FALSE,0,0);
        }
    }
    return FALSE;
}

void editor_scroll_to_cursor(struct MyGtkEditor *edi)
{
    GtkTextMark *mark=gtk_text_buffer_get_insert(edi->buf);
	gtk_text_view_scroll_to_mark(edi->view,mark,0.2,FALSE,0,0);
}

char *get_current_path(void)
{
	char *fpath;
	struct MyGtkEditor *edi;
	if (get_current_editor() < 0) return NULL;
	edi=current_editor;
	if (edi->owneditor) {
		edi=edi->owneditor;
	}
	if (edi->save_name[0]) fpath=edi->save_name;
	else if (edi->load_name[0]) fpath=edi->load_name;
	else return NULL;
	return g_path_get_dirname(fpath);
}
