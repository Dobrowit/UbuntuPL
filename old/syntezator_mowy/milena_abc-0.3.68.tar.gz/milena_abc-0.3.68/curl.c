/*
 * curl.c - Milena Audiobook Creator
 * Copyright (C) Bohdan R. Rau 2010 <ethanak@polip.com>
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write see:
 *               <http://www.gnu.org/licenses/>.
 */


#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <curl/curl.h>
#include <glib.h>


static int curl_error=1;

void initialize_curl(void)
{
	curl_error=curl_global_init(0);
}

static char *curl_data;
static int curl_len;


size_t curl_write(void *ptr,size_t size, size_t nmemb, void *userdata)
{
	size_t len=size * nmemb;
	if (!len) return 0;
	if (!curl_data) {
		curl_data=g_malloc(len+1);
		curl_len=0;
	}
	else curl_data=g_realloc(curl_data,curl_len+len+1);
	memcpy(curl_data+curl_len,ptr,len);
	curl_len+=len;
	return len;
}

int curl_fetch_file(char *url,void **data,int *len)
{
	CURL *curl;
	int rc=-1;

	if (curl_error) return -1;
	curl=curl_easy_init();
	curl_data=NULL;
	curl_len=0;
	curl_easy_setopt(curl,CURLOPT_NOSIGNAL,1);
	curl_easy_setopt(curl,CURLOPT_TIMEOUT,10);
	curl_easy_setopt(curl,CURLOPT_FOLLOWLOCATION,1);
	curl_easy_setopt(curl,CURLOPT_MAXREDIRS,5);
	curl_easy_setopt(curl,CURLOPT_WRITEFUNCTION,curl_write);
	curl_easy_setopt(curl,CURLOPT_WRITEDATA,NULL);
	curl_easy_setopt(curl,CURLOPT_URL,url);
	curl_easy_setopt(curl,CURLOPT_USERAGENT,"Mozilla/5.0 (compatible; Milena AudioBook Creator "PACKAGE_VERSION")");
	rc=curl_easy_perform(curl);
	if (!rc) {
		long rcode=0;
		curl_easy_getinfo(curl,CURLINFO_RESPONSE_CODE,&rcode);
		if (rcode != 200) {
			if (!rcode) rc=-1;
			else rc=rcode;
		}
	}
	if (rc) {
		if (curl_data) g_free(curl_data);
		curl_data=NULL;
		curl_len=0;
	}
	curl_easy_cleanup(curl);
	*data=curl_data;
	*len=curl_len;
	data[curl_len]=0;
	curl_data=NULL;
	return rc;
}
