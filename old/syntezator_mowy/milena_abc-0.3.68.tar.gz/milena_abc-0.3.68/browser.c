
#include "config.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "gmilena.h"
#include <webkit/webkit.h>
#include <ctype.h>
#include <glib.h>
#include <libsoup/soup.h>

static GtkWidget* createWindow(WebKitWebView** outWebView);
static GMutex *webMutex;

static struct WKBrowser {
    struct WKBrowser *next;
    GtkWidget *webWindow;
    WebKitWebView *webView;
} *Browsers;

static struct WKBrowser *browser_get(int is_new)
{
    struct WKBrowser *wb=NULL;
    g_mutex_lock(webMutex);
    if (!Browsers) is_new=1;
    if (!is_new) {
        wb=Browsers;
    }
    else {
        wb=g_malloc(sizeof(*wb));
        wb->next=Browsers;
        Browsers=wb;
    }
    if (is_new) wb->webWindow=createWindow(&wb->webView);
    g_mutex_unlock(webMutex);
    return wb;
}


static WebKitWebView*
createWebViewCb(WebKitWebView* webView, WebKitWebFrame* web_frame, GtkWidget* window)
{
    struct WKBrowser *wb;
    wb=browser_get(1);
    return wb->webView;
}

static int destroyCb(GtkWidget* widget, GtkWidget* window)
{
    struct WKBrowser **wbb,*wb;
    gboolean rc=TRUE;
    g_mutex_lock(webMutex);
    for (wbb=&Browsers;*wbb;wbb=&(*wbb)->next) {
        if ((*wbb)->webWindow == widget) {
            wb=*wbb;
            *wbb=wb->next;
            g_free(wb);
            rc=FALSE;
            break;
        }
    }
    g_mutex_unlock(webMutex);
    if (rc) fprintf(stderr,"Window %p not found\n",widget);
    return rc;
}

static void homeCb(GtkWidget* entry,   WebKitWebView* webView)
{
    webkit_web_view_load_uri(webView, "http://milena.polip.com");
}

static struct downManager {
    struct downManager *next;
    GtkWidget *frame;
    GtkWidget *progress;
    WebKitDownload *download;
    int finished;
} *downManagers;

static struct downManager *getDownManager(WebKitDownload *download)
{
    struct downManager *dm;
    GtkWidget *hbox;
    dm=g_malloc(sizeof(*dm));
    dm->finished=0;
    dm->download=download;
    dm->frame=gtk_frame_new(webkit_download_get_suggested_filename(download));
    hbox=gtk_hbox_new(FALSE,3);
    gtk_container_add((gpointer)(dm->frame),(gpointer)hbox);
    dm->progress=(GtkWidget *)gtk_progress_bar_new();
    gtk_box_pack_start((gpointer)hbox,(gpointer)dm->progress,FALSE,FALSE,2);
    gtk_widget_set_size_request((gpointer)dm->progress, 320,-1);

    dm->next=downManagers;
    downManagers=dm;
    return dm;
}
#if 0
static struct downManager *findDownManager(gpointer download)
{
    struct downManager *dm;
    g_mutex_lock(webMutex);
    for (dm=downManagers;dm;dm=dm->next) if (dm->download == download) break;
    g_mutex_unlock(webMutex);
    return dm;
}
#endif
static void destroyDownManager(struct downManager *dm)
{
    struct downManager **dmm;
    g_mutex_lock(webMutex);
    for (dmm=&downManagers;*dmm;dmm=&(*dmm)->next) {
        if (*dmm == dm) break;
    }
    if (*dmm) *dmm=dm->next;
    else dm=NULL;
    g_mutex_unlock(webMutex);
    if (dm) {
        gtk_widget_destroy(dm->frame);
        g_free(dm);
    }
}

static void destroyDownManagerD(struct downManager *dm)
{
	int destroyDM(void *data)
	{
		destroyDownManager(data);
		return FALSE;
	}
	g_timeout_add(2000,destroyDM,dm);
}

static GtkWidget *downloadWindow;
static GtkWidget *downloadVBox;

static gboolean closeDNW(void)
{
    gtk_widget_hide_all(downloadWindow);
    return TRUE;
}

static void downWindowCreate(void)
{
    if (downloadWindow) return;
    downloadWindow = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    gtk_window_set_default_size(GTK_WINDOW(downloadWindow), 340, 200);
    GtkWidget *vbox = gtk_vbox_new(FALSE, 0);
    downloadVBox=gtk_vbox_new(FALSE, 0);
    GtkWidget *scrolledWindow = gtk_scrolled_window_new(NULL, NULL);
    gtk_scrolled_window_set_policy(GTK_SCROLLED_WINDOW(scrolledWindow), GTK_POLICY_AUTOMATIC, GTK_POLICY_AUTOMATIC);
    gtk_scrolled_window_add_with_viewport(GTK_SCROLLED_WINDOW(scrolledWindow), GTK_WIDGET(downloadVBox));
    gtk_box_pack_start(GTK_BOX(vbox), scrolledWindow, TRUE, TRUE, 0);
    gtk_container_add(GTK_CONTAINER(downloadWindow), vbox);
    gtk_window_set_title((gpointer) downloadWindow, "Milena - Pobieranie plików");
    g_signal_connect(downloadWindow, "delete-event", G_CALLBACK(closeDNW), NULL);

}
static struct downManager *downloadGetPG(gpointer download)
{
    g_mutex_lock(webMutex);
    downWindowCreate();
    struct downManager *dm=getDownManager(download);
    gtk_box_pack_start((gpointer)downloadVBox,dm->frame,FALSE,FALSE,2);
    gtk_widget_show_all(downloadWindow);
    g_mutex_unlock(webMutex);
    gtk_window_present(GTK_WINDOW(downloadWindow));
    return dm;
}

static void updateDownload(WebKitDownload *download, GParamSpec *pspec, struct downManager *p)
{
    struct downManager *dm;
    int to_destroy=0;
    g_mutex_lock(webMutex);
    for (dm=downManagers;dm;dm=dm->next) {
		if (dm->finished) continue;
        int status=webkit_download_get_status(dm->download);
        const gchar *name=webkit_download_get_suggested_filename(dm->download);
        if (status != WEBKIT_DOWNLOAD_STATUS_CREATED &&
            status != WEBKIT_DOWNLOAD_STATUS_STARTED) {
                if (dm == p) {
					dm->finished=1;
					char *c=g_strdup_printf("Zakończono %s\n",name);
					gtk_progress_bar_set_fraction((gpointer)dm->progress,1.0);
					gtk_progress_bar_set_text((gpointer)dm->progress,c);
					g_free(c);
					to_destroy=1;
					}
            continue;
        }
        double rr=webkit_download_get_progress(dm->download);
        int r=(int)(100.0 * rr);
        char *c=g_strdup_printf("%3d %% %s\n",r,name);
        gtk_progress_bar_set_fraction((gpointer)dm->progress,rr);
        gtk_progress_bar_set_text((gpointer)dm->progress,c);
        g_free(c);
    }
    g_mutex_unlock(webMutex);
    if (to_destroy) destroyDownManagerD(p);
}

static gboolean downloadCb(WebKitWebView* webView,gpointer download, GtkWidget *window)
{


    char *c=(char *)webkit_download_get_suggested_filename(download);
    char *path=get_current_path();
	int n;
	GtkWidget *dialog=gtk_file_chooser_dialog_new(
		"Wybierz plik",
		GTK_WINDOW(window),GTK_FILE_CHOOSER_ACTION_SAVE,
		GTK_STOCK_CANCEL, GTK_RESPONSE_CANCEL,
		GTK_STOCK_SAVE, GTK_RESPONSE_ACCEPT,
		NULL);
	gtk_file_chooser_set_local_only((gpointer)dialog,TRUE);
	if (path) {
		gtk_file_chooser_set_current_folder((gpointer)dialog,path);
		g_free(path);
	}
	if (c) gtk_file_chooser_set_current_name((gpointer)dialog,c);
	gtk_file_chooser_set_do_overwrite_confirmation((gpointer)dialog,TRUE);
#if GTK_CHECK_VERSION(2,18,0)
	gtk_file_chooser_set_create_folders((gpointer)dialog,TRUE);
#endif
	n=gtk_dialog_run((gpointer)dialog);
    if (n==GTK_RESPONSE_ACCEPT) {
        c=gtk_file_chooser_get_filename((gpointer)dialog);
        //c=g_strconcat("file://",c,NULL);
        c=g_filename_to_uri(c,NULL,NULL);
	webkit_download_set_destination_uri(download,c);
        g_free(c);
	}
	gtk_widget_destroy(dialog);
    if (n != GTK_RESPONSE_ACCEPT) return FALSE;
    struct downManager *dm=downloadGetPG(download);
    g_signal_connect(download, "notify::progress", G_CALLBACK(updateDownload), dm);
    g_signal_connect(download, "notify::status", G_CALLBACK(updateDownload), dm);
    //webkit_download_start(download);
    return n==GTK_RESPONSE_ACCEPT;
}

const gchar *realUri(const gchar *uri)
{
    const gchar *c;
    if (!uri || !*uri) return g_strdup("about:blank");
    for (c=uri;*c;c++) {
        if (*c==':') return NULL;
        if (!isalpha(*c)) break;
    }
    return g_strconcat("http://",uri,NULL);
}

static void activateUriEntryCb(GtkWidget* entry, gpointer data)
{
    WebKitWebView *webView = g_object_get_data(G_OBJECT(entry), "web-view");
    const gchar* uri = gtk_entry_get_text(GTK_ENTRY(entry));
    const gchar *u2=realUri(uri);
    webkit_web_view_load_uri(webView,u2?u2:uri);
    if (u2) g_free((gpointer)u2);
}

static void updateTitle(GtkWindow* window, WebKitWebView* webView)
{
    GString *string;
    char *c=(char *)webkit_web_view_get_title(webView);
    if (c) {
        if (strncasecmp(c,"Milena - ",9)) {
            string = g_string_new("Milena - ");
            g_string_append(string,c);
        }
        else {
            string = g_string_new(c);
        }
    }
    else {
        string = g_string_new("Milena Web Browser");
    }
    gint loadProgress = webkit_web_view_get_progress(webView) * 100;
    if (loadProgress < 100)
        g_string_append_printf(string, " (%d%%)", loadProgress);
    gchar *title = g_string_free(string, FALSE);
    gtk_window_set_title(window, title);
    g_free(title);
}

static void linkHoverCb(WebKitWebView* page, const gchar* title, const gchar* link, GtkStatusbar* statusbar)
{
    guint statusContextId =
      GPOINTER_TO_UINT(g_object_get_data(G_OBJECT(statusbar), "link-hover-context"));
    /* underflow is allowed */
    gtk_statusbar_pop(statusbar, statusContextId);
    if (link)
        gtk_statusbar_push(statusbar, statusContextId, link);
}

static void notifyTitleCb(WebKitWebView* webView, GParamSpec* pspec, GtkWidget* window)
{
    updateTitle(GTK_WINDOW(window), webView);
}

static void notifyLoadStatusCb(WebKitWebView* webView, GParamSpec* pspec, GtkWidget* uriEntry)
{
    if (webkit_web_view_get_load_status(webView) == WEBKIT_LOAD_COMMITTED) {
        WebKitWebFrame *frame = webkit_web_view_get_main_frame(webView);
        const gchar *uri = webkit_web_frame_get_uri(frame);
        if (uri)
            gtk_entry_set_text(GTK_ENTRY(uriEntry), uri);
    }
}

static void notifyProgressCb(WebKitWebView* webView, GParamSpec* pspec, GtkWidget* window)
{
    updateTitle(GTK_WINDOW(window), webView);
}


static void goBackCb(GtkWidget* widget,  WebKitWebView* webView)
{
    webkit_web_view_go_back(webView);
}

static void goForwardCb(GtkWidget* widget, WebKitWebView* webView)
{
    webkit_web_view_go_forward(webView);
}


static gboolean webViewReadyCb(WebKitWebView* webView, GtkWidget* window)
{
    gtk_widget_grab_focus(GTK_WIDGET(webView));
    gtk_widget_show_all(window);
    return FALSE;
}

static gboolean closeWebViewCb(WebKitWebView* webView, GtkWidget* window)
{
    gtk_widget_destroy(window);
    return TRUE;
}

static gboolean decideDownload(WebKitWebView *v,
    WebKitWebFrame *f,
    WebKitNetworkRequest *r,
    gchar *m,
    WebKitWebPolicyDecision *p,
    gpointer dummy)
{
    if(!webkit_web_view_can_show_mime_type(v, m)) {
        webkit_web_policy_decision_download(p);
        return TRUE;
    }
    return FALSE;
}


static GtkWidget* createBrowser(GtkWidget* window, GtkWidget* uriEntry, GtkWidget* statusbar, WebKitWebView* webView)
{
    WebKitWebSettings *settings;
    static char *useragent;
    GtkWidget *scrolledWindow = gtk_scrolled_window_new(NULL, NULL);
    gtk_scrolled_window_set_policy(GTK_SCROLLED_WINDOW(scrolledWindow), GTK_POLICY_AUTOMATIC, GTK_POLICY_AUTOMATIC);

    gtk_container_add(GTK_CONTAINER(scrolledWindow), GTK_WIDGET(webView));

    g_signal_connect(webView, "notify::title", G_CALLBACK(notifyTitleCb), window);
    g_signal_connect(webView, "notify::load-status", G_CALLBACK(notifyLoadStatusCb), uriEntry);
    g_signal_connect(webView, "notify::progress", G_CALLBACK(notifyProgressCb), window);
    g_signal_connect(webView, "hovering-over-link", G_CALLBACK(linkHoverCb), statusbar);
    g_signal_connect(webView, "create-web-view", G_CALLBACK(createWebViewCb), window);
    g_signal_connect(webView, "web-view-ready", G_CALLBACK(webViewReadyCb), window);
    g_signal_connect(webView, "close-web-view", G_CALLBACK(closeWebViewCb), window);
    g_signal_connect(webView, "download-requested", G_CALLBACK(downloadCb), window);
    g_signal_connect(webView, "mime-type-policy-decision-requested", G_CALLBACK(decideDownload), window);
    settings = webkit_web_view_get_settings(webView);
    if (!useragent) {
        char buf[256];
        FILE *f=popen("uname -s -m","r");
        ignore((int)fgets(buf,256,f));
        pclose(f);
        useragent=g_strdup_printf("Mozilla/5.0 (X11; U; %s; pl-pl) AppleWebKit/%d.%d (KHTML, like Gecko) Milena_ABC/%s",
            trim(buf),
            WEBKIT_USER_AGENT_MAJOR_VERSION,
            WEBKIT_USER_AGENT_MINOR_VERSION,
            PACKAGE_VERSION);
    }
    g_object_set(G_OBJECT(settings), "user-agent", useragent, NULL);
    g_object_set(G_OBJECT(settings), "enable-caret-browsing",TRUE,NULL);


    return scrolledWindow;
}

static GtkWidget* createStatusbar()
{
    GtkStatusbar *statusbar = GTK_STATUSBAR(gtk_statusbar_new());
    guint statusContextId = gtk_statusbar_get_context_id(statusbar, "Link Hover");
    g_object_set_data(G_OBJECT(statusbar), "link-hover-context",
        GUINT_TO_POINTER(statusContextId));

    return GTK_WIDGET(statusbar);
}

static GtkWidget* createToolbar(GtkWidget* uriEntry, WebKitWebView* webView)
{
    GtkWidget *toolbar = gtk_toolbar_new();

#if GTK_CHECK_VERSION(2, 15, 0)
    gtk_orientable_set_orientation(GTK_ORIENTABLE(toolbar), GTK_ORIENTATION_HORIZONTAL);
#else
    gtk_toolbar_set_orientation(GTK_TOOLBAR(toolbar), GTK_ORIENTATION_HORIZONTAL);
#endif
    gtk_toolbar_set_style(GTK_TOOLBAR(toolbar), GTK_TOOLBAR_BOTH_HORIZ);

    GtkToolItem *item;

    /* the back button */
    item = gtk_tool_button_new_from_stock(GTK_STOCK_GO_BACK);
    g_signal_connect(G_OBJECT(item), "clicked", G_CALLBACK(goBackCb), webView);
    gtk_toolbar_insert(GTK_TOOLBAR(toolbar), item, -1);

    /* The forward button */
    item = gtk_tool_button_new_from_stock(GTK_STOCK_GO_FORWARD);
    g_signal_connect(G_OBJECT(item), "clicked", G_CALLBACK(goForwardCb), webView);
    gtk_toolbar_insert(GTK_TOOLBAR(toolbar), item, -1);

    item = gtk_tool_button_new_from_stock(GTK_STOCK_HOME);
    g_signal_connect(G_OBJECT(item), "clicked", G_CALLBACK(homeCb), webView);
    gtk_toolbar_insert(GTK_TOOLBAR(toolbar), item, -1);

    /* The URL entry */
    item = gtk_tool_item_new();
    gtk_tool_item_set_expand(item, TRUE);
    gtk_container_add(GTK_CONTAINER(item), uriEntry);
    g_signal_connect(G_OBJECT(uriEntry), "activate", G_CALLBACK(activateUriEntryCb), NULL);
    gtk_toolbar_insert(GTK_TOOLBAR(toolbar), item, -1);

    /* The go button */
    g_object_set_data(G_OBJECT(uriEntry), "web-view", webView);
    item = gtk_tool_button_new_from_stock(GTK_STOCK_OK);
    g_signal_connect_swapped(G_OBJECT(item), "clicked", G_CALLBACK(activateUriEntryCb), (gpointer)uriEntry);
    gtk_toolbar_insert(GTK_TOOLBAR(toolbar), item, -1);

    return toolbar;
}

static GtkWidget* createWindow(WebKitWebView** outWebView)
{
    WebKitWebView *webView;
    GtkWidget *vbox;
    GtkWidget *window;
    GtkWidget *uriEntry;
    GtkWidget *statusbar;


    window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    gtk_window_set_default_size(GTK_WINDOW(window), 800, 600);
    //gtk_widget_set_name(window, "GtkLauncher");

    webView = WEBKIT_WEB_VIEW(webkit_web_view_new());
    uriEntry = gtk_entry_new();

    vbox = gtk_vbox_new(FALSE, 0);
    statusbar = createStatusbar(webView);
    gtk_box_pack_start(GTK_BOX(vbox), createToolbar(uriEntry, webView), FALSE, FALSE, 0);
    gtk_box_pack_start(GTK_BOX(vbox), createBrowser(window, uriEntry, statusbar, webView), TRUE, TRUE, 0);
    gtk_box_pack_start(GTK_BOX(vbox), statusbar, FALSE, FALSE, 0);

    gtk_container_add(GTK_CONTAINER(window), vbox);

    g_signal_connect(window, "delete-event", G_CALLBACK(destroyCb), NULL);

    if (outWebView)
        *outWebView = webView;
    return window;
}


static void init_webkit(void)
{
	static int webkit_initialized=0;
	static char *cookiename;
	if (webkit_initialized) return;
	cookiename=g_build_filename(getenv("HOME"),".milena_abc_cookies.jar",NULL);
	soup_session_add_feature(
		webkit_get_default_session(),
		(void *)soup_cookie_jar_text_new(cookiename,FALSE));
}


void browser(char *uri)
{

    struct WKBrowser *wb;
    if (!webMutex) webMutex=g_mutex_new();
    init_webkit();
    wb=browser_get(0);
    if (uri && *uri) {
        const gchar *u2=realUri(uri);
        webkit_web_view_load_uri(wb->webView,u2?u2:uri);
        if (u2) g_free((gpointer)u2);
    }
    gtk_widget_grab_focus(GTK_WIDGET(wb->webView));
    gtk_widget_show_all(wb->webWindow);
    gtk_window_present(GTK_WINDOW(wb->webWindow));
}
