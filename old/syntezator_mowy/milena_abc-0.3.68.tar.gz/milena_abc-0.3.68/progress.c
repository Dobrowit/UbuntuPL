/*
 * progress.c - Milena Audiobook Creator
 * Copyright (C) Bohdan R. Rau 2009 <ethanak@polip.com>
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write see:
 *               <http://www.gnu.org/licenses/>.
 */
#include "config.h"
#include "gmilena.h"
#include <sys/time.h>

gint64 tvprec;

static GtkWidget *progressmeter,*progressbar,*e_time,*a_time,*r_time,*progresslabel;
int allow_run;
static int this_count;
static int this_file;
static int this_percent;

static struct timeval initial_tv;
int lost_milisec;
int elapsed_time,all_time,remaining_time,last_shown_sec;

void init_cajmer()
{
	gettimeofday(&initial_tv,NULL);	
	lost_milisec=0;
	elapsed_time=0;
	remaining_time=-1;
	all_time=-1;
	last_shown_sec=-100;
}

static void compute_times(double pc)
{
	struct timeval this_tv;
	int seconds,micros,milis;
	gettimeofday(&this_tv,NULL);
	seconds=this_tv.tv_sec-initial_tv.tv_sec;
	micros=this_tv.tv_usec-initial_tv.tv_usec;
	while (micros < 0) {
		micros+=1000000;
		seconds--;
	}
	milis=seconds * 1000 + micros / 1000 - lost_milisec;
	elapsed_time=milis;
	if (pc < 0.001) {
		all_time=-1;
		remaining_time=-1;
		return;
	}
	all_time=(double)milis / pc;
	remaining_time=all_time-elapsed_time;
}


static int rt(void)
{
	return TRUE;
}


static void progress_break(GtkWidget *w,gint id,gpointer udata)
{
	if (id != 100) return;
	struct timeval t1,t2;int sec,usec;
	gettimeofday(&t1,NULL);
	if (Ask("Pytanie","Przerywasz konwersję?")) allow_run=0;
	gettimeofday(&t2,NULL);
	sec=t2.tv_sec-t1.tv_sec;
	usec=t2.tv_usec-t1.tv_usec;
	if (usec < 0) {
		sec--;
		usec+=1000000;
	}
	lost_milisec+=sec*1000 + usec/1000;
	return;
}

void CreateProgressMeter()
{
	progressmeter=gtk_dialog_new_with_buttons(
		"Proces",
		(gpointer)main_window,
		GTK_DIALOG_MODAL,
		"Przerwij",100,
		NULL);
	g_signal_connect_swapped(G_OBJECT(progressmeter), "delete-event",
	      G_CALLBACK(rt), NULL);
	g_signal_connect_swapped(G_OBJECT(progressmeter), "response",
	      G_CALLBACK(progress_break), NULL);
	GtkWidget *box=gtk_dialog_get_content_area((gpointer)progressmeter);
	GtkWidget *vbox=gtk_vbox_new(0,2);
	gtk_box_pack_start(GTK_BOX(box),(gpointer)vbox,FALSE,FALSE,0);
	progresslabel=gtk_label_new("");
	gtk_label_set_selectable((gpointer)progresslabel,TRUE);
	gtk_box_pack_start(GTK_BOX(vbox),(gpointer)progresslabel,FALSE,FALSE,0);
	progressbar=gtk_progress_bar_new();
    init_progressbar((gpointer)progressbar);
	gtk_box_pack_start(GTK_BOX(vbox),(gpointer)progressbar,FALSE,FALSE,0);
	GtkWidget *stable=gtk_table_new(2,3,0);
	gtk_box_pack_start(GTK_BOX(vbox),stable,FALSE,FALSE,0);
	GtkWidget *label=gtk_label_new("Czas przetwarzania");
	gtk_table_attach_defaults((gpointer)stable,label,0,1,0,1);
	e_time=gtk_label_new("-");
	gtk_table_attach_defaults((gpointer)stable,e_time,1,2,0,1);
	gtk_label_set_selectable((gpointer)e_time,TRUE);
	connect_label(label,e_time);
	label=gtk_label_new("Czas całkowity");
	gtk_table_attach_defaults((gpointer)stable,label,0,1,1,2);
	a_time=gtk_label_new("-");
	gtk_table_attach_defaults((gpointer)stable,a_time,1,2,1,2);
	gtk_label_set_selectable((gpointer)a_time,TRUE);
	connect_label(label,a_time);
	label=gtk_label_new("Czas pozostały");
	gtk_table_attach_defaults((gpointer)stable,label,0,1,2,3);
	r_time=gtk_label_new("-");
	gtk_label_set_selectable((gpointer)r_time,TRUE);
	connect_label(label,r_time);
	gtk_table_attach_defaults((gpointer)stable,r_time,1,2,2,3);
	gtk_widget_set_size_request((gpointer)progressbar, 320,-1);
	
	
	gtk_widget_show_all(box);
	
	tvprec=g_get_real_time();
	
}

static void sh_time(GtkWidget *w,int milisec)
{
	int sec=milisec/1000;
	int m,h;
	char buf[32];
	h=sec/3600;
	sec=sec%3600;
	m=sec/60;
	sec=sec%60;
	if (h) {
		sprintf(buf,"%d:%02d:%02d",h,m,sec);
	}
	else {
		sprintf(buf,"%d:%02d",m,sec);
	}
	gtk_label_set_text((gpointer)w,buf);
}

void SetProgress(int file,double pc)
{
	char buf[256];
	int percent=pc*100;
	if (file == this_file && !g_timer_can_step(&tvprec,5000)) return;
	compute_times(pc);
	if (last_shown_sec < elapsed_time/1000) {
		//last_shown_sec=elapsed_time/1000;
		sh_time(e_time,elapsed_time);
		sh_time(a_time,all_time);
		sh_time(r_time,remaining_time);
	}
	if (file == this_file && percent == this_percent) return;
	this_file=file;
	this_percent=percent;
	sprintf(buf,"Plik %d z %d, %d%%",this_file,this_count?this_count:1,this_percent);
	//gtk_progress_bar_set_text((gpointer)progressbar,buf);
	gtk_label_set_text((gpointer)progresslabel,buf);
	gtk_progress_bar_set_fraction((gpointer)progressbar,percent/100.0);
}

void StartProgressMeter(int count)
{
	if (!progressmeter) CreateProgressMeter();
	this_count=count;
	this_file=0;
	this_percent=-1;
	init_cajmer();
	SetProgress(1,0.0);
	gtk_widget_show_all((gpointer)progressmeter);
	
}

void StopProgressMeter(void)
{
	gtk_widget_hide((gpointer)progressmeter);
}


void init_progressbar(gpointer p)
{
#ifdef HAVE_GTK3
    gtk_orientable_set_orientation(p,GTK_ORIENTATION_HORIZONTAL);
    gtk_progress_bar_set_inverted(p,FALSE);
#else
    gtk_progress_bar_set_orientation(p,GTK_PROGRESS_LEFT_TO_RIGHT);
    gtk_progress_bar_set_bar_style(p,GTK_PROGRESS_CONTINUOUS);
#endif
}

